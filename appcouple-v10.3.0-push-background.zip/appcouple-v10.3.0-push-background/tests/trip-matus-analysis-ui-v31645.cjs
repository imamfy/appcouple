const { chromium } = require("playwright");
const assert = require("node:assert/strict");

(async () => {
  const browser = await chromium.launch({
    headless: true,
    executablePath: process.env.CHROMIUM_PATH || "/usr/local/bin/chromium",
    args: ["--no-sandbox"],
  });
  const page = await browser.newPage({
    viewport: { width: 390, height: 844 },
    timezoneId: "Asia/Jakarta",
  });
  const errors = [];
  page.on("pageerror", (error) => errors.push(error.message));

  await page.goto("http://127.0.0.1:4194/?trip-matus=31645");
  await page.evaluate(() => localStorage.clear());
  await page.reload();
  await page.click("#demo-login");
  await page.waitForFunction(() => window.__appCoupleOpenFeature);
  await page.locator('[data-view="couple"]:visible').first().click();
  await page.evaluate(() => window.__appCoupleOpenFeature("trip"));
  await page.waitForSelector("#couple-trip-feature:not(.hidden)");

  await page.fill("#trip-origin", "Bogor");
  await page.fill("#trip-destination", "Yogyakarta");
  await page.fill("#trip-days", "2");
  await page.click('[data-trip-tab="matus"]');
  await page.click('[data-trip-matus-action="itinerary"]');

  await page.waitForSelector("#trip-route-analysis header");
  const text = await page.locator("#trip-route-analysis").innerText();
  assert.match(text, /ANALISIS MATUS · HARI 1/);
  assert.match(text, /Rute berhasil\s*1\/1/);
  assert.equal(
    await page.locator('[data-trip-tab="daily"]').getAttribute("aria-selected"),
    "true",
  );
  assert.deepEqual(errors, []);

  await browser.close();
  console.log(
    "PASS Matus Susun itinerary builds, switches tab, and analyzes the selected day",
  );
})().catch((error) => {
  console.error(error);
  process.exit(1);
});