const { chromium } = require("playwright");
const assert = require("node:assert/strict");

(async () => {
  const browser = await chromium.launch({
    headless: true,
    executablePath: process.env.CHROMIUM_PATH || "/usr/local/bin/chromium",
    args: ["--no-sandbox"],
  });
  const page = await browser.newPage({
    viewport: { width: 390, height: 844 },
    timezoneId: "Asia/Jakarta",
  });
  const errors = [];
  page.on("pageerror", (error) => errors.push(error.message));

  await page.goto("http://127.0.0.1:4194/?matus-trip=31646");
  await page.evaluate(() => localStorage.clear());
  await page.reload();
  await page.click("#demo-login");
  await page.waitForFunction(() => window.__appCoupleOpenFeature);
  await page.locator('[data-view="couple"]:visible').first().click();
  await page.evaluate(() => window.__appCoupleOpenFeature("trip"));
  await page.waitForSelector("#couple-trip-feature:not(.hidden)");

  await page.fill("#trip-origin", "Bogor");
  await page.fill("#trip-destination", "Yogyakarta");
  await page.fill("#trip-days", "2");
  await page.click('[data-trip-tab="matus"]');
  await page.click('[data-trip-matus-action="itinerary"]');
  await page.waitForFunction(
    () =>
      window.__appCoupleTripContext?.itinerary?.length === 2 &&
      window.__appCoupleTripContext?.routeInsights?.length >= 1,
  );

  const result = await page.evaluate(async () => {
    const core = await import("/src/matus-core.js?v=31646");
    const context = core.buildMatusContext();
    const activityToggle = document.querySelector(
      '[data-matus-perm="activity"]',
    );
    if (activityToggle) activityToggle.checked = false;
    const privateContext = core.buildMatusContext();
    if (activityToggle) activityToggle.checked = true;
    return {
      context,
      privateContext,
      prompt: core.buildMatusSystemPrompt({ allowResearch: false }),
      localReply: window.__appCoupleMatusLocalReply?.(
        "Bagaimana itinerary Jalan Berdua saya?",
      ),
    };
  });

  assert.equal(result.context.trip.plan.destination, "Yogyakarta");
  assert.equal(result.context.trip.itinerary.length, 2);
  assert(result.context.trip.routeInsights.length >= 1);
  assert.equal(result.privateContext.trip, undefined);
  assert.match(result.prompt, /JALAN BERDUA:/);
  assert.match(result.prompt, /"destination":"Yogyakarta"/);
  assert.match(result.localReply, /Yogyakarta/);
  assert.match(result.localReply, /2 agenda/);
  assert.deepEqual(errors, []);

  await browser.close();
  console.log(
    "PASS itinerary plan, agendas, route analysis, and warnings reach Matus AI and local mode",
  );
})().catch((error) => {
  console.error(error);
  process.exit(1);
});