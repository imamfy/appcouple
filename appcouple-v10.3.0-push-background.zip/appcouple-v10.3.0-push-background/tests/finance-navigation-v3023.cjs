const { chromium } = require('playwright');
const assert = require('assert');
const fs = require('fs');
const path = require('path');

(async () => {
  const browser = await chromium.launch({
    headless: true,
    executablePath: process.env.CHROMIUM_PATH || '/usr/local/bin/chromium',
    args: ['--no-sandbox'],
  });
  const checks = [];
  for (const width of [320, 390, 768]) {
    const page = await browser.newPage({ viewport: { width, height: 900 }, reducedMotion: 'reduce' });
    const errors = [];
    page.on('pageerror', error => errors.push(error.message));
    await page.goto('http://127.0.0.1:4194/');
    await page.click('#demo-login');
    await page.waitForFunction(() => !document.querySelector('#love-loader')?.classList.contains('is-visible'));
    await page.locator('[data-view="finance"]:visible').first().click();
    await page.evaluate(() => window.scrollTo(0, 0));

    const layout = await page.evaluate(() => {
      const nav = document.querySelector('#view-finance .fin3-launcher');
      return {
        display: getComputedStyle(nav).display,
        overflowX: getComputedStyle(nav).overflowX,
        clientWidth: nav.clientWidth,
        scrollWidth: nav.scrollWidth,
        buttons: [...nav.querySelectorAll('button')].map(button => {
          const rect = button.getBoundingClientRect();
          const top = document.elementFromPoint(rect.left + rect.width / 2, rect.top + rect.height / 2);
          return {
            label: button.innerText.replace(/\n/g, ' ').trim(),
            insideViewport: rect.left >= 0 && rect.right <= innerWidth,
            ownsCenter: button === top || button.contains(top),
            width: rect.width,
            height: rect.height,
          };
        }),
      };
    });
    assert.equal(layout.display, 'grid');
    assert(layout.scrollWidth <= layout.clientWidth + 2, JSON.stringify(layout));
    assert.equal(layout.buttons.length, 7);
    assert(layout.buttons.every(button => button.insideViewport && button.ownsCenter && button.width >= 44 && button.height >= 44), JSON.stringify(layout));

    for (const button of await page.locator('#view-finance .fin3-launcher button').all()) {
      await button.click();
    }
    assert.equal(await page.locator('#financial-report-page').isVisible(), true);
    await page.click('#fr-close');
    await page.locator('[data-finance-tab="newtx"]').click();
    await page.locator('[data-action="expense"]').click();
    await page.locator('#transaction-modal .modal-actions').scrollIntoViewIfNeeded();
    const saveClickable = await page.evaluate(() => {
      const button = document.querySelector('#transaction-modal .modal-actions .btn-primary');
      const rect = button.getBoundingClientRect();
      const top = document.elementFromPoint(rect.left + rect.width / 2, rect.top + rect.height / 2);
      return button === top || button.contains(top);
    });
    assert.equal(saveClickable, true);
    assert.deepEqual(errors, []);
    if (width === 390) await page.screenshot({ path: path.join(__dirname, '../qa/finance-navigation-390-v3023.png') });
    checks.push({ width, layout, reportOpened: true, transactionSaveClickable: true });
    await page.close();
  }
  await browser.close();
  fs.writeFileSync(path.join(__dirname, '../qa/finance-navigation-v3023.json'), JSON.stringify({ checks }, null, 2));
  console.log('PASS: all finance destinations and transaction actions are visible and clickable.');
})().catch(error => {
  console.error(error);
  process.exit(1);
});
