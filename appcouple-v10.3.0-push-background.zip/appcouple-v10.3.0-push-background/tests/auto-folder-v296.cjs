const assert=require('assert'),path=require('path');
const root=path.join(__dirname,'..');
(async()=>{
 const user='aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa';
 Object.assign(process.env,{SUPABASE_URL:'https://mock.example',SUPABASE_ANON_KEY:'fake',APPCOUPLE_ALLOWED_USER_IDS:user,GOOGLE_DRIVE_CLIENT_ID:'fake',GOOGLE_DRIVE_CLIENT_SECRET:'fake',GOOGLE_DRIVE_REFRESH_TOKEN:'fake'});
 delete process.env.GOOGLE_DRIVE_FOLDER_ID;delete process.env.GOOGLE_DRIVE_FOLDER_NAME;delete process.env.GOOGLE_DRIVE_SERVICE_ACCOUNT_JSON;
 let creates=0,searches=0,lists=0;
 global.fetch=async(url,opts={})=>{url=String(url);
  if(url.includes('/auth/v1/user'))return Response.json({id:user});
  if(url.includes('oauth2.googleapis.com'))return Response.json({access_token:'fake',expires_in:3600});
  const parsed=new URL(url),query=parsed.searchParams.get('q')||'';
  if(opts.method==='POST'&&parsed.pathname.endsWith('/files')){creates++;const body=JSON.parse(opts.body);assert.equal(body.name,'AppCouple Kenangan');assert.equal(body.mimeType,'application/vnd.google-apps.folder');assert.equal(body.appProperties.appcoupleGallery,'v1');return Response.json({id:'auto-folder-123',name:body.name,mimeType:body.mimeType,webViewLink:'https://drive.google.com/drive/folders/auto-folder-123'});}
  if(parsed.pathname.endsWith('/files')&&query.includes('appcoupleGallery')){searches++;return Response.json({files:[]});}
  if(parsed.pathname.endsWith('/files')&&query.includes("'auto-folder-123' in parents")){lists++;return Response.json({files:[]});}
  throw Error('Unexpected mocked endpoint '+url);
 };
 const api=require(root+'/netlify/functions/api.cjs'),event={httpMethod:'GET',path:'/api/v1/gallery/files',headers:{authorization:'Bearer fake'},queryStringParameters:{}};
 let result=await api.handler(event);assert.equal(result.statusCode,200,result.body);let body=JSON.parse(result.body);assert.equal(body.folder.id,'auto-folder-123');assert.equal(body.folder.name,'AppCouple Kenangan');assert.equal(creates,1);assert.equal(searches,1);assert.equal(lists,1);
 result=await api.handler(event);assert.equal(result.statusCode,200);assert.equal(creates,1,'folder must not be duplicated in warm instance');assert.equal(searches,1);assert.equal(lists,2);
 console.log(JSON.stringify({autoFolderCreated:true,folderName:body.folder.name,duplicatePrevented:true}));
})().catch(error=>{console.error(error);process.exit(1)});
