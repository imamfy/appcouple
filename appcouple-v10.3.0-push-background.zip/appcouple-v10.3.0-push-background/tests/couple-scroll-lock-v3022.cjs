const { chromium } = require('playwright');
const assert = require('assert');
const fs = require('fs');
const path = require('path');

(async () => {
  const browser = await chromium.launch({
    headless: true,
    executablePath: process.env.CHROMIUM_PATH || '/usr/local/bin/chromium',
    args: ['--no-sandbox'],
  });
  const page = await browser.newPage({ viewport: { width: 390, height: 844 }, reducedMotion: 'reduce' });
  const errors = [];
  page.on('pageerror', error => errors.push(error.message));
  await page.goto('http://127.0.0.1:4194/');
  await page.click('#demo-login');
  await page.waitForFunction(() => typeof window.__appCoupleOpenFeature === 'function' && !document.querySelector('#love-loader')?.classList.contains('is-visible'));
  await page.evaluate(() => window.scrollTo(0, 420));
  const originalScroll = await page.evaluate(() => window.scrollY);
  const features = ['activity', 'chat', 'game', 'map', 'rewards', 'savings', 'ai', 'sydas'];
  const checks = [];

  for (const feature of features) {
    await page.evaluate(feature => window.__appCoupleOpenFeature(feature), feature);
    await page.waitForFunction(feature => document.querySelector('#fs-overlay')?.dataset.activeFeature === feature, feature);
    const openState = await page.evaluate(() => {
      const html = document.documentElement;
      const body = document.body;
      const overlay = document.querySelector('#fs-overlay');
      const background = document.querySelector('.main');
      return {
        htmlLocked: html.classList.contains('couple-scroll-locked'),
        bodyLocked: body.classList.contains('couple-feature-open'),
        bodyPosition: getComputedStyle(body).position,
        bodyOverflow: getComputedStyle(body).overflow,
        htmlOverflow: getComputedStyle(html).overflow,
        overlayPosition: getComputedStyle(overlay).position,
        overlayVisible: !overlay.classList.contains('hidden'),
        backgroundPointerEvents: getComputedStyle(background).pointerEvents,
        sidebarPointerEvents: getComputedStyle(document.querySelector('.sidebar')).pointerEvents,
        overlayPointerEvents: getComputedStyle(overlay).pointerEvents,
        bodyTop: body.style.top,
      };
    });
    assert.equal(openState.htmlLocked, true, `${feature}: html unlocked`);
    assert.equal(openState.bodyLocked, true, `${feature}: body unlocked`);
    assert.equal(openState.bodyPosition, 'fixed', `${feature}: body is not fixed`);
    assert.equal(openState.bodyOverflow, 'hidden', `${feature}: body overflow`);
    assert.equal(openState.htmlOverflow, 'hidden', `${feature}: html overflow`);
    assert.equal(openState.overlayPosition, 'fixed', `${feature}: overlay not fixed`);
    assert.equal(openState.overlayVisible, true, `${feature}: overlay hidden`);
    assert.equal(openState.backgroundPointerEvents, 'auto', `${feature}: feature content blocked`);
    assert.equal(openState.sidebarPointerEvents, 'none', `${feature}: sidebar interactive`);
    assert.equal(openState.overlayPointerEvents, 'auto', `${feature}: overlay blocked`);

    await page.evaluate(() => window.__appCoupleCloseFeature());
    const closedState = await page.evaluate(() => ({
      htmlLocked: document.documentElement.classList.contains('couple-scroll-locked'),
      bodyLocked: document.body.classList.contains('couple-feature-open'),
      bodyPosition: document.body.style.position,
      overlayHidden: document.querySelector('#fs-overlay').classList.contains('hidden'),
      scrollY: window.scrollY,
    }));
    assert.equal(closedState.htmlLocked, false, `${feature}: html lock remained`);
    assert.equal(closedState.bodyLocked, false, `${feature}: body lock remained`);
    assert.equal(closedState.bodyPosition, '', `${feature}: fixed body remained`);
    assert.equal(closedState.overlayHidden, true, `${feature}: overlay remained`);
    assert.equal(closedState.scrollY, originalScroll, `${feature}: scroll position not restored`);
    checks.push({ feature, openState, closedState });
  }

  await page.evaluate(() => window.__appCoupleOpenFeature('activity'));
  await page.screenshot({ path: path.join(__dirname, '../qa/couple-scroll-lock-390-v3022.png') });
  assert.deepEqual(errors, []);
  await browser.close();
  fs.writeFileSync(path.join(__dirname, '../qa/couple-scroll-lock-v3022.json'), JSON.stringify({ originalScroll, checks }, null, 2));
  console.log('PASS: all Couple Space features lock background scrolling and restore the page position.');
})().catch(error => {
  console.error(error);
  process.exit(1);
});
