const { chromium } = require("playwright");
const assert = require("node:assert/strict");

(async () => {
  const browser = await chromium.launch({
    headless: true,
    executablePath: process.env.CHROMIUM_PATH || "/usr/bin/chromium",
    args: ["--no-sandbox"],
  });
  const page = await browser.newPage();
  const geocodeQueries = [];

  await page.route("https://nominatim.openstreetmap.org/**", async (route) => {
    const query = new URL(route.request().url()).searchParams.get("q");
    geocodeQueries.push(query);
    const points = {
      Bogor: { lat: "-6.595", lon: "106.816", display_name: "Bogor" },
      Kaliurang: {
        lat: "-7.596",
        lon: "110.426",
        display_name: "Kaliurang, Yogyakarta",
      },
      Malioboro: {
        lat: "-7.793",
        lon: "110.366",
        display_name: "Malioboro, Yogyakarta",
      },
    };
    await route.fulfill({
      status: 200,
      contentType: "application/json",
      body: JSON.stringify(points[query] ? [points[query]] : []),
    });
  });

  await page.route("https://router.project-osrm.org/**", async (route) => {
    assert.match(route.request().url(), /\/route\/v1\/driving\//);
    await route.fulfill({
      status: 200,
      contentType: "application/json",
      body: JSON.stringify({
        code: "Ok",
        routes: [{ distance: 4500, duration: 600 }],
      }),
    });
  });

  await page.goto("http://127.0.0.1:4194/");
  const result = await page.evaluate(async () => {
    const mod = await import("/src/trip-route-intelligence.js?v=31645");
    const normalized = await mod.analyzeTripDayRoutes({
      origin: "Bogor",
      destinationContext: "Yogyakarta",
      entries: [
        {
          id: "route-label",
          day: 1,
          time: "14:00",
          title: "Menuju Kaliurang",
          place: "Jombor - Kaliurang",
          transport: "Jalan kaki",
        },
      ],
    });
    const partial = await mod.analyzeTripDayRoutes({
      origin: "Bogor",
      destinationContext: "Yogyakarta",
      entries: [
        {
          id: "ok",
          day: 1,
          time: "09:00",
          title: "Jalan pagi",
          place: "Malioboro",
          transport: "Mobil",
        },
        {
          id: "bad",
          day: 1,
          time: "12:00",
          title: "Lokasi belum pasti",
          place: "Lokasi Mustahil 31645",
          transport: "Motor",
        },
      ],
    });
    return { normalized, partial };
  });

  assert.equal(result.normalized.legs.length, 1);
  assert.equal(result.normalized.warnings.length, 0);
  assert.equal(result.normalized.legs[0].destination, "Jombor - Kaliurang");
  assert.equal(result.normalized.legs[0].durationMinutes, 60);
  assert(geocodeQueries.includes("Jombor - Kaliurang"));
  assert(geocodeQueries.includes("Kaliurang"));

  assert.equal(result.partial.legs.length, 1);
  assert.equal(result.partial.warnings.length, 1);
  assert.equal(result.partial.warnings[0].title, "Lokasi belum pasti");
  assert.match(result.partial.warnings[0].message, /lebih spesifik/);

  await browser.close();
  console.log(
    "PASS route-label fallback, realistic walking time, and partial itinerary results",
  );
})().catch((error) => {
  console.error(error);
  process.exit(1);
});