const { chromium } = require('playwright');
const assert = require('assert');
const fs = require('fs');
const path = require('path');

(async () => {
  const browser = await chromium.launch({
    headless: true,
    executablePath: process.env.CHROMIUM_PATH || '/usr/local/bin/chromium',
    args: ['--no-sandbox'],
  });
  const checks = [];
  for (const viewport of [
    { width: 390, height: 844, name: 'mobile' },
    { width: 1440, height: 1000, name: 'desktop' },
  ]) {
    const page = await browser.newPage({ viewport, reducedMotion: 'reduce' });
    const errors = [];
    page.on('pageerror', error => errors.push(error.message));
    await page.goto('http://127.0.0.1:4194/');
    await page.click('#demo-login');
    await page.waitForFunction(() => !document.querySelector('#love-loader')?.classList.contains('is-visible'));
    await page.locator('[data-view="memories"]:visible').first().click();
    await page.waitForFunction(() => document.querySelectorAll('#ig-memory-slider .v305-photo-full').length > 1);
    await page.evaluate(() => window.scrollTo(0, 0));

    const before = await page.locator('#ig-memory-slider .ig6-slide.active').getAttribute('data-open');
    const layout = await page.evaluate(() => {
      const frame = document.querySelector('.v25-hero-memory');
      const slide = document.querySelector('#ig-memory-slider .ig6-slide.active');
      const full = slide.querySelector('.v305-photo-full');
      const backdrop = slide.querySelector('.v305-photo-backdrop');
      const frameRect = frame.getBoundingClientRect();
      const fullRect = full.getBoundingClientRect();
      return {
        slideCount: document.querySelectorAll('#ig-memory-slider .ig6-slide').length,
        fullFit: getComputedStyle(full).objectFit,
        fullPosition: getComputedStyle(full).objectPosition,
        backdropFit: getComputedStyle(backdrop).objectFit,
        frameOverflow: getComputedStyle(frame).overflow,
        frameWidth: frameRect.width,
        frameHeight: frameRect.height,
        fullInsideFrame: fullRect.left >= frameRect.left - 1 && fullRect.right <= frameRect.right + 1,
      };
    });
    assert(layout.slideCount > 1);
    assert.equal(layout.fullFit, 'contain');
    assert.equal(layout.fullPosition, '50% 50%');
    assert.equal(layout.backdropFit, 'cover');
    assert.equal(layout.frameOverflow, 'hidden');
    assert.equal(layout.fullInsideFrame, true);

    await page.waitForTimeout(4400);
    const after = await page.locator('#ig-memory-slider .ig6-slide.active').getAttribute('data-open');
    assert.notEqual(after, before, `${viewport.name}: foto tidak berganti`);
    await page.locator('#ig-memory-slider .ig6-slide.active').click();
    assert.equal(await page.locator('#dg-lightbox').isVisible(), true);
    await page.click('#dg-lightbox-close');
    assert.deepEqual(errors, []);
    const screenshot = path.join(__dirname, `../qa/memory-spotlight-${viewport.name}-v3025.png`);
    await page.screenshot({ path: screenshot });
    checks.push({ viewport, before, after, layout, lightboxClickable: true });
    await page.close();
  }
  await browser.close();
  fs.writeFileSync(path.join(__dirname, '../qa/memory-spotlight-v3025.json'), JSON.stringify({ checks }, null, 2));
  console.log('PASS: rotating memory photos remain fully visible and clickable on mobile and desktop.');
})().catch(error => {
  console.error(error);
  process.exit(1);
});
