const { chromium } = require('playwright');
const assert = require('assert');
const fs = require('fs');
const path = require('path');

(async () => {
  const browser = await chromium.launch({
    headless: true,
    executablePath: process.env.CHROMIUM_PATH || '/usr/bin/chromium',
    args: ['--no-sandbox'],
  });
  const checks = [];
  for (const viewport of [
    { width: 320, height: 568 },
    { width: 390, height: 844 },
    { width: 768, height: 900 },
  ]) {
    const page = await browser.newPage({ viewport, reducedMotion: 'reduce' });
    const errors = [];
    page.on('pageerror', error => errors.push(error.message));
    await page.goto('http://127.0.0.1:4194/');
    await page.click('#demo-login');
    await page.waitForFunction(() => !document.querySelector('#love-loader')?.classList.contains('is-visible'));
    await page.evaluate(() => {
      document.querySelector('#transaction-modal').classList.remove('hidden');
      document.querySelector('#transaction-form').elements.type.value = 'expense';
      document.querySelector('#transaction-title').textContent = 'Tambah pengeluaran';
    });
    await page.locator('#transaction-modal .modal-actions').scrollIntoViewIfNeeded();

    const geometry = await page.evaluate(() => {
      const modal = document.querySelector('#transaction-modal');
      const save = modal.querySelector('.modal-actions .btn-primary');
      const nav = document.querySelector('.bottom-nav');
      const mr = modal.getBoundingClientRect();
      const sr = save.getBoundingClientRect();
      const nr = nav.getBoundingClientRect();
      const point = document.elementFromPoint(sr.left + sr.width / 2, sr.top + sr.height / 2);
      return {
        modalZ: Number(getComputedStyle(modal).zIndex),
        navZ: Number(getComputedStyle(nav).zIndex),
        navVisibility: getComputedStyle(nav).visibility,
        saveTop: sr.top,
        saveBottom: sr.bottom,
        viewportHeight: innerHeight,
        modalTop: mr.top,
        modalBottom: mr.bottom,
        saveOwnsPoint: save === point || save.contains(point),
        horizontalOverflow: document.documentElement.scrollWidth > innerWidth + 2,
      };
    });

    assert(geometry.modalZ > geometry.navZ, JSON.stringify(geometry));
    assert.equal(geometry.navVisibility, 'hidden');
    assert(geometry.saveTop >= 0 && geometry.saveBottom <= viewport.height, JSON.stringify(geometry));
    assert.equal(geometry.saveOwnsPoint, true, JSON.stringify(geometry));
    assert.equal(geometry.horizontalOverflow, false, JSON.stringify(geometry));
    assert.deepEqual(errors, []);
    if (viewport.width === 390) {
      await page.screenshot({ path: path.join(__dirname, '../qa/finance-modal-390-v3021.png') });
    }
    checks.push({ viewport, ...geometry });
    await page.close();
  }
  await browser.close();
  fs.writeFileSync(path.join(__dirname, '../qa/finance-modal-v3021.json'), JSON.stringify({ checks }, null, 2));
  console.log('PASS: transaction save action remains visible and clickable above mobile navigation.');
})().catch(error => {
  console.error(error);
  process.exit(1);
});
