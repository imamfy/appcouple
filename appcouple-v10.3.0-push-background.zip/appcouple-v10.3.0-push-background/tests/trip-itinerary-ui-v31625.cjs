const {chromium}=require('playwright');
const assert=require('node:assert/strict');
const path=require('node:path');
(async()=>{
 const browser=await chromium.launch({headless:true,executablePath:process.env.CHROMIUM_PATH||'/usr/local/bin/chromium',args:['--no-sandbox']});
 for(const viewport of [{width:1440,height:1000,name:'desktop'},{width:390,height:844,name:'mobile'}]){
  const page=await browser.newPage({viewport,isMobile:viewport.width<500,hasTouch:viewport.width<500,timezoneId:'Asia/Jakarta'}); const errors=[];page.on('pageerror',e=>errors.push(e.message));
  await page.goto('http://127.0.0.1:4194/?trip-ui=31625');await page.evaluate(()=>localStorage.clear());await page.reload();await page.click('#demo-login');await page.waitForFunction(()=>window.__appCoupleOpenFeature);await page.locator('[data-view="couple"]:visible').first().click();await page.evaluate(()=>window.__appCoupleOpenFeature('trip'));await page.waitForSelector('#couple-trip-feature:not(.hidden)');await page.click('[data-trip-tab="daily"]');
  const add=async({day,time,title,place,duration,cost,transport,status})=>{await page.click('#trip-itinerary-add-open');await page.selectOption('#trip-itinerary-day',String(day));await page.fill('#trip-itinerary-time',time);await page.fill('#trip-itinerary-title',title);await page.fill('#trip-itinerary-place',place);await page.fill('#trip-itinerary-duration',duration);await page.fill('#trip-itinerary-cost',String(cost));await page.fill('#trip-itinerary-transport',transport);await page.selectOption('#trip-itinerary-status',status);await page.click('#trip-itinerary-submit');await page.waitForTimeout(100)};
  await add({day:1,time:'08:00',title:'Berangkat & check-in',place:'Hotel Purnama, Yogyakarta',duration:'2 jam',cost:150000,transport:'Kereta',status:'Dipesan'});
  await add({day:1,time:'12:30',title:'Makan siang bersama',place:'Malioboro, Yogyakarta',duration:'1 jam',cost:100000,transport:'Jalan kaki',status:'Rencana'});
  await add({day:2,time:'09:00',title:'Eksplorasi tempat wisata',place:'Candi Prambanan',duration:'3 jam',cost:250000,transport:'Mobil',status:'Selesai'});
  assert.equal(await page.locator('[data-itinerary-day-select]').count(),3);assert.equal(await page.locator('.trip-itinerary-day').count(),1);
  await page.click('[data-itinerary-day-select="1"]');assert.equal(await page.locator('.trip-itinerary-row').count(),2);
  await page.click('[data-itinerary-day-select="2"]');assert.equal(await page.locator('.trip-itinerary-row').count(),1);
  const iconButtons=page.locator('.trip-itinerary-actions button,.trip-itinerary-actions a,.trip-matus-actions button');assert((await iconButtons.count())>=8);assert.equal(await iconButtons.locator('svg').count(),await iconButtons.count());
  const overflow=await page.locator('#couple-trip-feature').evaluate(el=>el.scrollWidth>el.clientWidth+2);assert.equal(overflow,false);assert.deepEqual(errors,[]);
  await page.locator('.trip-itinerary-list').scrollIntoViewIfNeeded();await page.waitForTimeout(150);await page.screenshot({path:path.join('/data',`trip-itinerary-${viewport.name}-viewport.png`)});await page.close();
 }
 await browser.close();console.log('PASS itinerary timeline desktop/mobile, FA buttons, no horizontal overflow');
})().catch(e=>{console.error(e);process.exit(1)});
