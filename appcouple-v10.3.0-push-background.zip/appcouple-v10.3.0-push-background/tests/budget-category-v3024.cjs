const { chromium } = require('playwright');
const assert = require('assert');
const fs = require('fs');
const path = require('path');

(async () => {
  const browser = await chromium.launch({
    headless: true,
    executablePath: process.env.CHROMIUM_PATH || '/usr/local/bin/chromium',
    args: ['--no-sandbox'],
  });
  const checks = [];
  for (const width of [320, 390, 768]) {
    const page = await browser.newPage({ viewport: { width, height: 900 }, reducedMotion: 'reduce' });
    const errors = [];
    page.on('pageerror', error => errors.push(error.message));
    await page.goto('http://127.0.0.1:4194/');
    await page.click('#demo-login');
    await page.waitForFunction(() => !document.querySelector('#love-loader')?.classList.contains('is-visible'));
    await page.locator('[data-view="finance"]:visible').first().click();
    await page.locator('[data-finance-tab="budgets"]').click();
    const picker = page.locator('#p21-budget-category');
    await picker.scrollIntoViewIfNeeded();
    assert.equal(await picker.isVisible(), true);
    assert.equal(await picker.evaluate(node => node.tagName), 'SELECT');
    const options = await picker.locator('option').allTextContents();
    for (const expected of ['Pilih kategori', 'Kebutuhan', 'Transportasi', 'Tagihan', 'Kencan', 'Lainnya']) {
      assert(options.includes(expected), `${expected} tidak tersedia`);
    }
    await picker.selectOption('Transportasi');
    assert.equal(await picker.inputValue(), 'Transportasi');
    await page.fill('#p21-budget-form [name="limit"]', '750000');
    await page.click('#p21-budget-form [type="submit"]');
    await page.waitForFunction(() => document.querySelector('#p21-budget-list')?.innerText.includes('Transportasi'));
    assert((await page.locator('#p21-budget-list').innerText()).includes('750.000'));
    const hit = await picker.evaluate(node => {
      const rect = node.getBoundingClientRect();
      const top = document.elementFromPoint(rect.left + rect.width / 2, rect.top + rect.height / 2);
      return { ownsCenter: node === top || node.contains(top), width: rect.width, height: rect.height };
    });
    assert.equal(hit.ownsCenter, true);
    assert(hit.width >= 44 && hit.height >= 44);
    assert.deepEqual(errors, []);
    if (width === 390) await page.screenshot({ path: path.join(__dirname, '../qa/budget-category-390-v3024.png') });
    checks.push({ width, options, selected: 'Transportasi', saved: true, hit });
    await page.close();
  }
  await browser.close();
  fs.writeFileSync(path.join(__dirname, '../qa/budget-category-v3024.json'), JSON.stringify({ checks }, null, 2));
  console.log('PASS: budget category menu opens, selects a category, and saves the budget.');
})().catch(error => {
  console.error(error);
  process.exit(1);
});
