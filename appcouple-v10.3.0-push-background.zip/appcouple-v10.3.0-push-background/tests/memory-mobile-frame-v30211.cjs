const { chromium } = require('playwright');
const assert = require('assert');
const path = require('path');

(async()=>{
 const browser=await chromium.launch({headless:true,executablePath:process.env.CHROMIUM_PATH||'/usr/local/bin/chromium',args:['--no-sandbox']});
 for(const viewport of [{width:360,height:800,name:'360'},{width:390,height:844,name:'390'},{width:430,height:932,name:'430'}]){
  const page=await browser.newPage({viewport,reducedMotion:'reduce'});const errors=[];page.on('pageerror',e=>errors.push(e.message));
  await page.goto('http://127.0.0.1:4194/?v=30211');await page.click('#demo-login');await page.waitForFunction(()=>!document.querySelector('#love-loader')?.classList.contains('is-visible'));
  await page.locator('[data-view="memories"]:visible').first().click();await page.waitForFunction(()=>document.querySelectorAll('#ig-memory-slider .v305-photo-full').length>1);
  const layout=await page.evaluate(()=>{const frame=document.querySelector('.v25-hero-memory'),slider=document.querySelector('#ig-memory-slider'),img=document.querySelector('.ig6-slide.active .v305-photo-full'),stage=document.querySelector('.ig6-slide.active .v305-photo-stage');const f=frame.getBoundingClientRect(),s=slider.getBoundingClientRect(),i=img.getBoundingClientRect(),st=stage.getBoundingClientRect();return{frame:{w:f.width,h:f.height},slider:{l:s.left,t:s.top,r:s.right,b:s.bottom},stage:{l:st.left,t:st.top,r:st.right,b:st.bottom},img:{l:i.left,t:i.top,r:i.right,b:i.bottom},fit:getComputedStyle(img).objectFit,pos:getComputedStyle(img).objectPosition,overflow:getComputedStyle(frame).overflow,border:getComputedStyle(frame).borderTopWidth,gaps:{l:i.left-s.left,r:s.right-i.right,t:i.top-s.top,b:s.bottom-i.bottom}}});
  assert.equal(layout.fit,'contain');assert.equal(layout.pos,'50% 50%');assert.equal(layout.overflow,'hidden');assert(layout.frame.h>=340);assert(layout.frame.w>300);assert.equal(layout.border,'6px');
  for(const gap of Object.values(layout.gaps))assert(Math.abs(gap-8)<=1,`uneven photo inset ${JSON.stringify(layout.gaps)}`);
  const first=await page.locator('.ig6-slide.active').getAttribute('data-open');await page.waitForTimeout(4300);const second=await page.locator('.ig6-slide.active').getAttribute('data-open');assert.notEqual(second,first);
  await page.locator('.ig6-slide.active').click();assert(await page.locator('#dg-lightbox').isVisible());await page.click('#dg-lightbox-close');assert.deepEqual(errors,[]);
  if(viewport.name==='390')await page.screenshot({path:path.join(__dirname,'../qa/memory-mobile-frame-390-v30211.png')});await page.close();
 }
 await browser.close();console.log('PASS: mobile rotating memories use a larger, even frame without cropping.');
})().catch(e=>{console.error(e);process.exit(1)});
