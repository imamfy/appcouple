const { chromium } = require('playwright');
const assert = require('assert');

(async()=>{
  const browser=await chromium.launch({headless:true,executablePath:process.env.CHROMIUM_PATH||'/usr/local/bin/chromium',args:['--no-sandbox']});
  for(const viewport of [{width:390,height:844,name:'mobile'},{width:1440,height:1000,name:'desktop'}]){
    const page=await browser.newPage({viewport});
    const errors=[];page.on('pageerror',error=>errors.push(error.message));
    await page.goto('http://127.0.0.1:4194/?v=3029');
    await page.click('#demo-login');
    await page.waitForFunction(()=>typeof window.__appCoupleOpenFeature==='function'&&!document.querySelector('#love-loader')?.classList.contains('is-visible'));
    const open=async feature=>{await page.evaluate(feature=>window.__appCoupleOpenFeature(feature),feature);await page.waitForFunction(feature=>document.querySelector('#fs-overlay')?.dataset.activeFeature===feature,feature)};
    const close=()=>page.evaluate(()=>window.__appCoupleCloseFeature());

    await open('activity');await page.fill('#activity-search','makan');assert.equal(await page.inputValue('#activity-search'),'makan');await close();
    await open('chat');await page.fill('#chat-input','tes chat');assert.equal(await page.inputValue('#chat-input'),'tes chat');await close();
    await open('game');await page.click('[data-game-target="game-food"]');await page.fill('#custom-food-input','Sate');assert.equal(await page.inputValue('#custom-food-input'),'Sate');await close();
    await open('map');await page.click('#v41-map-search-toggle');await page.fill('#cv-map-search-input','Jakarta');assert.equal(await page.inputValue('#cv-map-search-input'),'Jakarta');await close();
    await open('rewards');if(viewport.width<680)await page.click('[data-reward-mobile-tab="catalog"]');await page.click('#reward-custom-toggle');await page.fill('#reward-custom-title','Es krim');assert.equal(await page.inputValue('#reward-custom-title'),'Es krim');await close();
    await open('savings');if(viewport.width<680)await page.click('[data-savings-mobile-tab="deposit"]');await page.fill('#sb-nominal-input','50000');assert.equal(await page.inputValue('#sb-nominal-input'),'50000');await close();
    await open('ai');await page.click('[data-ai-tab="brain"]');await page.fill('#ai-key-input','AIza-test');assert.equal(await page.inputValue('#ai-key-input'),'AIza-test');await close();
    await open('sydas');await page.fill('#ss-search','sejarah');assert.equal(await page.inputValue('#ss-search'),'sejarah');await close();

    assert.equal(await page.evaluate(()=>document.body.classList.contains('couple-feature-open')),false);
    assert.deepEqual(errors,[]);
    await page.close();
  }
  await browser.close();console.log('PASS: all application inputs remain clickable and typable on mobile and desktop.');
})().catch(error=>{console.error(error);process.exit(1)});
