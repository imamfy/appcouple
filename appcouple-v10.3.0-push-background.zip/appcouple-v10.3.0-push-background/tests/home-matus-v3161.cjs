const { chromium } = require('playwright');
const assert = require('assert');
const fs = require('fs');
const path = require('path');

(async () => {
  const browser = await chromium.launch({
    headless: true,
    executablePath: process.env.CHROMIUM_PATH || '/usr/bin/chromium',
    args: ['--no-sandbox'],
  });
  const report = [];
  for (const viewport of [{ width: 390, height: 844 }, { width: 1440, height: 900 }]) {
    const context = await browser.newContext({ viewport, isMobile: viewport.width < 500, hasTouch: viewport.width < 500 });
    const page = await context.newPage();
    const errors = [];
    page.on('pageerror', error => errors.push(error.message));
    await page.goto('http://127.0.0.1:4196/?qa=3161', { waitUntil: 'domcontentloaded' });
    await page.click('#demo-login');
    await page.waitForFunction(() => !document.querySelector('#love-loader')?.classList.contains('is-visible'));
    await page.locator('[data-view="home"]:visible').first().click().catch(() => {});
    const card = page.locator('.home-matus-whisper');
    assert(await card.isVisible(), `${viewport.width}: Matus card hidden`);
    assert.equal(await page.locator('[data-home-mood]').count(), 0, `${viewport.width}: old mood control remains`);
    assert.equal(await page.locator('.home-today-mood').count(), 0, `${viewport.width}: old mood section remains`);
    const first = (await page.locator('#home-matus-daily-message').innerText()).trim();
    const firstKind = (await page.locator('#home-matus-daily-kind').innerText()).trim();
    assert(first.length > 25, `${viewport.width}: generated message too short`);
    assert(firstKind.length > 2, `${viewport.width}: generated category missing`);
    await page.locator('[data-home-matus-reroll]').click();
    await page.waitForTimeout(100);
    const second = (await page.locator('#home-matus-daily-message').innerText()).trim();
    assert.notEqual(second, first, `${viewport.width}: reroll did not change message`);
    const layout = await page.evaluate(() => {
      const card = document.querySelector('.home-matus-whisper').getBoundingClientRect();
      return {
        documentWidth: document.documentElement.scrollWidth,
        viewportWidth: innerWidth,
        cardLeft: card.left,
        cardRight: card.right,
        context: document.querySelector('#home-matus-daily-context')?.textContent || '',
      };
    });
    assert(layout.documentWidth <= layout.viewportWidth + 1, `${viewport.width}: horizontal overflow`);
    assert(layout.cardLeft >= -1 && layout.cardRight <= layout.viewportWidth + 1, `${viewport.width}: card outside viewport`);
    assert(layout.context.includes('Dibuat otomatis'), `${viewport.width}: automatic context missing`);
    await page.evaluate(async () => (await import('/src/theme-system.js')).setAppTheme('dark'));
    await page.waitForTimeout(80);
    const darkBackground = await card.evaluate(el => getComputedStyle(el).backgroundImage);
    assert(darkBackground && darkBackground !== 'none', `${viewport.width}: dark style missing`);
    await page.screenshot({ path: path.join(__dirname, `../qa/home-matus-${viewport.width}-v3161.png`), fullPage: true });
    report.push({ viewport, firstKind, first, second, layout, darkBackground, errors });
    assert.deepEqual(errors, [], `${viewport.width}: page errors: ${errors.join('; ')}`);
    await context.close();
  }
  const source = fs.readFileSync(path.join(__dirname, '../src/home-ui.js'), 'utf8');
  assert(source.includes('},45000)'), '45-second automatic refresh timer missing');
  fs.writeFileSync(path.join(__dirname, '../qa/home-matus-v3161.json'), JSON.stringify(report, null, 2));
  await browser.close();
  console.log('PASS: Matus replaces mood controls and works across mobile/desktop and dark mode.');
})().catch(error => { console.error(error); process.exit(1); });
