const fs=require('fs');
const assert=require('assert');
const read=file=>fs.readFileSync(file,'utf8');

const service=read('src/supabase-service.js');
const worker=read('service-worker.js');
const redirects=read('_redirects');
const sql=read('docs/UPGRADE-PUSH-BACKGROUND.sql');
const backend=read('netlify/functions/push.cjs');

assert.match(service,/pushManager\.subscribe/);
assert.match(service,/sendPartnerPush\(\{messageId:row\.id/);
assert.match(worker,/self\.addEventListener\('push'/);
assert.match(worker,/visibilityState==='visible'/);
assert.match(redirects,/\/api\/push/);
assert.match(sql,/create table if not exists public\.push_subscriptions/);
assert.match(backend,/SUPABASE_SERVICE_ROLE_KEY/);
assert.match(backend,/webpush\.sendNotification/);
assert.doesNotMatch(service,/VAPID_PRIVATE_KEY/);

console.log('push-background-v103: ok');