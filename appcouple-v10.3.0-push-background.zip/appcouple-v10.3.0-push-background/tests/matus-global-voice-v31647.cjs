const { chromium } = require("playwright");
const assert = require("node:assert/strict");

(async () => {
  const browser = await chromium.launch({
    headless: true,
    executablePath: process.env.CHROMIUM_PATH || "/usr/local/bin/chromium",
    args: ["--no-sandbox"],
  });
  const page = await browser.newPage({
    viewport: { width: 390, height: 844 },
    timezoneId: "Asia/Jakarta",
  });
  const errors = [];
  page.on("pageerror", (error) => errors.push(error.message));
  await page.addInitScript(() => {
    window.__spoken = [];
    class MockUtterance {
      constructor(text) {
        this.text = text;
      }
    }
    Object.defineProperty(window, "SpeechSynthesisUtterance", {
      configurable: true,
      value: MockUtterance,
    });
    Object.defineProperty(window, "speechSynthesis", {
      configurable: true,
      value: {
      speaking: false,
      paused: false,
      getVoices: () => [],
      resume() {
        this.paused = false;
      },
      pause() {
        this.paused = true;
      },
      cancel() {
        this.speaking = false;
      },
      speak(utterance) {
        this.speaking = true;
        window.__spoken.push(utterance.text);
        setTimeout(() => utterance.onstart?.(), 0);
        setTimeout(() => {
          this.speaking = false;
          utterance.onend?.();
        }, 35);
      },
      },
    });
  });

  await page.goto("http://127.0.0.1:4194/?global-voice=31647");
  await page.evaluate(() => localStorage.clear());
  await page.reload();
  await page.click("#demo-login");
  await page.waitForFunction(() => window.__appCoupleOpenFeature);
  await page.evaluate(() => {
    window.__globalVoiceEvents = [];
    window.addEventListener("appcouple:matus-speaking-text", (event) =>
      window.__globalVoiceEvents.push(event.detail?.text),
    );
  });
  await page.locator('[data-view="couple"]:visible').first().click();
  await page.evaluate(() => window.__appCoupleOpenFeature("trip"));
  await page.waitForSelector("#couple-trip-feature:not(.hidden)");
  await page.fill("#trip-origin", "Bogor");
  await page.fill("#trip-destination", "Yogyakarta");
  await page.fill("#trip-days", "2");
  await page.click('[data-trip-tab="matus"]');
  await page.click('[data-trip-matus-action="itinerary"]');

  await page.waitForFunction(() =>
    window.__spoken.some((text) =>
      text.includes("Analisis itinerary hari 1 selesai"),
    ),
  );
  assert.equal(await page.locator("#view-ai.active").count(), 0);
  assert.equal(await page.locator("#view-couple.active").count(), 1);
  assert.equal(await page.locator("#matus-global-voice").count(), 1);
  assert(
    await page.evaluate(() =>
      window.__globalVoiceEvents.some((text) =>
        text.includes("Analisis itinerary hari 1 selesai"),
      ),
    ),
  );

  const before = await page.evaluate(() => window.__spoken.length);
  await page.evaluate(() => {
    localStorage.setItem("ac_matus_voice_auto", "0");
    window.dispatchEvent(
      new CustomEvent("appcouple:matus-announce", {
        detail: { text: "Pesan ini tidak boleh dibacakan" },
      }),
    );
  });
  await page.waitForTimeout(120);
  assert.equal(await page.evaluate(() => window.__spoken.length), before);
  assert.deepEqual(errors, []);

  await browser.close();
  console.log(
    "PASS Matus speaks globally outside Assistant view and respects auto-voice toggle",
  );
})().catch((error) => {
  console.error(error);
  process.exit(1);
});