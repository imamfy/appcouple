const { chromium } = require('playwright');
const assert = require('assert');
const path = require('path');

(async()=>{
  const browser=await chromium.launch({headless:true,executablePath:process.env.CHROMIUM_PATH||'/usr/local/bin/chromium',args:['--no-sandbox']});
  for(const viewport of [{width:390,height:844,name:'mobile'},{width:1440,height:1000,name:'desktop'}]){
    const page=await browser.newPage({viewport});
    const errors=[];page.on('pageerror',error=>errors.push(error.message));
    await page.goto('http://127.0.0.1:4194/?v=3028');
    await page.click('#demo-login');
    await page.waitForFunction(()=>!document.querySelector('#love-loader')?.classList.contains('is-visible'));
    await page.locator('[data-view="couple"]:visible').first().click();
    await page.locator('[data-couple-tab="apps"]').click();
    await page.locator('[data-couple-feature="ai"]').click();
    await page.locator('[data-ai-tab="brain"]').click();
    const input=page.locator('#ai-key-input');
    await input.waitFor({state:'visible'});
    const state=await page.evaluate(()=>({provider:document.querySelector('.ai-provider-chip.active')?.dataset.provider,disabled:document.querySelector('#ai-key-input').disabled,readOnly:document.querySelector('#ai-key-input').readOnly}));
    assert.equal(state.provider,'gemini');assert.equal(state.disabled,false);assert.equal(state.readOnly,false);
    await input.fill('AIzaSyTEST-123456789');assert.equal(await input.inputValue(),'AIzaSyTEST-123456789');
    await page.click('#ai-key-eye-btn');assert.equal(await input.getAttribute('type'),'text');assert.equal(await input.inputValue(),'AIzaSyTEST-123456789');
    await page.locator('[data-ai-tab="chat"]').click();await page.locator('[data-ai-tab="brain"]').click();
    assert.equal(await input.inputValue(),'AIzaSyTEST-123456789');
    assert.deepEqual(errors,[]);
    await page.screenshot({path:path.join(__dirname,`../qa/ai-key-input-${viewport.name}-v3028.png`)});
    await page.close();
  }
  await browser.close();console.log('PASS: Otak AI API key accepts typing and paste on mobile and desktop.');
})().catch(error=>{console.error(error);process.exit(1)});
