const { chromium } = require("playwright");
const assert = require("node:assert/strict");

(async () => {
  const browser = await chromium.launch({
    headless: true,
    executablePath: process.env.CHROMIUM_PATH || "/usr/bin/chromium",
    args: ["--no-sandbox"],
  });
  const page = await browser.newPage();
  await page.goto("http://127.0.0.1:4194/");
  const result = await page.evaluate(async () => {
    const { isBackupStorageKeySafe } = await import(
      "/src/backup-center.js?v=31645"
    );
    const keys = [
      "ai_key_openrouter",
      "aiKeyOpenRouter",
      "api_key_gemini",
      "accessToken",
      "refresh-token",
      "clientSecret",
      "private_key",
      "ac_session",
      "supabase.auth.token",
      "ac_trip_bundle_demo",
      "ac_matus_permissions_v5",
      "finagent_feed",
    ];
    return Object.fromEntries(
      keys.map((key) => [key, isBackupStorageKeySafe(key)]),
    );
  });

  for (const key of [
    "ai_key_openrouter",
    "aiKeyOpenRouter",
    "api_key_gemini",
    "accessToken",
    "refresh-token",
    "clientSecret",
    "private_key",
    "ac_session",
    "supabase.auth.token",
  ]) {
    assert.equal(result[key], false, `${key} must be excluded`);
  }
  for (const key of [
    "ac_trip_bundle_demo",
    "ac_matus_permissions_v5",
    "finagent_feed",
  ]) {
    assert.equal(result[key], true, `${key} should remain backup-safe`);
  }

  await browser.close();
  console.log("PASS backup excludes credential-like storage keys");
})().catch((error) => {
  console.error(error);
  process.exit(1);
});