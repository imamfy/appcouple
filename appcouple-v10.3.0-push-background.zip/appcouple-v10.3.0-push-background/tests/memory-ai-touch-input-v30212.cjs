const { chromium } = require('playwright');
const assert = require('assert');

(async()=>{
 const browser=await chromium.launch({headless:true,executablePath:process.env.CHROMIUM_PATH||'/usr/local/bin/chromium',args:['--no-sandbox']});
 for(const viewport of [{width:360,height:800},{width:390,height:844},{width:430,height:932}]){
  const page=await browser.newPage({viewport,isMobile:true,hasTouch:true});const errors=[];page.on('pageerror',e=>errors.push(e.message));
  await page.goto('http://127.0.0.1:4194/?v=30212');await page.tap('#demo-login');await page.waitForFunction(()=>!document.querySelector('#love-loader')?.classList.contains('is-visible'));
  await page.locator('[data-view="memories"]:visible').first().tap();
  const search=page.locator('#dg-search');await search.scrollIntoViewIfNeeded();await search.tap();await page.keyboard.type('kopi bersama');assert.equal(await search.inputValue(),'kopi bersama');
  await page.tap('#dg-heading-upload');await page.locator('#dg-upload-caption').tap();await page.keyboard.type('cerita kita lengkap');assert.equal(await page.inputValue('#dg-upload-caption'),'cerita kita lengkap');
  await page.locator('#dg-upload-place').tap();await page.keyboard.type('Bandung kota');assert.equal(await page.inputValue('#dg-upload-place'),'Bandung kota');await page.tap('#dg-upload-cancel');
  await page.locator('[data-view="couple"]:visible').first().tap();await page.tap('[data-couple-tab="apps"]');await page.tap('[data-couple-feature="ai"]');await page.tap('[data-ai-tab="brain"]');
  const key=page.locator('#ai-key-input');await key.scrollIntoViewIfNeeded();await key.tap();await page.keyboard.type('AIzaTouchTest123');assert.equal(await key.inputValue(),'AIzaTouchTest123');assert.equal(await page.evaluate(()=>document.activeElement?.id),'ai-key-input');
  await page.locator('details.ai3-advanced summary').tap();const model=page.locator('#ai-model-input');await model.tap();await page.keyboard.type('gemini-test-model');assert.equal(await model.inputValue(),'gemini-test-model');assert.equal(await page.evaluate(()=>document.activeElement?.id),'ai-model-input');
  assert.deepEqual(errors,[]);await page.close();
 }
 await browser.close();console.log('PASS: Memories and AI fields keep touch focus and accept complete mobile typing.');
})().catch(e=>{console.error(e);process.exit(1)});
