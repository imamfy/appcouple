const { chromium } = require('playwright');
const assert = require('assert');

(async()=>{
 const browser=await chromium.launch({headless:true,executablePath:process.env.CHROMIUM_PATH||'/usr/local/bin/chromium',args:['--no-sandbox']});
 for(const cfg of [{width:390,height:844,mobile:true},{width:1440,height:1000,mobile:false}]){
  const page=await browser.newPage({viewport:{width:cfg.width,height:cfg.height},isMobile:cfg.mobile,hasTouch:cfg.mobile});
  const errors=[];page.on('pageerror',e=>errors.push(e.message));
  await page.goto('http://127.0.0.1:4194/?v=30210');await page.click('#demo-login');
  await page.waitForFunction(()=>typeof window.__appCoupleOpenFeature==='function'&&!document.querySelector('#love-loader')?.classList.contains('is-visible'));
  const state=()=>page.evaluate(()=>({meta:document.querySelector('meta[name="viewport"]').content,locked:document.documentElement.classList.contains('mobile-zoom-locked'),scrollY:window.scrollY}));
  await page.locator('[data-view="couple"]:visible').first().click();let s=await state();
  assert.equal(s.locked,cfg.mobile);assert.equal(s.meta.includes('user-scalable=no'),cfg.mobile);assert.equal(s.meta.includes('maximum-scale=1'),cfg.mobile);
  await page.evaluate(()=>window.scrollTo(0,420));const before=await page.evaluate(()=>window.scrollY);
  for(const feature of ['activity','chat','game','map','rewards','savings','ai','sydas']){
   await page.evaluate(f=>window.__appCoupleOpenFeature(f),feature);
   const open=await page.evaluate(()=>({html:document.documentElement.classList.contains('couple-scroll-locked'),body:document.body.classList.contains('couple-feature-open'),bodyPos:getComputedStyle(document.body).position,htmlOverflow:getComputedStyle(document.documentElement).overflow,overlay:getComputedStyle(document.querySelector('#fs-overlay')).position,overlayPointer:getComputedStyle(document.querySelector('#fs-overlay')).pointerEvents,sidebarPointer:getComputedStyle(document.querySelector('.sidebar')).pointerEvents}));
   assert(open.html&&open.body,feature+' scroll lock missing');assert.equal(open.bodyPos,'fixed');assert.equal(open.htmlOverflow,'hidden');assert.equal(open.overlay,'fixed');assert.equal(open.overlayPointer,'auto');assert.equal(open.sidebarPointer,'none');
   const lockedTop=await page.evaluate(()=>document.body.style.top);await page.mouse.wheel(0,900);assert.equal(await page.evaluate(()=>document.body.style.top),lockedTop,feature+' background lock moved');assert.equal(lockedTop,`-${before}px`,feature+' saved scroll mismatch');
   await page.evaluate(()=>window.__appCoupleCloseFeature());assert.equal(await page.evaluate(()=>window.scrollY),before,feature+' scroll not restored');
  }
  await page.locator('[data-view="ai"]:visible').first().click();s=await state();assert.equal(s.locked,cfg.mobile);assert.equal(s.meta.includes('user-scalable=no'),cfg.mobile);
  await page.fill('#ai-input','tes matus');assert.equal(await page.inputValue('#ai-input'),'tes matus');
  await page.locator('[data-view="home"]').first().evaluate(el=>el.click());s=await state();assert.equal(s.locked,false);assert.equal(s.meta.includes('user-scalable=no'),false);
  assert.deepEqual(errors,[]);await page.close();
 }
 await browser.close();console.log('PASS: Couple Space background lock and mobile zoom lock for Couple Space/Matus are stable.');
})().catch(e=>{console.error(e);process.exit(1)});
