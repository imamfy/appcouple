const { chromium } = require('playwright');
const assert = require('assert');
const fs = require('fs');
const path = require('path');

const portraits = {
  user: `<svg xmlns="http://www.w3.org/2000/svg" width="240" height="240"><defs><linearGradient id="g" x2="1" y2="1"><stop stop-color="#ffb3c9"/><stop offset="1" stop-color="#b52d61"/></linearGradient></defs><rect width="240" height="240" fill="url(#g)"/><circle cx="120" cy="88" r="42" fill="#fff1e9"/><path d="M48 230c8-59 39-88 72-88s64 29 72 88" fill="#563042"/></svg>`,
  partner: `<svg xmlns="http://www.w3.org/2000/svg" width="240" height="240"><defs><linearGradient id="g" x2="1" y2="1"><stop stop-color="#c8bcff"/><stop offset="1" stop-color="#6551bf"/></linearGradient></defs><rect width="240" height="240" fill="url(#g)"/><circle cx="120" cy="88" r="42" fill="#fff1e9"/><path d="M48 230c8-59 39-88 72-88s64 29 72 88" fill="#302d56"/></svg>`,
};

(async () => {
  const browser = await chromium.launch({ headless: true, executablePath: process.env.CHROMIUM_PATH || '/usr/local/bin/chromium', args: ['--no-sandbox'] });
  const results = [];
  for (const viewport of [{width:390,height:844,name:'mobile'},{width:1440,height:1000,name:'desktop'}]) {
    const page = await browser.newPage({ viewport });
    const errors = [];
    page.on('pageerror', error => errors.push(error.message));
    await page.route('https://profiles.test/**', async route => {
      const svg = route.request().url().includes('partner') ? portraits.partner : portraits.user;
      await route.fulfill({ status: 200, contentType: 'image/svg+xml', body: svg });
    });
    await page.goto('http://127.0.0.1:4194/?v=3026');
    await page.click('#demo-login');
    await page.waitForFunction(() => !document.querySelector('#love-loader')?.classList.contains('is-visible'));
    await page.locator('[data-view="memories"]:visible').first().click();
    await page.evaluate(() => window.dispatchEvent(new CustomEvent('appcouple:couple-update', { detail: { me: 'Imam', partner: 'Pasangan', mePhoto: 'https://profiles.test/user.svg', partnerPhoto: 'https://profiles.test/partner.svg' } })));
    await page.waitForFunction(() => document.querySelector('#km-memory-user-avatar')?.classList.contains('has-google-photo') && document.querySelector('#km-memory-partner-avatar')?.classList.contains('has-google-photo'));
    await page.evaluate(() => window.scrollTo(0, 0));
    const state = await page.evaluate(() => {
      const wrap = document.querySelector('.v306-couple-portraits');
      const user = document.querySelector('#km-memory-user-avatar');
      const partner = document.querySelector('#km-memory-partner-avatar');
      const frame = document.querySelector('.v25-hero-memory');
      const wr = wrap.getBoundingClientRect(), fr = frame.getBoundingClientRect();
      return {
        userBackground: getComputedStyle(user).backgroundImage,
        partnerBackground: getComputedStyle(partner).backgroundImage,
        userName: user.dataset.profileName,
        partnerName: partner.dataset.profileName,
        userSize: user.getBoundingClientRect().width,
        partnerSize: partner.getBoundingClientRect().width,
        insideFrame: wr.left >= fr.left && wr.top >= fr.top && wr.right <= fr.right && wr.bottom <= fr.bottom,
        pointerEvents: getComputedStyle(wrap).pointerEvents,
      };
    });
    assert(state.userBackground.includes('user.svg'));
    assert(state.partnerBackground.includes('partner.svg'));
    assert.equal(state.userName, 'Imam');
    assert.equal(state.partnerName, 'Pasangan');
    assert.equal(state.insideFrame, true);
    assert.equal(state.pointerEvents, 'none');
    assert(state.userSize >= 36 && state.partnerSize >= 36);
    assert.deepEqual(errors, []);
    const screenshot = path.join(__dirname, `../qa/memory-account-portraits-${viewport.name}-v3026.png`);
    await page.screenshot({ path: screenshot });
    results.push({ viewport, state });
    await page.close();
  }
  await browser.close();
  fs.writeFileSync(path.join(__dirname, '../qa/memory-account-portraits-v3026.json'), JSON.stringify({ results }, null, 2));
  console.log('PASS: framed user and partner account photos sync on mobile and desktop.');
})().catch(error => { console.error(error); process.exit(1); });
