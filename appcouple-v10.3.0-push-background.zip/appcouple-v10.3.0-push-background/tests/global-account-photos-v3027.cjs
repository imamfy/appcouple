const { chromium } = require('playwright');
const assert = require('assert');
const fs = require('fs');
const path = require('path');

const userSelectors = ['.profile-chip .avatar','#home-me-avatar','#home-card-user-avatar','#pairing-user-avatar','#cv-me-avatar','#cs2-me-initial','#cs2-pulse-me-avatar','#anniversary-me','#cv-finance-me-avatar','#cm2-me-avatar','#cm2-map-me-avatar','#km-memory-user-avatar','#sb-couple-av-user'];
const partnerSelectors = ['#home-partner-avatar','#home-card-partner-avatar','#pairing-partner-avatar','#cv-partner-avatar','#cs2-partner-initial','#cs2-pulse-partner-avatar','#anniversary-partner','#partner-avatar','#cv-finance-partner-avatar','#cm2-partner-avatar','#cm2-map-partner-avatar','#wa-typing-avatar','#km-memory-partner-avatar','#sb-couple-av-partner'];

(async()=>{
  const browser=await chromium.launch({headless:true,executablePath:process.env.CHROMIUM_PATH||'/usr/local/bin/chromium',args:['--no-sandbox']});
  const results=[];
  for(const viewport of [{width:390,height:844,name:'mobile'},{width:1440,height:1000,name:'desktop'}]){
    const page=await browser.newPage({viewport});
    const errors=[]; page.on('pageerror',e=>errors.push(e.message));
    await page.route('https:'+'//profiles.test/**',route=>route.fulfill({status:200,contentType:'image/svg+xml',body:`<svg xmlns="http://www.w3.org/2000/svg" width="200" height="200"><rect width="200" height="200" rx="42" fill="${route.request().url().includes('partner')?'#6f58ce':'#bd3b63'}"/><circle cx="100" cy="76" r="34" fill="#fff"/><path d="M35 200c6-52 31-78 65-78s59 26 65 78" fill="#f5d9e4"/></svg>`}));
    await page.goto('http://127.0.0.1:4194/?v=3027');
    await page.click('#demo-login');
    await page.waitForFunction(()=>!document.querySelector('#love-loader')?.classList.contains('is-visible'));
    await page.evaluate(()=>window.dispatchEvent(new CustomEvent('appcouple:couple-update',{detail:{connected:true,me:'Imam',partner:'Partner',mePhoto:'https://profiles.test/user.svg',partnerPhoto:'https://profiles.test/partner.svg'}})));
    await page.waitForFunction(()=>document.documentElement.classList.contains('has-account-user-photo')&&document.documentElement.classList.contains('has-account-partner-photo'));
    const state=await page.evaluate(({userSelectors,partnerSelectors})=>{
      const inspect=(selectors,token)=>selectors.map(selector=>{const el=document.querySelector(selector);return{selector,exists:!!el,photo:!!el&&el.classList.contains('has-google-photo'),background:el?getComputedStyle(el).backgroundImage:'',name:el?.dataset.profileName||''}});
      return{users:inspect(userSelectors,'user.svg'),partners:inspect(partnerSelectors,'partner.svg'),userVar:getComputedStyle(document.documentElement).getPropertyValue('--account-user-photo'),partnerVar:getComputedStyle(document.documentElement).getPropertyValue('--account-partner-photo')};
    },{userSelectors,partnerSelectors});
    for(const row of state.users){assert(row.exists,`${viewport.name}: missing ${row.selector}`);assert(row.photo,`${viewport.name}: unsynced ${row.selector}`);assert(row.background.includes('user.svg'),`${viewport.name}: wrong user photo ${row.selector}`)}
    for(const row of state.partners){assert(row.exists,`${viewport.name}: missing ${row.selector}`);assert(row.photo,`${viewport.name}: unsynced ${row.selector}`);assert(row.background.includes('partner.svg'),`${viewport.name}: wrong partner photo ${row.selector}`)}
    assert(state.userVar.includes('user.svg')); assert(state.partnerVar.includes('partner.svg')); assert.deepEqual(errors,[]);
    await page.screenshot({path:path.join(__dirname,`../qa/global-account-photos-${viewport.name}-v3027.png`)});
    results.push({viewport,state}); await page.close();
  }
  await browser.close(); fs.writeFileSync(path.join(__dirname,'../qa/global-account-photos-v3027.json'),JSON.stringify({results},null,2));
  console.log('PASS: account photos sync across all applicable feature frames.');
})().catch(e=>{console.error(e);process.exit(1)});
