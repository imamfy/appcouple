/* Self-contained slippy map engine.
 * Replaces Leaflet entirely: no CDN, no vendor bundle, no window.L.
 * Renders OpenStreetMap-compatible raster tiles with pan, zoom, markers,
 * polylines and circles. If tiles cannot be fetched the map still shows a
 * readable graticule, so the UI never looks broken.
 */
const TILE = 256;

const LAYERS = {
  street: {
    tile: (z, x, y) => 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Street_Map/MapServer/tile/' + z + '/' + y + '/' + x,
    max: 19, credit: '\u00a9 Esri'
  },
  dark: {
    tile: (z, x, y) => 'https://server.arcgisonline.com/ArcGIS/rest/services/Canvas/World_Dark_Gray_Base/MapServer/tile/' + z + '/' + y + '/' + x,
    max: 16, credit: '\u00a9 Esri'
  },
  terrain: {
    tile: (z, x, y) => 'https://a.tile.opentopomap.org/' + z + '/' + x + '/' + y + '.png',
    max: 17, credit: '\u00a9 OpenTopoMap'
  },
  satellite: {
    tile: (z, x, y) => 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/' + z + '/' + y + '/' + x,
    max: 18, credit: '\u00a9 Esri'
  }
};

const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
const lngToX = (lng, z) => ((lng + 180) / 360) * Math.pow(2, z);
const latToY = (lat, z) => {
  const r = clamp(lat, -85.0511, 85.0511) * Math.PI / 180;
  return ((1 - Math.log(Math.tan(r) + 1 / Math.cos(r)) / Math.PI) / 2) * Math.pow(2, z);
};
const xToLng = (x, z) => (x / Math.pow(2, z)) * 360 - 180;
const yToLat = (y, z) => {
  const n = Math.PI - 2 * Math.PI * y / Math.pow(2, z);
  return 180 / Math.PI * Math.atan(0.5 * (Math.exp(n) - Math.exp(-n)));
};
const esc = v => String(v == null ? '' : v).replace(/[<>&"]/g, c => ({ '<': '&lt;', '>': '&gt;', '&': '&amp;', '"': '&quot;' })[c]);

export class MiniMap {
  constructor(el, opts) {
    const o = opts || {};
    this.el = typeof el === 'string' ? document.getElementById(el) : el;
    if (!this.el) throw new Error('MiniMap: container not found');
    this.center = o.center || { lat: -6.2, lng: 106.8167 };
    this.zoom = o.zoom == null ? 11 : o.zoom;
    this.layer = o.layer || 'street';
    this.markers = [];
    this.shapes = [];
    this._batchDepth = 0;
    this._renderQueued = false;
    this.onMarker = o.onMarker || null;
    this.el.classList.add('mm-root');
    this.el.innerHTML =
      '<div class="mm-grid" aria-hidden="true"></div>' +
      '<div class="mm-tiles" aria-hidden="true"></div>' +
      '<svg class="mm-vector" aria-hidden="true"></svg>' +
      '<div class="mm-markers"></div>' +
      '<div class="mm-zoom">' +
        '<button type="button" data-mm="in" aria-label="Perbesar peta">+</button>' +
        '<button type="button" data-mm="out" aria-label="Perkecil peta">\u2212</button>' +
      '</div>' +
      '<div class="mm-credit"></div>';
    this.$tiles = this.el.querySelector('.mm-tiles');
    this.$vector = this.el.querySelector('.mm-vector');
    this.$markers = this.el.querySelector('.mm-markers');
    this.$credit = this.el.querySelector('.mm-credit');
    this._bind();
    if (typeof ResizeObserver !== 'undefined') {
      this._ro = new ResizeObserver(() => this.requestRender());
      this._ro.observe(this.el);
    }
    this.render();
  }

  size() {
    const r = this.el.getBoundingClientRect();
    return { w: Math.round(r.width) || 640, h: Math.round(r.height) || 360 };
  }

  requestRender() {
    if (this._renderQueued) return this;
    this._renderQueued = true;
    const run = () => {
      this._renderQueued = false;
      if (this.el?.isConnected) this.render();
    };
    if (typeof requestAnimationFrame === 'function') requestAnimationFrame(run);
    else setTimeout(run, 16);
    return this;
  }

  batch(callback) {
    this._batchDepth += 1;
    try { callback?.(); } finally {
      this._batchDepth = Math.max(0, this._batchDepth - 1);
      if (!this._batchDepth) {
        this._renderVector();
        this._renderMarkers();
      }
    }
    return this;
  }

  setLayer(name) {
    if (!LAYERS[name]) return this;
    this.layer = name;
    this.zoom = clamp(this.zoom, 2, LAYERS[name].max);
    this.$tiles.innerHTML = '';
    this.el.dataset.layer = name;
    this.render();
    return this;
  }

  setView(center, zoom) {
    this.center = { lat: Number(center.lat), lng: Number(center.lng) };
    if (zoom != null) this.zoom = clamp(zoom, 2, LAYERS[this.layer].max);
    this.render();
    return this;
  }

  zoomBy(delta, anchor) {
    const next = clamp(this.zoom + delta, 2, LAYERS[this.layer].max);
    if (next === this.zoom) return this;
    if (anchor) {
      const before = this.unproject(anchor.x, anchor.y);
      this.zoom = next;
      const after = this.unproject(anchor.x, anchor.y);
      this.center = {
        lat: this.center.lat + (before.lat - after.lat),
        lng: this.center.lng + (before.lng - after.lng)
      };
    } else {
      this.zoom = next;
    }
    this.render();
    return this;
  }

  project(lat, lng) {
    const s = this.size(), z = this.zoom;
    return {
      x: (lngToX(lng, z) - lngToX(this.center.lng, z)) * TILE + s.w / 2,
      y: (latToY(lat, z) - latToY(this.center.lat, z)) * TILE + s.h / 2
    };
  }

  unproject(px, py) {
    const s = this.size(), z = this.zoom;
    return {
      lat: yToLat(latToY(this.center.lat, z) + (py - s.h / 2) / TILE, z),
      lng: xToLng(lngToX(this.center.lng, z) + (px - s.w / 2) / TILE, z)
    };
  }

  clearMarkers() {
    this.markers = [];
    if (!this._batchDepth) this.$markers.innerHTML = '';
    return this;
  }

  addMarker(lat, lng, o) {
    const m = Object.assign({ lat: Number(lat), lng: Number(lng) }, o || {});
    if (!Number.isFinite(m.lat) || !Number.isFinite(m.lng)) return this;
    this.markers.push(m);
    if (!this._batchDepth) this._renderMarkers();
    return this;
  }

  clearShapes() {
    this.shapes = [];
    if (!this._batchDepth) this._renderVector();
    return this;
  }

  addPolyline(points, o) {
    this.shapes.push(Object.assign({ type: 'line', points: points }, o || {}));
    if (!this._batchDepth) this._renderVector();
    return this;
  }

  addCircle(lat, lng, meters, o) {
    this.shapes.push(Object.assign({ type: 'circle', lat: Number(lat), lng: Number(lng), meters: meters }, o || {}));
    if (!this._batchDepth) this._renderVector();
    return this;
  }

  fitBounds(points, pad) {
    const padding = pad == null ? 60 : pad;
    const pts = (points || []).filter(p => Number.isFinite(Number(p[0])) && Number.isFinite(Number(p[1])));
    if (!pts.length) return this;
    if (pts.length === 1) return this.setView({ lat: Number(pts[0][0]), lng: Number(pts[0][1]) }, 17);
    const lats = pts.map(p => Number(p[0])), lngs = pts.map(p => Number(p[1]));
    const minLat = Math.min.apply(null, lats), maxLat = Math.max.apply(null, lats);
    const minLng = Math.min.apply(null, lngs), maxLng = Math.max.apply(null, lngs);
    const s = this.size(), max = LAYERS[this.layer].max;
    let best = 2;
    for (let z = max; z >= 2; z--) {
      const dx = (lngToX(maxLng, z) - lngToX(minLng, z)) * TILE;
      const dy = (latToY(minLat, z) - latToY(maxLat, z)) * TILE;
      if (dx <= Math.max(48, s.w - padding * 2) && dy <= Math.max(48, s.h - padding * 2)) { best = z; break; }
    }
    this.zoom = best;
    return this.setView({ lat: (minLat + maxLat) / 2, lng: (minLng + maxLng) / 2 });
  }

  _bind() {
    let drag = null, pinch = null;
    const pointers = new Map();
    const point = e => ({ x: e.clientX, y: e.clientY });
    const distance = (a,b) => Math.hypot(a.x-b.x,a.y-b.y);
    const midpoint = (a,b) => ({ x:(a.x+b.x)/2, y:(a.y+b.y)/2 });
    const beginSingle = () => {
      /* Fungsi geser/scroll peta dengan 1 jari dimatikan atas permintaan —
         peta sekarang statis (hanya zoom via tombol/scroll-wheel/pinch),
         tidak bisa digeser sama sekali. */
      const p=[...pointers.values()][0];
      drag=p?{point:{...p},center:{...this.center}}:null;
      pinch=null;
    };
    this.el.addEventListener('pointerdown', e => {
      if (e.target.closest('.mm-zoom') || e.target.closest('.mm-marker')) return;
      e.preventDefault();pointers.set(e.pointerId,point(e));
      try{if(this.el.setPointerCapture)this.el.setPointerCapture(e.pointerId)}catch{}
      if(pointers.size===1)beginSingle();
      else if(pointers.size===2){const [a,b]=[...pointers.values()];pinch={distance:Math.max(1,distance(a,b)),zoom:this.zoom};drag=null}
      this.el.classList.add('mm-dragging');
    },{passive:false});
    this.el.addEventListener('pointermove', e => {
      if(!pointers.has(e.pointerId))return;
      e.preventDefault();pointers.set(e.pointerId,point(e));
      if(pointers.size>=2){
        const [a,b]=[...pointers.values()],d=Math.max(1,distance(a,b));
        if(!pinch)pinch={distance:d,zoom:this.zoom};
        const target=clamp(pinch.zoom+Math.log2(d/pinch.distance),2,LAYERS[this.layer].max),anchor=midpoint(a,b),r=this.el.getBoundingClientRect();
        this.zoomBy(target-this.zoom,{x:anchor.x-r.left,y:anchor.y-r.top});
        return;
      }
      if(drag){const p=pointers.get(e.pointerId),z=this.zoom;this.center={lat:yToLat(latToY(drag.center.lat,z)+(drag.point.y-p.y)/TILE,z),lng:xToLng(lngToX(drag.center.lng,z)+(drag.point.x-p.x)/TILE,z)};this.requestRender();}
      return;
    },{passive:false});
    const end = e => {
      pointers.delete(e.pointerId);
      if(pointers.size===1)beginSingle();else if(!pointers.size){drag=null;pinch=null;this.el.classList.remove('mm-dragging')}
    };
    this.el.addEventListener('pointerup',end);
    this.el.addEventListener('pointercancel',end);
    this.el.addEventListener('lostpointercapture',end);
    this.el.addEventListener('dblclick', e => { e.preventDefault(); const r=this.el.getBoundingClientRect(); this.zoomBy(1,{x:e.clientX-r.left,y:e.clientY-r.top}); });
    this.el.addEventListener('wheel', e => {
      e.preventDefault();
      const r = this.el.getBoundingClientRect();
      this.zoomBy(e.deltaY < 0 ? 1 : -1, { x: e.clientX - r.left, y: e.clientY - r.top });
    }, { passive: false });
    this.el.addEventListener('click', e => {
      const zoomBtn = e.target.closest('[data-mm]');
      if (zoomBtn) { this.zoomBy(zoomBtn.dataset.mm === 'in' ? 1 : -1); return; }
      const marker = e.target.closest('[data-marker]');
      if (marker && this.onMarker) this.onMarker(this.markers[Number(marker.dataset.marker)]);
    });
  }

  render() {
    const s = this.size();
    if (!s.w || !s.h) return;
    const z = Math.round(this.zoom);
    const scale = Math.pow(2, this.zoom - z);
    const cfg = LAYERS[this.layer];
    const cx = lngToX(this.center.lng, z), cy = latToY(this.center.lat, z);
    const world = Math.pow(2, z);
    /* Keep the tile ring tight. The previous renderer requested a much
       larger grid, which made mobile maps slow and wasteful on data. */
    const cols = Math.max(1, Math.ceil(s.w / (TILE * scale) / 2));
    const rows = Math.max(1, Math.ceil(s.h / (TILE * scale) / 2));
    const keep = {};
    for (let dx = -cols; dx <= cols; dx++) {
      for (let dy = -rows; dy <= rows; dy++) {
        const tx = Math.floor(cx) + dx, ty = Math.floor(cy) + dy;
        if (ty < 0 || ty >= world) continue;
        const wx = ((tx % world) + world) % world;
        const key = z + '_' + wx + '_' + ty + '_' + dx + '_' + dy;
        keep[key] = 1;
        let img = this.$tiles.querySelector('[data-key="' + key + '"]');
        if (!img) {
          img = document.createElement('img');
          img.dataset.key = key;
          img.alt = '';
          img.decoding = 'async';
          img.loading = 'lazy';
          img.fetchPriority = 'low';
          img.referrerPolicy = 'no-referrer';
          img.addEventListener('error', function () { img.classList.add('mm-tile-failed'); }, { once: true });
          img.src = cfg.tile(z, wx, ty);
          this.$tiles.appendChild(img);
        }
        const left = (tx - cx) * TILE * scale + s.w / 2;
        const top = (ty - cy) * TILE * scale + s.h / 2;
        img.style.transform = 'translate3d(' + left.toFixed(1) + 'px,' + top.toFixed(1) + 'px,0)';
        img.style.width = img.style.height = (TILE * scale + 1).toFixed(1) + 'px';
      }
    }
    const stale = this.$tiles.querySelectorAll('img');
    for (let i = 0; i < stale.length; i++) {
      if (!keep[stale[i].dataset.key]) stale[i].remove();
    }
    this.$credit.textContent = cfg.credit;
    this._renderVector();
    this._renderMarkers();
  }

  _renderVector() {
    const s = this.size();
    this.$vector.setAttribute('viewBox', '0 0 ' + s.w + ' ' + s.h);
    this.$vector.setAttribute('width', s.w);
    this.$vector.setAttribute('height', s.h);
    const mpp = 156543.03392 * Math.cos(this.center.lat * Math.PI / 180) / Math.pow(2, this.zoom);
    this.$vector.innerHTML = this.shapes.map(shape => {
      if (shape.type === 'line') {
        const d = shape.points.map((p, i) => {
          const q = this.project(Number(p[0]), Number(p[1]));
          return (i ? 'L' : 'M') + q.x.toFixed(1) + ' ' + q.y.toFixed(1);
        }).join(' ');
        return '<path d="' + d + '" fill="none" stroke="' + (shape.color || '#d94f78') +
          '" stroke-width="' + (shape.weight || 5) + '" stroke-linecap="round" stroke-linejoin="round"' +
          (shape.dash ? ' stroke-dasharray="' + shape.dash + '"' : '') +
          ' opacity="' + (shape.opacity == null ? 0.85 : shape.opacity) + '"/>';
      }
      const c = this.project(shape.lat, shape.lng);
      const r = Math.max(5, shape.meters / mpp);
      return '<circle cx="' + c.x.toFixed(1) + '" cy="' + c.y.toFixed(1) + '" r="' + r.toFixed(1) +
        '" fill="' + (shape.color || '#d94f78') + '" fill-opacity="' + (shape.fillOpacity == null ? 0.14 : shape.fillOpacity) +
        '" stroke="' + (shape.color || '#d94f78') + '" stroke-opacity=".35"/>';
    }).join('');
  }

  _renderMarkers() {
    this.$markers.innerHTML = this.markers.map((m, i) => {
      const p = this.project(m.lat, m.lng);
      const isPerson = m.kind === 'live' || m.kind === 'me';
      const isMemory = m.kind === 'memory';
      const cls = 'mm-marker' + (m.kind === 'live' ? ' mm-live' : '') + (m.kind === 'me' ? ' mm-me' : '') + (isPerson ? ' mm-person' : '') + (isMemory ? ' mm-memory' : '');
      let dot;
      if (isPerson || isMemory) {
        const photo = m.photo ? String(m.photo).replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;') : '';
        const style = photo ? 'background-image:url(&quot;' + photo + '&quot;)' : 'background:' + esc(m.color || '#d94f78');
        dot = '<span class="' + (isMemory ? 'mm-memory-photo' : 'mm-person-avatar') + '" style="' + style + '">' + (photo ? '' : esc(m.initial || '')) + '</span>';
      } else {
        dot = '<i' + (m.color ? ' style="background:' + esc(m.color) + '"' : '') + '></i>';
      }
      const label = m.label ? '<b>' + esc(m.label) + '</b>' : '';
      const mid = m.memoryId ? ' data-memory-id="' + esc(String(m.memoryId)) + '"' : '';
      return '<button type="button" class="' + cls + '" data-marker="' + i + '"' + mid +
        ' title="' + esc(m.label || '') + '" style="transform:translate3d(' +
        p.x.toFixed(1) + 'px,' + p.y.toFixed(1) + 'px,0)">' + dot + label + '</button>';
    }).join('');
  }

  destroy() {
    if (this._ro) this._ro.disconnect();
    this.el.innerHTML = '';
    this.el.classList.remove('mm-root');
  }
}

export default MiniMap;
