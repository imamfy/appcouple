(()=>{
  const fine=matchMedia('(pointer:fine)'),reduce=matchMedia('(prefers-reduced-motion:reduce)');
  const clamp=(n,a,b)=>Math.min(b,Math.max(a,n));
  function tilt(){
    const card=document.querySelector('.auth-card'),screen=document.querySelector('.auth-screen');
    if(!card||!screen||card.dataset.l17)return;
    card.dataset.l17='1';
    screen.addEventListener('pointermove',e=>{
      if(!fine.matches||reduce.matches)return;
      const r=screen.getBoundingClientRect(),x=e.clientX/r.width-.5,y=e.clientY/r.height-.5;
      card.style.setProperty('--login-x',clamp(x*2.2,-1.2,1.2)+'px');
      card.style.setProperty('--login-y',clamp(y*2.2,-1.2,1.2)+'px');
    });
    screen.addEventListener('pointerleave',()=>{card.style.setProperty('--login-x','0px');card.style.setProperty('--login-y','0px')});
  }
  const wait=ms=>new Promise(resolve=>setTimeout(resolve,ms));
  const loader=document.querySelector('#love-loader'),bar=document.querySelector('#love-loader-progress'),status=document.querySelector('#love-loader-status'),steps=[...(loader?.querySelectorAll('.love-loader-steps span')||[])];
  let shownAt=0;
  function stage(index,label,progress){
    if(bar)bar.style.width=`${progress}%`;
    if(status)status.textContent=label;
    steps.forEach((step,i)=>{step.classList.toggle('active',i===index);step.classList.toggle('done',i<index)});
  }
  window.AppCoupleLoveLoader={
    async show(){
      if(!loader)return;
      shownAt=Date.now();loader.hidden=false;loader.classList.remove('is-complete');
      stage(0,'Memverifikasi sesi aman',16);
      requestAnimationFrame(()=>loader.classList.add('is-visible'));
      await wait(reduce.matches?40:260);
      stage(1,'Menyelaraskan data kalian',48);
      await wait(reduce.matches?40:360);
      stage(2,'Membuka ruang bersama',76);
    },
    async finish(){
      if(!loader)return;
      const elapsed=Date.now()-shownAt;
      if(elapsed<900&&!reduce.matches)await wait(900-elapsed);
      steps.forEach(step=>{step.classList.remove('active');step.classList.add('done')});
      if(bar)bar.style.width='100%';if(status)status.textContent='Ruang kalian siap';
      await wait(reduce.matches?80:420);
      loader.classList.add('is-complete');loader.classList.remove('is-visible');
      await wait(reduce.matches?30:300);
      loader.hidden=true;steps.forEach((step,i)=>{step.classList.toggle('active',i===0);step.classList.remove('done')});if(bar)bar.style.width='8%';
    }
  };
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',tilt,{once:true});else tilt();
})();
