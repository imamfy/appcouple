// Pure calendar, validation and account-scoped offline helpers.
export function todayWIB(d=new Date()){return new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Jakarta',year:'numeric',month:'2-digit',day:'2-digit'}).format(d)}
export function validDate(s){return /^\d{4}-\d{2}-\d{2}$/.test(s||'')&&Number.isFinite(Date.parse(s+'T00:00:00Z'))&&new Date(s+'T00:00:00Z').toISOString().slice(0,10)===s}
export function shiftDate(s,n){if(!validDate(s))throw Error('Tanggal tidak valid');const d=new Date(s+'T00:00:00Z');d.setUTCDate(d.getUTCDate()+n);return d.toISOString().slice(0,10)}
export function monday(s){const d=new Date(s+'T00:00:00Z');return shiftDate(s,-((d.getUTCDay()+6)%7))}
export function countDays(a,b){return Math.round((Date.parse(b+'T00:00:00Z')-Date.parse(a+'T00:00:00Z'))/86400000)+1}
export function validateTransaction(x){if(!['income','expense'].includes(x.type))throw Error('Jenis transaksi tidak valid');const amount=Number(x.amount);if(!Number.isSafeInteger(amount)||amount<1||amount>1e9)throw Error('Nominal harus Rupiah bulat, Rp1–Rp1 miliar');if(!validDate(x.date)||x.date>todayWIB())throw Error('Tanggal transaksi harus valid dan tidak di masa depan');if(!String(x.description||'').trim())throw Error('Deskripsi wajib diisi');return {...x,amount,description:String(x.description).trim().slice(0,120)}}
export const accountKey=(owner,kind)=>{if(!owner)throw Error('Pemilik data belum tersedia');return `ac_v20:${owner}:${kind}`};
export function readLocal(owner,kind,fallback=[]){try{return JSON.parse(localStorage.getItem(accountKey(owner,kind))||'null')??fallback}catch{return fallback}}
export function writeLocal(owner,kind,value){localStorage.setItem(accountKey(owner,kind),JSON.stringify(value))}
export function mergePending(remote,pending){const ids=new Set(remote.flatMap(x=>[x.id,x.clientId,x.client_id].filter(Boolean)));return [...remote,...pending.filter(x=>!ids.has(x.clientId)).map(x=>({...x,id:x.clientId,pending:true}))].sort((a,b)=>b.date.localeCompare(a.date))}
export function reportRange(mode,start,end,today=todayWIB()){
 let a,b=today;
 if(mode==='custom'){if(!validDate(start)||!validDate(end)||end<start||end>today)throw Error('Rentang laporan tidak valid');a=start;b=end}
 else if(mode==='daily')a=shiftDate(b,-13);
 else if(mode==='weekly')a=monday(b);
 else if(mode==='yearly')a=b.slice(0,4)+'-01-01';
 else {const d=new Date(b+'T00:00:00Z');d.setUTCDate(1);d.setUTCMonth(d.getUTCMonth()-11);a=d.toISOString().slice(0,10)}
 const days=countDays(a,b);return {start:a,end:b,previousStart:shiftDate(a,-days),previousEnd:shiftDate(a,-1),days};
}
export function buildReport(records,mode,start,end,today=todayWIB()){
 const r=reportRange(mode,start,end,today),items=records.filter(x=>x.date>=r.start&&x.date<=r.end),previousItems=records.filter(x=>x.date>=r.previousStart&&x.date<=r.previousEnd),opening=records.filter(x=>x.date<r.start).reduce((n,x)=>n+(x.type==='income'?x.amount:-x.amount),0),map=new Map();
 for(let d=r.start;d<=r.end;d=shiftDate(d,1)){const key=['daily','weekly'].includes(mode)?d:d.slice(0,7);if(!map.has(key))map.set(key,{key,label:key,income:0,expense:0})}
 items.forEach(x=>{const k=['daily','weekly'].includes(mode)?x.date:x.date.slice(0,7);map.get(k)[x.type]+=Number(x.amount)});
 return {...r,items,previousItems,opening,rows:[...map.values()],label:r.start+' — '+r.end,compareLabel:'vs '+r.previousStart+' — '+r.previousEnd,dayCount:r.days};
}
