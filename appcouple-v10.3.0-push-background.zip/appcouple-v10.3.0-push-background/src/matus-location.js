const LOCATION_KEY='ac_matus_current_location_v1';
const LOCATION_TTL_MS=15*60*1000;
let current=null;

function read(){try{const value=JSON.parse(sessionStorage.getItem(LOCATION_KEY)||'null');return value&&Number(value.expiresAt)>Date.now()?value:null}catch{return null}}
function save(value){current=value;try{sessionStorage.setItem(LOCATION_KEY,JSON.stringify(value))}catch{};window.__appCoupleMatusLocation=value;window.dispatchEvent(new CustomEvent('appcouple:matus-location',{detail:value}));return value}
function clear(){current=null;try{sessionStorage.removeItem(LOCATION_KEY)}catch{};delete window.__appCoupleMatusLocation;window.dispatchEvent(new CustomEvent('appcouple:matus-location',{detail:null}));renderStatus();}
function locationPermission(){try{return JSON.parse(localStorage.getItem('ac_matus_permissions_v5')||'{}').location!==false}catch{return true}}
function formatAddress(address={},fallback='Lokasi saat ini'){
  const parts=[address.house_number&&address.road?`${address.road} ${address.house_number}`:address.road||address.pedestrian||address.neighbourhood,address.suburb||address.village||address.town||address.city,address.state].filter(Boolean);return parts.length?parts.join(', '):fallback
}
async function reverseGeocode(lat,lng){const url=`https://nominatim.openstreetmap.org/reverse?format=jsonv2&addressdetails=1&zoom=18&lat=${encodeURIComponent(lat)}&lon=${encodeURIComponent(lng)}`;const response=await fetch(url,{headers:{accept:'application/json','accept-language':'id-ID,id;q=0.9'},signal:AbortSignal.timeout(10000)});if(!response.ok)throw new Error('Alamat belum dapat ditemukan');const data=await response.json();return{address:formatAddress(data.address,data.display_name||'Lokasi saat ini'),city:data.address?.city||data.address?.town||data.address?.village||'',region:data.address?.state||'',country:data.address?.country||'Indonesia'};}
export function getMatusLocation(){return current||read()}
export async function refreshMatusLocation({force=false}={}){
  if(!locationPermission())throw new Error('Izin lokasi Matus masih dimatikan di Pengaturan Matus');
  const cached=getMatusLocation();if(cached&&!force){current=cached;window.__appCoupleMatusLocation=cached;renderStatus();return cached;}
  if(!navigator.geolocation)throw new Error('Browser ini tidak mendukung GPS');
  setStatus('Meminta izin lokasi…');
  const position=await new Promise((resolve,reject)=>navigator.geolocation.getCurrentPosition(resolve,reject,{enableHighAccuracy:true,timeout:12000,maximumAge:30000}));
  const lat=Number(position.coords.latitude),lng=Number(position.coords.longitude),accuracy=Math.round(Number(position.coords.accuracy)||0),place=await reverseGeocode(lat,lng);
  const value={...place,accuracy,updatedAt:new Date().toISOString(),expiresAt:Date.now()+LOCATION_TTL_MS,source:'GPS browser'};
  save(value);renderStatus();return value;
}
function setStatus(text){const node=document.querySelector('#matus-location-status');if(node)node.textContent=text}
function renderStatus(){const value=getMatusLocation();setStatus(value?`${value.address} · akurasi ±${value.accuracy||0} m · aktif 15 menit`:'Belum dibaca. Matus hanya akan tahu lokasi setelah lu menekan tombol.');const button=document.querySelector('#matus-location-refresh');if(button)button.innerHTML=value?'<i data-fa="rotate"></i> Perbarui lokasi':'<i data-fa="location-dot"></i> Gunakan lokasi saya';window.dispatchEvent(new CustomEvent('appcouple:matus-location-status',{detail:value}));}
export function initMatusLocation(){current=read();if(current)window.__appCoupleMatusLocation=current;const refresh=document.querySelector('#matus-location-refresh'),remove=document.querySelector('#matus-location-clear');if(refresh&&!refresh.dataset.bound){refresh.dataset.bound='1';refresh.addEventListener('click',async()=>{try{await refreshMatusLocation({force:true});window.dispatchEvent(new CustomEvent('appcouple:matus-location-ready',{detail:current}));}catch(error){setStatus(error.message||'Lokasi belum tersedia')}})}if(remove&&!remove.dataset.bound){remove.dataset.bound='1';remove.addEventListener('click',()=>{clear();setStatus('Lokasi aktif dihapus dari sesi ini')})}window.addEventListener('appcouple:matus-context-refresh',renderStatus);renderStatus();}
