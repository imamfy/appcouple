import {localAiChat,loadLocalAiConfig,saveLocalAiConfig,clearLocalAiConfig,hasLocalAiConfig,getLastResolvedAiModel} from './local-ai.js';
import {downloadTripPlannerWorkbook} from './excel-trip-export.js';
import { MiniMap } from './mini-map.js';
import {analyzeTripDayRoutes,routeInsightFallback} from './trip-route-intelligence.js';
const NOOP_EL=new Proxy({},{get:(t,k)=>k==='classList'?{add(){},remove(){},toggle(){},contains:()=>false}:k==='style'||k==='dataset'?{}:['focus','blur','click','remove','reset','requestSubmit','scrollIntoView','addEventListener','removeEventListener','setAttribute','getAttribute','append','appendChild','insertAdjacentHTML','getBoundingClientRect','querySelector'].includes(k)?()=>undefined:k==='querySelectorAll'?()=>[]:'',set:()=>true});
/* Elements belonging to the retired map overlay resolve to a harmless stub. */
const $=(selector,root=document)=>root.querySelector(selector)||NOOP_EL;
const $$=(selector,root=document)=>[...root.querySelectorAll(selector)];
const dayMs=86_400_000;

let api=null;
let notify=()=>{};
let getState=()=>({});
let getActivity=()=>[];
let navigate=()=>{};
let state={chatId:null,uid:null,user:null,partner:null,demo:false};
let stops=[];
let shared={};
let sharedRecoveryAttempted=false;
let memories=[];
let driveMemories=[];
let locations={};
let locationHistory=[];
let gameState={};
let rewardFilter='all';
let depositFilter='all';
let depositQuery='';
let currentOpen=null;
let map=null;
let routeLayer=null;
let mapView='grid';
let footprintCoords=null;
let footprintPhoto=null;
let englishLevel='beginner';
let englishModule='tutor';
let reportPeriod='daily';
let mapFilter='all';
let journeyOwnerFilter='all';
let mapMemoryQuery='';
let mapShareMinutes=60;
let meetingPoint=null;
let searchResult=null;
let activeFootprintId=null;
let mapClock=null;
let mapResizeFrame=null;
let mapResizeTimer=null;
let mapLiteMode=localStorage.getItem('ac_map_lite')!=='0';
const MAP_LITE_MEMORY_LIMIT=36;
let routeMode='driving';
let routeDestination=null;
let routeOrigin=null;
let routeMetrics={km:0,minutes:0};
const routeGeocodeCache=new Map();

const defaultRewards=()=>[
  {id:'breakfast-bed',name:'Sarapan romantis di tempat tidur',cost:1000,icon:'<i data-fa="mug-hot"></i>',category:'romantic',desc:'Pasangan menyiapkan sarapan favorit dan waktu santai tanpa gangguan.'},
  {id:'movie-premium',name:'Movie night premium',cost:1200,icon:'<i data-fa="film"></i>',category:'date',desc:'Pilih film, camilan, minuman, dan nikmati malam berdua tanpa ponsel.'},
  {id:'massage-45',name:'Pijat rileks 45 menit',cost:1500,icon:'<i data-fa="spa"></i>',category:'favor',desc:'Sesi pijat santai dari pasangan untuk melepas lelah setelah hari panjang.'},
  {id:'favorite-dinner',name:'Dinner menu favorit',cost:1800,icon:'<i data-fa="utensils"></i>',category:'romantic',desc:'Makan malam pilihanmu, dimasak atau dipesankan khusus oleh pasangan.'},
  {id:'picnic-date',name:'Piknik berdua',cost:2000,icon:'<i data-fa="basket-shopping"></i>',category:'date',desc:'Piknik lengkap dengan makanan ringan, foto, dan waktu berkualitas.'},
  {id:'chores-weekend',name:'Bebas tugas rumah akhir pekan',cost:2200,icon:'<i data-fa="sparkles"></i>',category:'favor',desc:'Pasangan mengambil alih tugas rumah agar kamu bisa istirahat penuh.'},
  {id:'selfcare-day',name:'Hari self-care pilihanmu',cost:2500,icon:'<i data-fa="heart"></i>',category:'favor',desc:'Waktu bebas untuk perawatan diri, hobi, atau kegiatan yang membuatmu tenang.'},
  {id:'cafe-hopping',name:'Cafe hopping romantis',cost:2800,icon:'<i data-fa="coffee"></i>',category:'date',desc:'Kunjungi dua tempat favorit dan abadikan cerita baru berdua.'},
  {id:'surprise-gift',name:'Kado kejutan spesial',cost:3000,icon:'<i data-fa="gift"></i>',category:'romantic',desc:'Hadiah kejutan yang dipilih dengan perhatian sesuai hal yang kamu sukai.'},
  {id:'day-trip',name:'One day trip berdua',cost:3300,icon:'<i data-fa="car"></i>',category:'date',desc:'Jalan sehari ke tempat pilihan bersama, lengkap dengan itinerary sederhana.'},
  {id:'dream-date',name:'Dream date pilihanmu',cost:3700,icon:'<i data-fa="star"></i>',category:'date',desc:'Kencan impian yang kamu tentukan, direncanakan khusus oleh pasangan.'},
  {id:'royal-weekend',name:'Royal treatment weekend',cost:4000,icon:'<i data-fa="crown"></i>',category:'romantic',desc:'Satu akhir pekan penuh perhatian, pilihan aktivitasmu, dan bebas tugas.'}
];
const BUILTIN_REWARD_IDS=new Set(defaultRewards().map(item=>item.id));
const LEGACY_REWARD_IDS=new Set(['coffee','movie','massage','breakfast','date','chores']);
function mergedRewards(items=[]){const custom=(items||[]).filter(item=>item?.createdBy||(!BUILTIN_REWARD_IDS.has(item?.id)&&!LEGACY_REWARD_IDS.has(item?.id)));return[...defaultRewards(),...custom]}
const englishData={
  beginner:{phrase:'I appreciate everything you do for us.',translation:'Aku menghargai semua yang kamu lakukan untuk kita.',words:[['appreciate','menghargai'],['together','bersama'],['support','mendukung'],['promise','janji']],grammar:{q:'Choose the correct sentence:',options:['I am love you.','I love you.','I loving you.'],answer:1}},
  intermediate:{phrase:'Being with you makes ordinary days feel meaningful.',translation:'Bersamamu membuat hari biasa terasa bermakna.',words:[['meaningful','bermakna'],['effort','usaha'],['understand','memahami'],['encourage','menyemangati']],grammar:{q:'Complete: We have been together ___ two years.',options:['since','for','during'],answer:1}},
  advanced:{phrase:'Our relationship thrives when we communicate with empathy and intention.',translation:'Hubungan kita berkembang saat kita berkomunikasi dengan empati dan tujuan.',words:[['thrive','berkembang pesat'],['empathy','empati'],['intention','niat/tujuan'],['compromise','kompromi']],grammar:{q:'Choose the most natural phrase:',options:['Had I known, I would have listened sooner.','If I knew, I listen sooner.','Knowing I had listen.'],answer:0}}
};

export function configure(options={}){notify=options.toast||notify;getState=options.getState||getState;getActivity=options.getActivity||getActivity;navigate=options.navigate||navigate}
export function setApi(service){api=service}

export async function initCoupleFeatures(options){
  state={chatId:options.chatId,uid:options.uid,user:options.user||{},partner:options.partner||{},demo:!!options.demo};
  notify=options.toast||notify;navigate=options.navigate||navigate;
  wire();
  clearStops();
  if(state.demo){
    shared=demoShared();memories=[...(window.__appCouplePendingMemories||[]),...demoMemories()].filter((item,index,all)=>all.findIndex(x=>x.id===item.id)===index);locations=demoLocations();locationHistory=compactLocationHistory(demoLocationHistory());gameState={};if(shared.tripPlan)syncTripPlanFromShared(shared.tripPlan);tripRenderSharedBundle(shared);
    renderShared();renderMemories();renderLocations();renderLocationHistory();renderEnglish();
    return;
  }
  if(!api)try{api=await import('./supabase-service.js')}catch(error){console.error(error);return}
  sharedRecoveryAttempted=false;
  stops.push(api.watchSharedState(state.chatId,async data=>{let incoming=data&&typeof data==='object'?data:{};if(sharedHasContent(incoming))cacheSharedBackup(incoming);else if(!sharedRecoveryAttempted){sharedRecoveryAttempted=true;const backup=readSharedBackup();if(backup&&api.restoreSharedSnapshot)try{incoming=await api.restoreSharedSnapshot(state.chatId,backup);cacheSharedBackup(incoming);notify('Cadangan data pasangan dipulihkan otomatis')}catch(error){console.warn('Pemulihan cadangan bersama:',error)}}shared={...baseShared(),...incoming};renderShared();if(!tripDirty&&!tripSaveBusy){if(shared.tripPlan)syncTripPlanFromShared(shared.tripPlan);tripRenderSharedBundle(shared)}else renderTripSync()},error=>notify(error.message||'Data tabungan gagal dimuat')));
  stops.push(api.watchMemories(state.chatId,data=>{memories=data||[];renderMemories()},console.error));
  stops.push(api.watchCoupleGame(state.chatId,data=>{gameState=data||{};if(currentOpen==='game')refreshSyncedGame()},console.error));
  if(api.watchCoupleLocations)stops.push(api.watchCoupleLocations(state.partner.uid,data=>{locations=data||{};renderLocations()},console.error));
  if(api.watchLocationHistory)stops.push(api.watchLocationHistory(state.chatId,data=>{locationHistory=compactLocationHistory(data||[]);renderLocationHistory()},console.error));
  setTimeout(autoShareLocationOnOpen,700);
}

export function onFeatureOpen(type){
  currentOpen=type;
  if(type==='map'){document.documentElement.classList.add('map-view-open');window.scrollTo(0,0);const root=document.querySelector('#couple-map-feature'),sync=()=>{const view=window.visualViewport;root?.style.setProperty('--map-visual-width',`${Math.round(view?.width||innerWidth)}px`);root?.style.setProperty('--map-visual-height',`${Math.round(view?.height||innerHeight)}px`)};sync();requestAnimationFrame(()=>{sync();resizeMap()});ensureMap();}
  if(type==='tech')window.AppCoupleTech?.init?.();
  if(type==='sydas')window.SydasSector?.init?.();
  if(type==='english'){wireEnglish();renderEnglish();}
  if(type==='ai'){wireAiBrain();checkHealth();}
  if(type==='game'&&!currentGamePanel)closeGamePanel();
}
export function requestAiAnalysis(type){return runAiAnalysis(type)}

function wire(){
  if($('#fs-overlay')?.dataset.featuresWired)return;
  $('#fs-overlay').dataset.featuresWired='1';
  window.addEventListener('appcouple:finance-update',sendFinanceWarningToChat);
  $('#back-to-lobby-btn').onclick=closeGamePanel;
  $$('[data-game-target]').forEach(card=>card.onclick=()=>openGamePanel(card.dataset.gameTarget));
  $('#spin-food-btn').onclick=()=>spinWheel('food');
  $('#spin-place-btn').onclick=()=>spinWheel('place');
  $('#add-custom-food-btn').onclick=()=>addCustomOption('food');
  $('#add-custom-place-btn').onclick=()=>addCustomOption('place');
  $('#custom-food-input').onkeydown=event=>{if(event.key==='Enter'){event.preventDefault();addCustomOption('food')}};
  $('#custom-place-input').onkeydown=event=>{if(event.key==='Enter'){event.preventDefault();addCustomOption('place')}};
  loadWheelLocal();
  if(!window.__mapResizeWired){window.__mapResizeWired=true;window.addEventListener('resize',resizeMap);window.addEventListener('orientationchange',()=>setTimeout(resizeMap,180));}/*mapResizeWired*/
  if(!window.__mapThemeWired){window.__mapThemeWired=true;window.addEventListener('appcouple:theme-changed',event=>{const feature=$('#couple-map-feature'),current=feature?.dataset.mapLayer||map?.layer||'street';if(!feature||!map||!['street','dark'].includes(current))return;const next=event.detail?.dark?'dark':'street',button=$(`[data-map-layer="${next}"]`);switchMapLayer(next,button)})}
  if(!window.__memoryMapBridgeWired){window.__memoryMapBridgeWired=true;const syncDriveMemories=rows=>{if(!Array.isArray(rows))return;driveMemories=rows.filter(item=>item&&item.id);renderMemories()};window.addEventListener('appcouple:memories-data',event=>syncDriveMemories(event.detail));window.addEventListener('appcouple:memory-created',event=>{const item=event.detail;if(!item?.id)return;driveMemories=[item,...driveMemories.filter(row=>row.id!==item.id)];renderMemories()});window.addEventListener('appcouple:focus-map-memory',event=>{const id=event.detail?.id;if(id){toggleV41Drawer('memories');setTimeout(()=>focusFootprint(id),120)}});if(Array.isArray(window.__appCoupleMapMemories))syncDriveMemories(window.__appCoupleMapMemories)}
  $('#cv-map-search-button').onclick=searchMap;
  $('#cv-map-search-input').onkeydown=event=>{if(event.key==='Enter'){event.preventDefault();searchMap()}};
  $$('[data-map-layer]').forEach(button=>button.onclick=()=>switchMapLayer(button.dataset.mapLayer,button));
  $('#cv-map-location').onclick=centerOnMe;
  $('#v630-map-back').onclick=()=>{document.documentElement.classList.remove('map-view-open');document.querySelector('#close-couple-feature')?.click()};
  $('#cv-map-fit').onclick=fitAllMap;
  $('#cm2-fit-all').onclick=fitAllMap;
  $('#cv-map-lite-toggle').onclick=()=>setMapLiteMode(!mapLiteMode);
  $('#cv-map-refresh').onclick=()=>{map?.render();renderMapMarkers();watchTileHealth();notify('Peta disegarkan')};
  setMapLiteMode(mapLiteMode,false);
  $('#cv-map-route').onclick=openRoutePlanner;
  $('#cv-map-route-close').onclick=closeRoutePlanner;
  $('#cv-map-route-use-current').onclick=useCurrentRouteOrigin;
  $('#cv-map-route-plan').onclick=planMapRoute;
  $('#cv-map-ask-matus').onclick=askMatusRoute;
  $('#cv-map-share-route').onclick=shareMapRoute;
  $('#cv-map-save-trip').onclick=saveRouteToTripPlanner;
  $$('[data-map-route-mode]').forEach(button=>button.onclick=()=>{routeMode=button.dataset.mapRouteMode;$$('[data-map-route-mode]').forEach(item=>item.classList.toggle('active',item===button))});
  $('#cv-map-meet').onclick=showMeetingPoint;
  $('#cm2-meet-now').onclick=showMeetingPoint;
  $('#cv-map-clear-route').onclick=clearRoute;
  $('#cv-share-location').onclick=toggleLocationShare;
  $('#cv-map-share-duration').onchange=event=>{mapShareMinutes=Math.min(120,Math.max(15,Number(event.target.value)||60))};
  $('#cm2-copy-position').onclick=copyCoupleLocation;
  $('#cv-add-footprint').onclick=openFootprintForm;
  $('#cv-footprint-close').onclick=closeFootprintForm;
  $('#cv-footprint-cancel').onclick=closeFootprintForm;
  $('#cv-footprint-modal').onclick=event=>{if(event.target.id==='cv-footprint-modal')closeFootprintForm()};
  document.body.appendChild($('#cv-footprint-modal'));
  $('#cv-footprint-use-location').onclick=chooseFootprintLocation;
  $('#cv-footprint-photo').onchange=event=>{footprintPhoto=event.target.files?.[0]||null;$('#cv-footprint-photo-name').textContent=footprintPhoto?`${footprintPhoto.name} · ${Math.round(footprintPhoto.size/1024)} KB`:'Opsional · JPG/PNG'};
  $('#cv-footprint-form').onsubmit=saveFootprint;
  $$('[data-map-view]').forEach(button=>button.onclick=()=>{mapView=button.dataset.mapView;$$('[data-map-view]').forEach(item=>item.classList.toggle('active',item===button));renderMemories()});
  $$('[data-map-filter]').forEach(button=>button.onclick=()=>{mapFilter=button.dataset.mapFilter;$$('[data-map-filter]').forEach(item=>item.classList.toggle('active',item===button));renderMemories()});
  $$('[data-journey-owner]').forEach(button=>button.onclick=()=>{journeyOwnerFilter=button.dataset.journeyOwner;$$('[data-journey-owner]').forEach(item=>item.classList.toggle('active',item===button));renderJourneyStats();renderMemories()});
  $('#cm2-map-filter-input').oninput=event=>{mapMemoryQuery=String(event.target.value||'').trim().toLowerCase();renderMemories()};
  $('#cv-footprint-list').onclick=handleFootprintClick;
  $('#cmz-location-history').onclick=handleLocationHistoryClick;
  $('#cmz-clear-history').onclick=clearMyLocationHistory;
  $('#cm2-memory-preview').onclick=event=>{if(event.target.closest('[data-preview-close]'))closeMemoryPreview()};
  $('#v41-map-search-toggle').onclick=()=>toggleV41Search(true);
  $('#v41-map-search-close').onclick=()=>toggleV41Search(false);
  $('#v41-map-live-toggle').onclick=toggleV41LivePanel;
  $('#v41-map-album-toggle').onclick=()=>toggleV41Drawer('memories');
  $('#v41-map-drawer-close').onclick=closeV41Drawer;
  wireMobileMapSheets();
  $('#v41-map-compass').onclick=centerOnMe;
  $$('[data-v41-drawer]').forEach(button=>button.onclick=()=>openV41DrawerPanel(button.dataset.v41Drawer));
  document.addEventListener('keydown',event=>{if(event.key==='Escape'){closeV41Drawer();$('#v41-map-live-panel').classList.remove('open');toggleV41Search(false)}});
  $('#reward-custom-toggle').onclick=toggleRewardCustomForm;
  $('#reward-custom-form').onsubmit=createReward;
  $('#rewards-list').onclick=handleRewardsClick;
  $('#rw9-back').onclick=()=>$('#close-couple-feature')?.click();
  $$('[data-reward-mobile-tab]').forEach(button=>button.onclick=()=>switchRewardMobileTab(button.dataset.rewardMobileTab));
  wireEnglish();
  wireAiBrain();
  $$('#sb-quick-amounts [data-amt]').forEach(button=>button.onclick=()=>selectSavingsAmount(button));
  $('#sb-nominal-input').oninput=()=>{clearSavingsAmountSelection();updateDepositPreview()};
  $('#sb-nominal-input').onkeydown=event=>{if(event.key==='Enter'){event.preventDefault();addDeposit()}};
  $('#sb-note-input').onkeydown=event=>{if(event.key==='Enter'){event.preventDefault();addDeposit()}};
  $('#sb-confirm-btn').onclick=()=>addDeposit();
  $('#sb-copy-btn').onclick=copyAccountNumber;
  $('#sb-edit-account-btn').onclick=openSavingsAccount;
  $('#sv2-account-close').onclick=closeSavingsAccount;
  $('#sv2-account-cancel').onclick=closeSavingsAccount;
  $('#sv2-account-modal').onclick=event=>{if(event.target.id==='sv2-account-modal')closeSavingsAccount()};
  $('#sv2-account-input').oninput=event=>{event.target.value=event.target.value.replace(/\D/g,'').slice(0,30)};
  $('#sv2-account-form').onsubmit=commitSavingsAccount;
  $$('[data-savings-mobile-tab]').forEach(button=>button.onclick=()=>switchSavingsMobileTab(button.dataset.savingsMobileTab));
  $('#sb-target-btn').onclick=openSavingsTarget;
  $$('[data-sv2-open-target]').forEach(button=>button.onclick=openSavingsTarget);
  $('#sv2-target-close').onclick=closeSavingsTarget;
  $('#sv2-target-cancel').onclick=closeSavingsTarget;
  $('#sv2-target-modal').onclick=event=>{if(event.target.id==='sv2-target-modal')closeSavingsTarget()};
  $('#sv2-target-form').onsubmit=commitSavingsTarget;
  $$('[data-sv2-weekly]').forEach(button=>button.onclick=()=>{const input=$('#sv2-target-weekly');input.value=button.dataset.sv2Weekly;updateTargetDuration()});
  $('#sv2-target-total').oninput=updateTargetDuration;
  $('#sv2-target-weekly').oninput=updateTargetDuration;
  $('#sv2-history-search').oninput=event=>{depositQuery=String(event.target.value||'').trim().toLowerCase();renderDeposits()};
  $('#sv2-export').onclick=exportSavingsCsv;
  $$('[data-deposit-filter]').forEach(button=>button.onclick=()=>{depositFilter=button.dataset.depositFilter;$$('[data-deposit-filter]').forEach(item=>item.classList.toggle('active',item===button));renderDeposits()});
  $('#cv-copy-account').onclick=copyCoupleId;
  wireTripPlanner();
  window.addEventListener('appcouple:daily-points',event=>{const detail=event.detail||{};shared={...shared,dailyMissionDate:detail.day||shared.dailyMissionDate,dailyMissions:{...(shared.dailyMissions||{}),[state.uid]:detail.missions||{},[state.partner?.uid]:detail.partnerMissions||{}},points:detail.total??shared.points,pointsByUser:detail.pointsByUser||shared.pointsByUser};renderShared()});
  window.addEventListener('appcouple:shared-saved',event=>cacheSharedBackup(event.detail?.data||{}));
}

function clearStops(){stops.forEach(stop=>{try{stop?.()}catch{}});stops=[];if(mapClock){clearInterval(mapClock);mapClock=null}}
function jakartaDay(){return new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Jakarta',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date())}
function baseShared(){return{savingName:'Dana Kencan Impian',savingTarget:0,weeklyTarget:0,savingAccountNumber:'901427834591',savingTotal:0,points:0,pointsByUser:{},dailyMissionDate:'',dailyMissions:{},rewards:defaultRewards(),deposits:[],claims:[],tripExpenses:[],tripItinerary:[],tripChecklist:[],tripPresence:null}}
function sharedPairIds(){return[state.uid,state.partner?.uid].filter(Boolean).sort()}
function sharedBackupKey(){const ids=sharedPairIds();return ids.length===2?`ac_shared_pair_${ids.join('_')}`:''}
function sharedHasContent(data={}){const wedding=data.weddingPlan||{},trip=data.tripPlan||{},weddingContent=!!(wedding.weddingDate||Number(wedding.totalBudget)>0||['budgetItems','seserahan','guests','checklist','vendors','activityLog'].some(key=>Array.isArray(wedding[key])&&wedding[key].length)||(wedding.savings&&(Number(wedding.savings.target)>0||Number(wedding.savings.saved)>0||wedding.savings.deposits?.length))),tripContent=!!(trip.origin||trip.destination||trip.startDate||Number(trip.budget)>0||Number(trip.saved)>0||Number(trip.actual)>0);return Number(data.points)>0||Number(data.savingTarget)>0||Number(data.savingTotal)>0||Object.values(data.pointsByUser||{}).some(Number)||['rewards','claims','deposits','tripExpenses','tripItinerary','tripChecklist'].some(key=>Array.isArray(data[key])&&data[key].length>0)||weddingContent||tripContent}
function cacheSharedBackup(data){const key=sharedBackupKey();if(!key||!sharedHasContent(data))return;try{localStorage.setItem(key,JSON.stringify({pair:sharedPairIds(),savedAt:new Date().toISOString(),data}))}catch{}}
function readSharedBackup(){const key=sharedBackupKey();if(!key)return null;try{const backup=JSON.parse(localStorage.getItem(key)||'null');return backup&&JSON.stringify(backup.pair)===JSON.stringify(sharedPairIds())&&sharedHasContent(backup.data)?backup.data:null}catch{return null}}
function demoShared(){return{savingName:'Liburan Impian ke Jepang',savingTarget:12_000_000,weeklyTarget:350_000,savingAccountNumber:'901427834591',savingTotal:3_650_000,points:2850,pointsByUser:{'demo-imam':1550,'demo-partner':1300},dailyMissionDate:jakartaDay(),dailyMissions:{'demo-imam':{online:true,expense:true,chat:true,location:true,savings:true},'demo-partner':{online:true,expense:true,chat:true}},rewards:defaultRewards(),deposits:[{id:'d1',amount:750_000,note:'Setoran awal bulan',by:'demo-imam',byName:'Imam',createdAt:new Date(Date.now()-dayMs).toISOString()},{id:'d2',amount:500_000,note:'Bonus proyek',by:'demo-partner',byName:'Pasangan Demo',createdAt:new Date(Date.now()-3*dayMs).toISOString()},{id:'d3',amount:250_000,note:'Hemat makan siang',by:'demo-imam',byName:'Imam',createdAt:new Date(Date.now()-6*dayMs).toISOString()}],claims:[{id:'c1',rewardName:'Movie night pilihanmu',cost:140,claimedBy:'demo-partner',claimedAt:new Date(Date.now()-5*dayMs).toISOString()}]}}
function demoMemories(){return[{id:'f1',photoUrl:'/assets/drive-gallery/memory-coffee.webp',title:'Ngopi sore di Bandung',place:'Bandung',date:new Date(Date.now()-dayMs).toISOString().slice(0,10),story:'Menemukan kafe kecil dengan pemandangan kota yang tenang.',lat:-6.9175,lng:107.6191,createdAt:new Date(Date.now()-dayMs)},{id:'f2',photoUrl:'/assets/drive-gallery/memory-picnic.webp',title:'Piknik akhir pekan',place:'Taman Kota',date:new Date(Date.now()-14*dayMs).toISOString().slice(0,10),story:'Membawa bekal sendiri dan ngobrol sampai matahari terbenam.',lat:-6.2,lng:106.8167,createdAt:new Date(Date.now()-14*dayMs)},{id:'f3',photoUrl:'/assets/drive-gallery/memory-sunset.webp',title:'Makan malam pertama',place:'Jakarta Selatan',date:new Date(Date.now()-45*dayMs).toISOString().slice(0,10),story:'Tempat sederhana yang selalu ingin kami kunjungi lagi.',lat:-6.2615,lng:106.8106,createdAt:new Date(Date.now()-45*dayMs)}]}
function demoLocations(){return{'demo-imam':{lat:-6.9147,lng:107.6098,sharing:true,expiresAt:new Date(Date.now()+3_600_000)},'demo-partner':{lat:-6.9217,lng:107.6071,sharing:true,expiresAt:new Date(Date.now()+2_400_000)}}}

/* Shared rewards and savings */
function renderShared(){
  shared={...baseShared(),...shared,rewards:mergedRewards(shared.rewards),deposits:shared.deposits||[],claims:shared.claims||[],pointsByUser:shared.pointsByUser||{}};
  const mine=Number(shared.pointsByUser?.[state.uid]??0),partner=Number(shared.pointsByUser?.[state.partner?.uid]??0);setText('#cv-header-me-points',formatNumber(mine));setText('#cv-header-partner-points',formatNumber(partner));
  renderRewards();renderSavings();
}
function demoLocationHistory(){return[{id:'lh1',uid:'demo-imam',name:'Imam',lat:-6.9147,lng:107.6098,accuracy:18,sharedMinutes:60,createdAt:new Date(Date.now()-35*60_000)},{id:'lh2',uid:'demo-partner',name:'Pasangan Demo',lat:-6.9175,lng:107.6191,accuracy:24,sharedMinutes:60,createdAt:new Date(Date.now()-95*60_000)}]}
const rewardFilters=[['all','Semua'],['romantic','Romantis'],['date','Kencan'],['favor','Bantuan'],['custom','Buatan kami']];
function switchRewardMobileTab(tab='overview'){
  $$('[data-reward-mobile-tab]').forEach(button=>{const active=button.dataset.rewardMobileTab===tab;button.classList.toggle('active',active);button.setAttribute('aria-selected',String(active))});
  $$('[data-reward-mobile-panel]').forEach(panel=>panel.classList.toggle('active',panel.dataset.rewardMobilePanel===tab));
  $('#couple-rewards-feature')?.setAttribute('data-mobile-tab',tab);
}
function rewardIconHtml(item){const icon=String(item.icon||'');const match=icon.match(/^<i data-fa=\"([a-z0-9-]{1,32})\"><\/i>$/i);return match?`<i data-fa=\"${match[1]}\"></i>`:escapeHtml(icon||'\u{1F381}')}
function renderRewardFilters(){
  const box=$('#reward-filter-tabs');
  if(!box)return;
  box.innerHTML=rewardFilters.map(([value,label])=>`<button type="button" class="reward-filter-tab${rewardFilter===value?' active':''}" data-reward-filter="${value}">${label}</button>`).join('');
  $$('[data-reward-filter]',box).forEach(button=>button.onclick=()=>{rewardFilter=button.dataset.rewardFilter;renderRewards()});
}
function renderRewards(){
  const claims=shared.claims||[];
  const mine=Number(shared.pointsByUser?.[state.uid]??0);
  const partnerPoints=Number(shared.pointsByUser?.[state.partner?.uid]??0);
  const rewards=mergedRewards(shared.rewards);
  setText('#total-redeemable-points',formatNumber(mine));
  setText('#reward-user-points',formatNumber(mine));
  setText('#reward-partner-points',formatNumber(partnerPoints));
  setText('#claimed-rewards-count',formatNumber(claims.length));
  setText('#love-streak-days',formatNumber(loveStreakDays()));
  setText('#available-rewards-count',formatNumber(rewards.filter(item=>mine>=Number(item.cost||0)).length));
  renderDailyQuests();
  renderRewardFilters();
  const list=rewards.filter(item=>rewardFilter==='all'||(item.category||'custom')===rewardFilter);
  const box=$('#rewards-list');
  if(box){
    box.innerHTML=list.length?list.map(item=>{
      const cost=Number(item.cost)||0;
      const unlocked=mine>=cost;
      const progress=cost?Math.min(100,Math.round(mine/cost*100)):100;
      const claimed=claims.some(claim=>claim.rewardName===item.name);
      const tier=cost>=3500?'legendary':cost>=2500?'special':'sweet';
      const tierLabel=tier==='legendary'?'Legendary':tier==='special'?'Special':'Sweet';
      return `<article class="reward-pro-card reward-${tier}${unlocked?'':' locked'}${claimed?' claimed':''}">
        ${item.createdBy?`<button type="button" class="reward-delete-custom" data-reward-delete="${escapeHtml(item.id)}" aria-label="Hapus hadiah"><i data-fa="xmark"></i></button>`:''}
        <div class="reward-card-top">
          <span class="reward-card-icon">${rewardIconHtml(item)}</span>
          <div class="reward-card-title"><h4>${escapeHtml(item.name)}</h4><p>${escapeHtml(item.desc||'Hadiah manis untuk pasanganmu.')}</p><span class="reward-tag">${labelCategory(item.category)}</span><span class="reward-tier"><i data-fa="${tier==='legendary'?'crown':tier==='special'?'star':'heart'}"></i> ${tierLabel}</span></div>
          <span class="reward-cost"><i data-fa="gem"></i> ${formatNumber(cost)}</span>
        </div>
        <div class="reward-progress"><span style="width:${progress}%"></span></div>
        <div class="reward-card-footer">
          <span class="reward-progress-text">${unlocked?'Siap ditukar \u2728':`Kurang ${formatNumber(Math.max(0,cost-mine))} poin kamu`}</span>
          <button type="button" class="reward-redeem-btn" data-claim="${escapeHtml(item.id)}"${unlocked?'':' disabled'}>${unlocked?'Tukar':'Terkunci'}</button>
        </div>
      </article>`;
    }).join(''):'<div class="reward-empty-pro">Belum ada hadiah pada kategori ini.</div>';
  }
  setText('#cv-claim-summary',claims.length?`${claims.length} hadiah ditukar`:'Belum ada');
  const history=$('#cv-claim-history');
  if(history)history.innerHTML=claims.length?claims.slice(0,12).map(item=>`<div class="reward-history-item"><span>${escapeHtml(item.rewardName||'Hadiah')} \u00b7 ${escapeHtml(item.claimedByName||'Pasangan')} \u00b7 ${shortDate(item.claimedAt||item.createdAt)}</span><b>-${formatNumber(item.cost)} pt</b></div>`).join(''):'<div class="reward-empty-pro">Riwayat penukaran masih kosong.</div>';
  hydrateIconsIn($('#couple-rewards-feature'));
}
function renderDailyQuests(){
  const active=shared.dailyMissionDate===jakartaDay()?shared.dailyMissions||{}:{},mine=active[state.uid]||{},partner=active[state.partner?.uid]||{},actions=['online','expense','chat','location','savings'],done=actions.filter(action=>mine[action]).length,partnerDone=actions.filter(action=>partner[action]).length;
  setText('#reward-daily-progress',`${done}/5`);setText('#reward-partner-mission-count',`${partnerDone}/5 misi pasangan selesai`);
  $$('[data-reward-mission]').forEach(card=>{const complete=!!mine[card.dataset.rewardMission];card.classList.toggle('done',complete);card.classList.toggle('pending',!complete);card.setAttribute('aria-label',`${card.querySelector('b')?.textContent||'Misi'} ${complete?'selesai':'belum selesai'}`)});
}
function loveStreakDays(){
  const days=new Set();
  [...(shared.deposits||[]),...(shared.claims||[])].forEach(item=>{
    const time=new Date(item.createdAt?.toDate?.()||item.createdAt||item.claimedAt||0).getTime();
    if(time)days.add(new Date(time).toDateString());
  });
  let streak=0;
  for(let index=0;index<180;index+=1){
    const key=new Date(Date.now()-index*dayMs).toDateString();
    if(days.has(key))streak+=1;else if(index>0)break;
  }
  return streak;
}
function toggleRewardCustomForm(){
  const form=$('#reward-custom-form');
  if(!form)return;
  form.classList.toggle('hidden');
  if(!form.classList.contains('hidden'))$('#reward-custom-title')?.focus();
}
async function createReward(event){
  event.preventDefault();
  const name=$('#reward-custom-title').value.trim();
  const cost=Math.round(Number($('#reward-custom-cost').value)||0);
  const icon='<i data-fa="gift"></i>';
  const desc=$('#reward-custom-desc').value.trim();
  if(!name)return notify('Nama hadiah wajib diisi');
  if(cost<1000||cost>4000)return notify('Biaya hadiah harus 1.000 sampai 4.000 koin');
  if(state.demo){
    shared.rewards=[...(shared.rewards||defaultRewards()),{id:crypto.randomUUID(),name,cost,category:'custom',icon,desc,createdBy:state.uid}];
    renderShared();event.target.reset();event.target.classList.add('hidden');
    return notify('Hadiah custom ditambahkan');
  }
  try{
    await api.serverCreateSharedReward(name,cost,'custom');
    event.target.reset();event.target.classList.add('hidden');
    notify('Hadiah baru tersinkron');
  }catch(error){notify(error.message||'Hadiah gagal dibuat')}
}
function rewardConfetti(){
  const emojis=['\u{1F389}','\u{1F49D}','\u2728','\u{1F381}','\u{1F495}'];
  for(let index=0;index<14;index+=1){
    const piece=document.createElement('span');
    piece.className='reward-confetti';
    piece.textContent=emojis[index%emojis.length];
    piece.style.left=`${10+Math.random()*80}vw`;
    piece.style.top=`${40+Math.random()*30}vh`;
    piece.style.animationDelay=`${Math.random()*250}ms`;
    document.body.appendChild(piece);
    setTimeout(()=>piece.remove(),1400);
  }
}
async function handleRewardsClick(event){
  const removeButton=event.target.closest('[data-reward-delete]');
  if(removeButton){
    const id=removeButton.dataset.rewardDelete;
    if(!confirm('Hapus hadiah custom ini?'))return;
    shared.rewards=(shared.rewards||[]).filter(item=>item.id!==id);
    renderRewards();
    return notify('Hadiah custom dihapus');
  }
  const button=event.target.closest('[data-claim]');
  if(!button)return;
  const rewards=mergedRewards(shared.rewards);
  const reward=rewards.find(item=>item.id===button.dataset.claim);
  if(!reward)return;
  const myPoints=Number(shared.pointsByUser?.[state.uid]??0);
  if(myPoints<Number(reward.cost))return notify('Love Points kamu belum cukup (poin tidak digabung dengan pasangan)');
  if(!confirm(`Tukar ${reward.cost} Love Points kamu untuk \u201c${reward.name}\u201d?`))return;
  if(state.demo){
    shared.pointsByUser={...(shared.pointsByUser||{}),[state.uid]:myPoints-Number(reward.cost)};
    shared.points=Math.max(0,Number(shared.points||0)-Number(reward.cost));
    shared.claims.unshift({id:crypto.randomUUID(),rewardName:reward.name,cost:reward.cost,claimedBy:state.uid,claimedByName:firstName(state.user?.displayName||'Imam'),claimedAt:new Date().toISOString()});
    renderShared();rewardConfetti();window.dispatchEvent(new CustomEvent('appcouple:reward-claimed',{detail:{name:reward.name,cost:reward.cost}}));
    return notify('Hadiah berhasil ditukar \u{1F49D}');
  }
  try{
    await api.serverClaimSharedReward(reward.id,{name:reward.name,cost:reward.cost,category:reward.category});
    await api.sendCoupleActivity(state.chatId,'reward','Hadiah berhasil ditukar',reward.name);await api.sendChatMessage(state.chatId,`🎁 ${firstName(state.user?.displayName||'Kamu')} menukar hadiah “${reward.name}” seharga ${formatNumber(reward.cost)} Love Points.`);
    rewardConfetti();
    notify('Hadiah berhasil ditukar \u{1F49D}');
  }catch(error){notify(error.message||'Penukaran gagal')}
}
function weekStartMs(){const now=new Date();const day=(now.getDay()+6)%7;now.setHours(0,0,0,0);return now.getTime()-day*dayMs}
function depositTime(item){return new Date(item?.createdAt?.toDate?.()||item?.createdAt||0).getTime()}
function renderSavings(){
  const deposits=shared.deposits||[],total=Number(shared.savingTotal)||0,target=Number(shared.savingTarget)||0,weekly=Number(shared.weeklyTarget)||0,weekStart=weekStartMs();
  const weekDeposits=deposits.filter(item=>depositTime(item)>=weekStart),weekTotal=weekDeposits.reduce((sum,item)=>sum+Number(item.amount||0),0);
  const totalPercent=target?Math.min(100,total/target*100):0,weekPercent=weekly?Math.min(100,weekTotal/weekly*100):0,daysLeft=Math.max(0,7-Math.ceil((Date.now()-weekStart)/dayMs));
  const myName=firstName(state.user?.displayName||'Kamu'),partnerName=firstName(state.partner?.displayName||'Pasangan');
  const mine=deposits.filter(item=>item.by===state.uid).reduce((sum,item)=>sum+Number(item.amount||0),0),partnerTotal=Math.max(0,total-mine);
  const mineWeek=weekDeposits.filter(item=>item.by===state.uid).reduce((sum,item)=>sum+Number(item.amount||0),0),partnerWeek=Math.max(0,weekTotal-mineWeek);
  const series=savingsWeeklySeries(deposits,8),pace=savingsPace(series,weekTotal),monthly=Math.round(pace*4.345),remaining=Math.max(0,target-total),forecast=savingsForecast(total,target,pace);
  setText('#sb-hero-badge',shared.savingName||'Dana Kencan Impian');
  setText('#sb-account-number',shared.savingAccountNumber||'Belum diatur');
  setText('#sv2-total-amount',money(total));setText('#sv2-total-target',target?money(target):'Target belum diatur');
  setText('#sv2-total-progress-label',target?`${Math.round(totalPercent)}% tercapai`:'Mulai dari langkah pertama');
  setText('#sv2-total-remaining',target?(remaining?`${money(remaining)} lagi`:'Target tercapai'):'Atur target bersama');
  const totalFill=$('#sv2-total-progress');if(totalFill)totalFill.style.width=`${totalPercent}%`;
  $$('[data-sv2-milestone]').forEach(node=>node.classList.toggle('done',totalPercent>=Number(node.dataset.sv2Milestone)));
  setText('#sv2-forecast-date',forecast);setText('#sv2-saving-pace',`${money(pace)} / minggu`);
  setText('#sb-balance-amount',money(weekTotal));setText('#sb-balance-target',weekly?`Target ${money(weekly)} per minggu`:'Target mingguan belum diatur');
  const weekFill=$('#sb-progress-fill');if(weekFill)weekFill.style.width=`${weekPercent}%`;
  setText('#sb-progress-pct',`${Math.round(weekPercent)}%`);setText('#sb-days-left',daysLeft?`${daysLeft} hari tersisa`:'Berakhir hari ini');
  const weekRemaining=Math.max(0,weekly-weekTotal);setText('#sv2-weekly-remaining',weekly?(weekRemaining?`${money(weekRemaining)} lagi`:'Target tercapai'):'Atur target mingguan');
  const suggested=weekly&&weekRemaining?Math.ceil(weekRemaining/Math.max(1,daysLeft)/1000)*1000:0;
  setText('#sv2-next-deposit',suggested?`${money(suggested)} per hari`:(weekly?'Minggu ini sudah aman':'Atur target dahulu'));
  setText('#sb-target-btn-label',target||weekly?'Kelola target':'Atur target');
  const reached=weekly?weekTotal>=weekly:target>0&&total>=target,warn=$('#sb-warning-bar'),celebrate=$('#sb-celebrate-bar');
  warn?.classList.toggle('hidden',reached||!weekly);celebrate?.classList.toggle('hidden',!reached);
  if(weekly)setText('#sb-warning-text',`Masih ${money(weekRemaining)} menuju target minggu ini.`);
  setText('#sb-couple-names',`${myName} & ${partnerName}`);setText('#sb-couple-av-user-initial',initialOf(myName));setText('#sb-couple-av-partner-initial',initialOf(partnerName));
  const connected=Boolean(state.partner?.uid)||state.demo,pill=$('#sb-connected-pill');pill?.classList.toggle('not-connected',!connected);setText('#sb-connected-pill-text',connected?'Sinkron aktif':'Belum terhubung');
  setChipState('user1',myName,mineWeek);setChipState('user2',partnerName,partnerWeek);
  const minePct=total?Math.round(mine/total*100):50,ring=$('#sv2-contribution-ring');ring?.style.setProperty('--sv2-mine',minePct);
  setText('#sv2-mine-pct',`${minePct}%`);setText('#sv2-mine-name',myName);setText('#sv2-partner-name',partnerName);setText('#sv2-mine-total',money(mine));setText('#sv2-partner-total',money(partnerTotal));
  const delta=Math.abs(mine-(partnerTotal)),balanced=total>0&&delta/total<=.2;
  setText('#sv2-fairness-title',total?balanced?'Ritme kalian seimbang':'Kontribusi tetap satu tujuan':'Mulai ritme bersama');
  setText('#sv2-fairness-text',total?balanced?'Selisih kontribusi berada dalam rentang yang sehat.':'Tidak harus sama besar—yang penting disepakati dan konsisten.':'Setoran pertama akan membentuk ring kontribusi kalian.');
  setText('#sb-stat-total',money(total));setText('#sv2-monthly-average',money(monthly));setText('#sb-stat-mine',money(mine));setText('#sb-stat-partner',money(partnerTotal));setText('#sb-stat-streak',`${savingStreak(deposits)} minggu`);
  setText('#sb-motivasi-text',reached?'Target minggu ini tercapai. Pertahankan ritme tanpa memaksakan diri.':weekly?`Cukup ${money(weekRemaining)} lagi. Pecah menjadi nominal kecil yang nyaman.`:'Tentukan target mingguan agar progres lebih mudah dijaga.');
  renderSavingsChart(series,weekly);renderSavingsInsight({total,target,weekly,weekTotal,weekRemaining,daysLeft,pace,reached});renderDeposits();updateDepositPreview();
  window.__appCoupleSavingsSummary={total,target,weekly,weekTotal,weekPercent,totalPercent,pace,streak:savingStreak(deposits)};
  window.dispatchEvent(new CustomEvent('appcouple:savings-update',{detail:window.__appCoupleSavingsSummary}));
  hydrateIconsIn($('#couple-savings-feature'));
}
function setText(selector,value){const node=$(selector);if(node)node.textContent=value}
function setChipState(slot,name,amount){
  setText(`#sb-name-${slot}`,name);const dot=$(`#sb-dot-${slot}`),stateNode=$(`#sb-state-${slot}`),done=amount>0;dot?.classList.toggle('done',done);
  if(stateNode){stateNode.textContent=done?money(amount):'Belum setor';stateNode.classList.toggle('done-text',done)}
}
function savingStreak(deposits){let streak=0;for(let index=0;index<26;index+=1){const start=weekStartMs()-index*7*dayMs,end=start+7*dayMs,has=deposits.some(item=>{const time=depositTime(item);return time>=start&&time<end});if(has)streak+=1;else if(index>0)break}return streak}
function savingsWeeklySeries(deposits,count=8){const start=weekStartMs();return Array.from({length:count},(_,index)=>{const offset=count-1-index,from=start-offset*7*dayMs,to=from+7*dayMs,items=deposits.filter(item=>{const time=depositTime(item);return time>=from&&time<to}),date=new Date(from);return{from,total:items.reduce((sum,item)=>sum+Number(item.amount||0),0),mine:items.filter(item=>item.by===state.uid).reduce((sum,item)=>sum+Number(item.amount||0),0),label:new Intl.DateTimeFormat('id-ID',{day:'numeric',month:'short'}).format(date),current:offset===0}})}
function savingsPace(series,weekTotal){const completed=series.slice(0,-1).map(item=>item.total).filter(Boolean),average=completed.length?completed.reduce((sum,value)=>sum+value,0)/completed.length:0;return Math.round(Math.max(weekTotal,average)/1000)*1000}
function savingsForecast(total,target,pace){if(!target)return'Atur target';if(total>=target)return'Target tercapai selesai';if(!pace)return'Mulai menabung';const weeks=Math.min(520,Math.ceil((target-total)/pace)),date=new Date(Date.now()+weeks*7*dayMs);return new Intl.DateTimeFormat('id-ID',{month:'short',year:'numeric'}).format(date)}
function renderSavingsChart(series,weekly){const box=$('#sv2-chart');if(!box)return;const max=Math.max(weekly,...series.map(item=>item.total),1);box.innerHTML=series.map(item=>{const height=item.total?Math.max(10,item.total/max*100):4;return `<div class="sv2-bar-col${item.current?' current':''}" title="${escapeHtml(item.label)} · ${money(item.total)}"><span><i style="height:${height}%"></i></span><small>${escapeHtml(item.label)}</small></div>`}).join('');const values=series.map(item=>item.total).filter(Boolean),average=values.length?values.reduce((sum,value)=>sum+value,0)/values.length:0;setText('#sv2-chart-average',`Rata-rata ${money(average)}`)}
function renderSavingsInsight(data){let title='Tentukan ritme yang terasa ringan',text='Target mingguan membantu kalian membagi mimpi besar menjadi langkah yang dapat dilakukan.';if(data.target&&data.total>=data.target){title='Mimpi ini sudah tercapai ';text='Rayakan pencapaian, lalu sepakati apakah saldo digunakan atau dipindahkan ke tujuan baru.'}else if(data.reached){title='Target minggu ini aman';text=`Dengan ritme sekitar ${money(data.pace)} per minggu, kalian sedang bergerak konsisten menuju tujuan.`}else if(data.weekly&&data.weekRemaining){const daily=Math.ceil(data.weekRemaining/Math.max(1,data.daysLeft)/1000)*1000;title=`Satu langkah terbaik: ${money(daily)} per hari`;text='Nominal kecil dan konsisten biasanya lebih mudah dijaga daripada mengejar semuanya di akhir minggu.'}else if(data.pace){title='Ritme mulai terbentuk';text=`Kecepatan saat ini sekitar ${money(data.pace)} per minggu. Tetapkan target agar prediksi menjadi lebih akurat.`}setText('#sv2-insight-title',title);setText('#sv2-insight-text',text)}
function filteredDeposits(){let items=shared.deposits||[];if(depositFilter==='week')items=items.filter(item=>depositTime(item)>=weekStartMs());if(depositFilter==='mine')items=items.filter(item=>item.by===state.uid);if(depositFilter==='partner')items=items.filter(item=>item.by!==state.uid);if(depositQuery)items=items.filter(item=>`${item.byName||''} ${item.note||''} ${item.amount||''}`.toLowerCase().includes(depositQuery));return[...items].sort((a,b)=>depositTime(b)-depositTime(a))}
function renderDeposits(){const items=filteredDeposits();setText('#sb-history-count',String(items.length));const box=$('#deposit-history');if(!box)return;box.innerHTML=items.length?items.slice(0,50).map(item=>{const mine=item.by===state.uid,name=escapeHtml(item.byName||(mine?'Kamu':'Pasangan')),date=new Intl.DateTimeFormat('id-ID',{day:'numeric',month:'short',year:'numeric'}).format(new Date(depositTime(item)||Date.now()));return `<article class="sb-history-item"><span class="sb-history-icon ${mine?'mine':'partner'}">${escapeHtml(initialOf(item.byName||(mine?'K':'P')))}</span><div class="sb-history-info"><span class="sb-history-name">${name}<i>${mine?'Kamu':'Pasangan'}</i></span><span class="sb-history-date">${escapeHtml(item.note||'Setoran Celengan Cinta')} · ${date}</span></div><span class="sb-history-amount">+${money(item.amount)}</span></article>`}).join(''):'<div class="sb-history-empty"><span><i data-fa="piggy-bank"></i></span><b>Tidak ada setoran ditemukan</b><small>Ubah filter atau cari catatan lain.</small></div>'}
function selectSavingsAmount(button){const input=$('#sb-nominal-input');if(input)input.value=button.dataset.amt;$$('#sb-quick-amounts [data-amt]').forEach(item=>item.classList.toggle('active',item===button));input?.focus();updateDepositPreview()}
function clearSavingsAmountSelection(){$$('#sb-quick-amounts [data-amt]').forEach(item=>item.classList.remove('active'))}
function updateDepositPreview(){const amount=Math.max(0,Math.round(Number($('#sb-nominal-input')?.value)||0)),after=(Number(shared.savingTotal)||0)+amount,claimed=shared.dailyMissionDate===jakartaDay()&&shared.dailyMissions?.[state.uid]?.savings,points=amount&&!claimed?25:0;setText('#sv2-deposit-preview',money(after));setText('#sv2-points-preview',claimed?'Poin Celengan hari ini sudah diklaim':`+${points} Love Points · 1× sehari`)}
function switchSavingsMobileTab(name='summary'){const allowed=['summary','deposit','progress','history'],next=allowed.includes(name)?name:'summary';$$('[data-savings-mobile-tab]').forEach(button=>{const active=button.dataset.savingsMobileTab===next;button.classList.toggle('active',active);button.setAttribute('aria-selected',String(active))});$$('[data-savings-pane]').forEach(pane=>pane.classList.toggle('sv2-mobile-hidden',pane.dataset.savingsPane!==next));const shell=$('#couple-savings-feature');if(shell)shell.dataset.savingsTab=next}
async function addDeposit(){
  const input=$('#sb-nominal-input'),noteInput=$('#sb-note-input'),amount=Math.round(Number(input?.value)||0),note=String(noteInput?.value||'').trim().slice(0,100)||`Setoran ${new Intl.DateTimeFormat('id-ID',{day:'2-digit',month:'short'}).format(new Date())}`;
  if(amount<1000)return notify('Masukkan nominal minimal Rp1.000');if(amount>1_000_000_000)return notify('Nominal terlalu besar');const button=$('#sb-confirm-btn');if(button)button.disabled=true;
  try{let points=0;if(state.demo){const already=shared.dailyMissionDate===jakartaDay()&&shared.dailyMissions?.[state.uid]?.savings;points=already?0:25;shared.savingTotal=(Number(shared.savingTotal)||0)+amount;shared.points=(Number(shared.points)||0)+points;shared.pointsByUser[state.uid]=(shared.pointsByUser[state.uid]||0)+points;shared.dailyMissionDate=jakartaDay();shared.dailyMissions={...(shared.dailyMissions||{}),[state.uid]:{...(shared.dailyMissions?.[state.uid]||{}),savings:true}};shared.deposits.unshift({id:crypto.randomUUID(),amount,note,by:state.uid,byName:firstName(state.user?.displayName||'Imam'),createdAt:new Date().toISOString()});renderShared()}else{const result=await api.addSharedDeposit(state.chatId,amount,note);points=result.pointsAwarded||0;api.sendCoupleActivity?.(state.chatId,'savings','Setoran baru',`${money(amount)} · ${note}`).catch(()=>{})}if(input)input.value='';if(noteInput)noteInput.value='';clearSavingsAmountSelection();updateDepositPreview();showSavingsCelebration();notify(points?`Setoran masuk · +${points} Love Points`:'Setoran masuk · poin harian sudah diklaim');if(button){button.classList.add('confirmed');setText('#sb-confirm-label','Setoran tersimpan');setTimeout(()=>{button.classList.remove('confirmed');setText('#sb-confirm-label','Simpan setoran')},1800)}}catch(error){console.error('Simpan setoran:',error);notify(error.message||'Setoran gagal disimpan')}finally{if(button)button.disabled=false}
}
function showSavingsCelebration(){const box=$('#sv2-celebration');if(!box)return;box.innerHTML=Array.from({length:14},(_,index)=>`<i style="--x:${(index*37)%100}%;--d:${index%5};--r:${index*29}deg"></i>`).join('');box.classList.remove('play');requestAnimationFrame(()=>box.classList.add('play'));setTimeout(()=>box.classList.remove('play'),1500)}
function openSavingsTarget(){const modal=$('#sv2-target-modal');$('#sv2-target-name').value=shared.savingName||'Dana Kencan Impian';$('#sv2-target-total').value=Number(shared.savingTarget)||12_000_000;$('#sv2-target-weekly').value=Number(shared.weeklyTarget)||350_000;updateTargetDuration();modal.classList.remove('hidden');setTimeout(()=>$('#sv2-target-name').focus(),50)}
function closeSavingsTarget(){$('#sv2-target-modal').classList.add('hidden')}
function updateTargetDuration(){const total=Math.max(0,Number($('#sv2-target-total')?.value)||0),weekly=Math.max(0,Number($('#sv2-target-weekly')?.value)||0),remaining=Math.max(0,total-(Number(shared.savingTotal)||0));if(!total||!weekly)return setText('#sv2-target-duration','Isi target dan nominal mingguan');const weeks=Math.ceil(remaining/weekly);setText('#sv2-target-duration',remaining?`Sekitar ${weeks} minggu · ${savingsForecast(Number(shared.savingTotal)||0,total,weekly)}`:'Target sudah tercapai')}
async function commitSavingsTarget(event){event.preventDefault();const name=String($('#sv2-target-name')?.value||'').trim().slice(0,60),target=Math.round(Number($('#sv2-target-total')?.value)||0),weeklyTarget=Math.round(Number($('#sv2-target-weekly')?.value)||0),button=$('#sv2-target-save');if(!name)return notify('Nama target wajib diisi');if(target<1000||target>10_000_000_000)return notify('Target total tidak valid');if(weeklyTarget<1000||weeklyTarget>1_000_000_000)return notify('Target mingguan tidak valid');button.disabled=true;try{if(state.demo){shared.savingName=name;shared.savingTarget=target;shared.weeklyTarget=weeklyTarget;renderShared()}else await api.saveSharedTarget(state.chatId,name,target,weeklyTarget);closeSavingsTarget();notify(state.demo?'Target demo diperbarui':'Target tersinkron ke pasangan')}catch(error){console.error('Simpan target:',error);notify(error.message||'Target gagal disimpan')}finally{button.disabled=false}}
function saveTarget(){openSavingsTarget()}
function openSavingsAccount(){const modal=$('#sv2-account-modal'),input=$('#sv2-account-input');input.value=String(shared.savingAccountNumber||'').replace(/\D/g,'');modal.classList.remove('hidden');setTimeout(()=>input.focus(),50)}
function closeSavingsAccount(){$('#sv2-account-modal').classList.add('hidden')}
async function commitSavingsAccount(event){event.preventDefault();const number=String($('#sv2-account-input')?.value||'').replace(/\D/g,'').slice(0,30),button=$('#sv2-account-save');if(number.length<6)return notify('Nomor rekening minimal 6 digit');button.disabled=true;try{if(state.demo){shared.savingAccountNumber=number;renderShared()}else await api.saveSharedAccountNumber(state.chatId,number);closeSavingsAccount();notify(state.demo?'Nomor rekening demo diperbarui':'Nomor rekening tersinkron ke pasangan')}catch(error){console.error('Simpan rekening:',error);notify(error.message||'Nomor rekening gagal disimpan')}finally{button.disabled=false}}
function copyAccountNumber(){const number=$('#sb-account-number')?.textContent?.trim()||'',button=$('#sb-copy-btn');navigator.clipboard?.writeText(number).then(()=>{notify('Nomor rekening disalin');button?.classList.add('copied');setTimeout(()=>button?.classList.remove('copied'),1600)}).catch(()=>notify('Gagal menyalin nomor rekening'))}
function exportSavingsCsv(){const items=[...(shared.deposits||[])].sort((a,b)=>depositTime(b)-depositTime(a));if(!items.length)return notify('Belum ada setoran untuk diekspor');const quote=value=>`"${String(value??'').replace(/"/g,'""')}"`,rows=[['Tanggal','Nama','Catatan','Nominal'],...items.map(item=>[new Date(depositTime(item)||Date.now()).toLocaleString('id-ID'),item.byName||'',item.note||'',Number(item.amount)||0])],csv='\ufeff'+rows.map(row=>row.map(quote).join(',')).join('\n'),blob=new Blob([csv],{type:'text/csv;charset=utf-8'}),url=URL.createObjectURL(blob),link=document.createElement('a');link.href=url;link.download=`tabungan-couple-${new Date().toISOString().slice(0,10)}.csv`;link.click();setTimeout(()=>URL.revokeObjectURL(url),500);notify('Riwayat CSV berhasil dibuat')}
function appendSavingsBubble(role,html){const box=$('#savings-ai-messages');if(!box)return null;const bubble=document.createElement('div');bubble.className=`savings-ai-bubble ${role==='user'?'ai-bubble-user':'ai-bubble-bot'}`;bubble.innerHTML=`<span class="bubble-avatar ${role==='user'?'account-user-avatar':''}">${role==='user'?initialOf(state.user?.displayName||'K'):'<i data-fa="brain"></i>'}</span><div class="bubble-text">${html}</div>`;box.appendChild(bubble);box.scrollTop=box.scrollHeight;hydrateIconsIn(bubble);return bubble}
async function sendSavingsAi(text){const input=$('#savings-ai-input'),question=(text||input?.value||'').trim();if(!question)return;if(input&&!text)input.value='';appendSavingsBubble('user',escapeHtml(question));const dot=$('#savings-ai-dot');dot?.classList.add('typing');setText('#savings-ai-label','Menganalisis…');const pending=appendSavingsBubble('bot','<span class="savings-ai-typing"><span></span><span></span><span></span></span>');try{let reply;const context=JSON.stringify({savingName:shared.savingName,savingTotal:shared.savingTotal,savingTarget:shared.savingTarget,weeklyTarget:shared.weeklyTarget,depositCount:(shared.deposits||[]).length,streak:savingStreak(shared.deposits||[])});if(state.demo){await wait(700);reply=demoAiReply('savings')}else reply=(await aiChat(`${question}\n\nData agregat tabungan pasangan: ${context}`,aiScopes())).reply;if(pending)pending.querySelector('.bubble-text').innerHTML=formatAiText(reply)}catch(error){if(pending)pending.querySelector('.bubble-text').textContent=error.message||'AI belum tersedia saat ini.'}finally{dot?.classList.remove('typing');setText('#savings-ai-label','Siap membantu');const box=$('#savings-ai-messages');if(box)box.scrollTop=box.scrollHeight}}

async function copyCoupleId(){try{await navigator.clipboard.writeText(state.chatId);notify('ID Couple disalin')}catch{notify('Tidak dapat menyalin ID Couple')}}

/* Games — Roulette berdua (Makan Apa? & Kemana?) */
const foodPool=[['🍜','Mie Ayam'],['🍲','Bakso'],['🍳','Nasi Goreng'],['🌶️','Seblak'],['🍕','Pizza'],['🍗','Ayam Geprek'],['🍣','Sushi'],['🥘','Rendang'],['🍛','Nasi Padang'],['🥙','Kebab'],['🍔','Burger'],['🦐','Seafood']];
const placePool=[['🌳','Taman Kota'],['☕','Kafe Baru'],['🎬','Bioskop'],['🏛️','Museum'],['🌙','Jalan Malam'],['🧺','Piknik'],['🏖️','Pantai'],['🛍️','Mall'],['⛰️','Gunung'],['📚','Toko Buku'],['🎡','Taman Hiburan'],['🍽️','Restoran Baru']];
const wheelConfig={
  food:{key:'food',title:'Makan Apa?',pool:foodPool,defaultEmoji:'🍽️',subs:['Selamat makan berdua!','Pilihan hari ini sudah keluar!','Jangan lupa foto bareng ya','Traktir pasanganmu ya']},
  place:{key:'place',title:'Kemana?',pool:placePool,defaultEmoji:'📍',subs:['Selamat jalan-jalan!','Siap-siap kencan seru!','Jangan lupa dokumentasi','Hati-hati di jalan ya']}
};
let wheelSpinning={food:false,place:false};
let wheelCustom={food:[],place:[]};
let wheelHistory={food:[],place:[]};
let currentGamePanel=null;
let lastRemoteSpinId=null;

function loadWheelLocal(){
  try{
    wheelCustom={food:JSON.parse(localStorage.getItem('ac_game_custom_food')||'[]'),place:JSON.parse(localStorage.getItem('ac_game_custom_place')||'[]')};
    wheelHistory={food:JSON.parse(localStorage.getItem('ac_game_hist_food')||'[]'),place:JSON.parse(localStorage.getItem('ac_game_hist_place')||'[]')};
  }catch{wheelCustom={food:[],place:[]};wheelHistory={food:[],place:[]}}
}
function saveWheelLocal(kind){
  try{
    localStorage.setItem(`ac_game_custom_${kind}`,JSON.stringify(wheelCustom[kind]||[]));
    localStorage.setItem(`ac_game_hist_${kind}`,JSON.stringify((wheelHistory[kind]||[]).slice(0,8)));
  }catch{}
}
function wheelOptions(kind){
  const config=wheelConfig[kind];
  const custom=(wheelCustom[kind]||[]).map(label=>[config.defaultEmoji,label]);
  return [...config.pool,...custom];
}
function openGamePanel(panelId){
  const isWorld=panelId==='game-our-world';
  const kind=isWorld?'world':panelId==='game-food'?'food':'place';
  currentGamePanel=kind;
  $('#game-hub-lobby').classList.add('hidden');
  $('#back-to-lobby-btn').classList.remove('hidden');
  $('#game-panels-container').classList.remove('hidden');
  $$('#game-panels-container .game-panel').forEach(panel=>panel.classList.toggle('hidden',panel.id!==panelId));
  $('#game-main-title').querySelector('h3').textContent=isWorld?'Our Little World':wheelConfig[kind].title;
  setGameSyncStatus(isWorld?'Dunia kalian · Live':'Live berdua');
  if(isWorld){window.dispatchEvent(new CustomEvent('appcouple:our-world-open'));return}
  buildWheel(kind);renderCustomTags(kind);renderWheelHistory(kind);
  if(gameState?.mode===kind&&gameState.result)showWheelResult(kind,gameState.emoji||wheelConfig[kind].defaultEmoji,gameState.result,gameState.sub||'',false);
}
function closeGamePanel(){
  const closingWorld=currentGamePanel==='world';
  currentGamePanel=null;
  $('#game-panels-container').classList.add('hidden');
  $('#back-to-lobby-btn').classList.add('hidden');
  $$('#game-panels-container .game-panel').forEach(panel=>panel.classList.add('hidden'));
  $('#game-hub-lobby').classList.remove('hidden');
  $('#game-main-title').querySelector('h3').innerHTML='Game Pasangan <i data-fa="heart"></i>';hydrateIconsIn($('#game-main-title'));
  setGameSyncStatus('Live berdua');
  if(closingWorld)window.dispatchEvent(new CustomEvent('appcouple:our-world-close'));
}
function buildWheel(kind){
  const inner=$(`#${kind}-roulette-inner`);
  const options=wheelOptions(kind);
  const loops=[...options,...options,...options,...options];
  inner.style.transition='none';
  inner.style.transform='translateY(0)';
  inner.innerHTML=loops.map(([emoji,label])=>`<div class="roulette-segment"><span class="seg-emoji">${escapeHtml(emoji)}</span><span class="seg-label">${escapeHtml(label)}</span></div>`).join('');
}
function renderCustomTags(kind){
  const box=$(`#${kind}-custom-tags`);
  const list=wheelCustom[kind]||[];
  box.innerHTML=list.length?list.map((label,index)=>`<span class="custom-tag">${escapeHtml(label)}<button type="button" class="remove-tag-btn" data-remove-${kind}="${index}" aria-label="Hapus"><i data-fa="xmark"></i></button></span>`).join(''):'';
  $$(`[data-remove-${kind}]`,box).forEach(button=>button.onclick=()=>{
    wheelCustom[kind].splice(Number(button.dataset[kind==='food'?'removeFood':'removePlace']),1);
    saveWheelLocal(kind);renderCustomTags(kind);buildWheel(kind);
  });
  hydrateIconsIn(box);
}
function renderWheelHistory(kind){
  const box=$(`#${kind}-history`);
  const list=wheelHistory[kind]||[];
  box.innerHTML=list.length?list.slice(0,8).map(item=>`<li><span>${escapeHtml(item.emoji||'🎲')}</span><span>${escapeHtml(item.result||'')}</span><span>${escapeHtml(item.at||'')}</span></li>`).join(''):'<li class="game-history-empty">Belum ada spin. Coba putar sekarang!</li>';
}
function addCustomOption(kind){
  const input=$(`#custom-${kind}-input`);
  const value=(input.value||'').trim();
  if(!value)return;
  if((wheelCustom[kind]||[]).includes(value)){notify('Pilihan itu sudah ada');return}
  wheelCustom[kind]=[...(wheelCustom[kind]||[]),value].slice(0,12);
  input.value='';
  saveWheelLocal(kind);renderCustomTags(kind);buildWheel(kind);
  notify(`"${value}" ditambahkan ke roulette`);
}
function setGameSyncStatus(text,busy=false){
  setText('#game-sync-text',text||'Live berdua');
  const badge=$('#game-main-title .game-sync-badge');
  badge?.classList.toggle('spinning',!!busy);
}
function showWheelResult(kind,emoji,label,sub,animate=true){
  const box=$(`#${kind}-result`);
  $(`#${kind}-result-emoji`).textContent=emoji||'🎲';
  $(`#${kind}-result-text`).textContent=label;
  $(`#${kind}-result-sub`).textContent=sub||'';
  box.classList.remove('hidden');
  if(animate){box.classList.remove('result-pop');void box.offsetWidth;box.classList.add('result-pop')}
}
function spinWheel(kind,forcedResult=null,isRemote=false,remotePayload=null){
  if(wheelSpinning[kind])return;
  const config=wheelConfig[kind],options=wheelOptions(kind);
  if(!options.length)return;
  let index=forcedResult?options.findIndex(item=>item[1]===forcedResult):-1;
  if(index<0)index=Math.floor(Math.random()*options.length);
  const [emoji,label]=options[index];
  const sub=remotePayload?.sub||config.subs[Math.floor(Math.random()*config.subs.length)];
  const spinId=remotePayload?.spinId||`${Date.now()}-${Math.random().toString(36).slice(2,8)}`;
  wheelSpinning[kind]=true;
  const button=$(`#spin-${kind}-btn`),result=$(`#${kind}-result`),stage=$(`#game-${kind} .game-wheel-stage`);
  button.disabled=true;button.classList.add('is-spinning');
  result?.classList.add('hidden');stage?.classList.add('is-spinning');
  setGameSyncStatus(isRemote?'Pasangan sedang memutar…':'Menyinkronkan putaran…',true);
  if(!isRemote)syncGame({phase:'spinning',spinId,mode:kind,result:label,emoji,sub,options:options.map(item=>item[1]),createdBy:state.uid,createdAt:new Date().toISOString()});
  const inner=$(`#${kind}-roulette-inner`),wheel=inner.parentElement,selectedLoopIndex=options.length*3+index;
  const segment=inner.firstElementChild?.getBoundingClientRect().height||72;
  const target=Math.max(0,(selectedLoopIndex+.5)*segment-wheel.clientHeight/2);
  inner.querySelectorAll('.is-winning').forEach(node=>node.classList.remove('is-winning'));
  stage?.style.setProperty('--spin-seed',String(index));
  inner.style.transition='none';inner.style.transform='translate3d(0,0,0)';void inner.offsetWidth;
  inner.style.transition='transform 3.8s cubic-bezier(.12,.82,.16,1)';inner.style.transform=`translate3d(0,-${target}px,0)`;
  setTimeout(()=>{
    inner.children[selectedLoopIndex]?.classList.add('is-winning');
    showWheelResult(kind,emoji,label,isRemote?`Dipilih pasanganmu • ${sub}`:sub);
    wheelHistory[kind]=[{emoji,result:label,at:new Intl.DateTimeFormat('id-ID',{hour:'2-digit',minute:'2-digit'}).format(new Date())},...(wheelHistory[kind]||[])].slice(0,8);
    saveWheelLocal(kind);renderWheelHistory(kind);
    wheelSpinning[kind]=false;button.disabled=false;button.classList.remove('is-spinning');stage?.classList.remove('is-spinning');
    setGameSyncStatus(isRemote?'Hasil dari pasangan':'Tersinkron ke pasangan',false);
    if(!isRemote)syncGame({phase:'result',spinId,mode:kind,result:label,emoji,sub,options:options.map(item=>item[1]),createdBy:state.uid,createdAt:new Date().toISOString()});
    notify(`${isRemote?'Pasangan memilih':'Hasil'}: ${label}`);
    setTimeout(()=>setGameSyncStatus('Live berdua',false),2200);
  },3900);
}
function refreshSyncedGame(){
  if(!gameState?.mode||!gameState.result)return;
  const kind=gameState.mode;
  if(gameState.createdBy===state.uid)return;
  const live=$('#game-live-result');
  if(live)live.querySelector('small').textContent=`Terakhir: ${gameState.result} · dari pasangan`;
  if(currentGamePanel!==kind)return;
  if(gameState.phase==='spinning'){
    const spinId=gameState.spinId||gameState.updatedAt||gameState.createdAt;
    if(lastRemoteSpinId===spinId||wheelSpinning[kind])return;
    lastRemoteSpinId=spinId;
    spinWheel(kind,gameState.result,true,gameState);
    return;
  }
  if(!wheelSpinning[kind]){
    showWheelResult(kind,gameState.emoji||wheelConfig[kind].defaultEmoji,gameState.result,`Dipilih pasanganmu • ${gameState.sub||''}`.trim());
    setGameSyncStatus('Hasil dari pasangan');
  }
}
async function syncGame(next){
  gameState={...next,updatedAt:new Date().toISOString()};
  if(state.demo)return;
  try{
    await api.saveCoupleGame(state.chatId,next);
    await api.sendCoupleActivity(state.chatId,'game',`Game ${gameLabel(next.mode)}`,next.result||'Permainan diperbarui');
  }catch(error){notify(error.message||'Game gagal disinkronkan')}
}
function gameLabel(mode){return{food:'Makan Apa?',place:'Kemana?'}[mode]||'Pasangan'}
function hydrateIconsIn(root){import('./icons.js').then(module=>module.hydrateIcons?.(root||document)).catch(()=>{})}

/* Couple Map v4.1 controls — adapted from the supplied v41 map package. */
function toggleV41Search(force){const box=$('#v41-map-search'),open=typeof force==='boolean'?force:box.classList.contains('hidden');box.classList.toggle('hidden',!open);if(open)setTimeout(()=>$('#cv-map-search-input').focus(),60);else $('#cv-map-suggestions').classList.add('hidden')}
function toggleV41LivePanel(){const panel=$('#v41-map-live-panel'),open=!panel.classList.contains('open');if(open){panel.classList.add('open');$('#v41-map-live-toggle').classList.add('active');closeV41Drawer()}else closeV41LivePanel()}
function toggleV41Drawer(panel='memories'){const drawer=$('#v41-map-drawer'),open=!drawer.classList.contains('open');if(open){openV41DrawerPanel(panel);drawer.classList.add('open');drawer.setAttribute('aria-hidden','false');$('#v41-map-album-toggle').classList.add('active');$('#v41-map-live-panel').classList.remove('open')}else closeV41Drawer()}
function closeV41Drawer(){const drawer=$('#v41-map-drawer');drawer.classList.remove('open');drawer.setAttribute('aria-hidden','true');$('#v41-map-album-toggle').classList.remove('active')}
function openV41DrawerPanel(name){$$('[data-v41-drawer]').forEach(button=>button.classList.toggle('active',button.dataset.v41Drawer===name));$$('[data-v41-panel]').forEach(panel=>panel.classList.toggle('active',panel.dataset.v41Panel===name))}

function closeV41LivePanel(){const panel=$('#v41-map-live-panel');panel?.classList.remove('open');$('#v41-map-live-toggle')?.classList.remove('active')}
function wireMobileMapSheets(){
 if(window.__appCoupleMapSheetsWired)return;window.__appCoupleMapSheetsWired=true;
 const mobile=()=>matchMedia('(max-width:900px)').matches;
 const bind=(sheet,close,isOpen)=>{if(!sheet)return;let startY=0,lastY=0,startAt=0,dragging=false,pointerId=null;
  const reset=()=>{dragging=false;pointerId=null;sheet.classList.remove('is-dragging');sheet.style.removeProperty('transform')};
  sheet.addEventListener('pointerdown',event=>{if(!mobile()||!isOpen()||event.target.closest('button,input,select,textarea,a'))return;startY=lastY=event.clientY;startAt=performance.now();dragging=false;pointerId=event.pointerId});
  sheet.addEventListener('pointermove',event=>{
   if(event.pointerId!==pointerId)return;
   lastY=event.clientY;
   const dy=lastY-startY;
   if(!dragging){
    /* Only take over the gesture as a "pull to close" once the sheet's own
       content is already scrolled to the top and the finger is moving
       downward. Otherwise let the browser scroll the list normally —
       this is what let users scroll the jejak/album list on iPhone. */
    if(dy>6&&sheet.scrollTop<=0){dragging=true;sheet.setPointerCapture?.(event.pointerId);sheet.classList.add('is-dragging')}
    else return;
   }
   event.preventDefault?.();
   sheet.style.setProperty('transform',`translateY(${Math.max(0,dy)}px)`,'important');
  });
  const end=()=>{if(!dragging){reset();return}const dy=Math.max(0,lastY-startY),speed=dy/Math.max(1,performance.now()-startAt);reset();if(dy>72||speed>.65)close()};
  sheet.addEventListener('pointerup',end);sheet.addEventListener('pointercancel',end)
 };
 bind($('#v41-map-live-panel'),closeV41LivePanel,()=>$('#v41-map-live-panel')?.classList.contains('open'));
 bind($('#v41-map-drawer'),closeV41Drawer,()=>$('#v41-map-drawer')?.classList.contains('open'));
 bind($('#cm2-memory-preview'),closeMemoryPreview,()=>!$('#cm2-memory-preview')?.classList.contains('hidden'));
 const dock=$('#couple-map-feature .fp-bottom-bar');let dockY=0;
 dock?.addEventListener('pointerdown',event=>{dockY=event.clientY});dock?.addEventListener('pointerup',event=>{if(mobile()&&dockY-event.clientY>48&&!event.target.closest('button'))toggleV41Drawer('memories')});
}

/* Map and footprints — Couple Map v4.1, privacy-first and realtime */
function setMapLiteMode(enabled,refresh=true){
  mapLiteMode=Boolean(enabled);
  try{localStorage.setItem('ac_map_lite',mapLiteMode?'1':'0')}catch{}
  const feature=$('#couple-map-feature');
  feature?.classList.toggle('map-lite',mapLiteMode);
  const button=$('#cv-map-lite-toggle');
  if(button){
    button.classList.toggle('active',mapLiteMode);
    button.setAttribute('aria-pressed',String(mapLiteMode));
    button.setAttribute('aria-label',mapLiteMode?'Mode peta ringan aktif — tampilkan detail':'Mode peta detail aktif — ringankan peta');
    button.title=mapLiteMode?'Mode ringan aktif':'Mode detail aktif';
  }
  setText('#cv-map-performance',mapLiteMode?'Peta ringan':'Peta detail');
  if(refresh&&map){renderMapMarkers();resizeMap()}
}
async function ensureMap(){
  const host=document.querySelector('#cv-map');
  if(!host)return;
  renderMapIdentity();
  startMapClock();
  if(map){resizeMap();renderMapMarkers();setTimeout(fitAllMap,100);return}
  try{
    const initialLayer=document.body.classList.contains('dark')?'dark':'street',feature=$('#couple-map-feature');
    feature?.classList.toggle('map-dark-mode',initialLayer==='dark');if(feature)feature.dataset.mapLayer=initialLayer;
    $$('[data-map-layer]').forEach(button=>button.classList.toggle('active',button.dataset.mapLayer===initialLayer));
    map=new MiniMap(host,{center:{lat:-6.9147,lng:107.6098},zoom:12,layer:initialLayer,onMarker:marker=>{if(marker.footprintId)focusFootprint(marker.footprintId)}});
    renderMapMarkers();resizeMap();watchTileHealth();setTimeout(fitAllMap,180);
  }catch(error){console.warn('MiniMap gagal dimuat',error);setText('#couple-map-feature .cv-map-fallback small','Peta interaktif tidak tersedia. Jejak tetap dapat digunakan.')}
}
function resizeMap(){if(!map||!document.documentElement.classList.contains('map-view-open'))return;cancelAnimationFrame(mapResizeFrame);clearTimeout(mapResizeTimer);mapResizeFrame=requestAnimationFrame(()=>{try{map?.render()}catch{}});mapResizeTimer=setTimeout(()=>{try{map?.render()}catch{}},140)}
function watchTileHealth(){setTimeout(()=>{const host=document.querySelector('#cv-map');if(!host)return;const tiles=host.querySelectorAll('.mm-tiles img');if(!tiles.length){setText('#couple-map-feature .cv-map-fallback small','Peta sedang menyiapkan petak… geser peta bila belum tampil.');return}let loaded=0;tiles.forEach(img=>{if(img.complete&&img.naturalWidth>0)loaded++});setText('#couple-map-feature .cv-map-fallback small',loaded?'Peta aktif · pilih pin untuk membuka cerita.':'Petak peta diblokir jaringan · grid, jejak, lokasi, dan rute tetap berfungsi.')},2200)}
function renderMapIdentity(){
  const myName=state.user?.displayName||state.user?.name||'Kamu',partnerName=state.partner?.displayName||state.partner?.name||'Pasangan';
  ['#cm2-me-name','#cm2-map-me-name'].forEach(id=>setText(id,myName));['#cm2-partner-name','#cm2-map-partner-name'].forEach(id=>setText(id,partnerName));
  ['#cm2-me-avatar','#cm2-map-me-avatar','#cm2-meet-me'].forEach(id=>setText(id,initialOf(myName)));['#cm2-partner-avatar','#cm2-map-partner-avatar','#cm2-meet-partner'].forEach(id=>setText(id,initialOf(partnerName)));
}
function initialOf(value){return String(value||'P').trim().slice(0,1).toUpperCase()||'P'}
function switchMapLayer(name,button){$$('[data-map-layer]').forEach(item=>item.classList.toggle('active',item===button));const feature=$('#couple-map-feature');feature.classList.toggle('map-dark-mode',name==='dark');feature.dataset.mapLayer=name;map?.setLayer(name);watchTileHealth()}
function openRoutePlanner(){
  const panel=$('#cv-map-route-planner');if(!panel)return;
  panel.classList.remove('hidden');
  const from=$('#cv-map-route-from'),to=$('#cv-map-route-to');
  if(from&&!from.value)from.value='Lokasi saya';
  if(routeDestination&&to&&!to.value)to.value=routeDestination.label||'';
  setTimeout(()=>{if(!to?.value)to?.focus()},40);
}
function closeRoutePlanner(){$('#cv-map-route-planner')?.classList.add('hidden')}
async function routeCurrentPoint(){
  const saved=resolvedLocation(state.uid);
  if(saved)return{lat:Number(saved.lat),lng:Number(saved.lng),label:'Lokasi saya'};
  if(state.demo&&locations[state.uid])return{lat:Number(locations[state.uid].lat),lng:Number(locations[state.uid].lng),label:'Lokasi saya'};
  const point=await getPosition();
  return point?{lat:Number(point.lat),lng:Number(point.lng),label:'Lokasi saya'}:null;
}
async function geocodeRoutePlace(query){
  const value=String(query||'').trim(),key=value.toLowerCase();
  if(!value)return null;
  if(/^(lokasi|posisi)\s*(saya|ku)?$/i.test(value))return routeCurrentPoint();
  if(routeGeocodeCache.has(key))return routeGeocodeCache.get(key);
  const url='https://nominatim.openstreetmap.org/search?format=json&limit=1&countrycodes=id&q='+encodeURIComponent(value);
  const response=await fetch(url,{headers:{'Accept-Language':'id'}});
  if(!response.ok)throw new Error('Tempat belum bisa dicari');
  const rows=await response.json(),item=rows?.[0];
  if(!item)throw new Error(`Gua nggak menemukan “${value}”`);
  const result={lat:Number(item.lat),lng:Number(item.lon),label:String(item.display_name||value).split(',').slice(0,2).join(',')};
  routeGeocodeCache.set(key,result);return result;
}
function routeMinutesLabel(minutes){const value=Math.max(1,Math.round(Number(minutes)||0));return value>=60?`${Math.floor(value/60)} jam ${value%60?`${value%60} menit`:''}`.trim():`${value} menit`}
function localMatusRouteTip(km,minutes,destination){
  const place=destination?.label||'tujuan lu';
  if(routeMode==='walking'||km<=3)return`Jaraknya cuma ${km.toFixed(1)} km ke ${place}. Kalau cuaca aman, jalan santai bareng lebih seru daripada buru-buru naik kendaraan.`;
  if(km<=15)return`Rute ke ${place} sekitar ${km.toFixed(1)} km atau ${routeMinutesLabel(minutes)}. Berangkat sedikit lebih awal, cari tempat makan dekat tujuan, dan jangan bikin agenda terlalu padat.`;
  return`Ke ${place} lumayan jauh: ${km.toFixed(1)} km, sekitar ${routeMinutesLabel(minutes)}. Siapkan bensin, uang makan, dan satu titik istirahat. Jangan cuma fokus sampai sana—perjalanannya juga bagian dari date.`;
}
async function planMapRoute(){
  const fromText=String($('#cv-map-route-from')?.value||'').trim(),toText=String($('#cv-map-route-to')?.value||'').trim(),button=$('#cv-map-route-plan');
  if(!toText)return notify('Tulis dulu mau ke mana');
  button.disabled=true;setText('#cv-map-route-summary','Mencari rute…');setText('#cv-map-matus-tip','Bentar, gua cek jalan dan waktunya…');
  try{
    const from=fromText?await geocodeRoutePlace(fromText):await routeCurrentPoint();
    if(!from)throw new Error('Lokasi mulai belum tersedia');
    const to=await geocodeRoutePlace(toText);if(!to)throw new Error('Tujuan belum ditemukan');
    routeOrigin=from;routeDestination=to;searchResult=to;
    let coords=[[from.lat,from.lng],[to.lat,to.lng]],km=haversine(from.lat,from.lng,to.lat,to.lng),minutes=Math.max(2,Math.round(km/(routeMode==='walking'?5:28)*60)),networkRoute=false;
    try{
      const profile=routeMode==='walking'?'foot':'driving',url='https://router.project-osrm.org/route/v1/'+profile+'/'+from.lng+','+from.lat+';'+to.lng+','+to.lat+'?overview=full&geometries=geojson&steps=false',response=await fetch(url);
      if(!response.ok)throw new Error('route unavailable');
      const data=await response.json(),route=data.routes?.[0],routeCoords=route?.geometry?.coordinates?.map(([lng,lat])=>[lat,lng]);
      if(!route||!routeCoords?.length)throw new Error('route empty');
      coords=routeCoords;km=Number(route.distance||0)/1000;minutes=Number(route.duration||0)/60;networkRoute=true;
    }catch{}
    applyRoute(coords,km,minutes);setText('#cv-map-route-title',to.label||toText);setText('#cv-map-route-summary',`${km.toFixed(1)} km · ${routeMinutesLabel(minutes)}${networkRoute?'':' · estimasi langsung'}`);setText('#cv-map-matus-tip',localMatusRouteTip(km,minutes,to));$('#cv-map-route-result').classList.remove('hidden');renderMapMarkers();notify(networkRoute?'Rute berhasil ditemukan':'Rute jalan belum tersedia, estimasi jarak ditampilkan');
  }catch(error){setText('#cv-map-route-summary','Rute belum siap');setText('#cv-map-matus-tip',error.message||'Tujuan belum bisa dicari. Coba nama tempat yang lebih spesifik.');$('#cv-map-route-result').classList.remove('hidden');notify(error.message||'Rute gagal dicari')}finally{button.disabled=false}
}
async function askMatusRoute(){
  if(!routeDestination||!routeOrigin)return notify('Cari rute dulu, baru gua ikut kasih saran');
  const output=$('#cv-map-matus-tip'),fallback=localMatusRouteTip(routeMetrics.km||haversine(routeOrigin.lat,routeOrigin.lng,routeDestination.lat,routeDestination.lng),routeMetrics.minutes,routeDestination);
  if(!hasLocalAiConfig()){output.textContent=fallback;return}
  output.textContent='Matus lagi mikirin ide date yang nggak ngebosenin…';
  try{const answer=await localAiChat(`Bantu rencana jalan berdua dari ${routeOrigin.label||'lokasi user'} ke ${routeDestination.label||'tujuan'}. Jarak sekitar ${$('#cm2-route-distance')?.textContent||'tidak diketahui'} dan estimasi waktu ${$('#cm2-route-eta')?.textContent||'tidak diketahui'}. Beri satu saran aktivitas atau tempat singgah yang realistis. Jawab natural dengan gaya lu-gua, singkat, jangan mengarang detail tempat.`,{system:'Kamu Matus, teman perjalanan yang seru dan jujur. Jawab dalam Bahasa Indonesia sehari-hari gaya lu-gua.'});output.textContent=answer||fallback}catch{output.textContent=fallback}
}
async function shareMapRoute(){
  if(!routeDestination)return notify('Cari rute dulu sebelum dibagikan');
  const text=`Rute bareng ke ${routeDestination.label||'tujuan'} · ${$('#cv-map-route-summary')?.textContent||''}.`;
  try{
    if(!state.demo&&api?.sendChatMessage&&state.chatId)await api.sendChatMessage(state.chatId,text,null,'route-plan');
    if(navigator.share)await navigator.share({title:'Rute jalan berdua',text});else await navigator.clipboard.writeText(text);
    notify('Rute sudah dibagikan ke Couple Room');
  }catch(error){if(error?.name!=='AbortError')notify('Rute tidak dapat dibagikan')}
}
function saveRouteToTripPlanner(){
  if(!routeDestination)return notify('Cari rute dulu sebelum disimpan');
  const button=document.querySelector('[data-couple-feature="trip"]');if(!button)return notify('Planner Jalan Berdua belum tersedia');
  button.click();
  setTimeout(()=>{const destination=$('#trip-destination'),origin=$('#trip-origin');if(destination){destination.value=routeDestination.label||'';destination.dispatchEvent(new Event('input',{bubbles:true}))}if(origin&&routeOrigin?.label)origin.value=routeOrigin.label;notify('Tujuan dimasukkan ke Jalan Berdua')},180);
}
async function useCurrentRouteOrigin(){
  try{const point=await routeCurrentPoint();if(!point)throw new Error('Lokasi belum tersedia');routeOrigin=point;$('#cv-map-route-from').value='Lokasi saya';notify('Lokasi kamu dipakai sebagai titik mulai')}catch{notify('Aktifkan izin lokasi dulu atau tulis titik mulai manual')}
}
async function searchMap(){
  const query=String($('#cv-map-search-input').value||'').trim();if(!query)return notify('Tulis nama tempat yang ingin dicari');
  const box=$('#cv-map-suggestions');box.classList.remove('hidden');box.innerHTML='<div class="finance-empty">Mencari tempat terbaik…</div>';
  try{
    const url='https://nominatim.openstreetmap.org/search?format=json&limit=6&countrycodes=id&q='+encodeURIComponent(query),response=await fetch(url,{headers:{'Accept-Language':'id'}});if(!response.ok)throw new Error('gagal');
    const results=await response.json();box.innerHTML=results.length?results.map((item,index)=>`<button type="button" data-place="${index}">${escapeHtml(item.display_name)}</button>`).join(''):'<div class="finance-empty">Tempat tidak ditemukan. Coba kata lain.</div>';
    $$('[data-place]',box).forEach(button=>button.onclick=()=>{const item=results[Number(button.dataset.place)];searchResult={lat:Number(item.lat),lng:Number(item.lon),label:String(item.display_name||query).split(',')[0]};routeDestination=searchResult;box.classList.add('hidden');toggleV41Search(false);map?.setView(searchResult,17);renderMapMarkers();const destination=$('#cv-map-route-to');if(destination)destination.value=searchResult.label;openRoutePlanner();notify(`${searchResult.label} ditemukan · siap dibuatkan rute`)});
  }catch{box.innerHTML='<div class="finance-empty">Pencarian membutuhkan internet. Peta lokal tetap dapat digunakan.</div>'}
}
function activeLocation(item){return !!(item?.sharing&&!expired(item.expiresAt)&&validMapPoint(item))}
function latestSavedLocation(uid){return locationHistory.filter(item=>item.uid===uid&&validMapPoint(item)).sort((a,b)=>locationHistoryTime(b)-locationHistoryTime(a))[0]||null}
function resolvedLocation(uid){const live=locations[uid];if(activeLocation(live))return{...live,_live:true};const saved=latestSavedLocation(uid);return saved?{...saved,_live:false}:null}
function savedLocationLabel(item){if(!item)return'Belum ada lokasi';const at=new Date(locationHistoryTime(item)||item.updatedAt||Date.now());return`Tersimpan · ${at.toLocaleString('id-ID',{day:'numeric',month:'short',hour:'2-digit',minute:'2-digit'})}`}
async function centerOnMe(){try{const current=resolvedLocation(state.uid)||(state.demo?locations[state.uid]:await getPosition());if(!current)throw new Error('kosong');map?.setView({lat:Number(current.lat),lng:Number(current.lng)},18);notify(current._live?'Peta dipusatkan pada lokasimu':'Lokasi terakhirmu ditampilkan')}catch{notify('Aktifkan izin lokasi untuk menemukan posisimu')}}
async function toggleLocationShare(){
  const mine=locations[state.uid],active=activeLocation(mine),duration=mapShareMinutes;
  if(state.demo){if(active)delete locations[state.uid];else{const point=await getPosition().catch(()=>({lat:-6.9147,lng:107.6098,accuracy:24}));locations[state.uid]={...point,sharing:true,expiresAt:new Date(Date.now()+duration*60_000),updatedAt:new Date()};locationHistory=compactLocationHistory(locationHistory);const existing=locationHistory.find(item=>item.uid===state.uid);if(existing)Object.assign(existing,{name:state.user?.displayName||'Kamu',...point,sharedMinutes:duration});else locationHistory.unshift({id:crypto.randomUUID(),uid:state.uid,name:state.user?.displayName||'Kamu',...point,sharedMinutes:duration,createdAt:new Date(),expiresAt:new Date(Date.now()+86_400_000)});renderLocationHistory()}renderLocations();return notify(active?'Berbagi lokasi dihentikan':`Lokasi hari ini diperbarui · tersimpan maksimal 24 jam`)}
  try{if(active){await api.stopLocationShare();notify('Berbagi lokasi dihentikan')}else{const point=await getPosition();await api.startTemporaryLocationShare(point,duration);notify(`Lokasi dibagikan selama ${duration} menit`)}}catch(error){notify(error.message||'Lokasi gagal dibagikan')}
}
async function autoShareLocationOnOpen(){
  if(state.demo||!api?.startTemporaryLocationShare||!state.uid)return;
  const key=`ac_auto_location_${state.uid}`;
  if(sessionStorage.getItem(key)==='pending')return;
  sessionStorage.setItem(key,'pending');
  try{
    const point=await getPosition();
    await api.startTemporaryLocationShare(point,120);
    sessionStorage.setItem(key,'shared');
    window.dispatchEvent(new CustomEvent('appcouple:location-auto-shared',{detail:{minutes:120}}));
  }catch(error){
    sessionStorage.removeItem(key);
    const denied=Number(error?.code)===1||/denied|izin/i.test(String(error?.message||''));
    if(!denied)console.warn('Auto location share:',error);
  }
}
function renderLocations(){
  renderMapIdentity();const partnerUid=state.partner?.uid||'demo-partner',liveMe=locations[state.uid],livePartner=locations[partnerUid],meActive=activeLocation(liveMe),partnerActive=activeLocation(livePartner),me=resolvedLocation(state.uid),partner=resolvedLocation(partnerUid);
  const shareButton=$('#cv-share-location');shareButton.innerHTML=meActive?'<i data-fa="xmark"></i> Hentikan berbagi':'<i data-fa="crosshairs"></i> Simpan lokasi saya';shareButton.classList?.toggle('active',meActive);
  ['#cm2-me-row','#cm2-map-me'].forEach(id=>$(id).classList?.toggle('is-live',meActive));['#cm2-partner-row','#cm2-map-partner'].forEach(id=>$(id).classList?.toggle('is-live',partnerActive));
  setText('#cm2-me-state',meActive?`Live · ${remainingLabel(liveMe.expiresAt)}`:savedLocationLabel(me));setText('#cm2-map-me-state',meActive?`Live · ${remainingLabel(liveMe.expiresAt)}`:savedLocationLabel(me));setText('#cm2-partner-state',partnerActive?`Live · ${remainingLabel(livePartner.expiresAt)}`:savedLocationLabel(partner));setText('#cm2-map-partner-state',partnerActive?`Live · ${remainingLabel(livePartner.expiresAt)}`:savedLocationLabel(partner));
  const badge=$('#cm2-map-distance');if(me&&partner){const distance=haversine(me.lat,me.lng,partner.lat,partner.lng),label=distance<1?`${Math.round(distance*1000)} m`:`${distance.toFixed(1)} km`;setText('#cv-distance',label);setText('#cm2-map-distance-value',label);badge?.classList.remove('hidden');setText('#cm2-live-summary',meActive&&partnerActive?'Kalian berdua sedang live':'Lokasi terakhir kalian tersimpan')}else{setText('#cv-distance','—');setText('#cm2-map-distance-value','—');badge?.classList.add('hidden');setText('#cm2-live-summary',me?'Menunggu lokasi pasangan':partner?'Lokasi pasangan tersimpan':'Lokasi terakhir belum tersedia')}
  const accuracy=me?Math.round(Number(me.accuracy)||0):0;setText('#v41-gps-accuracy',meActive?`GPS ±${accuracy} m · ${remainingLabel(liveMe.expiresAt)}`:me?`Lokasi terakhir · ±${accuracy} m`:'GPS menunggu izin');startMapClock();renderMapMarkers();publishMatusMapContext();hydrateIconsIn($('#couple-map-feature'));
}
function publishMatusMapContext(){const partnerUid=state.partner?.uid||'demo-partner',me=locations[state.uid],partner=locations[partnerUid],meLive=activeLocation(me),partnerLive=activeLocation(partner),all=allMapMemories();let distance='—',distanceKm=null;if(meLive&&partnerLive){distanceKm=haversine(me.lat,me.lng,partner.lat,partner.lng);distance=distanceKm<1?`${Math.round(distanceKm*1000)} m`:`${distanceKm.toFixed(1)} km`}const cities=new Set(all.map(item=>String(item.place||'').trim()).filter(Boolean)),journey=journeyStats('all'),mineJourney=journeyStats('me'),partnerJourney=journeyStats('partner');window.__appCoupleMapSummary={connected:Boolean(state.partner?.uid)||state.demo,meLive,partnerLive,distance,distanceKm,memoryCount:all.length,cityCount:cities.size,journeyKm:Number(journey.total.toFixed(2)),journeyPhotos:journey.rows.length,journeyCities:journey.cities,journeyMineKm:Number(mineJourney.total.toFixed(2)),journeyPartnerKm:Number(partnerJourney.total.toFixed(2)),lastUpdated:new Date().toISOString()};window.dispatchEvent(new CustomEvent('appcouple:map-update',{detail:window.__appCoupleMapSummary}))}
function startMapClock(){if(mapClock)return;mapClock=setInterval(updateLocationClock,1000)}
function updateLocationClock(){const partnerUid=state.partner?.uid||'demo-partner',liveMe=locations[state.uid],livePartner=locations[partnerUid],me=resolvedLocation(state.uid),partner=resolvedLocation(partnerUid),meLabel=activeLocation(liveMe)?`Live · ${remainingLabel(liveMe.expiresAt)}`:savedLocationLabel(me),partnerLabel=activeLocation(livePartner)?`Live · ${remainingLabel(livePartner.expiresAt)}`:savedLocationLabel(partner);['#cm2-me-state','#cm2-map-me-state'].forEach(id=>setText(id,meLabel));['#cm2-partner-state','#cm2-map-partner-state'].forEach(id=>setText(id,partnerLabel))}
function remainingLabel(value){const date=value?.toDate?.()||new Date(value||0),seconds=Math.max(0,Math.ceil((date.getTime()-Date.now())/1000));if(seconds<60)return `${seconds} dtk lagi`;const minutes=Math.ceil(seconds/60);return minutes<60?`${minutes} menit lagi`:`${Math.floor(minutes/60)}j ${minutes%60}m lagi`}
function validMapPoint(item){return item?.lat!=null&&item?.lng!=null&&String(item.lat).trim()!==''&&String(item.lng).trim()!==''&&Number.isFinite(Number(item.lat))&&Number.isFinite(Number(item.lng))&&Math.abs(Number(item.lat))<=90&&Math.abs(Number(item.lng))<=180}
function allMapMemories(){return[...new Map([...memories,...driveMemories].filter(item=>item?.id).map(item=>[item.id,item])).values()]}
function mapFilteredMemories(){let list=allMapMemories().sort((a,b)=>memoryTime(b)-memoryTime(a));if(mapMemoryQuery)list=list.filter(item=>`${item.title||''} ${item.place||''} ${item.story||''}`.toLowerCase().includes(mapMemoryQuery));if(mapFilter==='nearby'){const me=resolvedLocation(state.uid);list=me?list.filter(item=>Number.isFinite(Number(item.lat))&&haversine(me.lat,me.lng,item.lat,item.lng)<=20):[]}if(mapFilter==='live')list=[];return list}
function memoryTime(item){const value=item?.createdAt?.toDate?.()||new Date(item?.createdAt||item?.date||0);return value.getTime()||0}
function memoryOwner(item){const owner=String(item?.addedBy||item?.uid||item?.userId||item?.ownerId||'');if(owner&&owner===state.uid)return'me';if(owner&&owner===state.partner?.uid)return'partner';return''}
function journeyRows(owner='all'){return allMapMemories().filter(item=>validMapPoint(item)&&(!owner||owner==='all'||memoryOwner(item)===owner)).sort((a,b)=>memoryTime(a)-memoryTime(b))}
function journeyStats(owner='all'){
  const rows=journeyRows(owner),points=rows.map(item=>[Number(item.lat),Number(item.lng)]),segments=[],seen=new Set();let total=0,ignored=0;
  rows.forEach(item=>{const place=String(item.place||'').trim();if(place)seen.add(place.toLowerCase())});
  for(let i=1;i<rows.length;i++){const prev=rows[i-1],next=rows[i],km=haversine(prev.lat,prev.lng,next.lat,next.lng),gap=Math.abs(memoryTime(next)-memoryTime(prev));if(km>300&&gap<2*60*60*1000){ignored++;continue}total+=km;segments.push({from:prev,to:next,km})}
  return{rows,points,total,segments,places:seen.size,cities:new Set(rows.map(item=>String(item.place||'').split(',').pop().trim().toLowerCase()).filter(Boolean)).size,ignored};
}
function formatJourneyKm(value){const km=Number(value)||0;return km<1?`${Math.round(km*1000)} m`:`${km.toFixed(1)} km`}
function journeyDelta(item){const rows=journeyRows(journeyOwnerFilter),index=rows.findIndex(row=>row.id===item.id);if(index<1)return'';const prev=rows[index-1],km=haversine(prev.lat,prev.lng,item.lat,item.lng);return km>300?'':` · +${formatJourneyKm(km)}`}
function renderJourneyStats(){
  const all=journeyStats('all'),mine=journeyStats('me'),partner=journeyStats('partner'),active=journeyStats(journeyOwnerFilter);
  setText('#cm2-journey-distance',formatJourneyKm(active.total));setText('#cm2-journey-photos',String(active.rows.length));setText('#cm2-journey-places',String(active.places));setText('#cm2-journey-cities',String(active.cities));
  setText('#cm2-journey-caption',active.rows.length>1?`${active.rows.length} foto ber-GPS · jarak antar titik dari urutan waktu${active.ignored?` · ${active.ignored} lompatan diabaikan`:''}`:'Tambahkan minimal dua foto ber-GPS untuk menghitung rute.');
  setText('#cm2-journey-me',`${firstName(state.user?.displayName||'Saya')} ${formatJourneyKm(mine.total)}`);setText('#cm2-journey-partner',`${firstName(state.partner?.displayName||state.partner?.name||'Pasangan')} ${formatJourneyKm(partner.total)}`);
}
function renderMemories(){
  renderJourneyStats();
  const list=mapFilteredMemories();setText('#cm2-memory-visible',list.length);
  const box=$('#cv-footprint-list');box.classList.toggle('timeline',mapView==='timeline');box.classList.toggle('map-ig-grid',mapView!=='timeline');box.innerHTML=list.length?list.map(item=>{const photo=safeMapPhoto(item.photoUrl),place=item.place||'Lokasi privat';return `<article class="cv-footprint-item map-ig-card${activeFootprintId===item.id?' is-active':''}" data-footprint="${escapeHtml(item.id)}"><button type="button" class="cmz-memory-open map-ig-open" data-footprint-open="${escapeHtml(item.id)}"><span class="map-ig-media">${photo?`<img class="map76-cover" src="${escapeHtml(photo)}" alt="" loading="lazy" decoding="async"/>`:'<span class="map-ig-fallback"><i data-fa="heart"></i></span>'}</span><span class="map-ig-overlay"><b>${escapeHtml(item.title||'Jejak bersama')}</b><small class="map-ig-location"><i data-fa="location-dot"></i>${escapeHtml(place)} · ${shortDate(item.date||item.createdAt)}${journeyDelta(item)}</small></span></button><div class="cmz-memory-actions map-ig-actions"><button type="button" data-memory-share="${escapeHtml(item.id)}" aria-label="Bagikan jejak"><i data-fa="paper-plane"></i></button><button type="button" data-memory-delete="${escapeHtml(item.id)}" aria-label="Hapus jejak"><i data-fa="trash"></i></button></div></article>`}).join(''):'<div class="cm2-empty"><span><i data-fa="location-dot"></i></span><b>Belum ada foto pada Album Jejak</b><small>Tambahkan momen dari halaman Kenangan atau abadikan jejak baru.</small></div>';
  $$('.map76-cover',box).forEach(img=>{const fail=()=>{img.hidden=true;img.closest('.map-ig-card')?.classList.add('photo-error')};img.addEventListener('error',fail,{once:true});if(img.complete&&!img.naturalWidth)fail()});
  renderMapMarkers();publishMatusMapContext();hydrateIconsIn($('#couple-map-feature'));
}
function renderMapMarkers(){
  if(!map)return;
  map.batch(()=>{
    map.clearMarkers();
    map.clearShapes();
    const showMemories=mapFilter!=='live',showPeople=mapFilter==='all'||mapFilter==='live';
    const memoryRows=mapFilteredMemories();
    setText('#cv-map-performance',mapLiteMode?'Peta ringan · marker aktif':'Peta detail');
    if(showMemories)memoryRows.forEach(item=>{
      if(validMapPoint(item))map.addMarker(Number(item.lat),Number(item.lng),{label:item.title||'Jejak',footprintId:item.id,kind:'memory',photo:safeMapPhoto(item.photoUrl),initial:'♥',color:'#d94f78'});
    });
    if(showPeople){
      const partnerUid=state.partner?.uid||'demo-partner';
      [[state.uid,true],[partnerUid,false]].forEach(([uid,mine])=>{
        const item=resolvedLocation(uid);if(!item)return;
        const person=mine?state.user:state.partner,name=person?.displayName||person?.name||(mine?'Kamu':'Pasangan');
        map.addMarker(Number(item.lat),Number(item.lng),{label:item._live?(mine?'Kamu · live':'Pasangan · live'):(mine?'Lokasi terakhirmu':'Lokasi terakhir pasangan'),kind:mine?'me':'live',color:mine?'#7664d8':'#2c976c',photo:safeMapPhoto(person?.photoURL),initial:initialOf(name)});
      });
    }
    const journey=journeyStats('all');
    if(showMemories&&journey.points.length>1)map.addPolyline(journey.points,{color:'#8b6cff',weight:3,opacity:.48});
    if(searchResult)map.addMarker(searchResult.lat,searchResult.lng,{label:searchResult.label,color:'#e18a2d'});
    if(meetingPoint)map.addMarker(meetingPoint.lat,meetingPoint.lng,{label:'Titik tengah',color:'#d94f78'});
    if(routeLayer?.length>1)map.addPolyline(routeLayer,{color:'#d94f78',weight:6,opacity:.88});
  });
}
function fitAllMap(){if(!map)return;const points=[];allMapMemories().forEach(item=>{if(validMapPoint(item))points.push([Number(item.lat),Number(item.lng)])});const partnerUid=state.partner?.uid||'demo-partner';[resolvedLocation(state.uid),resolvedLocation(partnerUid)].filter(Boolean).forEach(item=>points.push([Number(item.lat),Number(item.lng)]));if(meetingPoint)points.push([meetingPoint.lat,meetingPoint.lng]);if(searchResult)points.push([searchResult.lat,searchResult.lng]);if(routeLayer?.length)points.push(routeLayer[0],routeLayer[routeLayer.length-1]);if(points.length)map.fitBounds(points,70);else map.setView({lat:-6.9147,lng:107.6098},12);resizeMap()}
function focusFootprint(id){const item=allMapMemories().find(entry=>entry.id===id);if(!item)return;const hasPin=validMapPoint(item);if(!hasPin)return notify('Jejak ini belum memiliki pin lokasi');activeFootprintId=id;closeV41Drawer();const preview=$('#cm2-memory-preview');preview?.classList.remove('is-visible');preview?.classList.add('hidden');mapFilter='all';$$('[data-map-filter]').forEach(button=>button.classList.toggle('active',button.dataset.mapFilter==='all'));renderMemories();requestAnimationFrame(()=>{map?.setView({lat:Number(item.lat),lng:Number(item.lng)},19);resizeMap();renderMapMarkers()});notify(`Pin ${item.title||'jejak'} ditampilkan di peta`)}
function showMemoryPreview(id){const item=allMapMemories().find(entry=>entry.id===id),box=$('#cm2-memory-preview');if(!item)return;activeFootprintId=id;const photo=safeMapPhoto(item.photoUrl);box.innerHTML=`${photo?`<img class="cm2-preview-cover" src="${escapeHtml(photo)}" alt="${escapeHtml(item.title||'Momen')}"/>`:''}<div class="cm2-preview-body"><button class="cm2-preview-close" type="button" data-preview-close aria-label="Tutup"><i data-fa="xmark"></i></button><b>${escapeHtml(item.title||'Jejak bersama')}</b><small>${escapeHtml(item.place||'Lokasi privat')} · ${shortDate(item.date||item.createdAt)}</small><p>${escapeHtml(item.story||'Momen berdua yang tersimpan.')}</p></div>`;box.classList.remove('hidden');box.classList.remove('is-visible','image-error');const previewImage=box.querySelector('.cm2-preview-cover');previewImage?.addEventListener('error',()=>{previewImage.remove();box.classList.add('image-error')},{once:true});requestAnimationFrame(()=>box.classList.add('is-visible'));if(Number.isFinite(Number(item.lat)))map?.setView({lat:Number(item.lat),lng:Number(item.lng)},18);renderMapMarkers()}
function closeMemoryPreview(){activeFootprintId=null;const box=$('#cm2-memory-preview');box.classList.remove('is-visible');box.classList.add('hidden');renderMemories()}
function safeMapPhoto(value){const url=String(value||'');return /^(https:\/\/|blob:|data:image\/|\/assets\/)/i.test(url)?url:''}
function showMeetingPoint(){const partnerUid=state.partner?.uid||'demo-partner',me=locations[state.uid],partner=locations[partnerUid];if(!activeLocation(me)||!activeLocation(partner))return notify('Lokasi kalian berdua harus aktif untuk mencari titik tengah');meetingPoint={lat:(Number(me.lat)+Number(partner.lat))/2,lng:(Number(me.lng)+Number(partner.lng))/2};map?.setView(meetingPoint,15);renderMapMarkers();setText('#cv-route-status','Titik tengah ditemukan · pilih tempat nyaman di sekitarnya');notify('Titik tengah kalian ditampilkan ')}
async function drawRoute(){
  const partnerUid=state.partner?.uid||'demo-partner',me=locations[state.uid],partner=locations[partnerUid];if(!activeLocation(me)||!activeLocation(partner))return notify('Aktifkan lokasi kalian berdua untuk membuat rute');if(!map)return notify('Peta belum siap');
  const button=$('#cv-map-route');button.disabled=true;setText('#cv-route-status','Menyusun rute terbaik…');
  try{if(state.demo){await wait(420);const coords=romanticLine(me,partner),km=haversine(me.lat,me.lng,partner.lat,partner.lng)*1.18,minutes=Math.max(3,Math.round(km/28*60));applyRoute(coords,km,minutes);return}const url='https://router.project-osrm.org/route/v1/driving/'+me.lng+','+me.lat+';'+partner.lng+','+partner.lat+'?overview=full&geometries=geojson',response=await fetch(url);if(!response.ok)throw new Error('gagal');const data=await response.json(),coords=data.routes?.[0]?.geometry?.coordinates?.map(([lng,lat])=>[lat,lng]);if(!coords?.length)throw new Error('kosong');applyRoute(coords,data.routes[0].distance/1000,Math.round(data.routes[0].duration/60))}catch{const km=haversine(me.lat,me.lng,partner.lat,partner.lng);applyRoute([[me.lat,me.lng],[partner.lat,partner.lng]],km,Math.max(2,Math.round(km/25*60)));notify('Rute jalan tidak tersedia; estimasi jarak langsung ditampilkan')}finally{button.disabled=false}
}
function romanticLine(me,partner){const points=[];for(let i=0;i<=16;i+=1){const t=i/16,curve=Math.sin(Math.PI*t)*.0018;points.push([Number(me.lat)+(Number(partner.lat)-Number(me.lat))*t+curve,Number(me.lng)+(Number(partner.lng)-Number(me.lng))*t-curve*.45])}return points}
function applyRoute(coords,km,minutes){routeLayer=coords;routeMetrics={km:Number(km)||0,minutes:Number(minutes)||0};setText('#cm2-route-distance',`${Number(km).toFixed(1)} km`);setText('#cm2-route-eta',`${Math.max(1,Math.round(minutes))} menit`);setText('#cv-route-status',`Rute aktif · ${Number(km).toFixed(1)} km · sekitar ${Math.max(1,Math.round(minutes))} menit`);$('#cv-map-route').classList.add('active');$('#couple-map-feature .map-route-toast')?.classList.remove('hidden');renderMapMarkers();const endpoints=coords?.length?[coords[0],coords[coords.length-1]]:coords;map?.fitBounds(endpoints,80)}
function clearRoute(){routeLayer=null;meetingPoint=null;routeMetrics={km:0,minutes:0};setText('#cm2-route-distance','—');setText('#cm2-route-eta','—');setText('#cv-route-status','Aktifkan lokasi berdua untuk membuat rute');$('#cv-map-route').classList.remove('active');$('#couple-map-feature .map-route-toast')?.classList.add('hidden');renderMapMarkers()}
function openFootprintForm(){closeV41Drawer();footprintCoords=null;footprintPhoto=null;$('#cv-footprint-form').reset();$('#cv-footprint-date').value=new Date().toISOString().slice(0,10);setText('#cv-footprint-coordinates','Tanpa koordinat — tetap bisa disimpan');setText('#cv-footprint-photo-name','Opsional · JPG/PNG');$('#cv-footprint-modal').classList.remove('hidden');setTimeout(()=>$('#cv-footprint-title').focus(),80)}
function closeFootprintForm(){$('#cv-footprint-modal').classList.add('hidden')}
async function chooseFootprintLocation(){try{const current=activeLocation(locations[state.uid])?locations[state.uid]:state.demo?locations[state.uid]:await getPosition();if(!current)throw new Error('kosong');footprintCoords={lat:Number(current.lat),lng:Number(current.lng),accuracy:Number(current.accuracy)||0};setText('#cv-footprint-coordinates',`Lokasi dipilih · akurasi ±${Math.round(footprintCoords.accuracy||0)} m`);notify('Koordinat hanya disimpan pada jejak ini')}catch{notify('Lokasi tidak tersedia atau izin ditolak')}}
async function saveFootprint(event){event.preventDefault();const data={title:$('#cv-footprint-title').value.trim(),place:$('#cv-footprint-place').value.trim(),date:$('#cv-footprint-date').value,story:$('#cv-footprint-story').value.trim(),lat:footprintCoords?.lat??null,lng:footprintCoords?.lng??null};if(!data.title)return notify('Judul momen wajib diisi');if(state.demo){let photoUrl=null;if(footprintPhoto)photoUrl=URL.createObjectURL(footprintPhoto);const item={id:crypto.randomUUID(),...data,photoUrl,createdAt:new Date()};memories.unshift(item);renderMemories();closeFootprintForm();showMemoryPreview(item.id);return notify('Jejak demo tersimpan dan tampil di peta')}try{const photo=footprintPhoto?await compressImage(footprintPhoto):null;await api.addMemory(state.chatId,data,photo);await api.sendCoupleActivity(state.chatId,'memory','Jejak baru ditambahkan',`${data.title} · ${data.place}`);closeFootprintForm();notify('Jejak tersinkron ke pasangan')}catch(error){notify(error.message||'Jejak gagal disimpan')}}
function handleFootprintClick(event){const del=event.target.closest('[data-memory-delete]'),share=event.target.closest('[data-memory-share]'),open=event.target.closest('[data-footprint-open]');if(del)return deleteFootprint(del.dataset.memoryDelete);if(share)return shareFootprint(share.dataset.memoryShare);if(open)return showMemoryPreview(open.dataset.footprintOpen)}
async function deleteFootprint(id){if(driveMemories.some(x=>x.id===id))return window.__appCoupleDriveGallery?.deleteMemory?.(id);const item=memories.find(entry=>entry.id===id);if(!item||!confirm(`Hapus jejak "${item.title||'ini'}" dari kalian berdua?`))return;if(state.demo){memories=memories.filter(entry=>entry.id!==id);renderMemories();return notify('Jejak berhasil dihapus')}try{await api.deleteMemory(state.chatId,id);notify('Jejak dihapus untuk user dan partner')}catch(error){notify(error.message||'Jejak gagal dihapus')}}
async function shareFootprint(id){const item=allMapMemories().find(entry=>entry.id===id);if(!item)return;const coords=Number.isFinite(Number(item.lat))?`\nhttps://www.openstreetmap.org/?mlat=${item.lat}&mlon=${item.lng}#map=16/${item.lat}/${item.lng}`:'',text=`${item.title||'Jejak berdua'} · ${item.place||'Lokasi tersimpan'}${coords}`;try{if(navigator.share)await navigator.share({title:item.title||'Jejak berdua',text});else await navigator.clipboard.writeText(text);notify('Jejak siap dibagikan')}catch(error){if(error?.name!=='AbortError')notify('Jejak tidak dapat dibagikan')}}
const LOCATION_HISTORY_TTL_MS=86_400_000;
function locationHistoryTime(item){const value=item?.createdAt?.toDate?.()||new Date(item?.createdAt||0);return value.getTime()||0}
function compactLocationHistory(rows=[]){const cutoff=Date.now()-LOCATION_HISTORY_TTL_MS,seen=new Set();return rows.filter(item=>locationHistoryTime(item)>=cutoff).sort((a,b)=>locationHistoryTime(b)-locationHistoryTime(a)).filter(item=>!seen.has(item.uid)&&seen.add(item.uid)).slice(0,2)}
function renderLocationHistory(){const box=$('#cmz-location-history');if(!box)return;locationHistory=compactLocationHistory(locationHistory);setText('#cmz-history-count',String(locationHistory.length));box.innerHTML=locationHistory.length?locationHistory.map(item=>{const mine=item.uid===state.uid,created=locationHistoryTime(item)||Date.now(),date=new Date(created).toLocaleString('id-ID',{day:'numeric',month:'short',hour:'2-digit',minute:'2-digit'}),hours=Math.max(1,Math.ceil((created+LOCATION_HISTORY_TTL_MS-Date.now())/3_600_000));return `<article class="cmz-history-item"><span class="${mine?'mine':'partner'}">${escapeHtml(initialOf(item.name||(mine?'K':'P')))}</span><div><b>${mine?'Lokasimu hari ini':'Lokasi pasangan hari ini'}</b><small>${escapeHtml(item.name||'Pasangan')} · ${date}</small><em>Akurasi ±${Math.round(Number(item.accuracy)||0)} m · dihapus ≤${hours} jam</em></div><div class="cmz-history-actions"><button type="button" data-history-open="${item.id}" title="Buka lokasi"><i data-fa="location-arrow"></i></button><button type="button" data-history-share="${item.id}" title="Bagikan"><i data-fa="share-nodes"></i></button>${mine?`<button type="button" data-history-delete="${item.id}" title="Hapus sekarang"><i data-fa="trash"></i></button>`:''}</div></article>`}).join(''):'<div class="cmz-history-empty"><b>Belum ada lokasi dalam 24 jam</b><small>Hanya satu lokasi terbaru per orang yang disimpan dan otomatis dihapus setelah 24 jam.</small></div>';hydrateIconsIn(box)}
function handleLocationHistoryClick(event){const open=event.target.closest('[data-history-open]'),share=event.target.closest('[data-history-share]'),del=event.target.closest('[data-history-delete]');if(open){const item=locationHistory.find(x=>x.id===open.dataset.historyOpen);if(item){map?.setView({lat:Number(item.lat),lng:Number(item.lng)},18);searchResult={lat:Number(item.lat),lng:Number(item.lng),label:item.uid===state.uid?'Lokasimu tersimpan':'Lokasi pasangan tersimpan'};renderMapMarkers()}}else if(share)shareHistoryLocation(share.dataset.historyShare);else if(del)deleteHistoryLocation(del.dataset.historyDelete)}
async function shareHistoryLocation(id){const item=locationHistory.find(x=>x.id===id);if(!item)return;const url=`https://www.openstreetmap.org/?mlat=${item.lat}&mlon=${item.lng}#map=16/${item.lat}/${item.lng}`;try{if(navigator.share)await navigator.share({title:'Lokasi tersimpan AppCouple',text:`Lokasi ${item.name||'pasangan'}`,url});else await navigator.clipboard.writeText(url);notify('Lokasi tersimpan siap dibagikan')}catch(error){if(error?.name!=='AbortError')notify('Lokasi tidak dapat dibagikan')}}
async function deleteHistoryLocation(id){if(!confirm('Hapus lokasi tersimpan ini?'))return;if(state.demo){locationHistory=locationHistory.filter(x=>x.id!==id);renderLocationHistory();return notify('Riwayat lokasi dihapus')}try{await api.deleteLocationHistory(state.chatId,id);notify('Riwayat lokasi dihapus')}catch(error){notify(error.message||'Riwayat gagal dihapus')}}
async function clearMyLocationHistory(){const mine=locationHistory.filter(item=>item.uid===state.uid);if(!mine.length)return notify('Tidak ada riwayat lokasimu');if(!confirm(`Hapus ${mine.length} riwayat lokasimu?`))return;if(state.demo){locationHistory=locationHistory.filter(item=>item.uid!==state.uid);renderLocationHistory();return notify('Riwayat lokasimu dibersihkan')}try{await Promise.all(mine.map(item=>api.deleteLocationHistory(state.chatId,item.id)));notify('Riwayat lokasimu dibersihkan')}catch(error){notify(error.message||'Sebagian riwayat gagal dihapus')}}
async function copyCoupleLocation(){const partnerUid=state.partner?.uid||'demo-partner',me=locations[state.uid],partner=locations[partnerUid];const active=[['Kamu',me],['Pasangan',partner]].filter(([,item])=>activeLocation(item));if(!active.length)return notify('Belum ada lokasi live untuk dibagikan');const text=active.map(([name,item])=>`${name}: https://www.openstreetmap.org/?mlat=${item.lat}&mlon=${item.lng}#map=16/${item.lat}/${item.lng}`).join('\n');try{if(navigator.share)await navigator.share({title:'Lokasi Couple Space',text});else await navigator.clipboard.writeText(text);notify('Lokasi user dan partner siap dibagikan')}catch(error){if(error?.name!=='AbortError')notify('Lokasi tidak dapat dibagikan')}}

/* AI */
function buildAiPrompt(type){const activity=getActivity(),summary={period:new Date().toISOString().slice(0,10),savingName:shared.savingName,savingTotal:shared.savingTotal,savingTarget:shared.savingTarget,weeklyTarget:shared.weeklyTarget,depositCount:(shared.deposits||[]).length,rewardClaims:(shared.claims||[]).length,footprintCount:memories.length,activityTypes:activity.slice(0,30).map(item=>item.type)};const financeAllowed=$('[data-pref="aiFinance"]')?.checked!==false,activityAllowed=$('[data-pref="aiChat"]')?.checked||type!=='relationship';if(financeAllowed)summary.finance={income:$('#finance-income')?.textContent,expense:$('#finance-expense')?.textContent,balance:$('#finance-balance')?.textContent};if(!activityAllowed)delete summary.activityTypes;return `Buat ${type} untuk pasangan berdasarkan ringkasan agregat berikut. Jangan mengarang detail. Berikan 3 insight, 3 langkah kecil, dan satu kalimat apresiasi. Data: ${JSON.stringify(summary)}`}
function aiScopes(){const scopes=[];if($('[data-pref="aiFinance"]')?.checked!==false)scopes.push('finance_summary');scopes.push('couple_activity');if($('[data-pref="aiChat"]')?.checked)scopes.push('chat_excerpt');return scopes}
function demoAiReply(type){const replies={finance:'**Ringkasan utama**\n- Arus kas kalian masih positif dan pengeluaran kencan relatif terkendali.\n- Setoran rutin memberi hasil lebih stabil daripada setoran besar yang jarang.\n- Sisakan batas fleksibel agar target tidak terasa membebani.\n\n**Langkah kecil**\n1. Jadwalkan setoran mingguan otomatis.\n2. Review kategori kencan setiap Minggu malam.\n3. Rayakan progres tiap 25%.\n\nKalian sudah membangun kebiasaan yang sehat—lanjutkan dengan ritme yang nyaman.',relationship:'**Yang berjalan baik**\n- Kalian aktif berbagi aktivitas dan membuat momen bersama.\n- Permainan dan jejak baru menunjukkan ruang untuk kedekatan yang menyenangkan.\n- Apresiasi sederhana akan memperkuat ritme positif ini.\n\n**Coba minggu ini**\n1. Sediakan 20 menit tanpa ponsel.\n2. Tanyakan satu hal yang pasangan butuhkan.\n3. Pilih satu aktivitas bergantian.\n\nKedekatan kalian tumbuh dari perhatian kecil yang konsisten.',savings:'**Proyeksi Celengan Cinta**\n- Progres saat ini menunjukkan fondasi yang baik.\n- Target mingguan membantu menjaga momentum.\n- Setoran kecil Rp50.000–Rp100.000 tetap memberi dampak berarti.\n\n**Langkah kecil**\n1. Kejar target minggu berjalan.\n2. Alihkan satu pengeluaran impulsif.\n3. Periksa progres bersama setiap akhir pekan.\n\nKalian tidak hanya mengumpulkan uang, tetapi juga mendekatkan sebuah mimpi.',mood:'**Ritme minggu ini**\n- Aktivitas bersama terlihat cukup seimbang.\n- Ada ruang untuk check-in lebih eksplisit saat energi menurun.\n- Momen bermain bisa menjadi jeda yang sehat.\n\n**Langkah kecil**\n1. Tanyakan “energi kamu berapa dari 10?”.\n2. Dengarkan tanpa buru-buru memberi solusi.\n3. Pilih satu bentuk dukungan yang konkret.\n\nKalian berhak bertumbuh tanpa harus selalu kuat setiap saat.'};return replies[type]||replies.relationship}
function formatAiText(text){return String(text||'').split(/\n+/).filter(Boolean).map(line=>{const escaped=escapeHtml(line).replace(/\*\*(.*?)\*\*/g,'<b>$1</b>');if(/^[-•]\s/.test(line))return `<p>• ${escaped.replace(/^[-•]\s/,'')}</p>`;if(/^\d+\.\s/.test(line))return `<p>${escaped}</p>`;return `<p>${escaped}</p>`}).join('')}

/* Otak AI — Pusat Kendali */
const AI_PROVIDERS=[{id:'server',name:'Server privat (disarankan)',dot:'chip-green',needsKey:false,model:''},
  {id:'gemini',name:'Gemini Gratis',dot:'chip-blue',needsKey:true,free:true,base:'https://generativelanguage.googleapis.com',model:'gemini-2.5-flash'},
  {id:'openrouter',name:'OpenRouter Gratis',dot:'chip-green',needsKey:true,free:true,base:'https://openrouter.ai/api/v1',model:'openrouter/free'},
  {id:'custom',name:'Custom (OpenAI-compatible)',dot:'chip-purple',needsKey:true,custom:true,base:'',model:''}
];
const AI_CFG_KEY='ac_ai_cfg';
const AI_LOG_KEY='ac_ai_log';
let aiCfg={provider:'gemini',key:'',model:'',base:'',proxy:'',verifiedAt:0};
let tripStyle='balanced';
let tripPlan=null;
let aiLogs=[];
let aiKeyVisible=false;
let aiHealth=null;
let aiWired=false;

function aiProvider(){return AI_PROVIDERS.find(item=>item.id===aiCfg.provider)||AI_PROVIDERS[0]}
function aiLoadCfg(){aiCfg={...aiCfg,...loadLocalAiConfig()};try{aiLogs=JSON.parse(localStorage.getItem(AI_LOG_KEY)||'[]')||[]}catch(error){aiLogs=[]}}
function aiSaveCfg(){aiCfg=saveLocalAiConfig(aiCfg)}
function aiSaveLogs(){try{localStorage.setItem(AI_LOG_KEY,JSON.stringify(aiLogs.slice(-60)))}catch(error){}}
function aiShow(id,visible){const element=$(id);if(element)element.classList.toggle('hidden',!visible)}
function aiSet(id,text){const element=$(id);if(element)element.textContent=text}

function switchAiTab(name,button){$$('#couple-ai-feature .ai-tab').forEach(item=>item.classList.toggle('active',button?item===button:item.dataset.aiTab===name));$$('#couple-ai-feature .ai-pane').forEach(pane=>pane.classList.toggle('active',pane.dataset.aiPane===name));if(name==='system')renderSystemConsole()}

function renderProviderChips(){const box=$('#ai-provider-chips');if(!box)return;box.innerHTML=AI_PROVIDERS.map(item=>`<button type="button" class="ai-provider-chip${item.id===aiCfg.provider?' active':''}" data-provider="${item.id}"><span class="chip-dot ${item.dot}"></span>${escapeHtml(item.name)}</button>`).join('');aiSet('#ai-prov-count',`${AI_PROVIDERS.length} lokal`);aiSet('#ai-pill-count',AI_PROVIDERS.length);aiShow('#ai-base-group',!!aiProvider().custom)}
function renderAiForm(){const focused=document.activeElement;const key=$('#ai-key-input');if(key){key.disabled=aiCfg.provider==='server';key.readOnly=false;if(focused!==key)key.value=aiCfg.key||'';key.setAttribute('inputmode','text')}const model=$('#ai-model-input');if(model){model.disabled=aiCfg.provider==='server';if(focused!==model)model.value=aiCfg.model||'';model.placeholder=aiProvider().model||'model default'}const base=$('#ai-base-input');if(base){base.disabled=aiCfg.provider==='server';if(focused!==base)base.value=aiCfg.base||''}const proxy=$('#ai-proxy-input');if(proxy){proxy.disabled=aiCfg.provider==='server';if(focused!==proxy)proxy.value=aiCfg.proxy||''}aiRenderKeyPreview()}
function aiRenderKeyPreview(){const key=String(aiCfg.key||'');aiSet('#ai-key-preview-text',key?`${aiProvider().name} · ${key.slice(0,4)}…${key.slice(-4)} · sesi tab`:`${aiProvider().name} · konfigurasi belum diuji`)}
function aiReady(){return hasLocalAiConfig()&&Number(aiCfg.verifiedAt||0)>0}
function renderAiStatus(){const badge=$('#ai-status-badge');const provider=aiProvider();let mode='warn';let label='Belum aktif';if(aiReady()){mode='ok';label=`Aktif \u00b7 ${provider.name}`}else if(provider.needsKey)label='Butuh API key';else label='Mode demo';if(badge)badge.className=`ai-status-badge ${mode}`;aiSet('#ai-status-label',label);aiShow('#ai-no-key-notice',!aiReady());const hint=$('#ai-key-hint');if(hint)hint.textContent=provider.free?'Paket gratis: isi API key gratis, lalu kosongkan kolom model agar dipilih otomatis.':provider.needsKey?'Key sementara untuk sesi tab ini; tetap dapat diakses skrip halaman. Server lebih disarankan.':'Provider ini memakai kunci dari environment Netlify, tidak perlu mengisi kunci di sini.'}
function setAiProvider(id){if(id!==aiCfg.provider)aiCfg={provider:id,key:'',model:'',base:'',proxy:'',verifiedAt:0};else aiCfg.provider=id;aiSaveCfg();renderProviderChips();renderAiForm();renderAiStatus();aiLog('info',`Provider lokal diubah ke ${aiProvider().name}`)}
function toggleAiKeyEye(){aiKeyVisible=!aiKeyVisible;const input=$('#ai-key-input');if(input)input.type=aiKeyVisible?'text':'password'}
function clearAiKey(){clearLocalAiConfig();aiCfg={provider:'gemini',key:'',model:'',base:'',proxy:'',verifiedAt:0};renderAiForm();renderAiStatus();notify('API key lokal dihapus')}
async function testAiKey(){const candidate={...aiCfg,key:String($('#ai-key-input')?.value||'').trim(),model:String($('#ai-model-input')?.value||'').trim(),base:String($('#ai-base-input')?.value||'').trim(),proxy:String($('#ai-proxy-input')?.value||'').trim()};const result=$('#ai-test-result');aiShow('#ai-test-result',true);if(result){result.className='ai-test-result';result.textContent='Mendeteksi dan menguji model gratis yang tersedia…'}try{const reply=await localAiChat('Balas hanya dengan kata: TERHUBUNG',{config:candidate});candidate.verifiedAt=Date.now();if(['gemini','openrouter'].includes(candidate.provider))candidate.model='';aiCfg=saveLocalAiConfig(candidate);const resolved=getLastResolvedAiModel();if(result){result.className='ai-test-result ok';result.textContent=`Terhubung${resolved?` · ${resolved}`:''}: ${String(reply).slice(0,60)}`}renderAiForm();notify('AI gratis terhubung; model akan dipilih otomatis')}catch(error){if(result){result.className='ai-test-result bad';result.textContent=`Gagal: ${error.message||'koneksi ditolak'}`}notify('Koneksi belum berhasil; periksa key, izin API, atau kuota gratis')}renderAiStatus();aiRenderKeyPreview()}
async function aiChat(message){if(!aiReady())throw new Error('Uji dan aktifkan provider lokal terlebih dahulu');return{reply:await localAiChat(message)}}
async function runAiAnalysis(type){
  const titles={finance:'Kesehatan Keuangan',relationship:'Kesehatan Hubungan',savings:'Proyeksi Tabungan',mood:'Tren Mood'};
  switchAiTab('analysis');
  aiShow('#ai-output-panel',true);
  aiSet('#ai-output-title',titles[type]||'Analisa AI');
  aiSet('#ai-output-meta',`${aiProvider().name} \u00b7 ${new Date().toLocaleString('id-ID')}`);
  aiShow('#ai-output-loading',true);
  const content=$('#ai-output-content');
  if(content)content.innerHTML='';
  const prompt=buildAiPrompt(type);
  try{
    let reply;
    if(state.demo||!aiReady()){await wait(650);reply=demoAiReply(type)}
    else reply=(await aiChat(prompt,aiScopes())).reply;
    if(content)content.innerHTML=formatAiText(reply);
    aiLog('info',`Analisa ${type} selesai`);
  }catch(error){
    const message=error.message||'AI tidak tersedia';
    if(content)content.innerHTML=`<p><b>Analisa belum tersedia.</b></p><p>${escapeHtml(message)}</p>`;
    if(/429/.test(message))aiShow('#ai-error-banner',true);
    aiLog('error',`Analisa ${type} gagal: ${message}`);
  }
  aiShow('#ai-output-loading',false);
}

async function generateReport(){
  const body=$('#gw-report-body');
  if(body)body.innerHTML='<div class="ai-output-loading"><div class="ai-thinking-dots"><span></span><span></span><span></span></div><p>Menyusun laporan aktivitas\u2026</p></div>';
  aiSet('#gw-status-text','Menganalisa\u2026');
  const prompt=`Buat laporan ${reportPeriod==='weekly'?'mingguan':'harian'} pasangan dari ringkasan: ${buildAiPrompt('relationship')}. Format: sorotan, angka utama, apresiasi, fokus berikutnya.`;
  try{
    let reply;
    if(state.demo||!aiReady()){await wait(650);const mine=Number(shared.pointsByUser?.[state.uid]??0);reply=`**Sorotan ${reportPeriod==='weekly'?'minggu':'hari'} ini**\n- ${(shared.deposits||[]).length} setoran tercatat pada Celengan Cinta.\n- ${memories.length} jejak tersimpan di Peta Couple.\n- Love Points kamu: ${formatNumber(mine)}.\n\n**Apresiasi**\nKalian konsisten mengubah rencana menjadi kebiasaan kecil.\n\n**Fokus berikutnya**\nPilih satu waktu untuk mengecek target dan satu waktu untuk bersenang-senang tanpa membahas angka.`}
    else reply=(await aiChat(prompt,aiScopes())).reply;
    if(body)body.innerHTML=formatAiText(reply);
    aiSet('#gw-status-text','Selesai');
    aiSet('#gw-last-time',new Date().toLocaleString('id-ID'));
    try{localStorage.setItem('ac_ai_report_at',String(Date.now()))}catch(error){}
    aiLog('info',`Laporan ${reportPeriod} dibuat`);
  }catch(error){
    if(body)body.innerHTML=`<p>Laporan belum tersedia: ${escapeHtml(error.message||'')}</p>`;
    aiSet('#gw-status-text','Gagal');
    aiLog('error',`Laporan gagal: ${error.message||''}`);
  }
}

function aiLog(level,message){aiLogs.push({level,message,at:Date.now()});aiSaveLogs();renderAiLogs()}
function renderAiLogs(){const box=$('#sc-log-list');const bugs=aiLogs.filter(item=>item.level==='error').length;const counter=$('#sc-bug-count');if(counter){counter.textContent=bugs;counter.className=`sc-bug-count ${bugs?'has':'zero'}`}if(!box)return;if(!aiLogs.length){box.innerHTML='<div class="sc-log-empty">Tidak ada error tercatat. Sistem bersih.</div>';return}box.innerHTML=aiLogs.slice(-40).reverse().map(item=>`<div class="sc-log-row ${item.level}"><span class="sc-log-time">${new Date(item.at).toLocaleTimeString('id-ID')}</span><span class="sc-log-badge">${item.level.toUpperCase()}</span><span class="sc-log-msg">${escapeHtml(item.message)}</span></div>`).join('')}
function clearAiLogs(){aiLogs=[];aiSaveLogs();renderAiLogs();notify('Log dibersihkan')}
function renderHealthGrid(){
  const box=$('#sc-health-grid');
  if(!box)return;
  const rows=[
    {name:'Netlify Functions',ok:!!aiHealth,value:aiHealth?`v${aiHealth.version||'-'}`:'Offline'},
    {name:'Supabase',ok:!state.demo,value:state.demo?'Mode demo':'Terhubung'},
    {name:'AI Provider',ok:aiReady(),value:aiReady()?aiProvider().name:'Belum aktif'},
    {name:'Service Worker',ok:'serviceWorker' in navigator,value:'serviceWorker' in navigator?'Terpasang':'Tidak didukung'},
    {name:'Penyimpanan Lokal',ok:aiStorageOk(),value:aiStorageOk()?'Normal':'Diblokir'},
    {name:'Koneksi Internet',ok:navigator.onLine,value:navigator.onLine?'Online':'Offline'}
  ];
  box.innerHTML=`<table class="sc-table"><thead><tr><th>Komponen</th><th>Status</th></tr></thead><tbody>${rows.map(row=>`<tr class="${row.ok?'ok':'bad'}"><td class="sc-td-name">${escapeHtml(row.name)}</td><td class="sc-td-status"><span class="sc-st-dot"></span><span class="sc-cell-val">${escapeHtml(row.value)}</span></td></tr>`).join('')}</tbody></table>`;
  const bad=rows.filter(row=>!row.ok).length;
  const dot=$('#sc-summary-dot');
  if(dot)dot.className=`sc-sum-dot ${bad===0?'all':bad<3?'warn':'bad'}`;
  aiSet('#sc-summary-text',bad===0?'Semua normal':`${bad} perlu perhatian`);
}
function aiStorageOk(){try{localStorage.setItem('ac_probe','1');localStorage.removeItem('ac_probe');return true}catch(error){return false}}
function renderSystemConsole(){renderHealthGrid();renderAiLogs()}
async function checkHealth(){
  aiLoadCfg();
  renderProviderChips();
  renderAiForm();
  renderAiStatus();
  renderSystemConsole();
  window.addEventListener('appcouple:ai-config-changed',()=>{aiLoadCfg();renderProviderChips();renderAiForm();renderAiStatus()});
  try{
    const response=await fetch('/api/v1/health',{cache:'no-store'});
    if(!response.ok)throw new Error(`HTTP ${response.status}`);
    aiHealth=await response.json();
    aiSet('#gw-status-text',aiHealth.integrations?.ai?'AI aktif \u00b7 Auto 1x sehari':'AI belum dikonfigurasi');
  }catch(error){
    aiHealth=null;
    aiSet('#gw-status-text','Mode offline');
    aiLog('warn','Endpoint /api/v1/health tidak tersedia');
  }
  const last=Number(localStorage.getItem('ac_ai_report_at')||0);
  if(last)aiSet('#gw-last-time',new Date(last).toLocaleString('id-ID'));
  renderAiStatus();
  renderHealthGrid();
  hydrateIconsIn($('#couple-ai-feature'));
}
function appendConsole(line){const level=/error|gagal/i.test(line)?'error':/warn|offline/i.test(line)?'warn':'info';aiLog(level,String(line).replace(/^\[[a-z]+\]\s*/i,''))}

function appendCoupleAiMessage(role,text){const box=$('#couple-ai-chat-messages');if(!box)return;const item=document.createElement('div');item.className=`ai3-message ${role}`;item.innerHTML=`<span>${role==='user'?escapeHtml(initialOf(state.user?.displayName||'K')):'<i data-fa="brain"></i>'}</span><p>${escapeHtml(text)}</p>`;box.appendChild(item);box.scrollTop=box.scrollHeight;hydrateIconsIn(item);return item}
async function sendCoupleAiQuestion(value){const input=$('#couple-ai-chat-input'),question=String(value||input?.value||'').trim();if(!question)return;if(input)input.value='';appendCoupleAiMessage('user',question);const pending=appendCoupleAiMessage('bot','Sedang menyiapkan jawaban…');try{let reply;if(state.demo||!aiReady()){await wait(500);reply=demoAiReply('relationship')}else{const context=buildAiPrompt('relationship');reply=(await aiChat(`${question}\n\nGunakan konteks agregat berikut bila relevan: ${context}`,aiScopes())).reply}pending.querySelector('p').textContent=reply||'AI tidak memberikan jawaban.'}catch(error){pending.querySelector('p').textContent=error.message||'AI belum tersedia. Periksa pengaturan provider.'}const box=$('#couple-ai-chat-messages');if(box)box.scrollTop=box.scrollHeight}

function wireAiBrain(){
  if(aiWired)return;
  const root=$('#couple-ai-feature');
  if(!root)return;
  aiWired=true;
  aiLoadCfg();
  renderProviderChips();
  renderAiForm();
  renderAiStatus();
  renderSystemConsole();
  root.addEventListener('click',event=>{
    const tab=event.target.closest('.ai-tab');if(tab)return switchAiTab(tab.dataset.aiTab,tab);
    const chip=event.target.closest('[data-provider]');if(chip)return setAiProvider(chip.dataset.provider);
    const period=event.target.closest('[data-report-period]');
    if(period){reportPeriod=period.dataset.reportPeriod;$$('#gw-period button').forEach(item=>item.classList.toggle('active',item===period));return}
  });
  const bind=(selector,handler)=>{const element=$(selector);if(element)element.onclick=handler};
  const keyInput=$('#ai-key-input');if(keyInput){keyInput.disabled=aiCfg.provider==='server';keyInput.oninput=()=>{aiCfg.key=keyInput.value};keyInput.onpaste=()=>setTimeout(()=>{aiCfg.key=keyInput.value},0)}
  const wireCfgInput=(selector,field)=>{const input=$(selector);if(!input)return;input.oninput=()=>{aiCfg[field]=input.value};input.onpaste=()=>setTimeout(()=>{aiCfg[field]=input.value},0)};
  wireCfgInput('#ai-model-input','model');wireCfgInput('#ai-base-input','base');wireCfgInput('#ai-proxy-input','proxy');
  bind('#ai-key-eye-btn',toggleAiKeyEye);
  bind('#ai-btn-test',testAiKey);
  bind('#ai-btn-clear',clearAiKey);
  bind('#gw-analyze-btn',generateReport);
  bind('#sc-refresh-btn',()=>{checkHealth();notify('Status disegarkan')});
  bind('#sc-clear-log-btn',clearAiLogs);
}

/* English Pro Mastery (EPM) */
const EPM_LEVELS={basic:'Pemula (A1-A2)',inter:'Menengah (B1-B2)',adv:'Mahir (C1-C2)'};
const EPM_SCENES={
  presentation:{label:'Presentasi',desc:'Kamu sedang mempresentasikan laporan kuartalan kepada tim. AI berperan sebagai audiens yang bertanya.',opener:'Good morning! We are ready for your quarterly presentation. Please start whenever you are ready.'},
  meeting:{label:'Meeting',desc:'Rapat tim mingguan. AI berperan sebagai rekan kerja yang meminta update progres.',opener:'Hi! Before we start, could you give us a quick update on your project?'},
  interview:{label:'Wawancara',desc:'Wawancara kerja. AI berperan sebagai HR yang mewawancaraimu.',opener:'Thanks for coming in. Could you tell me a little about yourself?'},
  negotiation:{label:'Negosiasi',desc:'Negosiasi harga dengan klien. AI berperan sebagai klien yang menawar.',opener:'Your proposal looks good, but the price is a bit high for us. Can we discuss it?'},
  free:{label:'Bebas',desc:'Ngobrol bebas dalam bahasa Inggris tentang apa saja.',opener:'Hey! What would you like to talk about today?'}
};
const EPM_WRITE_MODES={
  correct:{hint:'Tempel teks bahasa Inggris untuk dikoreksi grammar, diksi & keformalan.',prompt:'Correct the following English text. Show the corrected version first, then list the mistakes and short explanations in Indonesian.'},
  email:{hint:'Tulis poin-poin dalam bahasa Indonesia/Inggris, AI menyusun email profesional.',prompt:'Write a professional English email based on these points. Then add a short Indonesian note about the tone used.'},
  report:{hint:'Tulis poin laporan, AI menyusun laporan singkat bahasa Inggris.',prompt:'Write a concise professional English report based on these points.'},
  translate:{hint:'Tulis teks Indonesia atau Inggris, AI menerjemahkan secara natural.',prompt:'Translate the following text (Indonesian<->English) naturally, then give one alternative phrasing.'},
  paraphrase:{hint:'Tulis kalimat, AI membuat 3 versi parafrase.',prompt:'Paraphrase the following English text into 3 versions: casual, neutral, and formal.'}
};
const EPM_WORDS=[
  {en:'leverage',ipa:'/\u02c8li\u02d0v\u0259r\u026ad\u0292/',id:'memanfaatkan',ex:'We can leverage our network to find new clients.'},
  {en:'streamline',ipa:'/\u02c8stri\u02d0mla\u026an/',id:'menyederhanakan',ex:'We need to streamline the approval process.'},
  {en:'milestone',ipa:'/\u02c8ma\u026alsto\u028an/',id:'tonggak pencapaian',ex:'Reaching 1,000 users is a big milestone.'},
  {en:'stakeholder',ipa:'/\u02c8ste\u026akh\u0259\u028ald\u0259r/',id:'pemangku kepentingan',ex:'Please inform every stakeholder about the change.'},
  {en:'feasible',ipa:'/\u02c8fi\u02d0z\u0259bl/',id:'layak dilakukan',ex:'That timeline is not feasible for our team.'},
  {en:'concise',ipa:'/k\u0259n\u02c8sa\u026as/',id:'ringkas',ex:'Please keep the summary concise.'},
  {en:'reliable',ipa:'/r\u026a\u02c8la\u026a\u0259bl/',id:'dapat diandalkan',ex:'She is the most reliable person on the team.'},
  {en:'delegate',ipa:'/\u02c8del\u026age\u026at/',id:'mendelegasikan',ex:'You should delegate some tasks to your team.'},
  {en:'insight',ipa:'/\u02c8\u026ansa\u026at/',id:'wawasan mendalam',ex:'The report gives useful insight into user behaviour.'},
  {en:'commitment',ipa:'/k\u0259\u02c8m\u026atm\u0259nt/',id:'komitmen',ex:'Thank you for your commitment to this project.'},
  {en:'appreciate',ipa:'/\u0259\u02c8pri\u02d0\u0283ie\u026at/',id:'menghargai',ex:'I really appreciate your support today.'},
  {en:'grateful',ipa:'/\u02c8gre\u026atfl/',id:'bersyukur',ex:'I am grateful to have you in my life.'}
];
const EPM_FILL=[
  {id:'Saya menghargai dukunganmu hari ini.',en:'I appreciate your support today.',hint:'gunakan kata "appreciate"'},
  {id:'Bisakah kita jadwalkan ulang rapatnya?',en:'Can we reschedule the meeting?',hint:'gunakan "reschedule"'},
  {id:'Saya akan mengirimkan laporannya besok.',en:'I will send the report tomorrow.',hint:'future simple'},
  {id:'Dia sudah bekerja di sini selama lima tahun.',en:'He has worked here for five years.',hint:'present perfect'},
  {id:'Kami perlu menyederhanakan prosesnya.',en:'We need to streamline the process.',hint:'gunakan "streamline"'},
  {id:'Terima kasih sudah bersabar denganku.',en:'Thank you for being patient with me.',hint:'thank you for + V-ing'}
];
let epmLevel=localStorage.getItem('epm_level')||'basic';
let epmTab='tutor';
let epmWriteMode='correct';
let epmPracticeTab='fc';
let epmScene='presentation';
let epmSpeakTyping=false;
let epmBank=[];
let epmDictLast=null;
let epmTutorHistory=[];
let epmSpeakHistory=[];
let epmLastAgentText='';
let epmFcQueue=[];
let epmFcIndex=0;
let epmFcKnown=0;
let epmFcUnknown=0;
let epmFcFlipped=false;
let epmQuiz=null;
let epmQuizRight=0;
let epmQuizWrong=0;
let epmQuizNo=1;
let epmFill=null;
let epmFillScore=0;
let epmFillStreak=0;
let epmFillTotal=0;
let epmRecognition=null;
let epmRecTarget='';
let epmWired=false;

function epmLoadBank(){try{epmBank=JSON.parse(localStorage.getItem('epm_bank')||'[]')||[]}catch(error){epmBank=[]}}
function epmSaveBank(){try{localStorage.setItem('epm_bank',JSON.stringify(epmBank))}catch(error){}}
function epmShow(id,visible){const element=$(id);if(element)element.classList.toggle('hidden',!visible)}
function epmSet(id,text){const element=$(id);if(element)element.textContent=text}
function epmWordPool(){const bank=epmBank.map(item=>({en:item.en,ipa:item.ipa||'',id:item.id,ex:item.ex||''}));const seen=new Set();return [...EPM_WORDS,...bank].filter(item=>{const key=String(item.en).toLowerCase();if(seen.has(key))return false;seen.add(key);return true})}
function epmLevelHint(){return `Learner level: ${EPM_LEVELS[epmLevel]}. Reply in clear English and add a short Indonesian explanation when helpful.`}
async function epmAsk(prompt){if(state.demo){await wait(520);return epmDemoReply(prompt)}try{const result=await aiChat(`${epmLevelHint()}\n\n${prompt}`,[]);return result.reply||'AI tidak memberikan jawaban.'}catch(error){return error.message||'AI sedang tidak tersedia. Coba lagi nanti.'}}
function epmDemoReply(prompt){const text=String(prompt).slice(-160);return `**Mode demo aktif** \u2014 hubungkan kunci AI di menu Otak AI untuk jawaban penuh.\n\nRingkasan permintaan: ${text}\n\nContoh jawaban: Try using clear, short sentences. Например: "I would like to confirm the schedule for tomorrow."\nTips: baca kalimatmu keras-keras untuk memeriksa kealamiannya.`}
function epmRenderAiChip(){const chip=$('#epm-ai-chip');if(!chip)return;const ok=!state.demo;chip.classList.toggle('ok',ok);epmSet('#epm-ai-chip-text',ok?'AI aktif':'Mode demo \u2014 AI terbatas')}
function epmGo(tab){epmTab=tab;$$('#epm-tabs .epm-tab').forEach(button=>button.classList.toggle('active',button.dataset.tab===tab));['tutor','dict','grammar','write','speak','practice','bank'].forEach(name=>{const screen=$(`#epm-s-${name}`);if(screen)screen.classList.toggle('active',name===tab)});if(tab==='bank')epmRenderBank();if(tab==='practice')epmRenderPractice()}
function epmSetLevel(level){epmLevel=level;try{localStorage.setItem('epm_level',level)}catch(error){}$$('#couple-english-feature .epm-level').forEach(button=>button.classList.toggle('active',button.dataset.lvl===level))}
function epmBubble(container,role,text){const box=$(container);if(!box)return null;const empty=box.querySelector('.epm-chat-empty');if(empty)empty.remove();const bubble=document.createElement('div');bubble.className=`epm-msg epm-msg-${role}`;bubble.innerHTML=role==='ai'?formatAiText(text):escapeHtml(text);box.appendChild(bubble);box.scrollTop=box.scrollHeight;return bubble}
function epmTyping(container){const box=$(container);if(!box)return null;const bubble=document.createElement('div');bubble.className='epm-msg epm-msg-ai';bubble.innerHTML='<span class="epm-dots"><i></i><i></i><i></i></span>';box.appendChild(bubble);box.scrollTop=box.scrollHeight;return bubble}

/* Tutor */
async function epmTutorSend(preset){const input=$('#epm-tutor-in');const text=String(preset||input?.value||'').trim();if(!text)return;if(input&&!preset)input.value='';epmBubble('#epm-tutor-chat','user',text);epmTutorHistory.push(text);const loading=epmTyping('#epm-tutor-chat');const reply=await epmAsk(`You are a friendly English tutor. Answer this learner question: ${text}`);if(loading)loading.innerHTML=formatAiText(reply)}
function epmTutorClear(){epmTutorHistory=[];const box=$('#epm-tutor-chat');if(box)box.innerHTML='<div class="epm-chat-empty">Mulai percakapan baru dengan tutor AI.</div>'}

/* Kamus */
async function epmDict(){const word=String($('#epm-dict-q')?.value||'').trim();if(!word)return notify('Ketik kata dulu');epmShow('#epm-dict-card',true);const out=$('#epm-dict-out');if(out)out.innerHTML='<span class="epm-dots"><i></i><i></i><i></i></span>';epmShow('#epm-dict-save',false);const local=EPM_WORDS.find(item=>item.en.toLowerCase()===word.toLowerCase()||item.id.toLowerCase()===word.toLowerCase());let entry;if(local)entry={...local};else{const reply=await epmAsk(`Define the English word "${word}". Reply in this exact format:\nWORD: ...\nIPA: ...\nPOS: ...\nID: (Indonesian meaning)\nEX: (one example sentence)\nSYN: (comma separated synonyms)`);entry=epmParseDict(reply,word)}epmDictLast=entry;if(out)out.innerHTML=`<div class="epm-dict-top"><div><div class="epm-word">${escapeHtml(entry.en)}</div><div class="epm-ipa">${escapeHtml(entry.ipa||'')}</div></div><button type="button" class="epm-spk" data-speak="${escapeHtml(entry.en)}"><i data-fa="volume-high"></i></button></div>${entry.pos?`<span class="epm-badge">${escapeHtml(entry.pos)}</span>`:''}<div class="epm-mini-label">Arti</div><div>${escapeHtml(entry.id||'-')}</div><div class="epm-mini-label">Contoh</div><div>${escapeHtml(entry.ex||'-')}</div>${entry.syn?`<div class="epm-mini-label">Sinonim</div><div>${entry.syn.split(',').map(item=>`<span class="epm-syn">${escapeHtml(item.trim())}</span>`).join('')}</div>`:''}${entry.raw?`<div class="epm-tip">${escapeHtml(entry.raw).slice(0,400)}</div>`:''}`;epmShow('#epm-dict-save',true);wireSpeak($('#epm-dict-out'));hydrateIconsIn($('#couple-english-feature'));epmPushRecent(entry.en)}
function epmParseDict(reply,fallback){const grab=key=>{const match=String(reply).match(new RegExp(key+':\\s*(.+)'));return match?match[1].trim():''};const parsed={en:grab('WORD')||fallback,ipa:grab('IPA'),pos:grab('POS'),id:grab('ID'),ex:grab('EX'),syn:grab('SYN')};if(!parsed.id)parsed.raw=reply;return parsed}
function epmPushRecent(word){const box=$('#epm-dict-recent');if(!box)return;let list=[];try{list=JSON.parse(localStorage.getItem('epm_recent')||'[]')}catch(error){list=[]}list=[word,...list.filter(item=>item!==word)].slice(0,8);try{localStorage.setItem('epm_recent',JSON.stringify(list))}catch(error){}box.innerHTML=`<div class="epm-mini-label">Terakhir dicari</div><div class="epm-chips">${list.map(item=>`<button type="button" class="epm-chip" data-recent="${escapeHtml(item)}">${escapeHtml(item)}</button>`).join('')}</div>`}
function epmSaveDict(){if(!epmDictLast)return;const key=String(epmDictLast.en).toLowerCase();if(epmBank.some(item=>String(item.en).toLowerCase()===key))return notify('Kata sudah ada di Bank Kata');epmBank.push({en:epmDictLast.en,ipa:epmDictLast.ipa||'',id:epmDictLast.id||'',ex:epmDictLast.ex||''});epmSaveBank();epmRenderBankBadge();notify('Tersimpan ke Bank Kata \u2705')}

/* Grammar */
async function epmGrammar(topic){const value=String(topic||$('#epm-gr-q')?.value||'').trim();if(!value)return notify('Pilih atau ketik topik grammar');if(topic&&$('#epm-gr-q'))$('#epm-gr-q').value=value;const out=$('#epm-gr-out');if(out)out.innerHTML='<span class="epm-dots"><i></i><i></i><i></i></span>';const reply=await epmAsk(`Explain this English grammar topic for an Indonesian learner, with formula, 3 examples, and 2 common mistakes: ${value}`);if(out)out.innerHTML=formatAiText(reply)}

/* Menulis */
function epmWriteTab(mode){epmWriteMode=mode;$$('#epm-write-tabs .epm-subtab').forEach(button=>button.classList.toggle('active',button.dataset.mode===mode));epmSet('#epm-write-hint',EPM_WRITE_MODES[mode].hint)}
async function epmWriteRun(){const text=String($('#epm-wr-text')?.value||'').trim();if(!text)return notify('Tulis teksnya dulu');epmShow('#epm-wr-card',true);const out=$('#epm-wr-out');if(out)out.innerHTML='<span class="epm-dots"><i></i><i></i><i></i></span>';const reply=await epmAsk(`${EPM_WRITE_MODES[epmWriteMode].prompt}\n\n${text}`);if(out)out.innerHTML=formatAiText(reply)}

/* Speaking */
function epmAgentState(mode,status){const agent=$('#epm-agent');if(agent)agent.dataset.state=mode;if(status)epmSet('#epm-agent-status',status)}
function epmSceneReset(){const scene=EPM_SCENES[epmScene];epmSet('#epm-scene-text',scene.desc);epmSpeakHistory=[];const box=$('#epm-speak-chat');if(box)box.innerHTML='';epmShow('#epm-speak-fb-card',false);epmBubble('#epm-speak-chat','ai',scene.opener);epmLastAgentText=scene.opener;epmAgentState('idle','Sentuh mikrofon lalu mulai bicara');speak(scene.opener)}
function epmSetScene(name){epmScene=name;$$('#epm-speak-tabs .epm-subtab').forEach(button=>button.classList.toggle('active',button.dataset.scene===name));epmSceneReset()}
function epmTypeToggle(){epmSpeakTyping=!epmSpeakTyping;epmShow('#epm-speak-typebox',epmSpeakTyping);if(epmSpeakTyping)$('#epm-speak-in')?.focus()}
function epmAgentReplay(){if(!epmLastAgentText)return notify('Belum ada suara untuk diulang');epmAgentState('speaking','Berbicara\u2026');speak(epmLastAgentText);setTimeout(()=>epmAgentState('idle','Sentuh mikrofon lalu mulai bicara'),1600)}
async function epmSpeakSend(preset){const input=$('#epm-speak-in');const text=String(preset||input?.value||'').trim();if(!text)return;if(input&&!preset)input.value='';epmBubble('#epm-speak-chat','user',text);epmSpeakHistory.push(text);epmAgentState('thinking','Memproses jawabanmu\u2026');const loading=epmTyping('#epm-speak-chat');const scene=EPM_SCENES[epmScene];const reply=await epmAsk(`Roleplay scenario: ${scene.desc}\nStay in character and reply in English (max 3 sentences) to: ${text}`);if(loading)loading.innerHTML=formatAiText(reply);epmLastAgentText=String(reply).replace(/\*\*/g,'');epmAgentState('speaking','Berbicara\u2026');speak(epmLastAgentText);setTimeout(()=>epmAgentState('idle','Sentuh mikrofon lalu mulai bicara'),1800);const feedback=await epmAsk(`Give short feedback (Indonesian) on this English sentence: grammar, word choice, and a more natural version. Sentence: ${text}`);epmShow('#epm-speak-fb-card',true);const fb=$('#epm-speak-fb');if(fb)fb.innerHTML=formatAiText(feedback)}
function epmMicToggle(button,onResult){const SpeechRecognition=window.SpeechRecognition||window.webkitSpeechRecognition;if(!SpeechRecognition)return notify('Speech recognition tidak didukung browser ini');if(epmRecognition){epmRecognition.stop();return}const recognition=new SpeechRecognition();epmRecognition=recognition;recognition.lang='en-US';recognition.interimResults=true;recognition.continuous=false;button?.classList.add('rec');epmAgentState('listening','Mendengarkan\u2026');recognition.onresult=event=>{let text='';for(let index=0;index<event.results.length;index+=1)text+=event.results[index][0].transcript;epmSet('#epm-live-caption',text);if(event.results[event.results.length-1].isFinal)epmRecTarget=text};recognition.onerror=()=>{notify('Tidak terdengar jelas, coba lagi')};recognition.onend=()=>{epmRecognition=null;button?.classList.remove('rec');epmSet('#epm-live-caption','');epmAgentState('idle','Sentuh mikrofon lalu mulai bicara');const text=epmRecTarget.trim();epmRecTarget='';if(text)onResult(text)};recognition.start()}

/* Latihan */
function epmRenderPractice(){epmRenderFc();epmRenderQuiz();epmRenderFill()}
function epmPracticeTabSet(name){epmPracticeTab=name;$$('#epm-practice-tabs .epm-subtab').forEach(button=>button.classList.toggle('active',button.dataset.p===name));epmShow('#epm-p-fc',name==='fc');epmShow('#epm-p-quiz',name==='quiz');epmShow('#epm-p-fill',name==='fill')}
function epmFcReset(){epmFcQueue=shuffle(epmWordPool());epmFcIndex=0;epmFcKnown=0;epmFcUnknown=0;epmRenderFc()}
function epmRenderFc(){if(!epmFcQueue.length)epmFcQueue=shuffle(epmWordPool());const item=epmFcQueue[epmFcIndex];epmFcFlipped=false;epmShow('#epm-fc-back',false);epmShow('#epm-fc-btns',false);epmSet('#epm-fc-hint','Ketuk kartu untuk lihat arti');epmSet('#epm-fc-known',epmFcKnown);epmSet('#epm-fc-unknown',epmFcUnknown);epmSet('#epm-fc-left',Math.max(0,epmFcQueue.length-epmFcIndex));if(!item){epmSet('#epm-fc-word','Selesai \ud83c\udf89');epmSet('#epm-fc-ipa','');return}epmSet('#epm-fc-word',item.en);epmSet('#epm-fc-ipa',item.ipa||'');epmSet('#epm-fc-id',item.id||'');epmSet('#epm-fc-ex',item.ex||'')}
function epmFcFlip(){const item=epmFcQueue[epmFcIndex];if(!item)return;epmFcFlipped=!epmFcFlipped;epmShow('#epm-fc-back',epmFcFlipped);epmShow('#epm-fc-btns',epmFcFlipped);epmSet('#epm-fc-hint',epmFcFlipped?'Tandai apakah kamu sudah hafal':'Ketuk kartu untuk lihat arti');if(epmFcFlipped)speak(item.en)}
function epmFcMark(known){if(known)epmFcKnown+=1;else epmFcUnknown+=1;epmFcIndex+=1;if(epmFcIndex>=epmFcQueue.length)epmFcIndex=epmFcQueue.length;epmRenderFc()}
function epmRenderQuiz(){const pool=epmWordPool();if(pool.length<4)return;const answer=randomItem(pool);const options=shuffle([answer,...shuffle(pool.filter(item=>item.en!==answer.en)).slice(0,3)]);epmQuiz={answer,options};epmSet('#epm-qz-q',`Apa arti dari "${answer.en}"?`);epmSet('#epm-qz-right',epmQuizRight);epmSet('#epm-qz-wrong',epmQuizWrong);epmSet('#epm-qz-n',epmQuizNo);const box=$('#epm-qz-opts');if(box)box.innerHTML=options.map(item=>`<button type="button" class="epm-opt" data-qz="${escapeHtml(item.en)}">${escapeHtml(item.id)}</button>`).join('');epmShow('#epm-qz-fb',false);epmShow('#epm-qz-ai',false);epmShow('#epm-qz-next',false)}
function epmQuizAnswer(button){if(!epmQuiz||button.disabled)return;const correct=button.dataset.qz===epmQuiz.answer.en;$$('#epm-qz-opts .epm-opt').forEach(option=>{option.disabled=true;if(option.dataset.qz===epmQuiz.answer.en)option.classList.add('correct');else if(option===button)option.classList.add('wrong')});const fb=$('#epm-qz-fb');if(fb){fb.className=`epm-fb ${correct?'good':'bad'}`;fb.textContent=correct?'Benar! \ud83c\udf89':`Kurang tepat. "${epmQuiz.answer.en}" = ${epmQuiz.answer.id}`}epmShow('#epm-qz-fb',true);const ai=$('#epm-qz-ai');if(ai){ai.innerHTML=formatAiText(`Contoh: ${epmQuiz.answer.ex||`I will ${epmQuiz.answer.en} this today.`}`);epmShow('#epm-qz-ai',true)}if(correct)epmQuizRight+=1;else epmQuizWrong+=1;epmSet('#epm-qz-right',epmQuizRight);epmSet('#epm-qz-wrong',epmQuizWrong);epmShow('#epm-qz-next',true);speak(epmQuiz.answer.en)}
function epmQuizNext(){epmQuizNo+=1;epmRenderQuiz()}
function epmQuizReset(){epmQuizRight=0;epmQuizWrong=0;epmQuizNo=1;epmRenderQuiz()}
function epmRenderFill(){epmFill=randomItem(EPM_FILL);epmSet('#epm-fi-q',epmFill.id);epmSet('#epm-fi-hint',epmFill.hint?`Petunjuk: ${epmFill.hint}`:'');const input=$('#epm-fi-in');if(input)input.value='';epmShow('#epm-fi-fb',false);epmSet('#epm-fi-score',epmFillScore);epmSet('#epm-fi-streak',epmFillStreak);epmSet('#epm-fi-total',epmFillTotal)}
function epmFillCheck(){if(!epmFill)return;const value=String($('#epm-fi-in')?.value||'').trim();if(!value)return notify('Ketik jawabanmu dulu');const score=similarity(value,epmFill.en);const correct=score>=75;epmFillTotal+=1;if(correct){epmFillScore+=1;epmFillStreak+=1}else epmFillStreak=0;const fb=$('#epm-fi-fb');if(fb){fb.className=`epm-fb ${correct?'good':'bad'}`;fb.textContent=correct?`Bagus! (${score}% mirip) \u2014 ${epmFill.en}`:`Belum tepat (${score}%). Jawaban: ${epmFill.en}`}epmShow('#epm-fi-fb',true);epmSet('#epm-fi-score',epmFillScore);epmSet('#epm-fi-streak',epmFillStreak);epmSet('#epm-fi-total',epmFillTotal);speak(epmFill.en)}
function epmFillNext(){epmRenderFill()}

/* Bank kata */
function epmRenderBankBadge(){const badge=$('#epm-bank-badge');if(!badge)return;badge.textContent=epmBank.length||'';badge.classList.toggle('show',epmBank.length>0)}
function epmRenderBank(){epmRenderBankBadge();epmSet('#epm-bank-count',epmBank.length);const box=$('#epm-bank-list');if(!box)return;if(!epmBank.length){box.innerHTML='<div class="epm-empty">Belum ada kata tersimpan. Cari kata di tab Kamus lalu simpan.</div>';return}box.innerHTML=epmBank.map((item,index)=>`<div class="epm-bank-item"><div class="epm-bank-main"><div class="epm-bank-en">${escapeHtml(item.en)}</div><div class="epm-bank-ipa">${escapeHtml(item.ipa||'')}</div><div class="epm-bank-id">${escapeHtml(item.id||'')}</div><div class="epm-bank-ex">${escapeHtml(item.ex||'')}</div></div><div class="epm-bank-actions"><button type="button" class="epm-spk" data-speak="${escapeHtml(item.en)}"><i data-fa="volume-high"></i></button><button type="button" class="epm-spk epm-del" data-bank-del="${index}"><i data-fa="trash"></i></button></div></div>`).join('');wireSpeak(box);hydrateIconsIn(box)}

function renderEnglish(){epmLoadBank();epmRenderAiChip();epmRenderBankBadge();if(!epmTutorHistory.length&&$('#epm-tutor-chat')&&!$('#epm-tutor-chat').children.length)epmTutorClear();if(!epmSpeakHistory.length&&$('#epm-speak-chat')&&!$('#epm-speak-chat').children.length){const scene=EPM_SCENES[epmScene];epmSet('#epm-scene-text',scene.desc);epmBubble('#epm-speak-chat','ai',scene.opener);epmLastAgentText=scene.opener}if(!epmFcQueue.length)epmFcQueue=shuffle(epmWordPool());epmRenderFc();if(!epmQuiz)epmRenderQuiz();if(!epmFill)epmRenderFill();hydrateIconsIn($('#couple-english-feature'))}

function wireEnglish(){
  if(epmWired)return;
  const root=$('#couple-english-feature');
  if(!root)return;
  epmWired=true;
  epmLoadBank();
  epmSetLevel(epmLevel);
  epmWriteTab(epmWriteMode);
  epmPracticeTabSet(epmPracticeTab);
  root.addEventListener('click',event=>{
    const tab=event.target.closest('#epm-tabs .epm-tab');if(tab)return epmGo(tab.dataset.tab);
    const level=event.target.closest('.epm-level');if(level)return epmSetLevel(level.dataset.lvl);
    const quick=event.target.closest('[data-quick]');if(quick)return epmTutorSend(quick.dataset.quick);
    const topic=event.target.closest('[data-topic]');if(topic)return epmGrammar(topic.dataset.topic);
    const recent=event.target.closest('[data-recent]');if(recent){const input=$('#epm-dict-q');if(input)input.value=recent.dataset.recent;return epmDict()}
    const writeTab=event.target.closest('#epm-write-tabs .epm-subtab');if(writeTab)return epmWriteTab(writeTab.dataset.mode);
    const sceneTab=event.target.closest('#epm-speak-tabs .epm-subtab');if(sceneTab)return epmSetScene(sceneTab.dataset.scene);
    const practiceTab=event.target.closest('#epm-practice-tabs .epm-subtab');if(practiceTab)return epmPracticeTabSet(practiceTab.dataset.p);
    const mark=event.target.closest('[data-fc-mark]');if(mark)return epmFcMark(mark.dataset.fcMark==='1');
    const option=event.target.closest('#epm-qz-opts .epm-opt');if(option)return epmQuizAnswer(option);
    const del=event.target.closest('[data-bank-del]');if(del){epmBank.splice(Number(del.dataset.bankDel),1);epmSaveBank();epmRenderBank();return}
    const card=event.target.closest('#epm-fc-card');if(card)return epmFcFlip();
  });
  const bind=(selector,handler)=>{const element=$(selector);if(element)element.onclick=handler};
  bind('#epm-tutor-send',()=>epmTutorSend());
  bind('#epm-tutor-clear',epmTutorClear);
  bind('#epm-tutor-mic',event=>epmMicToggle($('#epm-tutor-mic'),text=>{const input=$('#epm-tutor-in');if(input)input.value=text;epmTutorSend(text)}));
  bind('#epm-dict-btn',()=>epmDict());
  bind('#epm-dict-save',epmSaveDict);
  bind('#epm-gr-btn',()=>epmGrammar());
  bind('#epm-wr-btn',epmWriteRun);
  bind('#epm-wr-clear',()=>{const area=$('#epm-wr-text');if(area)area.value='';epmShow('#epm-wr-card',false)});
  bind('#epm-wr-copy',()=>{const out=$('#epm-wr-out');if(!out)return;navigator.clipboard?.writeText(out.innerText).then(()=>notify('Disalin \u2705'),()=>notify('Gagal menyalin'))});
  bind('#epm-speak-send',()=>epmSpeakSend());
  bind('#epm-agent-replay',epmAgentReplay);
  bind('#epm-type-toggle',epmTypeToggle);
  bind('#epm-scene-reset',epmSceneReset);
  bind('#epm-mic-btn',()=>epmMicToggle($('#epm-mic-btn'),text=>epmSpeakSend(text)));
  bind('#epm-fc-reset',epmFcReset);
  bind('#epm-qz-next',epmQuizNext);
  bind('#epm-qz-reset',epmQuizReset);
  bind('#epm-fi-check',epmFillCheck);
  bind('#epm-fi-next',epmFillNext);
  const tutorInput=$('#epm-tutor-in');
  if(tutorInput)tutorInput.onkeydown=event=>{if(event.key==='Enter'&&!event.shiftKey){event.preventDefault();epmTutorSend()}};
  const dictInput=$('#epm-dict-q');
  if(dictInput)dictInput.onkeydown=event=>{if(event.key==='Enter')epmDict()};
  const grammarInput=$('#epm-gr-q');
  if(grammarInput)grammarInput.onkeydown=event=>{if(event.key==='Enter')epmGrammar()};
  const speakInput=$('#epm-speak-in');
  if(speakInput)speakInput.onkeydown=event=>{if(event.key==='Enter')epmSpeakSend()};
  const fillInput=$('#epm-fi-in');
  if(fillInput)fillInput.onkeydown=event=>{if(event.key==='Enter')epmFillCheck()};
  epmGo('tutor');
}
function wireSpeak(root){$$('[data-speak]',root).forEach(button=>button.onclick=()=>speak(button.dataset.speak))}
function speak(text){if(!('speechSynthesis'in window))return notify('Text-to-speech tidak didukung browser');speechSynthesis.cancel();const utterance=new SpeechSynthesisUtterance(text);utterance.lang='en-US';utterance.rate=.88;speechSynthesis.speak(utterance)}
function listenSpeech(target){const SpeechRecognition=window.SpeechRecognition||window.webkitSpeechRecognition;if(!SpeechRecognition)return notify('Speech recognition tidak didukung browser ini');const recognition=new SpeechRecognition();recognition.lang='en-US';recognition.interimResults=false;const button=$('#epm-mic-btn');button.classList.add('listening');setText('#epm-live-caption','Listening…');recognition.onresult=event=>{const heard=event.results[0][0].transcript,score=similarity(heard,target);setText('#epm-live-caption',`You said: “${heard}” · Similarity ${score}%`);button.classList.remove('listening');};recognition.onerror=()=>{button.classList.remove('listening');setText('#epm-live-caption','Could not hear clearly. Please try again.');};recognition.onend=()=>button.classList.remove('listening');recognition.start();}

/* Helpers */
function getPosition(){return new Promise((resolve,reject)=>{if(!navigator.geolocation)return reject(new Error('Geolocation tidak didukung'));navigator.geolocation.getCurrentPosition(position=>resolve({lat:position.coords.latitude,lng:position.coords.longitude,accuracy:position.coords.accuracy}),reject,{enableHighAccuracy:true,timeout:12_000,maximumAge:30_000})})}
async function compressImage(file){if(file.size<800_000)return file;const image=await createImageBitmap(file),max=1440,scale=Math.min(1,max/Math.max(image.width,image.height)),canvas=document.createElement('canvas');canvas.width=Math.round(image.width*scale);canvas.height=Math.round(image.height*scale);canvas.getContext('2d').drawImage(image,0,0,canvas.width,canvas.height);return new Promise(resolve=>canvas.toBlob(resolve,'image/jpeg',.82))}
function haversine(lat1,lng1,lat2,lng2){const r=6371,toRad=value=>value*Math.PI/180,dLat=toRad(Number(lat2)-Number(lat1)),dLng=toRad(Number(lng2)-Number(lng1)),a=Math.sin(dLat/2)**2+Math.cos(toRad(Number(lat1)))*Math.cos(toRad(Number(lat2)))*Math.sin(dLng/2)**2;return 2*r*Math.asin(Math.sqrt(a))}
function expired(value){const date=value?.toDate?.()||new Date(value||0);return date.getTime()<=Date.now()}
function similarity(a,b){const aa=new Set(String(a).toLowerCase().replace(/[^a-z ]/g,'').split(/\s+/)),bb=new Set(String(b).toLowerCase().replace(/[^a-z ]/g,'').split(/\s+/)),hit=[...aa].filter(word=>bb.has(word)).length;return Math.round(hit/Math.max(aa.size,bb.size,1)*100)}
function randomItem(items){return items[Math.floor(Math.random()*items.length)]}
function shuffle(items){return [...items].sort(()=>Math.random()-.5)}
function wait(ms){return new Promise(resolve=>setTimeout(resolve,ms))}
function shortDate(value){const date=value?.toDate?.()||new Date(value||Date.now());return new Intl.DateTimeFormat('id-ID',{day:'numeric',month:'short',year:'numeric'}).format(date)}
function formatNumber(value){return new Intl.NumberFormat('id-ID').format(Math.round(Number(value)||0))}
function money(value){return 'Rp'+formatNumber(value)}
function firstName(value){return String(value||'').trim().split(/\s+/)[0]||'Pasangan'}
function labelCategory(value){return{romantic:'Romantis',date:'Kencan',favor:'Bantuan',custom:'Buatan kami'}[value]||'Buatan kami'}
function escapeHtml(value){const element=document.createElement('div');element.textContent=String(value??'');return element.innerHTML}

async function sendFinanceWarningToChat(event){const f=event.detail||{},income=Number(f.income)||0,expense=Number(f.expense)||0;if(state.demo||!api||!state.chatId||income<=0)return;const ratio=expense/income,key=`ac_finance_chat_warn_${f.period||''}_${ratio>=1?'100':ratio>=.9?'90':ratio>=.8?'80':'safe'}`;if(ratio<.8||localStorage.getItem(key))return;const level=ratio>=1?'melewati':ratio>=.9?'mencapai 90% dari':'mencapai 80% dari';localStorage.setItem(key,'1');try{await api.sendChatMessage(state.chatId,`⚠️ Peringatan keuangan: pengeluaran bulan ini ${level} pemasukan. Masuk ${money(income)}, keluar ${money(expense)}. Yuk cek Analisis Arus Kas bersama.`)}catch(error){console.warn('Peringatan keuangan ke chat:',error)}}
/* Jalan Berdua v3 — collaboration, actual costs, itinerary, offline queue */
const TRIP_INFLATION_RATE=3.19;
const TRIP_INFLATION_SOURCE='BPS · Agustus 2026';
function tripInflationMonths(value){if(!value)return 0;const start=new Date(`${value}T00:00:00`),now=new Date();if(Number.isNaN(start.getTime())||start<=now)return 0;return Math.max(0,(start-now)/dayMs/30.4375)}
let tripExpenses=[];
let tripItinerary=[];
let tripEditingId='';
let tripSelectedItineraryDay=1;
let tripItineraryEditorOpen=false;
let tripChecklist=[];
let tripLastMatusInsight='';
const TRIP_CHECKLIST_DEFAULTS=['Tiket transportasi sudah dibeli','Hotel/penginapan sudah dikonfirmasi','Dokumen dan identitas siap','Uang tunai dan e-wallet disiapkan','Cek prakiraan cuaca','Simpan alamat penting offline','Bagikan itinerary ke pasangan','Siapkan obat/kebutuhan pribadi','Pastikan agenda tidak terlalu padat','Siapkan ruang untuk foto kenangan'];
let tripDirty=false;
let tripPresenceTimer=null;
let tripSaveBusy=false;
let tripSaveQueued=false;
let tripAutoSaveTimer=null;
let tripPresenceActive=false;
let tripPresenceWrite=Promise.resolve();
function selectTripTab(tab='basics'){const root=$('#couple-trip-feature');if(!root)return;root.dataset.tripActive=tab;$$('[data-trip-tab]',root).forEach(button=>{const active=button.dataset.tripTab===tab;button.classList.toggle('active',active);button.setAttribute('aria-selected',String(active))})}
function tripPlanKey(){return`ac_trip_plan_${state.chatId||state.uid||'demo'}`}
function tripBundleKey(){return`ac_trip_bundle_${state.chatId||state.uid||'demo'}`}
function tripInputId(key){return`#trip-${({localTransport:'local-transport',startDate:'start-date'})[key]||key}`}
function tripValue(id,fallback=0){const value=Number($(id)?.value);return Number.isFinite(value)?Math.max(0,value):fallback}
function tripActor(){return state.user?.displayName||state.user?.name||'Kamu'}
function tripPartnerName(){return state.partner?.displayName||state.partner?.name||'Pasangan'}
function tripMoney(value){return money(Math.round(Number(value)||0))}
function tripSetStatus(label,detail,mode='saved'){setText('#trip-sync-label',label);setText('#trip-sync-detail',detail);const node=$('#trip-sync-status');if(node)node.dataset.state=mode}
function tripExpenseTotals(){return tripExpenses.reduce((out,item)=>{const amount=Math.max(0,Number(item.amount)||0);out.total+=amount;out[item.payer||'shared']+=amount;return out},{total:0,me:0,partner:0,shared:0})}
function tripPayerLabel(value){return value==='me'?'Saya':value==='partner'?tripPartnerName():'Bersama'}
function tripMapsSearchUrl(place=''){const query=String(place||'').trim();return query?`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(query)}`:''}
function tripMapsDirectionsUrl(origin='',destination='',transport=''){const from=String(origin||'').trim(),to=String(destination||'').trim();if(!to)return'';if(!from)return tripMapsSearchUrl(to);const text=String(transport||'').toLowerCase(),mode=/jalan|kaki|walk/.test(text)?'walking':/sepeda|bicycle/.test(text)?'bicycling':/transit|bus|kereta|angkot/.test(text)?'transit':'driving';return`https://www.google.com/maps/dir/?api=1&origin=${encodeURIComponent(from)}&destination=${encodeURIComponent(to)}&travelmode=${mode}`}
function tripEnsureChecklist(){if(!tripChecklist.length)tripChecklist=TRIP_CHECKLIST_DEFAULTS.map((title,index)=>({id:`trip-check-${index+1}`,title,owner:'Bersama',done:false,note:''}))}
function renderTripChecklist(){tripEnsureChecklist();const box=$('#trip-checklist-list'),done=tripChecklist.filter(x=>x.done).length;setText('#trip-checklist-count',`${done}/${tripChecklist.length} selesai`);setText('#trip-dash-checklist',`${done} selesai`);if(!box)return;box.innerHTML=tripChecklist.map((item,index)=>`<article class="trip-check-row ${item.done?'done':''}" data-trip-check-row="${escapeHtml(item.id)}"><header><label class="trip-check-toggle"><input data-trip-check="${escapeHtml(item.id)}" type="checkbox" ${item.done?'checked':''}/><span></span></label><div><small>TUGAS ${index+1}</small><b>${escapeHtml(item.title)}</b></div><em>${item.done?'Selesai':'Belum'}</em></header><div class="trip-check-fields"><label class="trip-check-task">Tugas<input data-trip-check-title="${escapeHtml(item.id)}" maxlength="100" value="${escapeHtml(item.title)}"/></label><label>Pemilik<select data-trip-check-owner="${escapeHtml(item.id)}"><option ${item.owner==='Bersama'?'selected':''}>Bersama</option><option ${item.owner==='Saya'?'selected':''}>Saya</option><option ${item.owner==='Pasangan'?'selected':''}>Pasangan</option></select></label><label>Deadline<input data-trip-check-deadline="${escapeHtml(item.id)}" type="date" value="${escapeHtml(item.deadline||'')}"/></label><label class="trip-check-note">Catatan<input data-trip-check-note="${escapeHtml(item.id)}" maxlength="120" placeholder="Catatan opsional" value="${escapeHtml(item.note||'')}"/></label></div></article>`).join('')}
function tripPublishPresence(active){const payload={uid:state.uid||'demo',name:tripActor(),active:!!active,at:new Date().toISOString()};if(state.demo){shared={...shared,tripPresence:payload};renderTripSync();return Promise.resolve()}if(state.chatId&&api?.saveSharedTripPresence){tripPresenceWrite=tripPresenceWrite.catch(()=>{}).then(()=>api.saveSharedTripPresence(state.chatId,payload)).catch(()=>{});return tripPresenceWrite}return Promise.resolve()}
function tripSchedulePersist(delay=700){clearTimeout(tripAutoSaveTimer);tripAutoSaveTimer=setTimeout(()=>{tripAutoSaveTimer=null;tripPersistBundle()},delay)}
function tripMarkDirty(){tripDirty=true;tripSaveLocal();tripSetStatus('Menyimpan…','Perubahan aman di perangkat ini','dirty');clearTimeout(tripPresenceTimer);tripPresenceTimer=setTimeout(()=>{tripPresenceTimer=null;tripPresenceActive=false;tripPublishPresence(false)},2400);if(!tripPresenceActive){tripPresenceActive=true;tripPublishPresence(true)}tripSchedulePersist()}
function renderTripSync(){const presence=shared.tripPresence||{},stamp=new Date(presence.at||0).getTime(),partnerEditing=stamp&&Date.now()-stamp<15000&&presence.active&&presence.uid!==state.uid;if(partnerEditing)return tripSetStatus(`${presence.name||tripPartnerName()} sedang mengedit`,'Perubahan partner akan masuk otomatis','partner');if(!navigator.onLine)return tripSetStatus(tripDirty?'Offline · belum dikirim':'Offline · data lokal aman','Akan disinkronkan saat online','offline');const updated=tripPlan?.updatedAt?new Date(tripPlan.updatedAt):null;tripSetStatus(tripDirty?'Menyimpan…':'Tersimpan',tripDirty?'Perubahan akan disimpan otomatis':updated?`Terakhir diubah ${updated.toLocaleString('id-ID',{day:'numeric',month:'short',hour:'2-digit',minute:'2-digit'})} oleh ${tripPlan.updatedBy||tripActor()}`:'Perubahan bersama siap digunakan',tripDirty?'dirty':'saved')}
function renderTripExpenses(){const totals=tripExpenseTotals();setText('#trip-expense-total',tripMoney(totals.total));setText('#trip-expense-mine',tripMoney(totals.me));setText('#trip-expense-partner',tripMoney(totals.partner));setText('#trip-expense-shared',tripMoney(totals.shared));const box=$('#trip-expense-list');if(!box)return;box.innerHTML=tripExpenses.length?tripExpenses.slice().reverse().slice(0,30).map(item=>`<article class="trip-expense-row"><div><b>${escapeHtml(item.category||'Lainnya')}</b><small>${escapeHtml(item.date||String(item.createdAt||'').slice(0,10))} · ${escapeHtml(item.method||'Metode belum diisi')} · ${escapeHtml(item.note||'Pengeluaran perjalanan')} · ${escapeHtml(tripPayerLabel(item.payer))}</small></div><strong>${tripMoney(item.amount)}</strong><button aria-label="Hapus pengeluaran" data-trip-expense-delete="${escapeHtml(item.id)}" type="button"><i data-fa="xmark"></i></button></article>`).join(''):'<div class="trip-empty-state">Belum ada pengeluaran aktual. Catat biaya pertama kalian di sini.</div>';hydrateIconsIn(box)}
function tripSetItineraryEditor(open,focus=false){tripItineraryEditorOpen=!!open;$('#trip-itinerary-editor')?.classList.toggle('hidden',!tripItineraryEditorOpen);$('#trip-itinerary-add-open')?.setAttribute('aria-expanded',String(tripItineraryEditorOpen));if(tripItineraryEditorOpen){const select=$('#trip-itinerary-day');if(select)select.value=String(tripSelectedItineraryDay);if(focus)setTimeout(()=>$('#trip-itinerary-title')?.focus(),180)}}
function tripResetItineraryEditor({keepOpen=false}={}){const form=$('#trip-itinerary-form');if(!form)return;form.reset();tripEditingId='';const id=$('#trip-itinerary-edit-id');if(id)id.value='';const time=$('#trip-itinerary-time');if(time)time.value='09:00';const cost=$('#trip-itinerary-cost');if(cost)cost.value='0';const status=$('#trip-itinerary-status');if(status)status.value='Rencana';$('#trip-itinerary-editing')?.classList.add('hidden');$('#trip-itinerary-cancel')?.classList.add('hidden');setText('#trip-itinerary-editor-title','Tambah agenda baru');setText('#trip-itinerary-submit-label','Tambah agenda');const submit=$('#trip-itinerary-submit'),icon=submit?.querySelector('[data-fa]');if(icon){icon.dataset.fa='plus';delete icon.dataset.faDone;icon.innerHTML='';hydrateIconsIn(submit)}renderTripItinerary();tripSetItineraryEditor(keepOpen,keepOpen)}
function tripOpenNewItinerary(day=tripSelectedItineraryDay){tripSelectedItineraryDay=Math.max(1,Number(day)||1);tripResetItineraryEditor({keepOpen:true})}
function tripBeginItineraryEdit(id){const item=tripItinerary.find(row=>row.id===id);if(!item)return;tripSelectedItineraryDay=Math.max(1,Number(item.day)||1);tripEditingId=id;renderTripItinerary();const values={day:item.day||1,time:item.time||'09:00',title:item.title||'',place:item.place||'',duration:item.duration||'',cost:Number(item.cost)||0,transport:item.transport||'',status:item.status||'Rencana'};Object.entries(values).forEach(([key,value])=>{const input=$(`#trip-itinerary-${key}`);if(input)input.value=String(value)});const editId=$('#trip-itinerary-edit-id');if(editId)editId.value=id;setText('#trip-itinerary-editing-name',item.title||'agenda');setText('#trip-itinerary-editor-title','Edit agenda');setText('#trip-itinerary-submit-label','Simpan perubahan');const submit=$('#trip-itinerary-submit'),icon=submit?.querySelector('[data-fa]');if(icon){icon.dataset.fa='pen';delete icon.dataset.faDone;icon.innerHTML='';hydrateIconsIn(submit)}$('#trip-itinerary-editing')?.classList.remove('hidden');$('#trip-itinerary-cancel')?.classList.remove('hidden');tripSetItineraryEditor(true,true);$('#trip-itinerary-editor')?.scrollIntoView({behavior:'smooth',block:'center'})}
function tripItineraryDayLabel(day){const start=$('#trip-start-date')?.value||tripPlan?.startDate;if(!start)return'';const date=new Date(`${start}T00:00:00`);if(Number.isNaN(date.getTime()))return'';date.setDate(date.getDate()+Math.max(0,Number(day)-1));return new Intl.DateTimeFormat('id-ID',{weekday:'long',day:'numeric',month:'short'}).format(date)}
function tripItineraryStatus(value='Rencana'){return String(value||'Rencana').toLowerCase().replace(/[^a-z]+/g,'-')}
function tripInvalidateRouteDay(day){const key=String(Math.max(1,Number(day)||1));tripItinerary.forEach(item=>{if(String(item.day)===key)delete item.routeAnalysis});if(tripPlan?.routeInsights){const insights={...tripPlan.routeInsights};delete insights[key];tripPlan={...tripPlan,routeInsights:insights}}}
function tripInvalidateAllRoutes(){tripItinerary.forEach(item=>delete item.routeAnalysis);if(tripPlan)tripPlan={...tripPlan,routeInsights:{}}}
function renderTripRouteInsight(day=tripSelectedItineraryDay){
  const box=$('#trip-route-analysis');if(!box)return;const insight=tripPlan?.routeInsights?.[String(day)],button=$('#trip-itinerary-analyze'),label=button?.querySelector('span');if(label)label.textContent=`Analisis Hari ${day}`;
  if(!insight){box.innerHTML=`<div class="trip-route-analysis-empty"><span><i data-fa="route"></i></span><div><b>Rute Hari ${day} belum dianalisis</b><small>Matus akan membaca jarak, waktu tempuh, dan traffic tanpa menambah isian form.</small></div></div>`;hydrateIconsIn(box);return}
  const warnings=Array.isArray(insight.warnings)?insight.warnings:[],hasLegs=Array.isArray(insight.legs)&&insight.legs.length>0,state=insight.conflicts?'danger':warnings.length?'warning':'estimate',status=insight.conflicts?'Jadwal bertabrakan':warnings.length?`${warnings.length} lokasi perlu diperjelas`:'Estimasi rute gratis';
  const warningHtml=warnings.length?`<div class="trip-route-warnings"><b><i data-fa="triangle-exclamation"></i> Lokasi yang perlu diperbaiki</b>${warnings.map(item=>`<article><strong>${escapeHtml(item.title||'Agenda')}</strong><span>${escapeHtml(item.place||'Lokasi belum diisi')}</span><small>${escapeHtml(item.message||'Rute belum dapat dihitung')}</small></article>`).join('')}</div>`:'';
  const legsHtml=hasLegs?`<div class="trip-route-legs">${insight.legs.map((leg,index)=>`<article data-traffic="${escapeHtml(leg.trafficKey)}"><span class="trip-route-leg-number">${index+1}</span><div><b>${escapeHtml(leg.origin)} → <a class="trip-route-location-link" href="${tripMapsDirectionsUrl(leg.origin,leg.destination,leg.travelMode)}" target="_blank" rel="noopener noreferrer">${escapeHtml(leg.destination)} <i data-fa="arrow-right"></i></a></b><small>${Number(leg.distanceKm||0).toLocaleString('id-ID')} km · ${Math.round(leg.durationMinutes)} menit · ${escapeHtml(leg.trafficLabel)}</small><em>Berangkat ${escapeHtml(leg.departAt)} · tiba ${escapeHtml(leg.arriveAt)} · agenda ${escapeHtml(leg.agendaStart)}</em></div><i data-fa="${leg.conflict?'triangle-exclamation':'route'}"></i></article>`).join('')}</div>`:'';
  box.innerHTML=`<header><div><span class="trip-route-ai"><i data-fa="sparkles"></i></span><div><small>ANALISIS MATUS · HARI ${day}</small><b>${escapeHtml(status)}</b></div></div><span class="trip-route-source ${state}">${escapeHtml(insight.provider||'Matus')}</span></header><p>${escapeHtml(insight.summary||routeInsightFallback(insight))}</p><div class="trip-route-metrics"><span><small>Rute berhasil</small><b>${Number(insight.legs?.length)||0}/${Number(insight.requestedLegs)||Number(insight.legs?.length)||0}</b></span><span><small>Total jarak</small><b>${Number(insight.totalKm||0).toLocaleString('id-ID')} km</b></span><span><small>Waktu di jalan</small><b>${Math.round(Number(insight.totalMinutes)||0)} menit</b></span><span><small>Potensi terlambat</small><b>${Number(insight.conflicts)||0}</b></span></div>${warningHtml}${legsHtml}<small class="trip-route-disclaimer">Jarak dan durasi dihitung gratis melalui OpenStreetMap + OSRM. Klik nama lokasi untuk membuka Google Maps dan melihat kemacetan aktual.</small>`;hydrateIconsIn(box)
}
async function tripAnalyzeSelectedDay(){
  const day=tripSelectedItineraryDay,entries=tripItinerary.filter(item=>Number(item.day)===day);if(!entries.length)return notify(`Hari ${day} belum memiliki agenda`);
  const button=$('#trip-itinerary-analyze');button.disabled=true;button.classList.add('loading');const label=button.querySelector('span');if(label)label.textContent='Matus menganalisis…';
  try{
    const result=await analyzeTripDayRoutes({entries,origin:tripPlan?.origin||$('#trip-origin')?.value||'',destinationContext:tripPlan?.destination||$('#trip-destination')?.value||'',day,startDate:tripPlan?.startDate||$('#trip-start-date')?.value||'',demo:state.demo,onProgress:({index,total})=>{if(label)label.textContent=`Rute ${index+1}/${total}…`}});
    let summary=routeInsightFallback(result);
    if(hasLocalAiConfig())try{summary=await localAiChat(`Analisis itinerary berikut hanya berdasarkan data rute yang diberikan. Jelaskan singkat apakah jadwal aman, bagian yang berisiko terlambat, dan satu saran paling penting. Jangan mengarang traffic. Data: ${JSON.stringify(result)}`,{system:'Kamu Matus, asisten perjalanan AppCouple. Gunakan Bahasa Indonesia natural. Maksimal 4 kalimat. Data traffic live hanya boleh disebut bila trafficLive=true.'})||summary}catch(error){console.warn('Ringkasan Matus memakai fallback:',error.message)}
    result.summary=summary;result.legs.forEach(leg=>{const item=tripItinerary.find(row=>row.id===leg.itemId);if(item)item.routeAnalysis={...leg,analyzedAt:result.analyzedAt}});
    tripPlan={...tripPlan,routeInsights:{...(tripPlan?.routeInsights||{}),[String(day)]:result}};tripSaveLocal();renderTripItinerary();tripMarkDirty();const announcement=`Analisis itinerary hari ${day} selesai. ${summary}`;if(typeof window.__appCoupleMatusSpeak==='function')window.__appCoupleMatusSpeak(announcement);else window.dispatchEvent(new CustomEvent('appcouple:matus-announce',{detail:{text:announcement,source:'trip'}}));notify('Rute gratis selesai dianalisis · klik lokasi untuk cek traffic Google Maps')
  }catch(error){notify(error.message||'Matus belum dapat menganalisis rute')}finally{button.disabled=false;button.classList.remove('loading');if(label)label.textContent=`Analisis Hari ${day}`}
}
function renderTripItinerary(){
  const itineraryEstimate=tripItinerary.reduce((sum,item)=>sum+Math.max(0,Number(item.cost)||0),0);
  setText('#trip-itinerary-cost-total',tripMoney(itineraryEstimate));
  const select=$('#trip-itinerary-day'),days=Math.max(1,Math.round(tripValue('#trip-days',3)));
  tripSelectedItineraryDay=Math.min(days,Math.max(1,Number(tripSelectedItineraryDay)||1));
  if(select){select.innerHTML=Array.from({length:days},(_,i)=>`<option value="${i+1}">Hari ${i+1}</option>`).join('');select.value=String(tripSelectedItineraryDay)}
  const items=tripItinerary.slice().sort((a,b)=>Number(a.day)-Number(b.day)||String(a.time||'').localeCompare(String(b.time||'')));
  const groups=items.reduce((out,item)=>{const day=Math.max(1,Number(item.day)||1);(out[day]||=[]).push(item);return out},{});
  const tabs=$('#trip-itinerary-day-tabs');
  if(tabs){tabs.innerHTML=Array.from({length:days},(_,index)=>{const day=index+1,entries=groups[day]||[],active=day===tripSelectedItineraryDay,dateLabel=tripItineraryDayLabel(day);return `<button aria-selected="${active}" class="${active?'active':''}" data-itinerary-day-select="${day}" role="tab" type="button"><span>Hari ${day}</span><small>${escapeHtml(dateLabel||`${entries.length} agenda`)}</small><b>${entries.length}</b></button>`}).join('');hydrateIconsIn(tabs)}
  const box=$('#trip-itinerary-list');if(!box)return;
  const day=tripSelectedItineraryDay,entries=groups[day]||[],dateLabel=tripItineraryDayLabel(day),dayCost=entries.reduce((sum,item)=>sum+Math.max(0,Number(item.cost)||0),0);
  if(!entries.length){box.innerHTML=`<div class="trip-itinerary-empty trip-itinerary-empty-day"><span><i data-fa="calendar-day"></i></span><b>Hari ${day} belum punya agenda</b><small>${escapeHtml(dateLabel||'Pilih Tambah agenda untuk mengisi hari ini.')}</small><button data-itinerary-add-day="${day}" type="button"><i data-fa="plus"></i> Tambah agenda Hari ${day}</button></div>`;hydrateIconsIn(box);renderTripRouteInsight(day);return}
  box.innerHTML=`<section class="trip-itinerary-day" data-itinerary-day="${day}"><header class="trip-itinerary-day-head"><span class="trip-itinerary-day-icon"><i data-fa="calendar-day"></i></span><div><small>HARI ${day}</small><b>${escapeHtml(dateLabel||`${entries.length} agenda`)}</b></div><div class="trip-itinerary-day-summary"><span>${entries.length} agenda</span><strong>${tripMoney(dayCost)}</strong></div></header><div class="trip-itinerary-timeline">${entries.map((item,index)=>{
    const status=item.status||'Rencana',statusKey=tripItineraryStatus(status),title=escapeHtml(item.title||'Agenda'),place=escapeHtml(item.place||'Lokasi belum diisi'),routeOrigin=index?entries[index-1]?.place:(tripPlan?.origin||$('#trip-origin')?.value||''),directionsUrl=tripMapsDirectionsUrl(routeOrigin,item.place,item.transport);
    const route=item.routeAnalysis;
    return `<article class="trip-itinerary-row" data-itinerary-status="${statusKey}"><div class="trip-itinerary-rail"><span>${escapeHtml(item.time||'—')}</span><i></i></div><div class="trip-itinerary-card"><div class="trip-itinerary-card-main"><div class="trip-itinerary-title"><b>${title}</b><span class="trip-itinerary-status status-${statusKey}"><i data-fa="${statusKey==='selesai'?'check':statusKey==='dibatalkan'?'xmark':statusKey==='dipesan'?'floppy-disk':'calendar-days'}"></i>${escapeHtml(status)}</span></div>${item.place?`<a aria-label="Buka rute dari ${escapeHtml(routeOrigin||'titik awal')} ke ${place} di Google Maps" class="trip-itinerary-place trip-itinerary-place-link" href="${directionsUrl}" rel="noopener noreferrer" target="_blank"><i data-fa="location-dot"></i><span>${place}</span><i data-fa="arrow-right"></i></a>`:`<small class="trip-itinerary-place"><i data-fa="location-dot"></i>${place}</small>`}<div class="trip-itinerary-meta"><span><i data-fa="clock-rotate-left"></i>${escapeHtml(item.duration||'Durasi belum diisi')}</span><span><i data-fa="route"></i>${escapeHtml(item.transport||'Transport belum diisi')}</span><span><i data-fa="wallet"></i>${tripMoney(item.cost||0)}</span></div>${route?`<div class="trip-itinerary-route-mini" data-traffic="${escapeHtml(route.trafficKey)}"><i data-fa="${route.conflict?'triangle-exclamation':'route'}"></i><span><b>${Number(route.distanceKm||0).toLocaleString('id-ID')} km · ${Math.round(route.durationMinutes)} menit · ${escapeHtml(route.trafficLabel)}</b><small>Berangkat ${escapeHtml(route.departAt)} · tiba ${escapeHtml(route.arriveAt)}</small></span></div>`:''}</div><div class="trip-itinerary-actions"><button aria-label="Edit agenda ${title}" class="trip-itinerary-edit" data-trip-itinerary-edit="${escapeHtml(item.id)}" type="button"><i data-fa="pen"></i></button>${item.place?`<a aria-label="Buka ${place} di Google Maps" class="trip-itinerary-google" href="${directionsUrl}" rel="noopener noreferrer" target="_blank"><i data-fa="location-dot"></i><span>Maps</span></a>`:''}<button aria-label="Buka lokasi di Peta Kita" data-trip-itinerary-map="${escapeHtml(item.place||'')}" type="button"><i data-fa="map"></i></button><button aria-label="Hapus agenda ${title}" class="trip-itinerary-delete" data-trip-itinerary-delete="${escapeHtml(item.id)}" type="button"><i data-fa="trash"></i></button></div></div></article>`}).join('')}</div></section>`;
  hydrateIconsIn(box);renderTripRouteInsight(day)
}
function tripRenderSharedBundle(data={}){if(Array.isArray(data.tripExpenses))tripExpenses=data.tripExpenses;if(Array.isArray(data.tripItinerary))tripItinerary=data.tripItinerary;if(Array.isArray(data.tripChecklist))tripChecklist=data.tripChecklist;renderTripExpenses();renderTripItinerary();renderTripChecklist();renderTripSync()}
function syncTripPlanFromShared(plan={}){if(!plan||!$('#couple-trip-feature'))return;['origin','destination','days','nights','travelers','startDate','budget','saved','actual','transport','lodging','meal','localTransport','activities','bufferPercent','inflationRate'].forEach(key=>{const input=$(tripInputId(key));if(input&&plan[key]!==undefined)input.value=plan[key]});if(plan.style){tripStyle=plan.style;$$('[data-trip-style]').forEach(button=>button.classList.toggle('active',button.dataset.tripStyle===tripStyle))}tripPlan={...tripPlan,...plan};tripDirty=false;tripCalculate();renderTripSync()}
function syncTripSharedData(data={}){if(data.tripPlan)syncTripPlanFromShared(data.tripPlan);tripRenderSharedBundle(data)}
function tripRead(){return{origin:$('#trip-origin')?.value.trim()||'',destination:$('#trip-destination')?.value.trim()||'',days:Math.max(1,Math.round(tripValue('#trip-days',3))),nights:Math.max(0,Math.round(tripValue('#trip-nights',2))),travelers:Math.max(1,Math.round(tripValue('#trip-travelers',2))),startDate:$('#trip-start-date')?.value||'',budget:tripValue('#trip-budget',5000000),saved:tripValue('#trip-saved',0),actual:tripValue('#trip-actual',0),transport:tripValue('#trip-transport',1200000),lodging:tripValue('#trip-lodging',450000),meal:tripValue('#trip-meal',60000),localTransport:tripValue('#trip-local-transport',120000),activities:tripValue('#trip-activities',300000),bufferPercent:Math.min(30,tripValue('#trip-buffer',12)),inflationRate:Math.min(50,tripValue('#trip-inflation',TRIP_INFLATION_RATE)),style:tripStyle}}
function tripExpenseCategory(value=''){const key=String(value||'').toLowerCase();if(key==='hotel'||key==='penginapan')return'Penginapan';if(key==='darurat'||key==='cadangan')return'Cadangan';if(key==='transportasi')return'Transportasi';if(key==='makan')return'Makan';if(key==='wisata')return'Wisata';if(key==='transport lokal')return'Transport lokal';if(key==='belanja')return'Belanja';return'Lainnya'}
function tripBudgetAlignmentRows(p){const actual=tripExpenses.reduce((out,item)=>{const key=tripExpenseCategory(item.category);out[key]=(out[key]||0)+Math.max(0,Number(item.amount)||0);return out},{}),planned=[['Transportasi',p.breakdown.transport],['Penginapan',p.breakdown.lodging],['Makan',p.breakdown.meals],['Transport lokal',p.breakdown.localTransport],['Wisata',p.breakdown.activities],['Cadangan',p.breakdown.buffer]];const known=new Set(planned.map(x=>x[0])),other=Object.entries(actual).filter(([key])=>!known.has(key)).reduce((sum,[,value])=>sum+value,0);if(other)planned.push(['Lainnya',0]);return planned.map(([category,estimate])=>{const spent=actual[category]||0,remaining=estimate-spent,status=spent<=0?'Belum dibayar':spent<estimate?'Dibayar sebagian':spent>estimate?'Melebihi rencana':'Lunas';return{category,estimate,actual:spent,remaining,status}})}
function renderTripAlignedSheets(p){if(!p?.breakdown)return;const rows=tripBudgetAlignmentRows(p),actual=rows.reduce((sum,row)=>sum+row.actual,0),estimate=rows.reduce((sum,row)=>sum+row.estimate,0),remaining=p.budget-actual,status=!p.budget?'Isi budget':remaining<0?'Melewati budget':remaining<p.budget*.1?'Mepet':'Aman';setText('#trip-dash-route',`${p.origin||'Titik awal'} → ${p.destination||'Tujuan'}`);setText('#trip-dash-date',p.startDate?new Date(`${p.startDate}T00:00:00`).toLocaleDateString('id-ID',{day:'numeric',month:'short',year:'numeric'}):'Belum diatur');setText('#trip-dash-duration',`${p.days} hari / ${p.nights} malam`);setText('#trip-dash-travelers',`${p.travelers} orang`);setText('#trip-dash-budget',tripMoney(p.budget));setText('#trip-dash-estimate',tripMoney(estimate));setText('#trip-dash-actual',tripMoney(actual));setText('#trip-dash-remaining',tripMoney(remaining));setText('#trip-dash-saving-target',tripMoney(estimate));setText('#trip-dash-saved',tripMoney(p.saved));setText('#trip-dash-agendas',`${tripItinerary.length} agenda`);setText('#trip-dash-checklist',`${tripChecklist.filter(x=>x.done).length} selesai`);setText('#trip-budget-sheet-status',status);const statusNode=$('#trip-budget-sheet-status');if(statusNode)statusNode.dataset.status=status.toLowerCase().replace(/\s+/g,'-');const body=$('#trip-budget-alignment-body');if(body)body.innerHTML=rows.map(row=>`<tr><td>${escapeHtml(row.category)}</td><td>${tripMoney(row.estimate)}</td><td>${tripMoney(row.actual)}</td><td class="${row.remaining<0?'negative':''}">${tripMoney(row.remaining)}</td><td><span data-budget-row-status="${row.status.toLowerCase().replace(/\s+/g,'-')}">${row.status}</span></td></tr>`).join('');setText('#trip-budget-alignment-estimate',tripMoney(estimate));setText('#trip-budget-alignment-actual',tripMoney(actual));setText('#trip-budget-alignment-remaining',tripMoney(remaining))}
function tripPublishMatusContext(){if(!tripPlan)return null;const routeInsights=Object.values(tripPlan.routeInsights||{}).map(item=>({day:Number(item.day)||0,totalKm:Number(item.totalKm)||0,totalMinutes:Number(item.totalMinutes)||0,conflicts:Number(item.conflicts)||0,warnings:(item.warnings||[]).slice(0,8).map(warning=>({title:String(warning.title||'').slice(0,80),place:String(warning.place||'').slice(0,120),message:String(warning.message||'').slice(0,180)})),legs:(item.legs||[]).slice(0,20).map(leg=>({origin:String(leg.origin||'').slice(0,120),destination:String(leg.destination||'').slice(0,120),distanceKm:Number(leg.distanceKm)||0,durationMinutes:Number(leg.durationMinutes)||0,departAt:leg.departAt||'',arriveAt:leg.arriveAt||'',conflict:!!leg.conflict,travelMode:leg.travelMode||''}))}));const totals=tripExpenseTotals(),context={plan:{origin:tripPlan.origin||'',destination:tripPlan.destination||'',startDate:tripPlan.startDate||'',days:Number(tripPlan.days)||0,nights:Number(tripPlan.nights)||0,travelers:Number(tripPlan.travelers)||0,budget:Number(tripPlan.budget)||0,total:Number(tripPlan.total)||0,actual:Number(tripPlan.actual)||0,remaining:Number(tripPlan.remaining)||0,gap:Number(tripPlan.gap)||0,updatedAt:tripPlan.updatedAt||null},itinerary:tripItinerary.slice().sort((a,b)=>Number(a.day)-Number(b.day)||String(a.time||'').localeCompare(String(b.time||''))).slice(0,80).map(item=>({day:Number(item.day)||1,time:item.time||'',title:String(item.title||'').slice(0,100),place:String(item.place||'').slice(0,140),duration:String(item.duration||'').slice(0,40),cost:Number(item.cost)||0,transport:String(item.transport||'').slice(0,60),status:String(item.status||'Rencana').slice(0,40)})),routeInsights,expenses:{total:totals.total,me:totals.me,partner:totals.partner,shared:totals.shared,count:tripExpenses.length},checklist:{total:tripChecklist.length,done:tripChecklist.filter(item=>item.done).length,pending:tripChecklist.filter(item=>!item.done).slice(0,15).map(item=>({title:String(item.title||'').slice(0,100),owner:String(item.owner||'').slice(0,40),deadline:item.deadline||'',note:String(item.note||'').slice(0,120)}))},lastInsight:String(tripLastMatusInsight||'').slice(0,1200),publishedAt:new Date().toISOString()};window.__appCoupleTripPlan={...tripPlan};window.__appCoupleTripContext=context;window.dispatchEvent(new CustomEvent('appcouple:trip-context-refresh',{detail:context}));return context}
function tripCalculate(){const p=tripRead(),monthsAhead=tripInflationMonths(p.startDate),inflationFactor=Math.pow(1+p.inflationRate/100,monthsAhead/12),lodgingToday=p.lodging*p.nights,mealsToday=p.meal*p.travelers*p.days,localToday=p.localTransport*p.days,todayBase=p.transport+lodgingToday+mealsToday+localToday+p.activities,inflatedBase=todayBase*inflationFactor,buffer=inflatedBase*p.bufferPercent/100,total=Math.round(inflatedBase+buffer),todayTotal=Math.round(todayBase*(1+p.bufferPercent/100)),gap=Math.max(0,total-p.budget),remaining=p.budget-total,ratio=p.budget?total/p.budget:0,actualTotal=tripExpenseTotals().total;p.actual=actualTotal;const actualInput=$('#trip-actual');if(actualInput)actualInput.value=String(actualTotal);p.total=total;p.todayTotal=todayTotal;p.inflationMonths=monthsAhead;p.inflationFactor=inflationFactor;p.inflationAdjustment=Math.max(0,Math.round(total-todayTotal));p.breakdown={transport:p.transport*inflationFactor,lodging:lodgingToday*inflationFactor,meals:mealsToday*inflationFactor,localTransport:localToday*inflationFactor,activities:p.activities*inflationFactor,buffer};p.gap=gap;p.remaining=remaining;p.daily=Math.round((inflatedBase-p.transport*inflationFactor)/p.days);tripPlan={...tripPlan,...p};tripPublishMatusContext();window.dispatchEvent(new CustomEvent('appcouple:trip-update',{detail:window.__appCoupleTripPlan}));setText('#trip-total',tripMoney(total));setText('#trip-plan-compare',tripMoney(total));setText('#trip-actual-compare',tripMoney(p.actual));setText('#trip-actual-copy',p.actual?(p.actual>total?`Aktual sudah ${tripMoney(p.actual-total)} di atas rencana.`:`Masih ada ruang ${tripMoney(total-p.actual)} dibanding estimasi.`):'Catat pengeluaran aktual di tab Pengeluaran.');setText('#trip-budget-label',tripMoney(p.budget));setText('#trip-saving-number',tripMoney(Math.max(0,total-p.saved)));setText('#trip-saving-title',gap?'Kekurangan dana':'Target tabungan');setText('#trip-saving-copy',gap?`Dana yang perlu ditambah dari budget: ${tripMoney(gap)}. Dana tersedia sekarang ${tripMoney(p.saved)}.`:`Dana tersedia sudah menutup estimasi. Tetap sisihkan cadangan sebelum berangkat.`);setText('#trip-inflation-note',monthsAhead?`${TRIP_INFLATION_SOURCE} · ${p.inflationRate.toFixed(2)}%/tahun · ${monthsAhead.toFixed(1)} bulan menuju berangkat · tambahan ${tripMoney(p.inflationAdjustment)}.`:`${TRIP_INFLATION_SOURCE} · ${p.inflationRate.toFixed(2)}%/tahun · keberangkatan dekat, belum ada penyesuaian waktu.`);const badge=$('#trip-status-badge');let status='Aman',copy=`Masih ada sisa ${tripMoney(Math.max(0,remaining))}.`;if(!p.budget){status='Isi budget';copy='Tentukan budget maksimal dulu.'}else if(ratio>1){status='Belum masuk';copy=`Kurang ${tripMoney(gap)} dari budget maksimal.`}else if(ratio>.9){status='Mepet';copy=`Masih masuk, tapi cuma tersisa ${tripMoney(Math.max(0,remaining))}.`}if(badge){badge.textContent=status;badge.className=`trip-status-badge ${status==='Aman'?'safe':status==='Mepet'?'tight':'over'}`}setText('#trip-status-copy',copy);const fill=$('#trip-budget-fill');if(fill)fill.style.width=`${Math.min(100,Math.max(4,ratio*100))}%`;setText('#trip-gap',p.budget?(remaining>=0?`${tripMoney(remaining)} tersisa`:`${tripMoney(gap)} di atas budget`):'Budget belum diisi');const breakdown=[['Transport pergi-pulang',p.breakdown.transport],['Penginapan',p.breakdown.lodging],['Makan',p.breakdown.meals],['Transport lokal',p.breakdown.localTransport],['Wisata & aktivitas',p.breakdown.activities],['Cadangan + inflasi',buffer]],box=$('#trip-breakdown');if(box)box.innerHTML=breakdown.map(([label,value])=>`<div><span>${label}</span><b>${tripMoney(value)}</b></div>`).join('');const dayBox=$('#trip-day-list');if(dayBox)dayBox.innerHTML=Array.from({length:p.days},(_,index)=>{const transport=index===0||index===p.days-1?p.breakdown.transport/(p.days===1?1:2):0;return`<div class="trip-day-row"><span>Hari ${index+1}<small>${index===0?'Berangkat':index===p.days-1?'Pulang':'Di tujuan'}</small></span><b>${tripMoney(Math.round(p.daily+transport))}</b></div>`}).join('');renderTripExpenses();renderTripItinerary();renderTripAlignedSheets(p);setText('#trip-expense-sync-note',navigator.onLine?'Tersimpan bersama':'Mode offline');return p}
function tripBuildItinerary(){const p=tripPlan||tripRead();if(!p.destination)return notify('Isi tujuan dulu, baru gua susun itinerary');if(tripItinerary.length)return notify('Itinerary sudah ada. Tambahkan agenda manual kalau mau');tripItinerary=Array.from({length:p.days},(_,index)=>({id:crypto.randomUUID(),day:index+1,time:index===0?'08:00':index===p.days-1?'09:00':'10:00',title:index===0?'Berangkat & check-in':index===p.days-1?'Pulang dan beli oleh-oleh':`Eksplorasi ${p.destination}`,place:index===0?(p.origin||'Titik berangkat'):p.destination}));tripSaveLocal();renderTripItinerary();tripMarkDirty();selectTripTab('daily');setText('#trip-matus-output',`Gua sudah bikin kerangka ${p.days} hari. Cek tab Harian, terus sesuaikan jam dan tempatnya.`)}
function tripMatusLocalCopy(p=tripPlan||tripRead()){if(!p?.destination)return'Isi tujuan dulu. Gua belum bisa menilai rencana yang masih kosong.';if(p.gap>0)return`Gua ngomong terus terang: ${p.destination} belum masuk budget lu. Estimasinya ${tripMoney(p.total)}, sementara batas lu ${tripMoney(p.budget)}. Potong ${p.breakdown.lodging>p.breakdown.activities?'penginapan':'aktivitas'} dulu atau tambah target tabungan ${tripMoney(p.gap)}.`;if(p.remaining<p.total*.1)return`Masih bisa berangkat, tapi tipis. Totalnya ${tripMoney(p.total)} dan sisa cuma ${tripMoney(Math.max(0,p.remaining))}. Simpan sisa itu sebagai dana darurat perjalanan.`;return`Menurut hitungan gua, rencana ke ${p.destination} masih aman. Estimasinya ${tripMoney(p.total)} dan masih ada sisa ${tripMoney(p.remaining)}. Makan dan transport lokal paling perlu diawasi.`}
function tripMatusAction(action){const p=tripCalculate(),totals=tripExpenseTotals(),output=$('#trip-matus-output');if(!output)return;if(action==='check'){output.textContent=tripMatusLocalCopy(p);tripLastMatusInsight=output.textContent;}if(action==='split')output.textContent=totals.total?`Dari ${tripMoney(totals.total)}, lu bayar ${tripMoney(totals.me)}, ${tripPartnerName()} bayar ${tripMoney(totals.partner)}, dan biaya bersama ${tripMoney(totals.shared)}. Sepakati biaya bersama ini dibagi dua.`:'Belum ada pengeluaran yang bisa gua bagi. Catat dulu di tab Pengeluaran.';if(action==='itinerary'){if(!p.destination)return notify('Isi tujuan dulu, baru Matus bisa menyusun dan menganalisis itinerary');if(!tripItinerary.length)tripBuildItinerary();else selectTripTab('daily');return tripAnalyzeSelectedDay()}if(action==='summary'){const text=`Rekap ${p.origin||'titik awal'} → ${p.destination||'tujuan'}: ${p.days} hari, estimasi ${tripMoney(p.total)}, aktual ${tripMoney(p.actual)}, sisa budget ${tripMoney(Math.max(0,p.remaining))}.`;output.textContent=text;tripLastMatusInsight=text;if(!state.demo&&api?.sendChatMessage&&state.chatId)api.sendChatMessage(state.chatId,text,null,'trip-summary').catch(()=>{})}selectTripTab('matus')}
function tripApplyStyle(style){tripStyle=style;const presets={budget:{lodging:300000,meal:40000,localTransport:80000,activities:150000,buffer:10},balanced:{lodging:450000,meal:60000,localTransport:120000,activities:300000,buffer:12},comfort:{lodging:800000,meal:100000,localTransport:220000,activities:600000,buffer:15}}[style]||{};Object.entries(presets).forEach(([key,value])=>{const input=$(tripInputId(key));if(input)input.value=value});$$('[data-trip-style]').forEach(button=>button.classList.toggle('active',button.dataset.tripStyle===style));tripCalculate();tripMarkDirty()}
function tripSaveLocal(){tripPublishMatusContext();try{localStorage.setItem(tripBundleKey(),JSON.stringify({plan:tripPlan,expenses:tripExpenses,itinerary:tripItinerary,checklist:tripChecklist,matusInsight:tripLastMatusInsight,savedAt:new Date().toISOString()}));localStorage.removeItem(tripPlanKey())}catch{}}
function tripReadLocal(){try{const bundle=JSON.parse(localStorage.getItem(tripBundleKey())||'null'),legacyPlan=JSON.parse(localStorage.getItem(tripPlanKey())||'null');if(bundle){if(Array.isArray(bundle.expenses))tripExpenses=bundle.expenses;if(Array.isArray(bundle.itinerary))tripItinerary=bundle.itinerary;if(Array.isArray(bundle.checklist))tripChecklist=bundle.checklist;if(bundle.matusInsight)tripLastMatusInsight=bundle.matusInsight;if(bundle.plan)syncTripPlanFromShared(bundle.plan)}else if(legacyPlan){syncTripPlanFromShared(legacyPlan);tripSaveLocal()}localStorage.removeItem(tripPlanKey())}catch{}}
async function tripPersistBundle(){clearTimeout(tripAutoSaveTimer);tripAutoSaveTimer=null;tripCalculate();tripPlan={...tripPlan,updatedAt:new Date().toISOString(),updatedBy:tripActor()};tripSaveLocal();if(state.demo){shared={...shared,tripPlan:{...tripPlan},tripExpenses:[...tripExpenses],tripItinerary:[...tripItinerary],tripChecklist:[...tripChecklist],tripPresence:{uid:state.uid||'demo',name:tripActor(),active:false,at:new Date().toISOString()}};tripDirty=false;tripRenderSharedBundle(shared);renderTripSync();return}if(!navigator.onLine){try{localStorage.setItem(`${tripBundleKey()}_pending`,'1')}catch{}tripSetStatus('Offline · tersimpan lokal','Akan dikirim saat online','offline');return}if(!api?.saveSharedTripBundle||!state.chatId){tripDirty=false;tripSetStatus('Tersimpan lokal','Belum terhubung ke pasangan','saved');return}if(tripSaveBusy){tripSaveQueued=true;return}tripSaveBusy=true;tripSetStatus('Menyinkronkan…','Mengirim rencana, biaya, dan itinerary','syncing');try{await tripPresenceWrite.catch(()=>{});await api.saveSharedTripBundle(state.chatId,{plan:tripPlan,expenses:tripExpenses,itinerary:tripItinerary,checklist:tripChecklist});tripDirty=false;try{localStorage.removeItem(`${tripBundleKey()}_pending`)}catch{}tripSetStatus('Tersimpan bersama',`Diubah oleh ${tripActor()}`,'saved');tripPresenceActive=false;tripPublishPresence(false);api.sendChatMessage?.(state.chatId,`Rencana Jalan Berdua diperbarui: ${tripPlan.origin||'titik awal'} → ${tripPlan.destination||'tujuan'} · ${tripPlan.days} hari · ${tripMoney(tripPlan.total)}.`,null,'trip-plan').catch(()=>{})}catch(error){try{localStorage.setItem(`${tripBundleKey()}_pending`,'1')}catch{}tripSetStatus('Belum tersinkron','Data aman di perangkat ini','offline');notify(error.message||'Rencana belum tersinkron')}finally{tripSaveBusy=false;if(tripSaveQueued){tripSaveQueued=false;tripDirty=true;tripSetStatus('Menyimpan…','Menyimpan perubahan terbaru','dirty');tripSchedulePersist(80)}}}
async function tripFlushPending(){if(state.demo||!navigator.onLine||!state.chatId||!api?.saveSharedTripBundle)return;let pending=false;try{pending=localStorage.getItem(`${tripBundleKey()}_pending`)==='1'}catch{}if(pending){await tripPersistBundle();try{localStorage.removeItem(`${tripBundleKey()}_pending`)}catch{}}}
function tripNavigate(view){document.querySelector('#close-couple-feature')?.click();setTimeout(()=>navigate?.(view),160)}
function tripOpenCoupleFeature(feature){document.querySelector(`[data-couple-feature="${feature}"]`)?.click()}
function tripOpenMaps(place=''){const destination=place||tripPlan?.destination||'';if(!destination)return notify('Isi tujuan atau lokasi agenda dulu');tripOpenCoupleFeature('map');setTimeout(()=>{document.querySelector('#cv-map-route')?.click();setTimeout(()=>{const input=$('#cv-map-route-to');if(input)input.value=destination},180)},220)}
async function tripExportExcel(){const button=$('#trip-export-excel'),label=button?.querySelector('span'),before=label?.textContent;try{if(button)button.disabled=true;if(label)label.textContent='Menyusun…';const plan=tripCalculate();await downloadTripPlannerWorkbook({...plan,expenses:[...tripExpenses],itinerary:[...tripItinerary],checklist:[...tripChecklist],reservations:Array.isArray(shared.tripReservations)?shared.tripReservations:[],contacts:Array.isArray(shared.tripEmergencyContacts)?shared.tripEmergencyContacts:[],health:shared.tripHealth||{},matusInsight:tripLastMatusInsight,savings:{...(window.__appCoupleSavingsSummary||{}),deposits:(shared.deposits||[]).map(item=>({amount:Number(item.amount)||0,byName:item.byName||'',createdAt:item.createdAt||'',note:item.note||'',source:'Celengan Cinta'}))},mapData:{origin:routeOrigin?.label||plan.origin,destination:routeDestination?.label||plan.destination,originLat:routeOrigin?.lat,originLng:routeOrigin?.lng,destinationLat:routeDestination?.lat,destinationLng:routeDestination?.lng,distanceKm:routeMetrics.km,durationMinutes:routeMetrics.minutes,meetingPoint},memories:[...memories],activityLog:(getActivity?.()||[]).filter(item=>String(item.type||item.source||item.action||'').toLowerCase().includes('trip')||String(item.type||item.source||item.action||'').toLowerCase().includes('jalan')),couple:{me:state.user?.displayName||state.user?.name||'Saya',partner:state.partner?.displayName||state.partner?.name||'Pasangan'},tripId:`${state.chatId||state.uid||'demo'}-${plan.startDate||jakartaDay()}`,exportedAt:new Date().toISOString()});notify('Excel Jalan Berdua lengkap berhasil dibuat tanpa pemotongan data')}catch(error){console.error('Ekspor Jalan Berdua:',error);notify(error.message||'Excel Jalan Berdua belum dapat dibuat')}finally{if(button)button.disabled=false;if(label)label.textContent=before||'Simpan Excel'}}
function loadTripPlan(){tripReadLocal();if(!tripPlan)tripCalculate();tripRenderSharedBundle(shared);renderTripSync()}
function wireTripPlanner(){const root=$('#couple-trip-feature');if(!root||root.dataset.tripWired)return;root.dataset.tripWired='1';root.dataset.tripActive='basics';if(!$('#trip-start-date').value)$('#trip-start-date').value=new Date().toISOString().slice(0,10);if(!$('#trip-expense-date').value)$('#trip-expense-date').value=new Date().toISOString().slice(0,10);renderTripChecklist();$('#trip-itinerary-add-open').onclick=()=>tripOpenNewItinerary();$('#trip-itinerary-analyze').onclick=tripAnalyzeSelectedDay;$('#trip-itinerary-editor-close').onclick=()=>tripResetItineraryEditor();$('#trip-itinerary-day-tabs').onclick=event=>{const button=event.target.closest('[data-itinerary-day-select]');if(!button)return;tripSelectedItineraryDay=Math.max(1,Number(button.dataset.itineraryDaySelect)||1);renderTripItinerary();if(tripItineraryEditorOpen){const select=$('#trip-itinerary-day');if(select)select.value=String(tripSelectedItineraryDay)}};$('#trip-itinerary-day').onchange=event=>{tripSelectedItineraryDay=Math.max(1,Number(event.target.value)||1);renderTripItinerary()};$$('[data-trip-tab]',root).forEach(button=>button.onclick=()=>selectTripTab(button.dataset.tripTab));$$('input,select',root).forEach(input=>input.addEventListener('input',()=>{if(input.closest('#trip-expense-form')||input.closest('#trip-itinerary-form')||input.closest('#trip-checklist-list'))return;if(['trip-origin','trip-start-date','trip-days'].includes(input.id))tripInvalidateAllRoutes();tripCalculate();tripMarkDirty()}));$$('[data-trip-style]',root).forEach(button=>button.onclick=()=>tripApplyStyle(button.dataset.tripStyle));$$('[data-trip-preset]',root).forEach(button=>button.onclick=()=>tripApplyStyle(button.dataset.tripPreset));$$('[data-trip-link]',root).forEach(button=>button.onclick=()=>{const link=button.dataset.tripLink;if(link==='room')return tripOpenCoupleFeature('chat');if(link==='matus')return selectTripTab('matus');if(link==='savings')return $('#trip-create-saving')?.click();if(link==='map')return tripOpenMaps();if(link==='memories')return tripNavigate('memories');if(link==='finance')return tripNavigate('finance')});$$('[data-trip-matus-action]',root).forEach(button=>button.onclick=()=>tripMatusAction(button.dataset.tripMatusAction));$('[data-trip-action="maps"]',root).onclick=()=>tripOpenMaps();$('#trip-expense-form').onsubmit=event=>{event.preventDefault();const amount=Math.round(Number($('#trip-expense-amount').value)||0);if(amount<1000)return notify('Masukkan nominal minimal Rp1.000');tripExpenses.push({id:crypto.randomUUID(),amount,date:$('#trip-expense-date').value||new Date().toISOString().slice(0,10),method:$('#trip-expense-method').value,category:$('#trip-expense-category').value,payer:$('#trip-expense-payer').value,note:$('#trip-expense-note').value.trim(),createdAt:new Date().toISOString()});event.target.reset();$('#trip-expense-date').value=new Date().toISOString().slice(0,10);tripCalculate();tripMarkDirty();notify(navigator.onLine?'Pengeluaran ditambahkan · sedang disimpan':'Pengeluaran tersimpan lokal · akan disinkronkan')};$('#trip-expense-list').onclick=event=>{const button=event.target.closest('[data-trip-expense-delete]');if(button){tripExpenses=tripExpenses.filter(item=>item.id!==button.dataset.tripExpenseDelete);tripCalculate();tripMarkDirty()}};$('#trip-itinerary-form').onsubmit=event=>{event.preventDefault();const title=$('#trip-itinerary-title').value.trim(),place=$('#trip-itinerary-place').value.trim();if(!title)return notify('Isi nama agenda dulu');if(!place)return notify('Isi nama lokasi agar link Maps dapat dibuat');const payload={day:Number($('#trip-itinerary-day').value)||1,time:$('#trip-itinerary-time').value,title,place,duration:$('#trip-itinerary-duration').value.trim(),cost:tripValue('#trip-itinerary-cost',0),transport:$('#trip-itinerary-transport').value.trim(),status:$('#trip-itinerary-status').value,updatedAt:new Date().toISOString()},previousDay=tripItinerary.find(item=>item.id===tripEditingId)?.day;tripInvalidateRouteDay(previousDay||payload.day);tripInvalidateRouteDay(payload.day);tripSelectedItineraryDay=payload.day;if(tripEditingId){const index=tripItinerary.findIndex(item=>item.id===tripEditingId);if(index>=0)tripItinerary[index]={...tripItinerary[index],...payload};notify('Perubahan agenda disimpan')}else{tripItinerary.push({id:crypto.randomUUID(),...payload,createdAt:new Date().toISOString()});notify('Agenda ditambahkan dan disimpan')}tripResetItineraryEditor();tripCalculate();tripPersistBundle()};$('#trip-itinerary-list').onclick=event=>{const addButton=event.target.closest('[data-itinerary-add-day]'),editButton=event.target.closest('[data-trip-itinerary-edit]'),mapButton=event.target.closest('[data-trip-itinerary-map]'),deleteButton=event.target.closest('[data-trip-itinerary-delete]');if(addButton)return tripOpenNewItinerary(addButton.dataset.itineraryAddDay);if(editButton)return tripBeginItineraryEdit(editButton.dataset.tripItineraryEdit);if(mapButton)return tripOpenMaps(mapButton.dataset.tripItineraryMap);if(deleteButton){const id=deleteButton.dataset.tripItineraryDelete,removed=tripItinerary.find(item=>item.id===id);tripInvalidateRouteDay(removed?.day||tripSelectedItineraryDay);tripItinerary=tripItinerary.filter(item=>item.id!==id);if(tripEditingId===id)tripResetItineraryEditor();tripCalculate();tripPersistBundle();notify('Agenda dihapus dan perubahan disimpan')}};$('#trip-itinerary-cancel').onclick=tripResetItineraryEditor;const updateTripChecklistField=event=>{const target=event.target,attrs=['tripCheck','tripCheckTitle','tripCheckOwner','tripCheckDeadline','tripCheckNote'],key=attrs.find(name=>target.dataset[name]);if(!key)return;const id=target.dataset[key],item=tripChecklist.find(x=>x.id===id);if(!item)return;if(key==='tripCheck')item.done=target.checked;if(key==='tripCheckTitle')item.title=target.value;if(key==='tripCheckOwner')item.owner=target.value;if(key==='tripCheckDeadline')item.deadline=target.value;if(key==='tripCheckNote')item.note=target.value;const row=target.closest('[data-trip-check-row]');if(row&&key==='tripCheck'){row.classList.toggle('done',item.done);const status=row.querySelector('header em');if(status)status.textContent=item.done?'Selesai':'Belum';const done=tripChecklist.filter(x=>x.done).length;setText('#trip-checklist-count',`${done}/${tripChecklist.length} selesai`);setText('#trip-dash-checklist',`${done} selesai`)}tripMarkDirty();tripCalculate()};$('#trip-checklist-list').oninput=updateTripChecklistField;$('#trip-checklist-list').onchange=event=>{const target=event.target;if(target.dataset.tripCheckTitle!==undefined){const item=tripChecklist.find(x=>x.id===target.dataset.tripCheckTitle);if(item&&!item.title.trim()){item.title='Tugas perjalanan';target.value=item.title}}updateTripChecklistField(event)};$('#trip-save').onclick=tripPersistBundle;$('#trip-export-excel').onclick=tripExportExcel;$('#trip-ask-matus').onclick=async()=>{selectTripTab('matus');tripCalculate();const output=$('#trip-matus-output');if(!hasLocalAiConfig()){output.textContent=tripMatusLocalCopy(tripPlan);tripLastMatusInsight=output.textContent;return}output.textContent='Bentar, gua cek angkanya…';try{const answer=await localAiChat(`Cek rencana liburan ini dan jawab seperti teman dekat dengan gaya lu-gua. Sebut apakah budget aman, bagian paling boros, biaya aktual dan pembagian pembayaran. Data: ${JSON.stringify({plan:tripPlan,expenses:tripExpenses,itinerary:tripItinerary})}`,{system:'Kamu Matus, teman perjalanan yang jujur dan frontal. Jawab natural dalam Bahasa Indonesia lu-gua, tanpa label kaku, tanpa mengarang harga atau data.'});output.textContent=answer||tripMatusLocalCopy(tripPlan);tripLastMatusInsight=output.textContent}catch(error){output.textContent=tripMatusLocalCopy(tripPlan);tripLastMatusInsight=output.textContent}};$('#trip-create-saving').onclick=()=>{selectTripTab('savings');tripCalculate();const amount=Math.max(0,Math.round(tripPlan.total-tripPlan.saved));if(!amount)return notify('Rencana ini sudah tertutup dana yang tersedia');document.querySelector('[data-couple-feature="savings"]')?.click();setTimeout(()=>{const targetButton=$('#sb-target-btn'),totalInput=$('#sv2-target-total'),weeklyInput=$('#sv2-target-weekly');if(!targetButton||!totalInput)return notify(`Target tabungan perlu disiapkan: ${tripMoney(amount)}`);targetButton.click();totalInput.value=amount;const weekly=Math.max(1000,Math.ceil(amount/12/1000)*1000);if(weeklyInput)weeklyInput.value=weekly;totalInput.dispatchEvent(new Event('input',{bubbles:true}));weeklyInput?.dispatchEvent(new Event('input',{bubbles:true}));notify(`Target Celengan Cinta disiapkan: ${tripMoney(amount)}`)},180)};window.addEventListener('online',tripFlushPending);window.addEventListener('online',renderTripSync);window.addEventListener('offline',renderTripSync);loadTripPlan()}
