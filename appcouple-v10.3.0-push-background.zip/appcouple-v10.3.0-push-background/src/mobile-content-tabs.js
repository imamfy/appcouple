import { hydrateIcons } from './icons.js';

const $=(s,r=document)=>r.querySelector(s);
const $$=(s,r=document)=>[...r.querySelectorAll(s)];

const configs=[
  {view:'home',insertAfter:'.home-welcome',tabs:[
    {id:'summary',label:'Hari ini',icon:'house',selectors:['.home-secondary-grid']},
    {id:'insight',label:'Tentang',icon:'heart',selectors:['.home-overview-grid']},
    {id:'activity',label:'Aktivitas',icon:'bolt',selectors:['.home-bottom-grid']}
  ]},
  {view:'ai',insertBefore:'.mv2-hero',tabs:[
    {id:'brief',label:'Ringkas',icon:'sparkles',selectors:['.mv2-hero','.mv2-cap-grid']},
    {id:'tasks',label:'Tugas',icon:'bell',selectors:['.mv2-workspace']},
    {id:'chat',label:'Chat Matus',icon:'comments',selectors:['.mv2-chat-layout']}
  ]},
  {view:'couple-pairing',root:'#pairing-panel',insertBefore:'.pairing-hero',tabs:[
    {id:'create',label:'Buat kode',icon:'qrcode',selectors:['.pairing-hero']},
    {id:'connect',label:'Masukkan kode',icon:'link',selectors:['.connect-card']}
  ]}
];

function build(config){
  const root=config.root?$(config.root):$(`#view-${config.view}`);if(!root||root.dataset.mobileTabsReady)return;
  root.dataset.mobileTabsReady='1';
  config.tabs.forEach(tab=>tab.selectors.forEach(selector=>$$(selector,root).forEach(el=>{el.dataset.mobilePane=tab.id})));
  const nav=document.createElement('nav');nav.className='mobile-content-tabs';nav.setAttribute('aria-label','Bagian halaman');nav.innerHTML=config.tabs.map((tab,index)=>`<button type="button" data-mobile-tab="${tab.id}" class="${index?'':'active'}" aria-selected="${index?'false':'true'}"><i data-fa="${tab.icon}"></i><span>${tab.label}</span></button>`).join('');
  const anchor=$(config.insertBefore||config.insertAfter,root);if(!anchor)return;
  if(config.insertBefore)anchor.before(nav);else anchor.after(nav);
  const activate=id=>{root.dataset.mobileActive=id;$$('[data-mobile-tab]',nav).forEach(button=>{const active=button.dataset.mobileTab===id;button.classList.toggle('active',active);button.setAttribute('aria-selected',String(active))});$$('[data-mobile-pane]',root).forEach(pane=>pane.classList.toggle('is-mobile-active',pane.dataset.mobilePane===id));try{sessionStorage.setItem(`ac_mobile_tab_${config.view}`,id)}catch{}if(id==='map'){requestAnimationFrame(()=>window.dispatchEvent(new Event('resize')))}nav.scrollIntoView({block:'nearest',behavior:'smooth'})};
  nav.addEventListener('click',event=>{const button=event.target.closest('[data-mobile-tab]');if(button)activate(button.dataset.mobileTab)});
  let initial=config.tabs[0].id;try{const saved=sessionStorage.getItem(`ac_mobile_tab_${config.view}`);if(config.tabs.some(tab=>tab.id===saved))initial=saved}catch{}activate(initial);hydrateIcons(nav);
}

export function initMobileContentTabs(){configs.forEach(build)}
initMobileContentTabs();
