// Compatibility entry point. The dynamic exporter is the single source of truth.
export {buildWeddingPlannerWorkbook,downloadWeddingPlannerWorkbook} from './excel-wedding-template-export.js';
