import {localAiChat,hasLocalAiConfig} from './local-ai.js';
const $=(selector,root=document)=>root.querySelector(selector);
const $$=(selector,root=document)=>[...root.querySelectorAll(selector)];
const dayMs=86_400_000;
const activityTtlMs=dayMs;

let api=null;
let featureModule=null;
let notify=()=>{};
let stopProfile=null;
let stopChat=null;
let stopTyping=null;
let stopAnniversary=null;
let stopActivity=null;
let stopFinance=null;
let stopPulse=null;
let stopWedding=null;
let pulseState={};
let weddingPlan=null;
let weddingRecoveryAttempted=false;
let selectedMood='happy';
let countdownTimer=null;
let loveNoteTimer=null;
let typingTimer=null;
let activeFeature=null;
let activityFilter='all';
let activityLimit=20,activityState='loading';
const deletingActivities=new Set();
let messages=[];
let activities=[];
let activityCleanupTimer=null;
let financeSummaries={};
let financeSyncTimer=null;
let replyTo=null;
let chatSending=false,chatStickToBottom=false,chatViewportFrame=0;
let hiddenBefore=Number(localStorage.getItem('ac_chat_cleared_at')||0);
let chatNotificationPrimed=false,seenIncomingMessageIds=new Set();
window.addEventListener('appcouple:reward-claimed',event=>{if(!state.demo)return;const detail=event.detail||{};messages.push({id:'reward-'+Date.now(),from:state.uid,text:`🎁 Kamu menukar hadiah “${detail.name||'Hadiah'}” seharga ${Number(detail.cost||0).toLocaleString('id-ID')} Love Points.`,createdAt:new Date().toISOString(),read:true});renderMessages(messages)});
let currentAnniversary=null;
let audio=null;
let presenceTimer=null;
let dailyStatus={missions:{},partnerMissions:{},locked:true,inactivityDays:0,partnerInactivityDays:0};
let state={demo:false,uid:null,user:null,partner:null,chatId:null,navigate:()=>{}};
let pageScrollY=0;
function lockPageScroll(){
  if(document.documentElement.classList.contains('couple-scroll-locked'))return;
  pageScrollY=Math.max(0,window.scrollY||document.documentElement.scrollTop||0);
  document.documentElement.classList.add('couple-scroll-locked');
  document.body.classList.add('couple-feature-open');
  Object.assign(document.body.style,{position:'fixed',top:`-${pageScrollY}px`,left:'0',right:'0',width:'100%',overflow:'hidden'});
}
function unlockPageScroll(){
  if(!document.documentElement.classList.contains('couple-scroll-locked'))return;
  document.documentElement.classList.remove('couple-scroll-locked');
  document.body.classList.remove('couple-feature-open');
  ['position','top','left','right','width','overflow'].forEach(name=>document.body.style.removeProperty(name));
  window.scrollTo(0,pageScrollY);
}

const labels={activity:['AKTIVITAS BERDUA','Aktivitas'],chat:['CHAT PRIVAT','Chat'],game:['GAME PASANGAN','Game'],map:['PETA COUPLE','Peta & Jejak'],rewards:['LOYALLOVE','Hadiah'],savings:['CELENGAN CINTA','Tabungan'],trip:['JALAN BERDUA','Planner'],ai:['OTAK AI COUPLE','Otak AI'],sydas:['SYDAS SECTOR','Video']};
const activityIcons={mood:'<i data-fa="face-smile"></i>',chat:'<i data-fa="comment"></i>',game:'<i data-fa="gamepad"></i>',anniversary:'<i data-fa="heart"></i>',savings:'<i data-fa="piggy-bank"></i>',reward:'<i data-fa="gift"></i>',memory:'<i data-fa="location-dot"></i>',location:'<i data-fa="map"></i>',finance:'<i data-fa="money-bill-wave"></i>',ai:'<i data-fa="sparkles"></i>'};
const coupleMoods={happy:{icon:'face-smile',label:'Bahagia'},loved:{icon:'heart',label:'Dicintai'},calm:{icon:'spa',label:'Tenang'},tired:{icon:'moon',label:'Lelah'},miss:{icon:'heart-o',label:'Rindu'}};
const loveNotes=['“Hal kecil yang dilakukan bersama akan menjadi cerita besar.”','“Bukan tentang selalu sempurna, tetapi selalu memilih satu sama lain.”','“Rumah adalah saat kita bisa menjadi diri sendiri, bersama.”','“Setiap hari biasa terasa istimewa ketika dijalani berdua.”','“Cinta tumbuh dari perhatian kecil yang terus diulang.”'];
const MATUS_ROOM_PROMPTS={
  summary:'Ringkas percakapan ini seperti teman yang sudah mengikuti obrolan kalian. Sebut inti masalah, yang sudah disepakati, dan yang masih menggantung. Pakai bahasa lu-gua yang natural, tanpa format kaku.',
  reply:'Bantu gua menyusun jawaban yang hangat dan natural untuk pesan terakhir pasangan. Tulis seperti teman dekat yang ngerti konteks, bukan seperti customer service. Jangan lebay dan jangan menyalahkan siapa pun.',
  mediate:'Jadi teman netral yang berani ngomong apa adanya. Jelaskan kebutuhan dua pihak, tunjukkan bagian yang bikin buntu, lalu tawarkan satu jalan tengah yang realistis dengan bahasa santai.',
  plan:'Ubah obrolan terakhir menjadi rencana yang benar-benar bisa dijalankan. Sebut tujuan, tanggal, anggaran, dan pembagian tugas User A serta User B dengan gaya ngobrol santai.',
  memory:'Lihat histori seperti teman yang ikut menyaksikan momen kalian. Kalau ada momen yang layak disimpan, usulkan judul dan cerita singkat yang terasa manusiawi tanpa mengarang detail.',
  task:'Lihat apa yang masih menggantung di histori, lalu usulkan maksimal tiga pengingat bersama. Jangan membuat tugas diam-diam; ngomongnya seperti teman yang membantu, bukan robot.'
};
function roomHistory(){return messages.slice(-40).map(item=>{const matus=item.type==='matus'||item.from==='matus',mine=item.from===state.uid;const speaker=matus?'Matus':mine?firstName(state.user?.displayName||'User A'):firstName(state.partner?.displayName||state.partner?.name||'User B');return{role:matus?'assistant':'user',content:`[${speaker}] ${String(item.text||'').slice(0,1000)}`}})}
function roomWeddingContext(){const w=window.__appCoupleWeddingPlan;if(!w)return'';const pending=(w.checklist||[]).filter(row=>!row.done).slice(0,5).map(row=>`${row.title} (${row.status||'Belum mulai'}${row.dueDate?`, tenggat ${row.dueDate}`:''})`),unpaid=(w.vendors||[]).filter(row=>Number(row.paid||0)<Number(row.planned||0)).slice(0,5).map(row=>`${row.name}: sisa Rp${Math.max(0,(Number(row.planned)||0)-(Number(row.paid)||0)).toLocaleString('id-ID')}`);return`\nDATA WEDDING BERSAMA: total rencana Rp${Number(w.totalBudget||0).toLocaleString('id-ID')}, realisasi Rp${Number(w.actual||0).toLocaleString('id-ID')}, sisa ${Number(w.remaining||0)<0?'lebih ':''}Rp${Math.abs(Number(w.remaining||0)).toLocaleString('id-ID')}; checklist berikutnya: ${pending.join('; ')||'belum ada'}; vendor belum lunas: ${unpaid.join('; ')||'belum ada'}.`}
function roomPrompt(action='reply',question=''){const names=`User A: ${state.user?.displayName||'Imam'}; User B: ${state.partner?.displayName||state.partner?.name||'Pasangan'}`;return `Kamu adalah Matus AI di Matus Couple Room. ${names}. Kamu pendamping netral, bukan hakim dan bukan pengambil keputusan. Gunakan hanya isi percakapan bersama yang diberikan. Jangan membaca atau menyebut saldo pribadi, alamat pribadi, lokasi pribadi, kesehatan, password, token, atau chat pribadi. Jangan memihak. Jawab seperti teman dekat yang benar-benar mengikuti obrolan kalian: pakai bahasa Indonesia sehari-hari dengan gaya lu-gua, kalimat natural, dan jangan terdengar seperti robot atau customer service. Boleh frontal dan langsung menyebut masalah sebenarnya, tapi jangan menghina atau mempermalukan. Jangan membuat keputusan atau tugas tanpa persetujuan kedua pihak. Hindari label kaku seperti “Saran ·” atau “Ringkasan ·” kecuali memang membantu. ${MATUS_ROOM_PROMPTS[action]||MATUS_ROOM_PROMPTS.reply}${roomWeddingContext()}${question?`\\nPertanyaan pengguna: ${question}`:''}`}
function roomLocalReply(action='reply'){const recent=messages.filter(item=>item.type!=='matus').slice(-5),last=recent.at(-1)?.text||'',thread=recent.map(item=>`${item.from===state.uid?'User A':'User B'}: ${String(item.text||'').slice(0,110)}`).join(' | ');if(action==='summary')return`Oke, gua ringkas ya. Dari obrolan terakhir: ${thread||'belum ada percakapan'}. Yang sudah jelas belum bisa disebut keputusan final. Kalian perlu nulis satu kesepakatan yang jelas, lengkap sama tanggal atau tindakan berikutnya.`;if(action==='mediate')return`Gua lihat dua kebutuhan yang belum ketemu: “${String(recent.at(-2)?.text||'belum jelas').slice(0,120)}” dan “${String(last).slice(0,120)}”. Jangan saling lempar sindiran. Masing-masing bilang satu kebutuhan utama, terus pilih satu kompromi yang bisa dicoba hari ini.`;if(action==='plan')return`Gua terus terang aja: masalahnya bukan kurang ide, tapi belum ada yang membagi tugas. Tentukan tujuan, tanggal, dan anggaran. Habis itu bagi satu tugas buat User A dan satu buat User B. Jangan berhenti di “nanti kita atur”.`;if(action==='memory')return`Ini kayaknya layak disimpan, tapi gua nggak akan ngarang detail. Pilih momen, tanggal, tempat, dan satu kalimat yang paling ingin kalian ingat.`;if(action==='task')return`Gua lihat ada hal yang masih menggantung di obrolan. Gua bisa bantu bikin maksimal tiga pengingat, tapi judul dan waktunya tetap harus kalian setujui dulu.`;return`Gua lihat inti yang perlu dibereskan adalah “${String(last).slice(0,160)||'belum ada pesan yang cukup jelas'}”. Balas langsung ke poin itu. Jangan pindah topik atau berharap pasangan lu menebak maksud lu.`}

async function sendMatusRoomAnswer(action='reply',question=''){const prompt=question||MATUS_ROOM_PROMPTS[action]||MATUS_ROOM_PROMPTS.reply;let answer='';try{if(state.demo||!hasLocalAiConfig()){await new Promise(resolve=>setTimeout(resolve,260));answer=roomLocalReply(action)}else{answer=await localAiChat(prompt,{history:roomHistory(),system:roomPrompt(action,question)})}}catch(error){answer=`Gua belum bisa bantu lewat AI provider sekarang. ${error.message||'Coba lagi sebentar.'}`}if(!answer)return;const row={id:crypto.randomUUID(),from:'matus',type:'matus',text:String(answer).trim(),createdAt:new Date().toISOString(),read:true};if(state.demo){messages.push(row);renderMessages(messages)}else if(api&&state.chatId){try{await api.sendChatMessage(state.chatId,row.text,null,'matus')}catch(error){notify(error.message||'Jawaban Matus belum tersimpan')}}}
function handleMatusRoomAction(action){const input=$('#chat-input');if(action==='mention'){if(input){input.value=(input.value&&!/^@matus\\b/i.test(input.value)?'@Matus ':'@Matus ')+input.value;input.focus();syncChatSendButton()}return}closeDropdown();sendMatusRoomAnswer(action)}

export async function initCouple({demo=false,user,toast,navigate}){
  state={...state,demo,uid:user?.uid||'demo-imam',user:user||{displayName:'Imam'},navigate:navigate||(()=>{})};
  notify=toast||(()=>{});
  wireCore();
  await loadFeatures();
  window.__appCoupleOpenFeature=openFeature;window.__appCoupleCloseFeature=closeFeature;window.__appCoupleSwitchTab=switchHomeTab;window.dispatchEvent(new Event('appcouple:feature-router-ready'));
  if(demo){
    showConnected({uid:'demo-partner',name:'Pasangan Demo',displayName:'Pasangan Demo',connectionDate:new Date(Date.now()-428*dayMs),lastActiveAt:new Date()},'demo-imam_demo-partner');
    renderMessages(demoMessages());
    renderActivity(demoActivities());
    financeSummaries=demoFinance();
    renderFinanceSummaries();
    return;
  }
  try{
    api=await import('./supabase-service.js');
    featureModule?.setApi?.(api);
    await api.touchPresence?.();
    api.claimDailyPoint?.('online').then(()=>refreshDailyGate()).catch(error=>console.warn('Poin online:',error?.message||error));
    clearInterval(presenceTimer);presenceTimer=setInterval(()=>{if(document.visibilityState==='visible')api?.touchPresence?.().catch(()=>{})},60_000);
    stopProfile?.();
    stopProfile=api.watchCoupleState(data=>{
      if(data?.partner)showConnected(data.partner,data.chatId);
      else showPairing();
    },error=>notify(error.message||'Gagal membaca status pasangan'));
  }catch(error){
    console.error(error);
    showPairing();
  }
}

async function loadFeatures(){
  try{
    featureModule=await import('./couple-features-ui.js');
    featureModule.configure?.({toast:notify,getState:()=>state,getActivity:()=>activities,openFeature,navigate:state.navigate});
    if(api)featureModule.setApi?.(api);
  }catch(error){console.error('Couple features:',error)}
}

function wireCore(){
  if($('#view-couple')?.dataset.cvWired)return;
  $('#view-couple').dataset.cvWired='1';
  $('#generate-pair-code').onclick=generatePairCode;
  $('#copy-pair-code').onclick=copyPairCode;
  $('#partner-code').oninput=event=>event.target.value=event.target.value.toUpperCase().replace(/[^A-Z0-9]/g,'').slice(0,6);
  $('#pair-form').onsubmit=connectPair;
  $('#cv-show-qr').onclick=toggleQr;
  $('#disconnect-couple').onclick=disconnectPair;
  $('#cs2-add-expense').onclick=()=>{state.navigate('finance');setTimeout(()=>document.querySelector('[data-action="expense"]')?.click(),120)};
  $$('[data-couple-tab]').forEach(button=>button.onclick=()=>switchHomeTab(button.dataset.coupleTab));
  $$('[data-couple-tab-jump]').forEach(button=>button.onclick=()=>button.dataset.coupleTabJump==='wedding'?openWeddingPlanner():switchHomeTab(button.dataset.coupleTabJump));
  $('[data-cw-fullscreen-close]')?.addEventListener('click',()=>switchHomeTab('apps'));
  wireWeddingPlanner();
  $$('[data-couple-feature]').forEach(button=>button.onclick=()=>openFeature(button.dataset.coupleFeature));
  $('#close-couple-feature').onclick=closeFeature;
  $('#cv-chat-back').onclick=closeFeature;
  $('#cv-edit-anniversary').onclick=()=>$('#cv-anniversary-editor').classList.toggle('hidden');
  $('#save-anniversary').onclick=saveAnniversary;
  $('#cs2-pulse-form').onsubmit=savePulse;
  $$('[data-couple-mood]').forEach(button=>button.onclick=()=>selectMood(button.dataset.coupleMood));
  $$('[data-activity-filter]').forEach(button=>button.onclick=()=>{
    activityFilter=button.dataset.activityFilter;activityLimit=20;
    $$('[data-activity-filter]').forEach(item=>item.classList.toggle('active',item===button));
    renderActivity(activities);
  });
  $('#chat-form').onsubmit=sendMessage;
  $$('[data-matus-room-action]').forEach(button=>button.onclick=()=>handleMatusRoomAction(button.dataset.matusRoomAction));
  $('#chat-input').oninput=event=>{handleTyping(event);syncChatSendButton()};
  const chatInput=$('#chat-input');
  chatInput.addEventListener('keydown',event=>{if(event.key==='Enter'&&(event.ctrlKey||event.metaKey)&&!event.isComposing){event.preventDefault();$('#chat-form').requestSubmit()}});
  $('#sendMsg').addEventListener('pointerdown',event=>{if(document.activeElement===chatInput&&!chatSending)event.preventDefault()});
  $('#chat-latest').onclick=()=>{const box=$('#chat-messages');box.scrollTop=box.scrollHeight;$('#chat-latest').classList.add('hidden')};
  $('#chat-messages').addEventListener('scroll',()=>{const box=$('#chat-messages');if(box.scrollHeight-box.scrollTop-box.clientHeight<60)$('#chat-latest').classList.add('hidden')},{passive:true});
  window.visualViewport?.addEventListener('resize',scheduleChatViewport);
  window.visualViewport?.addEventListener('scroll',scheduleChatViewport);
  window.addEventListener('resize',scheduleChatViewport);
  window.addEventListener('orientationchange',()=>setTimeout(scheduleChatViewport,250));
  $('#fs-overlay').addEventListener('focusin',scheduleChatViewport);
  $('#fs-overlay').addEventListener('focusout',()=>{scheduleChatViewport();setTimeout(scheduleChatViewport,300)});
  syncChatSendButton();
  $('#chat-emoji').onclick=()=>{const panel=$('#cv-emoji-panel');panel.classList.toggle('hidden');if(!panel.classList.contains('hidden'))renderEmojiGrid(emojiCategory);};
  $$('.wa-ep-tab').forEach(tab=>tab.onclick=()=>{
    $$('.wa-ep-tab').forEach(item=>item.classList.toggle('active',item===tab));
    const map={emoji:'#ep-emoji',sticker:'#ep-sticker',gif:'#ep-gif'};
    Object.entries(map).forEach(([key,selector])=>$(selector).classList.toggle('hidden',key!==tab.dataset.ep));
    if(tab.dataset.ep==='sticker')renderStickerGrid();
  });
  $$('.wa-ecat').forEach(chip=>chip.onclick=()=>{
    emojiCategory=chip.dataset.cat;
    $$('.wa-ecat').forEach(item=>item.classList.toggle('active',item===chip));
    renderEmojiGrid(emojiCategory);
  });
  renderEmojiGrid(emojiCategory);renderStickerGrid();
  $('#cv-reply-cancel').onclick=clearReply;
  $('#clear-chat-btn').onclick=clearChatView;
  $('#wa-mute-btn').onclick=toggleChatMute;
  $('#wa-summary-btn').onclick=()=>{closeDropdown();openFeature('ai');featureModule?.requestAiAnalysis?.('relationship');};
  $('#cv-chat-search-toggle').onclick=()=>{const box=$('#cv-chat-search');box.classList.toggle('hidden');if(!box.classList.contains('hidden'))$('#cv-chat-search-input').focus();};
  $('#cv-chat-search-close').onclick=()=>{$('#cv-chat-search').classList.add('hidden');$('#cv-chat-search-input').value='';renderMessages(messages);};
  $('#cv-chat-search-input').oninput=()=>renderMessages(messages);
  $('#chat-messages').onclick=handleMessageClick;
  $('#cv-activity-feed').onclick=handleActivityFeedClick;
  ['#activity-search','#activity-actor','#activity-order'].forEach(id=>$(id).addEventListener(id==='#activity-search'?'input':'change',()=>{activityLimit=20;renderActivity(activities)}));
  $('#activity-reset').onclick=()=>{activityFilter='all';activityLimit=20;$('#activity-search').value='';$('#activity-actor').value='all';$('#activity-order').value='newest';renderActivity(activities)};
  $('#activity-more').onclick=()=>{activityLimit+=20;renderActivity(activities)};
  $('#activity-retry').onclick=()=>state.demo?renderActivity(activities):startActivityWatch();
  window.addEventListener('appcouple:finance-update',event=>{
    const summary={...(event.detail||{}),period:new Date().toISOString().slice(0,7)};
    financeSummaries={...financeSummaries,[state.uid]:summary};
    renderFinanceSummaries();
    clearTimeout(financeSyncTimer);
    if(!state.demo&&api&&state.chatId)financeSyncTimer=setTimeout(()=>api.saveCoupleFinanceSummary?.(state.chatId,summary).catch(error=>console.warn('Sinkron keuangan pasangan:',error?.message||error)),250);
    if(!state.demo)setTimeout(()=>refreshDailyGate(),180);
  });
  window.addEventListener('appcouple:points-awarded',event=>{const detail=event.detail||{};if(detail.dailyMissions){dailyStatus={...dailyStatus,day:detail.day,total:detail.total,pointsByUser:detail.pointsByUser,missions:detail.dailyMissions[state.uid]||dailyStatus.missions,partnerMissions:detail.dailyMissions[state.partner?.uid]||dailyStatus.partnerMissions};applyDailyGate();window.dispatchEvent(new CustomEvent('appcouple:daily-points',{detail:dailyStatus}))}refreshDailyGate()});
  window.addEventListener('appcouple:profile-updated',event=>{state.user={...state.user,...(event.detail||{})};setIdentity();renderActivity(activities)});
  window.addEventListener('online',setIdentity);window.addEventListener('offline',setIdentity);
  $('#cv-chat-more').onclick=event=>{event.stopPropagation();toggleDropdown();};
  $('#cv-pinned-message').onclick=()=>{const pinned=$('[data-message-id].pinned');pinned?.scrollIntoView({behavior:'smooth',block:'center'});};
  $('#cv-music-toggle').onclick=toggleMusic;
  $('#cv-overlay-music').onclick=toggleMusic;
  document.addEventListener('keydown',event=>{if(event.key==='Escape'&&!$('#fs-overlay').classList.contains('hidden'))closeFeature();});
  document.addEventListener('click',event=>{
    if(!event.target.closest('.wa-msg-menu')&&!event.target.closest('[data-message-menu]'))$('.wa-msg-menu')?.remove();
    if(!event.target.closest('#wa-dropdown')&&!event.target.closest('#cv-chat-more'))closeDropdown();
  });
  document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible'&&!state.demo){api?.touchPresence?.().then(()=>refreshDailyGate()).catch(()=>{})}});
  refreshMuteLabel();
}

const emojiSets={
  recent:['\u2764\uFE0F','\uD83D\uDE18','\uD83E\uDD70','\uD83D\uDE02','\uD83D\uDC4D','\uD83D\uDE4F','\uD83D\uDD25','\uD83C\uDF89','\uD83E\uDD17','\uD83D\uDE0D','\uD83E\uDD7A','\uD83D\uDE34','\uD83D\uDCAF','\u2728','\uD83C\uDF39','\uD83C\uDF82'],
  love:['\u2764\uFE0F','\uD83E\uDDE1','\uD83D\uDC9B','\uD83D\uDC9A','\uD83D\uDC99','\uD83D\uDC9C','\uD83E\uDD0D','\uD83D\uDC94','\uD83D\uDC95','\uD83D\uDC9E','\uD83D\uDC93','\uD83D\uDC97','\uD83D\uDC96','\uD83D\uDC98','\uD83D\uDC9D','\uD83D\uDC8B','\uD83D\uDE18','\uD83D\uDE0D','\uD83E\uDD70','\uD83D\uDC91','\uD83D\uDC8D','\uD83C\uDF39','\uD83C\uDF3A','\uD83D\uDC90'],
  face:['\uD83D\uDE00','\uD83D\uDE03','\uD83D\uDE04','\uD83D\uDE01','\uD83D\uDE06','\uD83D\uDE05','\uD83D\uDE02','\uD83E\uDD23','\uD83D\uDE0A','\uD83D\uDE07','\uD83D\uDE42','\uD83D\uDE43','\uD83D\uDE09','\uD83D\uDE0C','\uD83E\uDD72','\uD83D\uDE0B','\uD83D\uDE1B','\uD83E\uDD2A','\uD83E\uDD14','\uD83E\uDD10','\uD83D\uDE10','\uD83D\uDE36','\uD83D\uDE0F','\uD83D\uDE12','\uD83D\uDE1E','\uD83D\uDE22','\uD83D\uDE2D','\uD83E\uDD7A','\uD83D\uDE20','\uD83D\uDE31','\uD83E\uDD73','\uD83E\uDD29'],
  nature:['\uD83C\uDF38','\uD83C\uDF3C','\uD83C\uDF3B','\uD83C\uDF37','\uD83C\uDF39','\uD83E\uDEB7','\uD83C\uDF3F','\uD83C\uDF40','\uD83C\uDF43','\uD83C\uDF32','\uD83C\uDF34','\u2600\uFE0F','\uD83C\uDF19','\u2B50','\uD83C\uDF1F','\u2728','\u26C5','\uD83C\uDF08','\u2744\uFE0F','\uD83D\uDD25','\uD83C\uDF0A','\uD83E\uDD8B','\uD83D\uDC1D','\uD83D\uDC26'],
  food:['\uD83C\uDF5C','\uD83C\uDF5B','\uD83C\uDF5A','\uD83C\uDF5D','\uD83C\uDF72','\uD83C\uDF71','\uD83C\uDF63','\uD83C\uDF71','\uD83C\uDF54','\uD83C\uDF55','\uD83C\uDF2D','\uD83C\uDF57','\uD83E\uDD69','\uD83C\uDF5F','\uD83E\uDD57','\uD83C\uDF66','\uD83C\uDF70','\uD83C\uDF82','\uD83C\uDF6B','\uD83C\uDF69','\u2615','\uD83E\uDDCB','\uD83E\uDDCB','\uD83C\uDF7B']
};
const stickerSet=['\uD83D\uDC95','\uD83E\uDD17','\uD83D\uDE18','\uD83E\uDD79','\uD83D\uDC90','\uD83E\uDDF8','\uD83C\uDF88','\uD83C\uDF81','\uD83C\uDF80','\uD83D\uDC8C','\uD83C\uDF1F','\uD83E\uDD8B','\uD83C\uDF08','\uD83C\uDF19','\u2615','\uD83C\uDF7F','\uD83C\uDFA1','\uD83C\uDFB5','\uD83D\uDCF8','\uD83E\uDDF3'];
let emojiCategory='recent';

function renderEmojiGrid(category='recent'){
  const grid=$('#wa-emoji-grid');if(!grid)return;
  grid.innerHTML=(emojiSets[category]||emojiSets.recent).map(value=>`<button type="button" class="wa-emoji-pick">${value}</button>`).join('');
  $$('.wa-emoji-pick',grid).forEach(button=>button.onclick=()=>insertIntoInput(button.textContent));
}
function renderStickerGrid(){
  const grid=$('#wa-sticker-grid');if(!grid)return;
  grid.innerHTML=stickerSet.map(value=>`<button type="button" class="wa-sticker-pick">${value}</button>`).join('');
  $$('.wa-sticker-pick',grid).forEach(button=>button.onclick=()=>{sendSticker(button.textContent);$('#cv-emoji-panel').classList.add('hidden');});
}
function insertIntoInput(value){
  const input=$('#chat-input');input.value+=value;input.focus();input.dispatchEvent(new Event('input'));
}
function closeDropdown(){$('#wa-dropdown')?.classList.add('hidden')}
function toggleDropdown(){$('#wa-dropdown')?.classList.toggle('hidden')}
function chatMuted(){return localStorage.getItem('ac_chat_muted')==='1'}
function refreshMuteLabel(){
  const button=$('#wa-mute-btn');if(!button)return;
  button.innerHTML=chatMuted()?'<i data-fa="bell"></i> Aktifkan Notif':'<i data-fa="bell"></i> Bisukan Notif';
  hydrateFeatureIcons(button);
}
function toggleChatMute(){
  const next=!chatMuted();
  localStorage.setItem('ac_chat_muted',next?'1':'0');
  refreshMuteLabel();closeDropdown();
  notify(next?'Notifikasi chat dibisukan':'Notifikasi chat diaktifkan');
}
function clearChatView(){
  closeDropdown();
  if(!confirm('Bersihkan tampilan chat di perangkat ini? Pesan tetap tersimpan untuk pasangan.'))return;
  hiddenBefore=Date.now();
  localStorage.setItem('ac_chat_cleared_at',String(hiddenBefore));
  renderMessages(messages);
  notify('Tampilan chat dibersihkan');
}
function hydrateFeatureIcons(root){
  import('./icons.js').then(module=>module.hydrateIcons?.(root||document)).catch(()=>{});
}

async function generatePairCode(){
  try{
    const code=state.demo?'DEMO26':await api.serverCreatePairCode();
    $('#my-pair-code').textContent=typeof code==='string'?code:code.code;
    $('#cv-qr-box').classList.add('hidden');
    notify('Kode pasangan dibuat dan berlaku 24 jam');
  }catch(error){notify(error.message||'Gagal membuat kode')}
}

async function copyPairCode(){
  const code=$('#my-pair-code').textContent;
  if(code==='------')return notify('Buat kode terlebih dahulu');
  try{await navigator.clipboard.writeText(code);notify('Kode disalin')}catch{notify(`Kode pasangan: ${code}`)}
}

async function toggleQr(){
  const code=$('#my-pair-code').textContent;
  if(code==='------')return notify('Buat kode terlebih dahulu');
  const box=$('#cv-qr-box');
  box.classList.toggle('hidden');
  if(box.classList.contains('hidden'))return;
  const target=$('#cv-qr-canvas');target.innerHTML='';
  try{
    await ensureQrLibrary();
    if(window.QRCode)new window.QRCode(target,{text:`appcouple://pair/${code}`,width:152,height:152,colorDark:'#241c23',colorLight:'#ffffff',correctLevel:window.QRCode.CorrectLevel.M});
    else throw new Error('QR library unavailable');
  }catch{
    target.innerHTML=`<div style="width:152px;height:152px;display:grid;place-items:center;background:#fff;border:8px solid #fff;color:#241c23;font:800 20px ui-monospace,monospace">${escapeHtml(code)}</div>`;
    notify('QR offline: kode tetap dapat dimasukkan manual');
  }
}

function ensureQrLibrary(){
  if(window.QRCode)return Promise.resolve();
  const load=src=>new Promise((resolve,reject)=>{const script=document.createElement('script');script.src=src;script.onload=()=>window.QRCode?resolve():reject(new Error('QR library unavailable'));script.onerror=reject;document.head.appendChild(script)});
  return load('/src/vendor-qrcode.min.js').catch(()=>load('https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js'));
}

async function connectPair(event){
  event.preventDefault();
  const code=$('#partner-code').value.trim();
  if(code.length!==6)return notify('Kode harus enam karakter');
  if(state.demo){
    showConnected({uid:'demo-partner',name:'Pasangan Demo',connectionDate:new Date(Date.now()-428*dayMs)},'demo-imam_demo-partner');
    return notify('Mode demo berhasil terhubung');
  }
  try{await api.serverConnectWithCode(code);notify('Couple Space berhasil dibuat')}catch(error){notify(error.message||'Kode tidak valid')}
}

async function disconnectPair(){
  if(!confirm('Putuskan Couple Space? Chat dan jejak tetap tersimpan sampai dihapus melalui kebijakan data.'))return;
  if(state.demo){showPairing();return notify('Couple Space demo diputuskan')}
  try{await api.serverDisconnectCouple();notify('Couple Space diputuskan')}catch(error){notify(error.message||'Gagal memutuskan pasangan')}
}

function showPairing(){
  stopConnectedWatchers();
  state.partner=null;state.chatId=null;
  $('#pairing-panel').classList.remove('hidden');
  $('#connected-panel').classList.add('hidden');
  $('#couple-connection-badge').textContent='Belum terhubung';
  closeFeature();
  publishHomeCouple({connected:false});
}

function showConnected(partner,chatId){
  const changed=state.chatId!==chatId;
  state.partner=partner;state.chatId=chatId;
  $('#pairing-panel').classList.add('hidden');
  $('#connected-panel').classList.remove('hidden');
  $('#couple-connection-badge').innerHTML=`<i data-fa="circle"></i> ${firstName(state.user?.displayName||'Kamu')} online`; 
  setIdentity();
  publishHomeCouple({connected:true});
  const fallback=partner.connectionDate?.toDate?.()||new Date(partner.connectionDate||Date.now());
  if(changed){
    subscribeConnected();
    featureModule?.initCoupleFeatures?.({chatId,uid:state.uid,user:state.user,partner,demo:state.demo,toast:notify,navigate:state.navigate});
    if(!state.demo&&window.__appCoupleFinanceSummary)api?.saveCoupleFinanceSummary?.(chatId,{...window.__appCoupleFinanceSummary,period:new Date().toISOString().slice(0,7)}).catch(error=>console.warn('Publikasi ringkasan awal:',error?.message||error));
  }
  if(!currentAnniversary)renderAnniversary({date:fallback.toISOString().slice(0,10)});
  if(state.demo){dailyStatus={missions:{online:true,expense:true,chat:true,location:true,savings:true},partnerMissions:{online:true,expense:true,chat:true},locked:false,inactivityDays:0,partnerInactivityDays:0};applyDailyGate()}else refreshDailyGate();
}

function publishHomeCouple(extra={}){
  const me=firstName(state.user?.displayName||'Kamu');
  const partner=firstName(state.partner?.name||state.partner?.displayName||state.partner?.email||'Pasangan');
  const last=state.partner?.lastActiveAt?.toDate?.()||new Date(state.partner?.lastActiveAt||Date.now());
  let daysTogether=0;
  if(currentAnniversary?.date){const start=new Date(currentAnniversary.date+'T00:00:00');daysTogether=Math.max(0,Math.floor((startOfDay(new Date())-startOfDay(start))/dayMs))}
  const detail={connected:Boolean(state.partner),me,partner,mePhoto:state.user?.photoURL||'',partnerPhoto:state.partner?.photoURL||'',online:Boolean(state.partner)&&Date.now()-last.getTime()<120000,daysTogether,...extra};
  window.__appCoupleCoupleSummary=detail;
  window.dispatchEvent(new CustomEvent('appcouple:couple-update',{detail}));
}
function publishHomeActivity(items=[]){
  const rows=(Array.isArray(items)?items:[]).slice(0,12).map(item=>{
    const raw=item.createdAt?.toDate?.()||item.createdAt||Date.now();
    return {type:item.type||'all',title:item.title||'Aktivitas bersama',detail:item.detail||'',amount:Number(item.amount)||0,createdAt:new Date(raw).toISOString()};
  });
  window.__appCoupleActivity=rows;
  window.dispatchEvent(new CustomEvent('appcouple:activity-update',{detail:rows}));
}

function offlineCopy(days){if(days<=0)return'Kamu kembali aktif hari ini.';if(days===1)return'Kamu tidak membuka AppCouple selama 1 hari.';return`Kamu tidak membuka AppCouple selama ${days} hari.`}
async function refreshDailyGate(){if(state.demo||!api||!state.chatId)return;try{const [status,hasExpense]=await Promise.all([api.getDailyPointStatus(),api.hasExpenseToday()]);dailyStatus={...dailyStatus,...status,locked:!hasExpense};applyDailyGate();window.dispatchEvent(new CustomEvent('appcouple:daily-points',{detail:dailyStatus}))}catch(error){console.warn('Status penguncian:',error?.message||error);dailyStatus={...dailyStatus,locked:true};applyDailyGate()}}
function applyDailyGate(){const screen=$('#couple-home-screen'),warning=$('#cs2-daily-lock');if(!screen||!warning)return;const locked=!state.demo&&dailyStatus.locked!==false;screen.classList.toggle('daily-locked',locked);warning.classList.toggle('hidden',!locked);const days=Number(dailyStatus.inactivityDays||0),partnerDays=Number(dailyStatus.partnerInactivityDays||0);setTextSafe('#cs2-lock-title',days>0?`Selamat datang kembali setelah ${days} hari`:'Couple Space masih terkunci');setTextSafe('#cs2-lock-copy',`${offlineCopy(days)} Catat minimal satu pengeluaran hari ini untuk membuka Ruang Kita.`);setTextSafe('#cs2-lock-away',partnerDays>0?`Pasangan terakhir aktif ${partnerDays} hari lalu.`:'Pasangan aktif hari ini.')}
function setTextSafe(selector,value){const el=$(selector);if(el)el.textContent=value}

function paintProfile(imageSelector,fallbackSelector,url,label){const image=$(imageSelector),fallback=$(fallbackSelector);if(!image||!fallback)return;image.alt=`Foto profil ${label}`;image.onerror=()=>{image.classList.add('hidden');fallback.classList.remove('hidden')};image.onload=()=>{image.classList.remove('hidden');fallback.classList.add('hidden')};if(url){image.src=url;image.classList.remove('hidden');fallback.classList.add('hidden')}else{image.removeAttribute('src');image.classList.add('hidden');fallback.classList.remove('hidden')}}
function setIdentity(){
  const me=firstName(state.user?.displayName||'Imam');
  const partner=firstName(state.partner?.name||state.partner?.displayName||state.partner?.email||'Pasangan');
  const meInitial=(me[0]||'I').toUpperCase(),partnerInitial=(partner[0]||'P').toUpperCase();
  $('#cv-couple-name').textContent=`${me} & ${partner}`;
  $('#cs2-hero-name').textContent=`${me} & ${partner}`;
  $('#cs2-me-initial').textContent=meInitial;$('#cs2-partner-initial').textContent=partnerInitial;
  $('#cs2-pulse-me-avatar').textContent=meInitial;$('#cs2-pulse-partner-avatar').textContent=partnerInitial;
  $('#cs2-pulse-me-name').textContent=me;$('#cs2-pulse-partner-name').textContent=partner;
  $('#anniversary-title').textContent=`${me} & ${partner}`;
  $('#cv-me-avatar').textContent=meInitial;$('#anniversary-me').textContent=meInitial;
  $('#cv-partner-avatar').textContent=partnerInitial;$('#anniversary-partner').textContent=partnerInitial;
  paintProfile('#cv-me-photo','#cv-me-avatar',state.user?.photoURL||'',me);paintProfile('#cv-partner-photo','#cv-partner-avatar',state.partner?.photoURL||'',partner);
  paintProfile('#anniversary-me-photo','#anniversary-me',state.user?.photoURL||'',me);paintProfile('#anniversary-partner-photo','#anniversary-partner',state.partner?.photoURL||'',partner);setTextSafe('#anniversary-me-label',me);setTextSafe('#anniversary-partner-label',partner);
  $('#partner-avatar').textContent=partnerInitial;$('#partner-name').textContent='Couple Room';setTextSafe('#cv-chat-presence',`${me} + ${partner} · Matus siap`);setTextSafe('#chat-member-a',meInitial);setTextSafe('#chat-member-b',partnerInitial);
  $('#cv-finance-me-avatar').textContent=meInitial;$('#cv-finance-me-name').textContent=me;
  $('#cv-finance-partner-avatar').textContent=partnerInitial;$('#cv-finance-partner-name').textContent=partner;
  $('#cv-reward-me-label').textContent=me;$('#cv-reward-partner-label').textContent=partner;
  setTextSafe('#cv-header-me-label',me);setTextSafe('#cv-header-partner-label',partner);
  const last=state.partner?.lastActiveAt?.toDate?.()||new Date(state.partner?.lastActiveAt||Date.now());
  const online=Date.now()-last.getTime()<120_000;
  const myOnline=typeof navigator==='undefined'||navigator.onLine;$('#cv-partner-presence').innerHTML=`<i></i> ${me} ${myOnline?'online sekarang':'sedang offline'}`;$('#cv-me-online')?.classList.toggle('active',myOnline);$('#cv-partner-online')?.classList.toggle('active',online);
  const status=$('#cv-chat-presence');
  if(status)status.textContent=online?'online':`terakhir dilihat ${new Intl.DateTimeFormat('id-ID',{hour:'2-digit',minute:'2-digit'}).format(last)}`;
  $('#wa-online-dot')?.classList.toggle('active',online);
  $('#cs2-hero-presence').textContent=online?'Online sekarang':'Terhubung aman';
  const typingAvatar=$('#wa-typing-avatar');if(typingAvatar)typingAvatar.textContent=partnerInitial;
}

function selectMood(mood){if(!coupleMoods[mood])return;selectedMood=mood;$$('[data-couple-mood]').forEach(button=>{const selected=button.dataset.coupleMood===mood;button.classList.toggle('is-selected',selected);button.setAttribute('aria-pressed',String(selected))})}
function pulseTime(value){const date=value?.toDate?.()||new Date(value||Date.now());if(Number.isNaN(date.getTime()))return'Baru saja';return new Intl.DateTimeFormat('id-ID',{hour:'2-digit',minute:'2-digit'}).format(date)}
function renderPulse(data={}){pulseState=data||{};const mine=pulseState[state.uid]||null,partner=pulseState[state.partner?.uid]||null;const paint=(prefix,item,empty)=>{const mood=coupleMoods[item?.mood]||null;$(prefix+'-mood').innerHTML=`<i data-fa="${mood?.icon||'heart-o'}"></i>`;$(prefix+'-note').textContent=item?.note||empty;$(prefix+'-time').textContent=item?`${mood?.label||'Update'} · ${pulseTime(item.updatedAt)}`:(prefix.includes('partner')?'Menunggu pasangan':'Belum memperbarui')};paint('#cs2-me',mine,'Bagikan kabarmu hari ini.');paint('#cs2-partner',partner,'Status pasangan akan muncul otomatis.');$('#cs2-sync-time').textContent='Tersinkron '+new Intl.DateTimeFormat('id-ID',{hour:'2-digit',minute:'2-digit'}).format(new Date());$('#cs2-pulse-status').textContent=partner?'Kalian berdua sudah berbagi kabar hari ini.':'Statusmu akan langsung muncul di perangkat pasangan.'}
async function savePulse(event){event.preventDefault();const note=$('#cs2-pulse-note').value.trim(),item={uid:state.uid,name:state.user?.displayName||'Imam',mood:selectedMood,note,updatedAt:new Date().toISOString()};const button=$('#cs2-pulse-form button[type="submit"]');button.disabled=true;try{if(state.demo){pulseState={...pulseState,[state.uid]:item};localStorage.setItem('ac_demo_pulse',JSON.stringify(item));renderPulse(pulseState)}else{await api.saveCouplePulse(state.chatId,{mood:selectedMood,note});await api.sendCoupleActivity(state.chatId,'mood','Pulse hari ini diperbarui',coupleMoods[selectedMood].label)}$('#cs2-pulse-note').value='';notify('Pulse tersinkron ke pasangan')}catch(error){notify(error.message||'Pulse gagal disinkronkan')}finally{button.disabled=false}}

function subscribeConnected(){
  stopConnectedWatchers();
  if(state.demo){
    const defaultDate=new Date(Date.now()-428*dayMs).toISOString().slice(0,10);
    renderAnniversary({date:localStorage.getItem('ac_demo_anniversary')||defaultDate});
    const mine=JSON.parse(localStorage.getItem('ac_demo_pulse')||'null')||{uid:state.uid,name:state.user?.displayName||'Imam',mood:'happy',note:'Senang bisa menjalani hari ini bersamamu.',updatedAt:new Date().toISOString()};
    renderPulse({[state.uid]:mine,[state.partner.uid]:{uid:state.partner.uid,name:state.partner.name||'Pasangan',mood:'loved',note:'Aku juga ada di sini untukmu',updatedAt:new Date(Date.now()-18*60_000).toISOString()}});
    cwLoadDemo();
    return;
  }
  if(!api||!state.chatId)return;
  stopChat=api.watchChatMessages(state.chatId,renderMessages,error=>notify(error.message||'Chat gagal dimuat'));
  stopTyping=api.watchChatTyping?.(state.chatId,data=>{
    const partnerTyping=data?.[state.partner.uid]?.typing;
    $('#cv-typing').classList.toggle('hidden',!partnerTyping);
  },console.error);
  stopPulse=api.watchCouplePulse?.(state.chatId,renderPulse,error=>notify(error.message||'Pulse pasangan gagal dimuat'));
  stopAnniversary=api.watchCoupleAnniversary(state.chatId,data=>{
    const fallback=state.partner?.connectionDate?.toDate?.()||new Date(state.partner?.connectionDate||Date.now());
    renderAnniversary(data?.date?data:{date:fallback.toISOString().slice(0,10)});
  },console.error);
  startActivityWatch();
  cleanupExpiredActivities();
  clearInterval(activityCleanupTimer);
  activityCleanupTimer=setInterval(cleanupExpiredActivities,60_000);
  stopFinance=api.watchCoupleFinanceSummaries?.(state.chatId,data=>{financeSummaries=data||{};renderFinanceSummaries()},console.error);
  stopWedding=api.watchSharedState?.(state.chatId,data=>cwApplyShared(data),error=>notify(error.message||'Wedding Planner gagal dimuat'));
}

function stopConnectedWatchers(){
  [stopChat,stopTyping,stopAnniversary,stopActivity,stopFinance,stopPulse,stopWedding].forEach(stop=>{try{stop?.()}catch{}});
  stopChat=stopTyping=stopAnniversary=stopActivity=stopFinance=stopPulse=stopWedding=null;
  clearInterval(countdownTimer);clearInterval(loveNoteTimer);clearInterval(activityCleanupTimer);activityCleanupTimer=null;
}

function switchHomeTab(name){
  const view=$('#view-couple');if(view)view.dataset.activeTab=name;
  if(name!=='wedding')document.body.classList.remove('cw-wedding-fullscreen');
  $$('[data-couple-tab]').forEach(button=>{const selected=button.dataset.coupleTab===name;button.classList.toggle('active',selected);button.setAttribute('aria-selected',String(selected));});
  $$('[data-couple-panel]').forEach(panel=>panel.classList.toggle('active',panel.dataset.couplePanel===name));
}
function openWeddingPlanner(){
  switchHomeTab('wedding');
  document.body.classList.add('cw-wedding-fullscreen');
  requestAnimationFrame(()=>document.querySelector('[data-cw-fullscreen-close]')?.focus());
}

function openFeature(type){
  if(!labels[type])return;
  if(activeFeature==='chat'&&type!=='chat')document.activeElement?.blur?.();
  activeFeature=type;
  scheduleChatViewport();
  const [kicker,title]=labels[type];
  $('#cv-overlay-kicker').textContent=kicker;$('#cv-overlay-title').textContent=title;
  $$('[data-feature-panel]').forEach(panel=>panel.classList.toggle('hidden',panel.dataset.featurePanel!==type));
  $('#fs-overlay').dataset.activeFeature=type;
  $('#fs-overlay').classList.remove('hidden');
  lockPageScroll();
  $('#fs-body').scrollTop=0;
  if(type==='chat'){document.querySelector('.chat85-heads-up')?.remove();$('#cv-chat-badge').classList.add('hidden');requestAnimationFrame(()=>requestAnimationFrame(()=>{const box=$('#chat-messages');box.scrollTop=box.scrollHeight}));markRead();}
  featureModule?.onFeatureOpen?.(type);
}

function closeFeature(){
  if($('#fs-overlay').contains(document.activeElement))document.activeElement.blur();
  activeFeature=null;
  scheduleChatViewport();
  const overlay=$('#fs-overlay');
  overlay?.classList.add('hidden');
  if(overlay)delete overlay.dataset.activeFeature;
  document.documentElement.classList.remove('map-view-open');
  unlockPageScroll();
  api?.setChatTyping?.(state.chatId,false).catch(()=>{});
}

async function saveAnniversary(){
  const date=$('#anniversary-date').value;
  if(!date)return notify('Pilih tanggal mulai hubungan');
  if(new Date(date+'T00:00:00')>new Date())return notify('Tanggal hubungan tidak boleh di masa depan');
  if(state.demo){localStorage.setItem('ac_demo_anniversary',date);renderAnniversary({date});$('#cv-anniversary-editor').classList.add('hidden');return notify('Tanggal anniversary demo disimpan')}
  try{
    await api.saveCoupleAnniversary(state.chatId,date);
    await api.sendCoupleActivity(state.chatId,'anniversary','Tanggal hubungan diperbarui',new Intl.DateTimeFormat('id-ID',{dateStyle:'long'}).format(new Date(date+'T00:00:00')));
    $('#cv-anniversary-editor').classList.add('hidden');notify('Tanggal tersinkron ke pasangan');
  }catch(error){notify(error.message||'Tanggal gagal disimpan')}
}

function renderAnniversary(data={}){
  currentAnniversary=data;
  const date=data.date||new Date().toISOString().slice(0,10);
  $('#anniversary-date').value=date;
  clearInterval(countdownTimer);clearInterval(loveNoteTimer);
  const update=()=>{
    const start=new Date(date+'T00:00:00');
    const now=new Date();
    const totalDays=Math.max(0,Math.floor((startOfDay(now)-startOfDay(start))/dayMs));
    const duration=calendarDuration(start,now);
    $('#cv-years').textContent=duration.years;$('#cv-months').textContent=duration.months;$('#cv-days').textContent=duration.days;
    $('#anniversary-days').textContent=`${new Intl.NumberFormat('id-ID').format(totalDays)} hari bertumbuh, belajar, dan saling memilih.`;
    const next=nextAnniversary(start,now),remaining=Math.max(0,next-now);
    $('#anniversary-next-date').textContent=new Intl.DateTimeFormat('id-ID',{day:'numeric',month:'long',year:'numeric'}).format(next);
    $('#cs2-hero-days').textContent=new Intl.NumberFormat('id-ID').format(totalDays);
    $('#cs2-next-date').textContent=new Intl.DateTimeFormat('id-ID',{day:'numeric',month:'short'}).format(next);
    $('#cv-countdown-days').textContent=Math.floor(remaining/dayMs);
    $('#cv-countdown-hours').textContent=pad(Math.floor(remaining/3_600_000)%24);
    $('#cv-countdown-minutes').textContent=pad(Math.floor(remaining/60_000)%60);
    $('#cv-countdown-seconds').textContent=pad(Math.floor(remaining/1000)%60);
    renderMilestones(totalDays);
  };
  update();publishHomeCouple({connected:true});countdownTimer=setInterval(update,1000);
  let noteIndex=Math.floor(Date.now()/10_000)%loveNotes.length;
  $('#cv-love-note').textContent=loveNotes[noteIndex];
  loveNoteTimer=setInterval(()=>{$('#cv-love-note').textContent=loveNotes[++noteIndex%loveNotes.length]},10_000);
}

function calendarDuration(start,end){
  let years=end.getFullYear()-start.getFullYear();
  let months=end.getMonth()-start.getMonth();
  let days=end.getDate()-start.getDate();
  if(days<0){months--;days+=new Date(end.getFullYear(),end.getMonth(),0).getDate()}
  if(months<0){years--;months+=12}
  return {years:Math.max(0,years),months:Math.max(0,months),days:Math.max(0,days)};
}
function nextAnniversary(start,now){let next=new Date(now.getFullYear(),start.getMonth(),start.getDate());if(next<=now)next.setFullYear(next.getFullYear()+1);return next}
function startOfDay(date){return new Date(date.getFullYear(),date.getMonth(),date.getDate())}
function pad(value){return String(value).padStart(2,'0')}
function renderMilestones(days){
  const marks=[7,30,100,180,365,500,730];
  const next=marks.find(value=>value>days)||Math.ceil((days+1)/365)*365;
  const previous=[0,...marks].filter(value=>value<=days).at(-1)||0;
  const pct=Math.max(0,Math.min(100,(days-previous)/(next-previous)*100));
  $('#cv-next-milestone').textContent=`${new Intl.NumberFormat('id-ID').format(next)} hari`;
  $('#cv-milestone-label').textContent=`${Math.round(pct)}%`;
  $('#cv-milestone-progress').style.width=`${pct}%`;
  $('#cv-milestones').innerHTML=marks.map(value=>`<span class="${days>=value?'done':value===next?'next':''}">${days>=value?'<i data-fa="check"></i> ':''}${value}</span>`).join('');
}

function activityTime(item){
  const value=item?.createdAt?.toDate?.()||new Date(item?.createdAt||0);
  return value.getTime()||0;
}
function isRecentActivity(item,now=Date.now()){const time=activityTime(item);return time>now-activityTtlMs&&time<=now+300000}
async function cleanupExpiredActivities(){
  const fresh=activities.filter(item=>isRecentActivity(item));
  if(fresh.length!==activities.length)renderActivity(fresh);
  if(!state.demo&&api&&state.chatId){
    try{await api.deleteExpiredCoupleActivities?.(state.chatId)}catch(error){console.warn('Pembersihan cerita 24 jam:',error?.message||error)}
  }
}
function startActivityWatch(){
  if(!api||!state.chatId)return;
  stopActivity?.();activityState='loading';renderActivity(activities);
  const room=state.chatId;
  stopActivity=api.watchCoupleActivity(room,rows=>{if(state.chatId!==room)return;activityState='ready';renderActivity(rows)},()=>{if(state.chatId!==room)return;activityState='error';renderActivity(activities)});
}
function renderActivity(items=[]){
  const seen=new Set();activities=(Array.isArray(items)?items:[]).filter(item=>{if(!isRecentActivity(item)||item.id&&seen.has(item.id))return false;if(item.id)seen.add(item.id);return true}).sort((a,b)=>activityTime(b)-activityTime(a));
  publishHomeActivity(activities);
  const query=$('#activity-search').value.trim().toLowerCase(),actor=$('#activity-actor').value;
  const filtered=activities.filter(item=>(activityFilter==='all'||normalizeActivityType(item.type)===activityFilter)&&(actor==='all'||actor==='me'&&item.actorId===state.uid||actor==='partner'&&!!state.partner?.uid&&item.actorId===state.partner.uid)&&(!query||[item.title,item.detail,item.actorName].join(' ').toLowerCase().includes(query)));
  if($('#activity-order').value==='oldest')filtered.reverse();
  $('#activity-total').textContent=activities.length;$('#activity-mine').textContent=activities.filter(x=>x.actorId===state.uid).length;$('#activity-partner').textContent=activities.filter(x=>x.actorId&&x.actorId===state.partner?.uid).length;
  $('#activity-sync-status').textContent=state.demo?'Mode demo':activityState==='error'?'Sinkronisasi bermasalah':activityState==='loading'?'Memuat aktivitas…':'Data terakhir dimuat';
  $('#activity-feedback').textContent=activityState==='error'&&!state.demo?'Gagal memperbarui. Data sebelumnya tetap ditampilkan. Coba Muat ulang.':`${Math.min(activityLimit,filtered.length)} dari ${filtered.length} hasil · 24 jam terakhir (WIB)`;
  $('#activity-more').classList.toggle('hidden',filtered.length<=activityLimit);
  $$('[data-activity-filter]').forEach(button=>{const selected=button.dataset.activityFilter===activityFilter;button.classList.toggle('active',selected);button.setAttribute('aria-pressed',String(selected))});
  const box=$('#cv-activity-feed');
  const counter=$('#activity-feed-count');
  if(counter)counter.textContent=`${filtered.length} cerita`;
  if(!filtered.length){box.innerHTML=`<div class="act-empty"><b>${activityState==='loading'&&!state.demo?'Menyiapkan cerita…':activities.length?'Tidak ada cerita yang cocok':'Belum ada cerita dalam 24 jam terakhir'}</b><p>${activities.length?'Ubah pencarian atau pilih Reset filter.':'Aktivitas dari fitur yang tersambung akan muncul di sini.'}</p></div>`;return}
  let lastDay='';box.innerHTML=filtered.slice(0,activityLimit).map(item=>{
    const date=item.createdAt?.toDate?.()||new Date(item.createdAt||Date.now());
    const type=normalizeActivityType(item.type),amount=Number.isFinite(Number(item.amount))&&Number(item.amount)!==0?money(item.amount):'';
    const day=new Intl.DateTimeFormat('id-ID',{timeZone:'Asia/Jakarta',weekday:'long',day:'numeric',month:'long'}).format(date),heading=day!==lastDay?`<h5 class="act-day-label">${escapeHtml(day)}</h5>`:'';lastDay=day;
    const mine=item.actorId&&state.uid&&item.actorId===state.uid;
    const title=escapeHtml(item.title||'Aktivitas bersama'),detail=escapeHtml(item.detail||''),actorName=escapeHtml(item.actorName||(mine?firstName(state.user?.displayName||'Kamu'):firstName(state.partner?.name||state.partner?.displayName||'Pasangan'))),actorPhoto=escapeHtml(item.actorPhotoURL||(mine?state.user?.photoURL:state.partner?.photoURL)||''),actorInitial=escapeHtml(String(item.actorName||(mine?state.user?.displayName:state.partner?.name||state.partner?.displayName)||'P').trim().charAt(0).toUpperCase());
    return `${heading}<article class="${mine?'act-mine':''}" data-activity-id="${escapeHtml(item.id||'')}"><span class="act-entry-avatar ${mine?'me':'partner'}">${actorPhoto?`<img src="${actorPhoto}" alt="Foto ${actorName}"/>`:''}<span>${actorInitial}</span><i class="act-type-badge">${activityIcons[type]||'<i data-fa="heart-o"></i>'}</i></span><div class="act-entry-copy"><header><b title="${title}">${title}</b><span class="act-entry-owner ${mine?'me':'partner'}">${mine?'Kamu':actorName}</span></header>${detail?`<p title="${detail}">${detail}</p>`:''}<div class="act-entry-meta"><small>${new Intl.DateTimeFormat('id-ID',{timeZone:'Asia/Jakarta',hour:'2-digit',minute:'2-digit'}).format(date)+' WIB'}</small>${amount?`<strong>${amount}</strong>`:''}</div></div><div class="act-entry-actions">${mine&&item.id?`<button type="button" class="act-delete-btn" data-delete-activity="${escapeHtml(item.id)}" aria-label="Hapus cerita" title="Hapus cerita" ${deletingActivities.has(item.id)?'disabled aria-busy="true"':''}><i data-fa="trash"></i></button>`:''}</div></article>`;
  }).join('');$$('.act-entry-avatar img',box).forEach(image=>image.addEventListener('error',()=>image.classList.add('hidden'),{once:true}));hydrateFeatureIcons(box);
}
async function handleActivityFeedClick(event){
  const button=event.target.closest('[data-delete-activity]');if(!button)return;
  const id=button.dataset.deleteActivity,item=activities.find(entry=>entry.id===id),room=state.chatId;
  if(!item||deletingActivities.has(id))return;
  if(!item.actorId||item.actorId!==state.uid)return notify('Hanya cerita milik Anda yang dapat dihapus');
  if(!confirm('Hapus cerita ini dari timeline? Transaksi, foto, dan pesan aslinya tidak ikut dihapus.'))return;
  deletingActivities.add(id);renderActivity(activities);
  try{if(!state.demo)await api.deleteCoupleActivity(room,id);if(state.chatId!==room)return;activities=activities.filter(x=>x.id!==id);notify('Cerita berhasil dihapus')}
  catch(error){if(state.chatId===room)notify(error.message||'Cerita gagal dihapus')}
  finally{deletingActivities.delete(id);if(state.chatId===room)renderActivity(activities)}
}
function normalizeActivityType(type){if(type==='memory')return'location';if(['savings','reward','location','finance','ai'].includes(type))return type;return type||'all'}
function renderFinanceSummaries(){
  const parts=new Intl.DateTimeFormat('en-US',{timeZone:'Asia/Jakarta',year:'numeric',month:'2-digit'}).formatToParts(new Date());const period=parts.find(x=>x.type==='year').value+'-'+parts.find(x=>x.type==='month').value;
  for(const [role,id] of [['me',state.uid],['partner',state.partner?.uid]]){
    const raw=financeSummaries[id]||{},rawBalance=raw.availableBalance??raw.balance,n=Number(rawBalance),has=rawBalance!=null&&String(rawBalance).trim()!==''&&Number.isFinite(n),stale=!!raw.period&&raw.period!==period;
    const balance=$(`#cv-finance-${role}-balance`),spend=$(`#cv-finance-${role}-spend`);
    balance.textContent=has?moneyBalance(n):'Belum tersedia';balance.classList.toggle('red',has&&n<0);spend.textContent=has?(stale?'—':money(Number(raw.expense)||0)):'—';
    balance.title=has?(stale?'Saldo total terakhir; ringkasan bulan berjalan belum diperbarui.':n<0?'Saldo total sedang minus. Periksa pengeluaran bulan ini.':'Saldo total terakhir yang diterima.'):'Buka Keuangan pada akun terkait untuk sinkronisasi.';
    if(role==='partner'){$('.act-partner-card')?.classList.toggle('finance-awaiting',!has);$('.act-partner-card')?.setAttribute('data-sync-status',has?'Saldo terakhir diterima':'Menunggu sinkronisasi pasangan')}
  }
}

function syncChatSendButton(){
  const button=$('#sendMsg');button.disabled=chatSending||!$('#chat-input').value.trim();
  button.setAttribute('aria-busy',String(chatSending));
  button.setAttribute('aria-label',chatSending?'Sedang mengirim':'Kirim pesan');
}
function scheduleChatViewport(){
  cancelAnimationFrame(chatViewportFrame);chatViewportFrame=requestAnimationFrame(updateChatViewport);
}
function updateChatViewport(){
  const overlay=$('#fs-overlay'),vv=window.visualViewport;
  if(activeFeature!=='chat'||(vv&&Math.abs(vv.scale-1)>.03)){
    overlay.style.removeProperty('--chat-viewport-height');overlay.style.removeProperty('--chat-viewport-top');overlay.classList.remove('chat-compact-height');return;
  }
  overlay.classList.toggle('chat-compact-height',(vv?.height||innerHeight)<420);
  const box=$('#chat-messages'),atBottom=box.scrollHeight-box.scrollTop-box.clientHeight<70;
  overlay.style.setProperty('--chat-viewport-height',`${vv?.height||window.innerHeight}px`);
  overlay.style.setProperty('--chat-viewport-top',`${vv?.offsetTop||0}px`);
  if(atBottom)requestAnimationFrame(()=>{box.scrollTop=box.scrollHeight});
}
async function sendMessage(event){
  event.preventDefault();
  const input=$('#chat-input'),text=input.value.trim();
  if(!text||chatSending)return;
  const matusMention=/^@matus\b/i.test(text),matusQuestion=text.replace(/^@matus\b[:\s-]*/i,'').trim();
  const original=input.value,reply=replyTo,chatId=state.chatId,uid=state.uid,demo=state.demo;
  const payload={text,replyTo:reply?{id:reply.id,text:reply.text,from:reply.from}:null};
  const stillCurrent=()=>state.uid===uid&&state.chatId===chatId&&state.demo===demo;
  chatSending=true;chatStickToBottom=true;syncChatSendButton();
  $('#chat-send-status').textContent='Mengirim…';$('#cv-emoji-panel').classList.add('hidden');
  try{
    if(demo){
      messages.push({id:crypto.randomUUID(),from:uid,text,replyTo:payload.replyTo,createdAt:new Date(),read:true});renderMessages(messages);
      if(!matusMention)setTimeout(()=>{if(!stillCurrent())return;messages.push({id:crypto.randomUUID(),from:'demo-partner',text:'Aku sudah baca. Terima kasih sudah cerita',createdAt:new Date(),read:true});renderMessages(messages)},700);
    }else{
      if(!api||!chatId)throw Error('Chat belum tersambung. Coba lagi setelah koneksi siap.');
      await api.sendChatMessage(chatId,text,payload.replyTo);
    }
    if(!stillCurrent())return;
    if(input.value===original){input.value='';input.style.height='auto'}
    if(replyTo===reply)clearReply();
    $('#chat-send-status').textContent='Pesan terkirim';
    clearTimeout(typingTimer);if(!demo)api.setChatTyping?.(chatId,false).catch(()=>{});
    // Activity logging is secondary: its failure must not label a sent message as failed.
    if(!demo)Promise.resolve().then(()=>api.sendCoupleActivity(chatId,'chat','Pesan baru dikirim',text.slice(0,120))).catch(()=>{});
    if(matusMention)sendMatusRoomAnswer('reply',matusQuestion||'Bantu tanggapi percakapan terakhir di room ini.');
  }catch(error){
    chatStickToBottom=false;
    if(stillCurrent()){
      $('#chat-send-status').textContent='Pengiriman belum terkonfirmasi. Draf tetap tersedia; periksa chat sebelum mencoba lagi.';
      notify(error.message||'Pesan belum terkonfirmasi. Draf tidak dihapus.');
    }
  }finally{chatSending=false;syncChatSendButton();scheduleChatViewport()}
}

function handleTyping(event){
  const input=event.target;input.style.height='auto';input.style.height=Math.min(input.scrollHeight,96)+'px';
  if(state.demo||!api||!state.chatId)return;
  api.setChatTyping?.(state.chatId,true).catch(()=>{});clearTimeout(typingTimer);typingTimer=setTimeout(()=>api.setChatTyping?.(state.chatId,false).catch(()=>{}),1400);
}

function messageTime(message){const value=message.createdAt?.toDate?.()||new Date(message.createdAt||Date.now());return value}
function dayLabelFor(date){
  const today=startOfDay(new Date()).getTime(),target=startOfDay(date).getTime();
  if(target===today)return 'Hari ini';
  if(target===today-dayMs)return 'Kemarin';
  return new Intl.DateTimeFormat('id-ID',{day:'numeric',month:'long',year:'numeric'}).format(date);
}
function isStickerOnly(text){
  const value=String(text||'').trim();
  if(!value||value.length>8)return false;
  return /^[\p{Extended_Pictographic}\uFE0F\u200D]+$/u.test(value);
}

function renderMessages(items=[]){
  messages=Array.isArray(items)?items:[];
  const incoming=messages.filter(item=>item.from!==state.uid&&item.type!=='matus'),fresh=chatNotificationPrimed?incoming.filter(item=>!seenIncomingMessageIds.has(item.id)):[];
  incoming.forEach(item=>seenIncomingMessageIds.add(item.id));chatNotificationPrimed=true;
  if(!chatMuted())fresh.forEach(item=>window.dispatchEvent(new CustomEvent('appcouple:incoming-chat',{detail:{id:item.id,text:item.text,name:firstName(state.partner?.displayName||state.partner?.name||'Pasangan'),createdAt:item.createdAt||item.timestamp}})));
  const query=$('#cv-chat-search-input')?.value.trim().toLowerCase()||'';
  const kept=messages.filter(message=>messageTime(message).getTime()>hiddenBefore);
  const visible=query?kept.filter(item=>String(item.text||'').toLowerCase().includes(query)):kept;
  const box=$('#chat-messages'),previousTop=box.scrollTop,follow=chatStickToBottom||box.scrollHeight-box.scrollTop-box.clientHeight<80;
  chatStickToBottom=false;
  const partnerInitial=(firstName(state.partner?.name||state.partner?.displayName||'Pasangan')[0]||'P').toUpperCase();
  if(!visible.length){
    box.innerHTML=`<div class="wa-empty"><span><i data-fa="heart-o"></i></span><b>${query?'Pesan tidak ditemukan':'Ruang chat kalian siap'}</b><p>${query?'Coba kata kunci lain.':'Kirim pesan pertama.'}</p></div>`;
    hydrateFeatureIcons(box);updatePinned();return;
  }
  let lastDay='',previousFrom=null,previousTime=0;
  box.innerHTML=visible.map(message=>{
    const date=messageTime(message);
    const day=dayLabelFor(date);
    const mine=message.from===state.uid;
    let html='';
    if(day!==lastDay){html+=`<div class="wa-date-divider"><span>${escapeHtml(day)}</span></div>`;previousFrom=null;}
    lastDay=day;
    const matus=message.type==='matus'||message.from==='matus';
    const grouped=!matus&&previousFrom===message.from&&(date.getTime()-previousTime)<300000;
    previousFrom=matus?'matus':message.from;previousTime=date.getTime();
    const reactions=[...new Set(Object.values(message.reactions||{}).filter(Boolean))];
    const sticker=isStickerOnly(message.text);
    const avatar=matus?'<span class="wa-msg-avatar wa-matus-avatar"><i data-fa="sparkles"></i></span>':mine?'':(grouped?'<span class="wa-msg-avatar-spacer"></span>':`<span class="wa-msg-avatar account-partner-avatar">${escapeHtml(partnerInitial)}</span>`);
    const quote=message.replyTo?.text?`<div class="wa-reply-quote"><div class="wa-reply-quote-name">${escapeHtml(message.replyTo.from===state.uid?'Kamu':matus?'Matus':firstName(state.partner?.name||'Pasangan'))}</div><div class="wa-reply-quote-text">${escapeHtml(message.replyTo.text)}</div></div>`:'';
    const tick=!matus&&mine?`<span class="wa-tick ${message.read?'wa-read-blue':'wa-read-grey'}"><i data-fa="${message.read?'check-double':'check'}"></i></span>`:'';
    const meta=sticker?'':`<div class="wa-bubble-meta"><span class="wa-bubble-time">${new Intl.DateTimeFormat('id-ID',{hour:'2-digit',minute:'2-digit'}).format(date)}</span>${tick}</div>`;
    const badge=reactions.length?`<span class="wa-reaction-badge">${reactions.map(value=>escapeHtml(value)).join('')}</span>`:'';
    const matusLabel=matus?'<span class="wa-matus-label"><i data-fa="sparkles"></i> Matus AI · Pendamping</span>':'';
    const speakerLabel=!matus&&!grouped?`<span class="wa-speaker-label">${escapeHtml(mine?firstName(state.user?.displayName||'Imam'):firstName(state.partner?.name||state.partner?.displayName||'Pasangan'))}</span>`:'';
    html+=`<div class="wa-msg-wrap ${matus?'wa-matus-wrap':mine?'wa-out':'wa-in'} ${grouped?'wa-grouped':''}" data-message-id="${escapeHtml(message.id)}">${avatar}<div class="wa-msg-col">${matusLabel}${speakerLabel}<button type="button" class="wa-bubble ${matus?'wa-bubble-matus':mine?'wa-bubble-out':'wa-bubble-in'} ${grouped?'':'wa-group-first'} ${sticker?'wa-bubble-sticker':''} ${message.pinned?'wa-pinned-msg':''}" data-message-menu="${escapeHtml(message.id)}">${quote}${escapeHtml(message.text||'')}${meta}${badge}</button></div></div>`;
    return html;
  }).join('');
  hydrateFeatureIcons(box);
  if(!query&&follow){box.scrollTop=box.scrollHeight;$('#chat-latest').classList.add('hidden')}else{box.scrollTop=previousTop;if(!query&&fresh.length)$('#chat-latest').classList.remove('hidden')}
  const unread=messages.filter(item=>item.from!==state.uid&&item.type!=='matus'&&!item.read).length;
  const badge=$('#cv-chat-badge');badge.textContent=unread>99?'99+':String(unread);badge.classList.toggle('hidden',!unread||activeFeature==='chat');
  updatePinned();
  if(activeFeature==='chat')markRead();
}

async function sendSticker(value){
  if(!value)return;
  if(state.demo){
    messages.push({id:crypto.randomUUID(),from:state.uid,text:value,createdAt:new Date(),read:true});
    renderMessages(messages);return;
  }
  try{await api.sendChatMessage(state.chatId,value,null)}catch(error){notify(error.message||'Stiker gagal dikirim')}
}

function handleMessageClick(event){
  const button=event.target.closest('[data-message-menu]');
  if(!button)return;
  const message=messages.find(item=>item.id===button.dataset.messageMenu);if(!message)return;
  showMessageMenu(button,message);
}
function showMessageMenu(anchor,message){
  $('.wa-msg-menu')?.remove();
  const menu=document.createElement('div');menu.className='wa-msg-menu';
  const mine=message.from===state.uid;
  menu.innerHTML=`<button data-action="reply"><i data-fa="reply"></i> Balas</button><button data-action="react"><i data-fa="heart"></i> Reaksi hati</button><button data-action="pin"><i data-fa="thumbtack"></i> ${message.pinned?'Lepas sematan':'Sematkan'}</button><button data-action="forward"><i data-fa="copy"></i> Salin pesan</button>${mine?'<button data-action="delete" class="danger"><i data-fa="trash"></i> Hapus pesan</button>':''}`;
  document.body.appendChild(menu);
  hydrateFeatureIcons(menu);
  const rect=anchor.getBoundingClientRect(),width=200;
  menu.style.left=Math.max(8,Math.min(window.innerWidth-width-8,mine?rect.right-width:rect.left))+'px';
  menu.style.top=Math.max(74,Math.min(window.innerHeight-250,rect.top))+'px';
  menu.onclick=async event=>{const action=event.target.closest('[data-action]')?.dataset.action;if(!action)return;menu.remove();await messageAction(action,message)};
}
async function messageAction(action,message){
  if(action==='reply'){replyTo=message;$('#cv-reply-text').textContent=message.text;$('#cv-reply-bar').classList.remove('hidden');$('#chat-input').focus();return}
  if(action==='forward'){try{await navigator.clipboard.writeText(message.text);notify('Pesan disalin')}catch{notify('Tidak dapat menyalin pesan')}return}
  if(action==='delete'&&!confirm('Hapus pesan ini untuk kalian berdua?'))return;
  if(state.demo){
    if(action==='react')message.reactions={...(message.reactions||{}),[state.uid]:'️'};
    if(action==='pin'){messages.forEach(item=>item.pinned=false);message.pinned=!message.pinned;updatePinned()}
    if(action==='delete')messages=messages.filter(item=>item.id!==message.id);
    renderMessages(messages);return;
  }
  try{
    if(action==='react')await api.reactChatMessage(state.chatId,message.id,'️');
    if(action==='pin')await api.pinChatMessage(state.chatId,message.id,!message.pinned);
    if(action==='delete')await api.deleteChatMessage(state.chatId,message.id);
  }catch(error){notify(error.message||'Aksi pesan gagal')}
}
function clearReply(){replyTo=null;$('#cv-reply-bar').classList.add('hidden');$('#cv-reply-text').textContent=''}
function updatePinned(){const message=messages.find(item=>item.pinned);$('#cv-pinned-message')?.classList.toggle('hidden',!message);if(message)$('#cv-pinned-text').textContent=message.text}
function markRead(){if(state.demo){messages.forEach(item=>{if(item.from!==state.uid)item.read=true});return}if(api&&state.chatId)api.markChatRead?.(state.chatId).catch(()=>{})}
function toggleMusic(){
  if(!audio){audio=new Audio('/assets/couple-song.mp3');audio.loop=true;audio.volume=.32;audio.addEventListener('ended',updateMusicButtons)}
  if(audio.paused)audio.play().then(updateMusicButtons).catch(()=>notify('Ketuk sekali lagi untuk memutar musik'));else{audio.pause();updateMusicButtons()}
}
function updateMusicButtons(){[$('#cv-music-toggle'),$('#cv-overlay-music')].forEach(button=>{if(button){button.innerHTML=audio&&!audio.paused?'<i data-fa="circle-half"></i>':'<i data-fa="music"></i>';hydrateFeatureIcons(button);button.title=audio&&!audio.paused?'Jeda musik':'Putar musik'}})}

function demoMessages(){return[
  {id:'m1',from:'demo-partner',text:'Jangan lupa makan siang ya',createdAt:new Date(Date.now()-7_200_000),read:true,pinned:true,reactions:{'demo-imam':'️'}},
  {id:'m2',from:'demo-imam',text:'Siap. Nanti malam kita cek target tabungan juga ya.',replyTo:{text:'Jangan lupa makan siang ya'},createdAt:new Date(Date.now()-7_000_000),read:true},
  {id:'m3',from:'demo-partner',text:'Boleh, sekalian cari ide kencan untuk akhir pekan',createdAt:new Date(Date.now()-6_800_000),read:false}
]}
function demoActivities(){return[
  {id:'a1',actorId:'demo-imam',actorName:'Imam',type:'savings',title:'Setoran Celengan Cinta',detail:'Pasangan menambahkan Rp750.000 · Liburan Impian',amount:750000,createdAt:new Date(Date.now()-3_600_000)},
  {id:'a2',actorId:'demo-partner',actorName:'Halimatus',type:'reward',title:'Hadiah berhasil ditukar',detail:'Movie night pilihan pasangan',createdAt:new Date(Date.now()-7_200_000)},
  {id:'a3',actorId:'demo-imam',actorName:'Imam',type:'location',title:'Jejak baru di Bandung',detail:'Ngopi sore berdua',createdAt:new Date(Date.now()-10_800_000)},
  {id:'a4',actorId:'demo-partner',actorName:'Halimatus',type:'finance',title:'Ringkasan finance diperbarui',detail:'Pengeluaran kencan turun 18%',createdAt:new Date(Date.now()-18_000_000)},
  {id:'a5',actorId:'demo-imam',actorName:'Imam',type:'ai',title:'Laporan AI mingguan siap',detail:'Kalian konsisten menabung 4 hari berturut-turut',createdAt:new Date(Date.now()-dayMs)},
  {id:'a6',actorId:'demo-partner',actorName:'Halimatus',type:'game',title:'Kuis Cinta selesai',detail:'Skor bersama 8/10',createdAt:new Date(Date.now()-2*dayMs)}
]}
function demoFinance(){const live=window.__appCoupleFinanceSummary||{},income=Math.max(0,Number(live.income)||9_500_000),expense=Math.max(0,Number(live.expense)||1_670_000),available=Number.isFinite(Number(live.availableBalance))?Number(live.availableBalance):income-expense,period=new Date().toISOString().slice(0,7);return{'demo-imam':{income,expense,balance:income-expense,availableBalance:available,period},'demo-partner':{income:8_700_000,expense:2_480_000,balance:6_220_000,availableBalance:6_220_000,period}}}
function firstName(value){return String(value||'').trim().split(/\s+/)[0]||'Pasangan'}
function money(value){return 'Rp'+new Intl.NumberFormat('id-ID').format(Math.max(0,Math.round(Number(value)||0)))}
function moneyBalance(value){const amount=Math.round(Number(value)||0);return(amount<0?'-':'')+'Rp'+new Intl.NumberFormat('id-ID').format(Math.abs(amount))}
function safePhoto(value){try{const url=new URL(String(value||''),location.href);return url.protocol==='https:'?url.href.replace(/["'()]/g,encodeURIComponent):''}catch{return''}}
function escapeHtml(value){const element=document.createElement('div');element.textContent=String(value??'');return element.innerHTML}

/* Wedding Planner: a compact, shared control room for the Couple Space. */
function cwDefaultPlan(){return{weddingDate:'',totalBudget:0,budgetItems:[],seserahan:[],guests:[],checklist:[
  {id:'cw-c1',title:'Fotokopi KTP dan KK',owner:'Bersama',done:false,status:'Belum mulai',dueDate:''},
  {id:'cw-c2',title:'Surat pengantar nikah',owner:'Bersama',done:false,status:'Belum mulai',dueDate:''},
  {id:'cw-c3',title:'Pas foto dan surat sehat',owner:'Bersama',done:false,status:'Belum mulai',dueDate:''}],vendors:[],savings:{target:0,saved:0,deadline:'',deposits:[]},activityLog:[],updatedAt:'',updatedBy:''}}
function cwMerge(plan={}){const base=cwDefaultPlan(),raw=plan&&typeof plan==='object'?plan:{},legacyTotal=Number(raw.totalBudget??(Array.isArray(raw.budgetItems)?raw.budgetItems.reduce((sum,row)=>sum+Math.max(0,Number(row.planned)||0),0):0))||0;return{...base,...raw,totalBudget:Math.max(0,legacyTotal),budgetItems:Array.isArray(raw.budgetItems)?raw.budgetItems:base.budgetItems,seserahan:Array.isArray(raw.seserahan)?raw.seserahan:[],guests:Array.isArray(raw.guests)?raw.guests:[],checklist:Array.isArray(raw.checklist)?raw.checklist:base.checklist.map(row=>({...row})),vendors:Array.isArray(raw.vendors)?raw.vendors:[],activityLog:Array.isArray(raw.activityLog)?raw.activityLog.slice(0,200):[],savings:{...base.savings,...(raw.savings||{}),deposits:Array.isArray(raw.savings?.deposits)?raw.savings.deposits:[]}}}
function cwMoney(value){return money(Math.round(Number(value)||0))}
function cwBalanceLabel(planned,actual){const balance=Math.round(Number(planned)||0)-Math.round(Number(actual)||0);return balance>=0?`Sisa ${cwMoney(balance)}`:`Lebih ${cwMoney(Math.abs(balance))}`}
function cwId(prefix){return `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2,7)}`}
function cwSetSync(label,stateName='saved'){setTextSafe('#cw-sync-label',label);const pill=$('#cw-sync-pill');if(pill)pill.dataset.state=stateName}
function cwTab(name='overview'){const view=$('#view-couple');if(!view)return;view.dataset.cwActiveTab=name;$$('[data-cw-tab]').forEach(button=>{const active=button.dataset.cwTab===name;button.classList.toggle('active',active);button.setAttribute('aria-selected',String(active))});$$('[data-cw-panel]').forEach(panel=>panel.classList.toggle('active',panel.dataset.cwPanel===name));requestAnimationFrame(()=>{const tabs=$('#cw-mobile-tabs'),active=tabs?.querySelector(`[data-cw-tab="${name}"]`);active?.scrollIntoView({block:'nearest',inline:'center',behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'auto':'smooth'});if(name!=='overview')tabs?.scrollIntoView({block:'nearest',behavior:'smooth'})})}
function cwFormatDate(value){if(!value)return'Atur tanggal';const date=new Date(`${value}T00:00:00`);return Number.isNaN(date.getTime())?'Atur tanggal':new Intl.DateTimeFormat('id-ID',{day:'numeric',month:'long',year:'numeric'}).format(date)}
function cwPublishMatusContext(plan){
  const p=cwMerge(plan),budgetAllocated=p.budgetItems.reduce((sum,row)=>sum+Math.max(0,Number(row.planned)||0),0),budgetActual=p.budgetItems.reduce((sum,row)=>sum+Math.max(0,Number(row.actual)||0),0),seserahanActual=p.seserahan.reduce((sum,row)=>sum+Math.max(0,Number(row.actual)||0),0),actual=budgetActual+seserahanActual,planned=Math.max(0,Number(p.totalBudget)||0),categories={};
  p.budgetItems.forEach(row=>{const key=row.category||'Lainnya';categories[key]=(categories[key]||0)+Math.max(0,Number(row.actual)||0)});p.seserahan.forEach(row=>{const key=row.category||'Seserahan';categories[key]=(categories[key]||0)+Math.max(0,Number(row.actual)||0)});
  const depositTotal=p.savings.deposits.reduce((sum,row)=>sum+Math.max(0,Number(row.amount)||0),0),saved=p.savings.deposits.length?depositTotal:Math.max(0,Number(p.savings.saved)||0);
  window.__appCoupleWeddingPlan={weddingDate:p.weddingDate,totalBudget:planned,budgetAllocated,budgetActual,seserahanActual,actual,remaining:planned-actual,unallocated:planned-budgetAllocated,categoryTotals:categories,budgetItems:p.budgetItems.map(row=>({category:String(row.category||'').slice(0,40),item:String(row.item||'').slice(0,80),planned:Number(row.planned)||0,actual:Number(row.actual)||0,status:String(row.status||'Belum mulai'),dueDate:row.dueDate||''})).slice(0,100),guests:p.guests.map(row=>({name:String(row.name||'').slice(0,80),contact:!!row.contact,side:String(row.side||'Bersama'),relationship:String(row.relationship||'').slice(0,50),inviteType:String(row.inviteType||'Digital'),seats:Number(row.seats)||1,status:String(row.status||'Belum diundang'),rsvpDue:row.rsvpDue||''})).slice(0,100),checklist:p.checklist.map(row=>({title:String(row.title||'').slice(0,100),owner:String(row.owner||'Bersama'),status:String(row.status||(row.done?'Selesai':'Belum mulai')),done:!!row.done,dueDate:row.dueDate||''})).slice(0,100),vendors:p.vendors.map(row=>({category:String(row.category||'').slice(0,40),name:String(row.name||'').slice(0,80),planned:Number(row.planned)||0,paid:Number(row.paid)||0,status:String(row.status||'Riset'),dueDate:row.dueDate||'',contact:!!row.contact})).slice(0,100),savings:{target:Math.max(0,Number(p.savings.target)||0),saved,deadline:p.savings.deadline||''},activityLog:p.activityLog.slice(0,12)};
  window.dispatchEvent(new CustomEvent('appcouple:wedding-update',{detail:window.__appCoupleWeddingPlan}))
}
function cwRender(){
  weddingPlan=cwMerge(weddingPlan);const p=weddingPlan;cwPublishMatusContext(p);
  const budgetAllocated=p.budgetItems.reduce((sum,row)=>sum+Math.max(0,Number(row.planned)||0),0),budgetActual=p.budgetItems.reduce((sum,row)=>sum+Math.max(0,Number(row.actual)||0),0),seserahanActual=p.seserahan.reduce((sum,row)=>sum+Math.max(0,Number(row.actual)||0),0),planned=Math.max(0,Number(p.totalBudget)||0),actual=budgetActual+seserahanActual,remaining=planned-actual,progress=planned?Math.min(100,Math.round(actual/planned*100)):0;
  setTextSafe('#cw-total-budget',cwMoney(planned));setTextSafe('#cw-total-actual',cwMoney(actual));setTextSafe('#cw-total-remaining',cwBalanceLabel(planned,actual));const bar=$('#cw-budget-progress');if(bar)bar.style.width=`${progress}%`;setTextSafe('#cw-budget-status',planned?`${progress}% sudah tercatat · ${remaining<0?'Melebihi rencana':remaining===0?'Budget habis':`Sisa ${cwMoney(remaining)}`}`:'Masukkan total rencana anggaran');const budgetEmpty=$('#cw-budget-empty');if(budgetEmpty)budgetEmpty.classList.toggle('hidden',p.budgetItems.length>0);
  setTextSafe('#cw-wedding-date',cwFormatDate(p.weddingDate));const date=p.weddingDate?new Date(`${p.weddingDate}T00:00:00`):null,days=date&&!Number.isNaN(date.getTime())?Math.ceil((date.getTime()-new Date().setHours(0,0,0,0))/dayMs):null;setTextSafe('#cw-wedding-countdown',days===null?'Tanggal pernikahan belum diatur.':days>=0?`${days} hari lagi · siap-siap pelan-pelan.`:'Tanggal ini sudah lewat · pilih tanggal baru.');const dateInput=$('#cw-wedding-date-input');if(dateInput&&dateInput.value!==p.weddingDate)dateInput.value=p.weddingDate||'';
  const seats=p.guests.reduce((sum,row)=>sum+Math.max(0,Number(row.seats)||0),0),done=p.checklist.filter(row=>row.done).length,depositTotal=p.savings.deposits.reduce((sum,row)=>sum+Math.max(0,Number(row.amount)||0),0),saved=p.savings.deposits.length?depositTotal:Math.max(0,Number(p.savings.saved)||0),target=Math.max(0,Number(p.savings.target)||0),checkPct=p.checklist.length?Math.round(done/p.checklist.length*100):0,budgetPct=planned?Math.min(100,Math.round(budgetAllocated/planned*100)):0,confirmed=p.guests.filter(row=>['Hadir','Terkonfirmasi','Konfirmasi'].includes(row.status)).reduce((sum,row)=>sum+Math.max(0,Number(row.seats)||0),0),guestPct=seats?Math.min(100,Math.round(confirmed/seats*100)):0,vendorPct=p.vendors.length?Math.round(p.vendors.filter(row=>Number(row.planned)>0&&Number(row.paid)>=Number(row.planned)).length/p.vendors.length*100):0,seserahanPct=p.seserahan.length?Math.round(p.seserahan.filter(row=>Math.max(0,Number(row.actual)||0)>0).length/p.seserahan.length*100):0,savingsPct=target?Math.min(100,Math.round(saved/target*100)):0,overall=Math.round(checkPct*.25+budgetPct*.25+guestPct*.2+vendorPct*.15+seserahanPct*.1+savingsPct*.05);setTextSafe('#cw-guest-count',String(p.guests.length));setTextSafe('#cw-guest-summary',`${seats} kursi`);setTextSafe('#cw-vendor-count',String(p.vendors.length));setTextSafe('#cw-vendor-summary',`${p.vendors.length} vendor`);setTextSafe('#cw-checklist-count',`${done}/${p.checklist.length}`);setTextSafe('#cw-checklist-summary',`${done} selesai`);setTextSafe('#cw-saved-total',cwMoney(saved));setTextSafe('#cw-savings-amount',cwMoney(saved));const savingsDeadline=p.savings.deadline?new Date(`${p.savings.deadline}T00:00:00`):null,savingsMonths=savingsDeadline&&!Number.isNaN(savingsDeadline.getTime())?Math.max(1,Math.ceil((savingsDeadline.getTime()-Date.now())/(30.44*dayMs))):0,savingsGap=Math.max(0,target-saved),monthlyNeed=savingsMonths?Math.ceil(savingsGap/savingsMonths):0;setTextSafe('#cw-savings-copy',target?`${savingsPct}% dari target ${cwMoney(target)} · ${p.savings.deposits.length} setoran.${monthlyNeed?` Perlu sekitar ${cwMoney(monthlyNeed)}/bulan.`:''}`:'Atur target lalu catat setiap setoran dari akun masing-masing.');const masterInput=$('#cw-master-budget');if(masterInput&&document.activeElement!==masterInput){const masterValue=planned?new Intl.NumberFormat('id-ID').format(planned):'';if(masterInput.value!==masterValue)masterInput.value=masterValue}const targetInput=$('#cw-savings-target');if(targetInput&&targetInput.value!==String(target||''))targetInput.value=target||'';const deadlineInput=$('#cw-savings-deadline');if(deadlineInput&&deadlineInput.value!==(p.savings.deadline||''))deadlineInput.value=p.savings.deadline||'';setTextSafe('#cw-overall-progress',`${overall}%`);setTextSafe('#cw-check-progress-value',`${checkPct}%`);setTextSafe('#cw-budget-progress-value',`${budgetPct}%`);setTextSafe('#cw-guest-progress-value',`${guestPct}%`);setTextSafe('#cw-vendor-progress-value',`${vendorPct}%`);setTextSafe('#cw-seserahan-progress-value-overview',`${seserahanPct}%`);setTextSafe('#cw-savings-progress-value',`${savingsPct}%`);setTextSafe('#cw-savings-progress-value-overview',`${savingsPct}%`);const checkBar=$('#cw-check-progress-bar'),budgetBar=$('#cw-budget-progress-bar'),guestBar=$('#cw-guest-progress-bar'),vendorBar=$('#cw-vendor-progress-bar'),seserahanBar=$('#cw-seserahan-progress-bar-overview'),savingsBar=$('#cw-savings-progress-bar'),savingsOverviewBar=$('#cw-savings-progress-bar-overview');if(checkBar)checkBar.style.width=`${checkPct}%`;if(budgetBar)budgetBar.style.width=`${budgetPct}%`;if(guestBar)guestBar.style.width=`${guestPct}%`;if(vendorBar)vendorBar.style.width=`${vendorPct}%`;if(seserahanBar)seserahanBar.style.width=`${seserahanPct}%`;if(savingsBar)savingsBar.style.width=`${savingsPct}%`;if(savingsOverviewBar)savingsOverviewBar.style.width=`${savingsPct}%`;setTextSafe('#cw-progress-copy',overall>=80?'Keren, tinggal rapikan detail terakhir dan jaga komunikasi berdua.':overall>=40?'Fondasinya sudah mulai terbentuk. Lanjutkan satu bagian kecil hari ini.':'Isi data sedikit demi sedikit. Perubahannya ikut terlihat di perangkat pasangan.');const todayKey=new Date().toISOString().slice(0,10),overdueTasks=p.checklist.filter(row=>!row.done&&row.dueDate&&row.dueDate<todayKey),dueVendors=p.vendors.filter(row=>Number(row.paid)<Number(row.planned)&&row.dueDate&&row.dueDate<=new Date(Date.now()+7*dayMs).toISOString().slice(0,10)),pendingSeats=p.guests.filter(row=>!['Hadir','Terkonfirmasi','Konfirmasi','Tidak hadir'].includes(row.status)).reduce((sum,row)=>sum+Math.max(1,Number(row.seats)||1),0),risks=[];if(remaining<0)risks.push({tone:'danger',icon:'wallet',title:'Budget terlampaui',copy:`Lebih ${cwMoney(Math.abs(remaining))} dari batas utama.`});if(overdueTasks.length)risks.push({tone:'danger',icon:'list-check',title:`${overdueTasks.length} tugas terlambat`,copy:overdueTasks[0].title});if(dueVendors.length)risks.push({tone:'warn',icon:'store',title:`${dueVendors.length} pembayaran dekat`,copy:`Mulai dari ${dueVendors[0].name||'vendor'}.`});if(pendingSeats)risks.push({tone:'warn',icon:'users',title:`${pendingSeats} kursi belum pasti`,copy:'Tindak lanjuti RSVP yang belum menjawab.'});if(planned>0&&budgetAllocated<planned)risks.push({tone:'warn',icon:'chart-pie',title:'Budget belum dialokasikan',copy:`Masih ${cwMoney(planned-budgetAllocated)} belum dibagi ke item.`});if(target>saved&&monthlyNeed)risks.push({tone:'warn',icon:'piggy-bank',title:'Target tabungan',copy:`Perlu sekitar ${cwMoney(monthlyNeed)} per bulan.`});if(!risks.length&&cwHasData(p))risks.push({tone:'ok',icon:'check',title:'Tidak ada risiko mendesak',copy:'Lanjutkan ritme dan perbarui data secara berkala.'});const riskRoot=$('#cw-risk-list');setTextSafe('#cw-risk-summary',risks.length?`${risks.filter(row=>row.tone!=='ok').length} perhatian`:'Belum ada risiko');if(riskRoot)riskRoot.innerHTML=risks.length?risks.slice(0,3).map(row=>`<div class="cw-risk-item is-${row.tone}"><i data-fa="${row.icon}"></i><div><b>${escapeHtml(row.title)}</b><small>${escapeHtml(row.copy)}</small></div></div>`).join(''):'<p class="cw-empty">Isi data wedding agar prioritas muncul otomatis.</p>';
  const categoryTotals={};p.budgetItems.forEach(row=>{const key=row.category||'Lainnya';categoryTotals[key]=(categoryTotals[key]||0)+Math.max(0,Number(row.actual)||0)});p.seserahan.forEach(row=>{const key=row.category||'Seserahan';categoryTotals[key]=(categoryTotals[key]||0)+Math.max(0,Number(row.actual)||0)});const catEntries=Object.entries(categoryTotals).sort((a,b)=>b[1]-a[1]);setTextSafe('#cw-category-total',cwMoney(actual));const categoryRoot=$('#cw-category-breakdown');if(categoryRoot)categoryRoot.innerHTML=catEntries.length?catEntries.slice(0,6).map(([name,value])=>`<div class="cw-category-row"><span>${escapeHtml(name)}</span><div class="cw-category-track"><i style="width:${actual?Math.round(value/actual*100):0}%"></i></div><strong>${cwMoney(value)}</strong></div>`).join(''):'<p class="cw-empty">Isi realisasi untuk melihat pembagiannya.</p>';const alert=$('#cw-budget-alert');if(alert){const over=planned>0&&actual>planned;alert.classList.toggle('hidden',!over);setTextSafe('#cw-budget-alert-title',over?'Anggaran terlampaui':'Anggaran masih aman');setTextSafe('#cw-budget-alert-copy',over?`Realisasi lebih ${cwMoney(actual-planned)} dari total rencana.`:planned?`Sisa ${cwMoney(Math.max(0,planned-actual))}.`:'Masukkan total rencana agar Matus bisa mengingatkan.')}const weekAgo=Date.now()-7*24*60*60*1000,weeklyCount=p.activityLog.filter(row=>{const time=Date.parse(row.createdAt||'');return Number.isFinite(time)&&time>=weekAgo}).length;setTextSafe('#cw-weekly-title',weeklyCount?`${weeklyCount} perubahan minggu ini`:'Belum ada aktivitas minggu ini');setTextSafe('#cw-weekly-copy',`${p.budgetItems.length+p.seserahan.length} item biaya · ${done} tugas selesai · ${p.guests.length} tamu tercatat.`);const activityRoot=$('#cw-activity-list');if(activityRoot)activityRoot.innerHTML=p.activityLog.length?p.activityLog.slice(0,6).map(row=>`<li><b>${escapeHtml(row.actorName||'Pasangan')} · ${escapeHtml(row.action||'Aktivitas')}</b><span>${escapeHtml(row.detail||'Perubahan tersimpan')}</span><time>${escapeHtml(String(row.createdAt||'').slice(0,16).replace('T',' '))}</time></li>`).join(''):'<li class="cw-empty">Aktivitas pasangan akan muncul setelah kalian mulai mengisi.</li>';const next=p.checklist.find(row=>!row.done);setTextSafe('#cw-next-title',next?`Berikutnya: ${next.title}`:planned?'Semua rapi, tinggal jaga ritmenya':'Mulai dari budget kalian');setTextSafe('#cw-next-copy',next?`${next.owner} pegang bagian ini. Tandai selesai setelah beres supaya pasangan ikut tahu.`:planned?'Kalian sudah punya fondasi. Lanjutkan dengan tamu, vendor, dan tabungan.':'Masukkan angka pertama, nanti Matus bantu melihat bagian yang paling perlu dibereskan.');
  const timeline={date:!!p.weddingDate,budget:planned>0,vendor:p.vendors.length>0,guests:p.guests.length>0,seserahan:p.seserahan.length>0,checklist:done>0,savings:target>0&&saved>0};const nextStep=Object.entries(timeline).find(([,value])=>!value)?.[0]||'savings';$$('[data-cw-timeline]').forEach(item=>{const key=item.dataset.cwTimeline,doneState=timeline[key],current=key===nextStep;item.classList.toggle('done',doneState);item.classList.toggle('current',current&&!doneState)});setTextSafe('#cw-timeline-status',timeline[nextStep]? 'Hampir selesai':'Berikutnya: '+({date:'tentukan tanggal',budget:'susun budget',vendor:'pilih vendor',guests:'daftar tamu',seserahan:'siapkan seserahan',checklist:'administrasi',savings:'tabungan'}[nextStep]||'lanjutkan'));const dueSoon=p.checklist.find(row=>!row.done&&row.dueDate);setTextSafe('#cw-matus-insight-title',remaining<0?'Gua saranin: rem budget dulu':dueSoon?`Gua ingetin: ${dueSoon.title}`:next?`Gua saranin: ${next.title}`:overall?'Ritmenya sudah mulai kebentuk':'Mulai dari satu angka');setTextSafe('#cw-matus-insight-copy',remaining<0?`Realisasi sudah lewat ${cwMoney(Math.abs(remaining))}. Tahan dulu belanja yang belum wajib.`:dueSoon?`${dueSoon.owner||'Pasangan'} pegang bagian ini. ${cwDueLabel(dueSoon)}.`:next?`${next.owner} pegang bagian ini. Kalau sudah beres, tandai supaya progress kalian ikut naik.`:'Isi data sedikit demi sedikit. Gua bantu baca bagian yang paling perlu dibereskan.');
  const budget=$('#cw-budget-list');if(budget)budget.innerHTML=p.budgetItems.length?p.budgetItems.map(row=>`<article class="cw-row"><div><b>${escapeHtml(row.category)} · ${escapeHtml(row.item)}</b><small>${escapeHtml(row.status||'Proses')} · rencana ${cwMoney(row.planned)} · realisasi ${cwMoney(row.actual)}${row.dueDate?` · ${escapeHtml(cwDueLabel(row))}`:''}</small></div><strong>${cwBalanceLabel(row.planned,row.actual)}</strong><button aria-label="Edit budget" data-cw-edit-budget="${escapeHtml(row.id)}" type="button"><i data-fa="pen"></i></button><button aria-label="Hapus budget" data-cw-delete-budget="${escapeHtml(row.id)}" type="button"><i data-fa="trash"></i></button></article>`).join(''):'<p class="cw-empty">Belum ada item. Tambahkan satu biaya yang paling kalian tahu dulu.</p>';
  const seserahan=$('#cw-seserahan-list');setTextSafe('#cw-seserahan-summary',`${p.seserahan.length} item`);if(seserahan)seserahan.innerHTML=p.seserahan.length?p.seserahan.map(row=>`<article class="cw-row"><div><b>${escapeHtml(row.category)} · ${escapeHtml(row.item)}</b><small>${escapeHtml(row.brand||'Keterangan belum diisi')} · realisasi ${cwMoney(row.actual)}</small></div><strong>${cwMoney(row.actual)}</strong><button aria-label="Edit seserahan" data-cw-edit-seserahan="${escapeHtml(row.id)}" type="button"><i data-fa="pen"></i></button><button aria-label="Hapus seserahan" data-cw-delete-seserahan="${escapeHtml(row.id)}" type="button"><i data-fa="trash"></i></button></article>`).join(''):'<p class="cw-empty">Belum ada seserahan. Tambahkan kebutuhan kecil yang ingin kalian siapkan bersama.</p>';
  const guests=$('#cw-guest-list');if(guests){const filter=$('#cw-guest-filter')?.value||'all',rows=p.guests.filter(row=>filter==='all'||(row.status||'Belum diundang')===filter);guests.innerHTML=rows.length?rows.map(row=>`<article class="cw-row"><div><b>${escapeHtml(row.name)}</b><small>${escapeHtml(row.side||'Bersama')} · ${escapeHtml(row.relationship||'Hubungan belum diisi')} · ${escapeHtml(row.inviteType||'Digital')} · ${Number(row.seats)||1} kursi${row.contact?` · ${escapeHtml(row.contact)}`:''}${row.rsvpDue?` · RSVP ${escapeHtml(row.rsvpDue)}`:''} · <span class="cw-status-chip">${escapeHtml(row.status||'Belum diundang')}</span></small></div><button aria-label="Edit tamu" data-cw-edit-guest="${escapeHtml(row.id)}" type="button"><i data-fa="pen"></i></button><button aria-label="Hapus tamu" data-cw-delete-guest="${escapeHtml(row.id)}" type="button"><i data-fa="trash"></i></button></article>`).join(''):p.guests.length?'<p class="cw-empty">Tidak ada tamu dengan status ini.</p>':'<p class="cw-empty">Daftar tamu masih kosong. Isi nama pertama, lalu pasangan bisa langsung melihatnya.</p>';}
  const checks=$('#cw-check-list');if(checks){const filter=$('#cw-check-filter')?.value||'all',rows=p.checklist.filter(row=>filter==='all'||(row.status||(row.done?'Selesai':'Belum mulai'))===filter);checks.innerHTML=rows.length?rows.map(row=>{const status=row.status||(row.done?'Selesai':'Belum mulai'),due=cwDueLabel(row);return `<article class="cw-row cw-check-row"><button aria-label="${row.done?'Buka kembali':'Tandai selesai'}" class="cw-check-toggle ${row.done?'done':''}" data-cw-toggle-check="${escapeHtml(row.id)}" type="button"><i data-fa="${row.done?'check':'circle'}"></i></button><div><b class="${row.done?'done':''}">${escapeHtml(row.title)}</b><small>${escapeHtml(row.owner||'Bersama')} · ${escapeHtml(status)}${due?` · ${escapeHtml(due)}`:''}</small></div><button aria-label="Edit checklist" data-cw-edit-check="${escapeHtml(row.id)}" type="button"><i data-fa="pen"></i></button><button aria-label="Hapus checklist" data-cw-delete-check="${escapeHtml(row.id)}" type="button"><i data-fa="trash"></i></button></article>`}).join(''):p.checklist.length?'<p class="cw-empty">Tidak ada tugas dengan status ini.</p>':'<p class="cw-empty">Belum ada checklist. Ambil dari administrasi atau sesuaikan dengan kebutuhan kalian.</p>';}
  const vendors=$('#cw-vendor-list');if(vendors){const filter=$('#cw-vendor-filter')?.value||'all',rows=p.vendors.filter(row=>filter==='all'||(filter==='paid'?Number(row.paid)>=Number(row.planned):Number(row.paid)<Number(row.planned)));vendors.innerHTML=rows.length?rows.map(row=>{const href=cwContactHref(row.contact);return `<article class="cw-row"><div><b>${escapeHtml(row.category)} · ${escapeHtml(row.name)}</b><small>${escapeHtml(row.contact||'Kontak belum diisi')} · ${escapeHtml(row.status||'Riset')} · dibayar ${cwMoney(row.paid)} dari ${cwMoney(row.planned)}${row.dueDate?` · ${escapeHtml(cwDueLabel(row))}`:''}</small></div>${href?`<a class="cw-contact-link" href="${href}" target="_blank" rel="noreferrer" aria-label="Hubungi vendor via WhatsApp"><i data-fa="comments"></i></a>`:''}<button aria-label="Edit vendor" data-cw-edit-vendor="${escapeHtml(row.id)}" type="button"><i data-fa="pen"></i></button><button aria-label="Hapus vendor" data-cw-delete-vendor="${escapeHtml(row.id)}" type="button"><i data-fa="trash"></i></button></article>`}).join(''):p.vendors.length?'<p class="cw-empty">Tidak ada vendor dengan filter ini.</p>':'<p class="cw-empty">Vendor belum dicatat. Simpan nama dan kontaknya supaya tidak tercecer di chat.</p>';}
  const contributor=$('#cw-deposit-by');if(contributor){const options=[{id:state.uid,name:firstName(state.user?.displayName||'Saya')},{id:state.partner?.uid,name:firstName(state.partner?.displayName||state.partner?.name||'Pasangan')}].filter((item,index,list)=>item.id&&!list.slice(0,index).some(prev=>prev.id===item.id));contributor.innerHTML=options.map(item=>`<option value="${escapeHtml(item.id)}">${escapeHtml(item.name)}</option>`).join('')}const depositList=$('#cw-savings-list');setTextSafe('#cw-savings-table-summary',`${p.savings.deposits.length} setoran`);if(depositList)depositList.innerHTML=p.savings.deposits.length?p.savings.deposits.slice().sort((a,b)=>String(b.date||'').localeCompare(String(a.date||''))).map(row=>`<tr><td><b>${escapeHtml(row.byName||'Pasangan')}</b></td><td>${escapeHtml(row.date||'-')}</td><td><strong>${cwMoney(row.amount)}</strong></td><td>${escapeHtml(row.note||'-')}</td><td><button aria-label="Hapus setoran" data-cw-delete-deposit="${escapeHtml(row.id)}" type="button"><i data-fa="trash"></i></button></td></tr>`).join(''):'<tr class="cw-savings-empty-row"><td colspan="5"><i data-fa="piggy-bank"></i><span>Belum ada setoran. Tambahkan setoran pertama.</span></td></tr>';const depositDate=$('#cw-deposit-date');if(depositDate&&!depositDate.value)depositDate.value=new Date().toISOString().slice(0,10);
  hydrateFeatureIcons($('#couple-home-screen')||document);
}
function cwHasData(plan){return!!(plan&&(plan.weddingDate||Number(plan.totalBudget)>0||['budgetItems','seserahan','guests','checklist','vendors','activityLog'].some(key=>Array.isArray(plan[key])&&plan[key].length)||(plan.savings&&(Number(plan.savings.target)>0||Number(plan.savings.saved)>0||plan.savings.deposits?.length))))}
function cwLocalBackupKey(){const ids=[state.uid,state.partner?.uid].filter(Boolean).sort();return ids.length===2?`ac_wedding_pair_${ids.join('_')}`:`ac_wedding_${state.chatId||state.uid}`}
function cwFindLocalBackup(){const rows=[];try{for(let index=0;index<localStorage.length;index++){const key=localStorage.key(index)||'';if(!key.startsWith('ac_wedding_'))continue;try{const value=JSON.parse(localStorage.getItem(key)||'null');if(cwHasData(value))rows.push(value)}catch{}}}catch{}return rows.sort((a,b)=>Date.parse(b.updatedAt||0)-Date.parse(a.updatedAt||0))[0]||null}
function cwApplyShared(data={}){if(data?.weddingPlan&&cwHasData(data.weddingPlan)){weddingPlan=cwMerge(data.weddingPlan);try{localStorage.setItem(cwLocalBackupKey(),JSON.stringify(weddingPlan))}catch{}cwSetSync('Tersinkron ke partner')}else if(!weddingRecoveryAttempted){weddingRecoveryAttempted=true;const backup=cwFindLocalBackup();if(backup){weddingPlan=cwMerge(backup);cwSetSync('Cadangan lokal ditemukan','syncing');setTimeout(()=>{cwSave();notify('Cadangan Wedding Planner dipulihkan dan disinkronkan')},120)}}cwRender()}
function cwLoadDemo(){try{const raw=JSON.parse(localStorage.getItem('ac_demo_wedding')||'null'),legacy=raw&&!raw.updatedAt&&Array.isArray(raw.budgetItems)&&raw.budgetItems.length===5&&raw.budgetItems.every((row,index)=>row.id===`cw-b${index+1}`);weddingPlan=cwMerge(legacy?cwDefaultPlan():(raw||cwDefaultPlan()))}catch{weddingPlan=cwDefaultPlan()}cwSetSync('Demo tersimpan');cwRender()}
async function cwSave(){weddingPlan=cwMerge({...weddingPlan,updatedAt:new Date().toISOString(),updatedBy:state.uid||'user'});try{localStorage.setItem(cwLocalBackupKey(),JSON.stringify(weddingPlan));localStorage.setItem(`ac_wedding_${state.chatId||state.uid}`,JSON.stringify(weddingPlan))}catch{}try{if(state.demo){localStorage.setItem('ac_demo_wedding',JSON.stringify(weddingPlan));cwSetSync('Demo tersimpan');cwRender();return}if(api?.saveSharedWeddingPlan&&state.chatId){cwSetSync('Menyinkronkan…','syncing');await api.saveSharedWeddingPlan(state.chatId,weddingPlan);localStorage.removeItem(`ac_wedding_pending_${state.chatId}`);cwSetSync('Tersinkron ke partner')}else{cwSetSync('Tersimpan lokal','offline')}cwRender()}catch(error){localStorage.setItem(`ac_wedding_pending_${state.chatId||state.uid}`,JSON.stringify(weddingPlan));cwSetSync('Offline · tersimpan lokal','offline');notify('Perubahan disimpan di perangkat dan akan dicoba lagi saat online')}}
async function cwExport(){const button=$('[data-cw-action="export"]');if(button)button.disabled=true;try{const module=await import('./excel-wedding-template-export.js');await module.downloadWeddingPlannerWorkbook({...cwMerge(weddingPlan),couple:{me:state.user?.displayName||'Imam',partner:state.partner?.displayName||state.partner?.name||'Imeh'}});notify('Wedding Planner berhasil disimpan ke Excel')}catch(error){notify(error.message||'Excel belum dapat dibuat')}finally{if(button)button.disabled=false}}
function cwInputValue(id){return $(`#${id}`)?.value.trim()||''}
function cwNumberValue(id){return Number(String($(`#${id}`)?.value||'').replace(/\D/g,''))||0}
function cwFormatCurrencyInput(input){if(!input)return;const digits=String(input.value||'').replace(/\D/g,'');input.value=digits?new Intl.NumberFormat('id-ID').format(Number(digits)):''}
function cwLogActivity(action,detail){weddingPlan=cwMerge(weddingPlan);const actor=firstName(state.user?.displayName||'Saya');weddingPlan.activityLog=[{id:cwId('activity'),action:String(action||'Aktivitas'),detail:String(detail||''),actorName:actor,createdAt:new Date().toISOString()},...weddingPlan.activityLog].slice(0,200)}
function cwContactHref(contact){const digits=String(contact||'').replace(/[^0-9+]/g,'').replace(/^\+/,'');return digits?`https://wa.me/${digits}`:''}
function cwDueLabel(row){if(!row?.dueDate)return'';const date=new Date(`${row.dueDate}T00:00:00`),today=new Date();today.setHours(0,0,0,0);return `${date<today?'Lewat':'Tenggat'} ${row.dueDate}`}
function cwReset(form){form?.reset();const seats=$('#cw-guest-seats');if(seats)seats.value='1'}
function cwFinishEdit(form){form?.removeAttribute('data-edit-id');cwReset(form);const button=form?.querySelector('button[type=submit]');if(button)button.innerHTML='<i data-fa="plus"></i> Tambah';hydrateFeatureIcons(form)}
function cwStartEdit(type,id){weddingPlan=cwMerge(weddingPlan);const list={budget:weddingPlan.budgetItems,seserahan:weddingPlan.seserahan,guest:weddingPlan.guests,check:weddingPlan.checklist,vendor:weddingPlan.vendors}[type],row=list?.find(item=>item.id===id);if(!row)return;const panel={budget:'budget',seserahan:'seserahan',guest:'guests',check:'checklist',vendor:'vendors'}[type],form=$(`#cw-${type==='guest'?'guest':type}-form`);if(!form)return;cwTab(panel);form.dataset.editId=id;const set=(selector,value)=>{const input=$(selector);if(input)input.value=value??''};if(type==='budget'){set('#cw-budget-category',row.category);set('#cw-budget-item',row.item);set('#cw-budget-planned',row.planned);set('#cw-budget-actual',row.actual);set('#cw-budget-due',row.dueDate||'');set('#cw-budget-item-status',row.status||'Proses');cwFormatCurrencyInput($('#cw-budget-planned'));cwFormatCurrencyInput($('#cw-budget-actual'))}if(type==='seserahan'){set('#cw-seserahan-category',row.category);set('#cw-seserahan-item',row.item);set('#cw-seserahan-brand',row.brand);set('#cw-seserahan-actual',row.actual);cwFormatCurrencyInput($('#cw-seserahan-actual'))}if(type==='guest'){set('#cw-guest-name',row.name);set('#cw-guest-contact',row.contact||'');set('#cw-guest-rsvp-due',row.rsvpDue||'');set('#cw-guest-side',row.side||'Bersama');set('#cw-guest-relationship',row.relationship||'');set('#cw-guest-invite-type',row.inviteType||'Digital');set('#cw-guest-seats',row.seats||1);set('#cw-guest-status',row.status||'Belum diundang')}if(type==='check'){set('#cw-check-title',row.title);set('#cw-check-owner',row.owner||'Bersama');set('#cw-check-due',row.dueDate||'');set('#cw-check-status',row.status||(row.done?'Selesai':'Belum mulai'))}if(type==='vendor'){set('#cw-vendor-category',row.category);set('#cw-vendor-name',row.name);set('#cw-vendor-contact',row.contact);set('#cw-vendor-planned',row.planned);set('#cw-vendor-paid',row.paid);set('#cw-vendor-due',row.dueDate||'');set('#cw-vendor-status',row.status||'Riset')}const button=form.querySelector('button[type=submit]');if(button)button.innerHTML='<i data-fa="check"></i> Perbarui';hydrateFeatureIcons(form);form.querySelector('input,select')?.focus()}

function wireWeddingPlanner(){const root=$('#cw-mobile-tabs');if(!root||root.dataset.wired)return;root.dataset.wired='1';['#cw-guest-filter','#cw-check-filter','#cw-vendor-filter'].forEach(selector=>$(selector)?.addEventListener('change',cwRender));$$('[data-currency-input]').forEach(input=>{input.addEventListener('input',()=>cwFormatCurrencyInput(input));input.addEventListener('blur',()=>cwFormatCurrencyInput(input))});$$('[data-cw-tab]').forEach(button=>button.onclick=()=>cwTab(button.dataset.cwTab));$$('[data-cw-tab-jump]').forEach(button=>button.onclick=()=>cwTab(button.dataset.cwTabJump));$('[data-cw-action="export"]')?.addEventListener('click',cwExport);$('[data-cw-action="add-budget"]')?.addEventListener('click',()=>{cwTab('budget');setTimeout(()=>$('#cw-budget-category')?.focus(),40)});$('[data-cw-action="date"]')?.addEventListener('click',()=>$('#cw-wedding-date-input')?.showPicker?.()||$('#cw-wedding-date-input')?.focus());$('#cw-master-budget')?.addEventListener('change',event=>{weddingPlan=cwMerge(weddingPlan);weddingPlan.totalBudget=cwNumberValue('cw-master-budget');cwSave()});$('#cw-wedding-date-input')?.addEventListener('change',event=>{weddingPlan=cwMerge(weddingPlan);weddingPlan.weddingDate=event.target.value;cwSave()});$('#cw-budget-form')?.addEventListener('submit',event=>{event.preventDefault();const form=event.currentTarget;weddingPlan=cwMerge(weddingPlan);const value={category:cwInputValue('cw-budget-category'),item:cwInputValue('cw-budget-item'),planned:cwNumberValue('cw-budget-planned'),actual:cwNumberValue('cw-budget-actual'),dueDate:$('#cw-budget-due').value||'',status:$('#cw-budget-item-status').value},row=weddingPlan.budgetItems.find(item=>item.id===form.dataset.editId);if(row)Object.assign(row,value);else weddingPlan.budgetItems.push({id:cwId('budget'),...value});cwLogActivity('Budget',`${value.category} · ${value.item} · ${cwMoney(value.actual)}`);cwFinishEdit(form);cwSave();cwTab('budget')});$('#cw-seserahan-form')?.addEventListener('submit',event=>{event.preventDefault();const form=event.currentTarget;weddingPlan=cwMerge(weddingPlan);const actual=cwNumberValue('cw-seserahan-actual');const value={category:cwInputValue('cw-seserahan-category'),item:cwInputValue('cw-seserahan-item'),brand:cwInputValue('cw-seserahan-brand'),actual},row=weddingPlan.seserahan.find(item=>item.id===form.dataset.editId);if(row)Object.assign(row,value);else weddingPlan.seserahan.push({id:cwId('seserahan'),...value});cwLogActivity('Seserahan',`${value.item} · ${cwMoney(value.actual)}`);cwFinishEdit(form);cwSave();cwTab('seserahan');setTimeout(()=>$('#cw-seserahan-item')?.focus(),40)});$('#cw-guest-form')?.addEventListener('submit',event=>{event.preventDefault();const form=event.currentTarget;weddingPlan=cwMerge(weddingPlan);const value={name:cwInputValue('cw-guest-name'),contact:cwInputValue('cw-guest-contact'),side:$('#cw-guest-side').value,relationship:cwInputValue('cw-guest-relationship'),inviteType:$('#cw-guest-invite-type').value,seats:Number($('#cw-guest-seats').value)||1,rsvpDue:$('#cw-guest-rsvp-due').value||'',status:$('#cw-guest-status').value},row=weddingPlan.guests.find(item=>item.id===form.dataset.editId);if(row)Object.assign(row,value);else weddingPlan.guests.push({id:cwId('guest'),...value});cwLogActivity('Tamu',`${value.name} · ${value.status}`);cwFinishEdit(form);cwSave();cwTab('guests')});$('#cw-check-form')?.addEventListener('submit',event=>{event.preventDefault();const form=event.currentTarget;weddingPlan=cwMerge(weddingPlan);const status=$('#cw-check-status').value,value={title:cwInputValue('cw-check-title'),owner:$('#cw-check-owner').value,dueDate:$('#cw-check-due').value||'',status,done:status==='Selesai'},row=weddingPlan.checklist.find(item=>item.id===form.dataset.editId);if(row)Object.assign(row,value);else weddingPlan.checklist.push({id:cwId('check'),...value});cwLogActivity('Checklist',`${value.title} · ${status}`);cwFinishEdit(form);cwSave();cwTab('checklist')});$('#cw-vendor-form')?.addEventListener('submit',event=>{event.preventDefault();const form=event.currentTarget;weddingPlan=cwMerge(weddingPlan);const value={category:cwInputValue('cw-vendor-category'),name:cwInputValue('cw-vendor-name'),contact:cwInputValue('cw-vendor-contact'),planned:Number($('#cw-vendor-planned').value)||0,paid:Number($('#cw-vendor-paid').value)||0,dueDate:$('#cw-vendor-due').value||'',status:$('#cw-vendor-status').value||'Riset'},row=weddingPlan.vendors.find(item=>item.id===form.dataset.editId);if(row)Object.assign(row,value);else weddingPlan.vendors.push({id:cwId('vendor'),...value});cwLogActivity('Vendor',`${value.name} · dibayar ${cwMoney(value.paid)}`);cwFinishEdit(form);cwSave();cwTab('vendors')});$('#cw-savings-form')?.addEventListener('submit',event=>{event.preventDefault();weddingPlan=cwMerge(weddingPlan);weddingPlan.savings={...weddingPlan.savings,target:Number($('#cw-savings-target').value)||0,deadline:$('#cw-savings-deadline').value||'',saved:weddingPlan.savings.deposits.length?weddingPlan.savings.saved:Math.max(0,Number(weddingPlan.savings.saved)||0)};cwSave();cwTab('savings')});$('#cw-deposit-form')?.addEventListener('submit',event=>{event.preventDefault();weddingPlan=cwMerge(weddingPlan);const contributor=$('#cw-deposit-by'),name=contributor?.selectedOptions?.[0]?.textContent||'Pasangan';const amount=Number($('#cw-deposit-amount').value)||0;weddingPlan.savings.deposits.push({id:cwId('deposit'),byId:contributor?.value||state.uid,byName:name,amount,date:$('#cw-deposit-date').value||new Date().toISOString().slice(0,10),note:cwInputValue('cw-deposit-note')});cwLogActivity('Tabungan',`${name} · ${cwMoney(amount)}`);event.currentTarget.reset();const dateInput=$('#cw-deposit-date');if(dateInput)dateInput.value=new Date().toISOString().slice(0,10);cwSave();cwTab('savings')});$('#cw-budget-list')?.addEventListener('click',event=>{const edit=event.target.closest('[data-cw-edit-budget]')?.dataset.cwEditBudget;if(edit)return cwStartEdit('budget',edit);const id=event.target.closest('[data-cw-delete-budget]')?.dataset.cwDeleteBudget;if(id){weddingPlan.budgetItems=weddingPlan.budgetItems.filter(row=>row.id!==id);cwSave()}});$('#cw-seserahan-list')?.addEventListener('click',event=>{const edit=event.target.closest('[data-cw-edit-seserahan]')?.dataset.cwEditSeserahan;if(edit)return cwStartEdit('seserahan',edit);const id=event.target.closest('[data-cw-delete-seserahan]')?.dataset.cwDeleteSeserahan;if(id){weddingPlan.seserahan=weddingPlan.seserahan.filter(row=>row.id!==id);cwSave()}});$('#cw-guest-list')?.addEventListener('click',event=>{const edit=event.target.closest('[data-cw-edit-guest]')?.dataset.cwEditGuest;if(edit)return cwStartEdit('guest',edit);const id=event.target.closest('[data-cw-delete-guest]')?.dataset.cwDeleteGuest;if(id){weddingPlan.guests=weddingPlan.guests.filter(row=>row.id!==id);cwSave()}});$('#cw-check-list')?.addEventListener('click',event=>{const edit=event.target.closest('[data-cw-edit-check]')?.dataset.cwEditCheck;if(edit)return cwStartEdit('check',edit);const toggle=event.target.closest('[data-cw-toggle-check]')?.dataset.cwToggleCheck,remove=event.target.closest('[data-cw-delete-check]')?.dataset.cwDeleteCheck;if(toggle){const row=weddingPlan.checklist.find(item=>item.id===toggle);if(row){row.done=!row.done;row.status=row.done?'Selesai':'Belum mulai';cwLogActivity('Checklist',`${row.title} · ${row.status}`)}cwSave()}if(remove){weddingPlan.checklist=weddingPlan.checklist.filter(row=>row.id!==remove);cwSave()}});$('#cw-vendor-list')?.addEventListener('click',event=>{const edit=event.target.closest('[data-cw-edit-vendor]')?.dataset.cwEditVendor;if(edit)return cwStartEdit('vendor',edit);const id=event.target.closest('[data-cw-delete-vendor]')?.dataset.cwDeleteVendor;if(id){weddingPlan.vendors=weddingPlan.vendors.filter(row=>row.id!==id);cwSave()}});$('#cw-savings-list')?.addEventListener('click',event=>{const id=event.target.closest('[data-cw-delete-deposit]')?.dataset.cwDeleteDeposit;if(id){weddingPlan.savings.deposits=weddingPlan.savings.deposits.filter(row=>row.id!==id);cwSave()}});window.addEventListener('online',()=>{if(weddingPlan){cwSetSync('Menyinkronkan…','syncing');cwSave()}});window.addEventListener('offline',()=>cwSetSync('Offline · tersimpan lokal','offline'));weddingPlan=cwMerge(weddingPlan||cwDefaultPlan());cwTab('overview');cwRender()}
