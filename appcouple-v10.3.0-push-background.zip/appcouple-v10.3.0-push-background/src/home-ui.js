import { hydrateIcons } from './icons.js';

const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];

let notify = () => {};
let navigateTo = () => {};
let currentUser = { displayName: 'Kamu' };
let financeState = null;
let coupleState = null;
let financeActivity = [];
let coupleActivity = [];
let homeDaily = { missions: {}, partnerMissions: {}, day: '' };
let homeMatusMessageIndex = -1;
let homeMatusTimer = 0;
let homeMemoryTimer = 0;
let homeMemoryIndex = 0;
const HOME_MEMORY_DEFAULTS = [
  { photoUrl: '/assets/drive-gallery/memory-sunset.webp', title: 'Senja bersama' },
  { photoUrl: '/assets/drive-gallery/memory-coffee.webp', title: 'Ngopi bersama' },
  { photoUrl: '/assets/drive-gallery/memory-mountain.webp', title: 'Pagi di pegunungan' },
  { photoUrl: '/assets/drive-gallery/memory-picnic.webp', title: 'Piknik kecil' },
  { photoUrl: '/assets/drive-gallery/memory-rain.webp', title: 'Cerita di bawah hujan' },
  { photoUrl: '/assets/drive-gallery/memory-city.webp', title: 'Jalan-jalan berdua' },
];

const SEARCH_ITEMS = [
  { label: 'Beranda', description: 'Ringkasan hari ini', view: 'home', icon: 'house' },
  { label: 'Keuangan', description: 'Transaksi, anggaran, dan laporan', view: 'finance', icon: 'table-list' },
  { label: 'Couple Space', description: 'Anniversary dan fitur berdua', view: 'couple', icon: 'heart-o' },
  { label: 'Peta Cinta', description: 'Lokasi dan album perjalanan', view: 'couple', feature: 'map', icon: 'map' },
  { label: 'Kenangan Kita', description: 'Cerita cinta yang tersimpan rapi di Google Drive', view: 'memories', icon: 'image' },
  { label: 'Matus Assistant', description: 'Asisten pribadi dan insight AI', view: 'ai', icon: 'sparkles' },
  { label: 'Chat pasangan', description: 'Buka obrolan realtime', view: 'couple', feature: 'chat', icon: 'comments' },
  { label: 'Game pasangan', description: 'Main dan sinkronkan hasil', view: 'couple', feature: 'game', icon: 'gamepad' },
  { label: 'Tabungan bersama', description: 'Target dan setoran berdua', view: 'couple', feature: 'savings', icon: 'piggy-bank' },
  { label: 'Hadiah', description: 'Love Points dan penukaran', view: 'couple', feature: 'rewards', icon: 'gift' },
  { label: 'Sydas Sector', description: 'Video sejarah, geopolitik, dan misteri', view: 'couple', feature: 'sydas', icon: 'play' },
];

const DEFAULT_NOTIFICATIONS = [
  { icon: 'sparkles', title: 'Beranda baru siap', body: 'Ringkasan keuangan dan Couple Space kini berada dalam satu tampilan.', unread: true },
  { icon: 'shield', title: 'Privasi tetap terkendali', body: 'Lokasi dan data AI hanya digunakan sesuai izinmu.', unread: true },
  { icon: 'heart-o', title: 'Couple Space aktif', body: 'Buka ruang bersama untuk melihat aktivitas terbaru.', unread: false },
];

export function initHome({ user = {}, toast = () => {}, navigate = () => {} } = {}) {
  currentUser = user;
  notify = toast;
  navigateTo = navigate;
  const root = $('#view-home');
  if (!root) return;

  updateWelcome();
  wireHome(root);
  financeState = window.__appCoupleFinanceSummary || financeState;
  coupleState = window.__appCoupleCoupleSummary || coupleState;
  renderFinance(financeState || emptyFinance());
  renderCouple(coupleState || pendingCouple());
  renderSearch('');
  renderNotifications();
  renderHomeMemoryGrid(window.__appCoupleMapMemories || []);
  hydrateIcons(document);
}

function wireHome(root) {
  if (root.dataset.homeWired) return;
  root.dataset.homeWired = '1';

  window.addEventListener('appcouple:finance-update', (event) => {
    financeState = event.detail || emptyFinance();
    financeActivity = Array.isArray(financeState.recent) ? financeState.recent : [];
    renderFinance(financeState);
  });
  window.addEventListener('appcouple:couple-update', (event) => {
    coupleState = event.detail || pendingCouple();
    renderCouple(coupleState);
  });
  window.addEventListener('appcouple:daily-points', (event) => {
    homeDaily = { ...homeDaily, ...(event.detail || {}) };
    renderCouple(coupleState || pendingCouple());
  });
  window.addEventListener('appcouple:notification-added', renderNotifications);
  window.addEventListener('appcouple:activity-update', (event) => {
    coupleActivity = Array.isArray(event.detail) ? event.detail : [];
    renderActivityFeed();
  });
  window.addEventListener('appcouple:memories-data', event => renderHomeMemoryGrid(event.detail || []));
  window.addEventListener('appcouple:memory-created', event => renderHomeMemoryGrid([event.detail, ...(window.__appCoupleMapMemories || [])]));

  root.addEventListener('click', (event) => {
    const memoryFrame = event.target.closest('[data-home-memory-open]');
    if (memoryFrame) { navigateTo('memories'); return; }
    const matusReroll = event.target.closest('[data-home-matus-reroll]');
    if (matusReroll) { renderHomeMatus(coupleState || pendingCouple(), true); notify('Matus bikin pesan baru buat lu'); return; }
    const viewButton = event.target.closest('[data-home-view]');
    if (viewButton) {
      openDestination({ view: viewButton.dataset.homeView, feature: viewButton.dataset.homeFeature });
      return;
    }
    const refresh = event.target.closest('#home-refresh');
    if (refresh) refreshHome(refresh);
  });

  wireTopbar();
}

function renderHomeMemoryGrid(rows = []) {
  const grid = $('#home-memory-grid');
  if (!grid) return;
  const valid = (Array.isArray(rows) ? rows : []).filter(item => item && item.photoUrl);
  const memories = valid.length ? valid.slice(0, 10) : HOME_MEMORY_DEFAULTS;
  const frames = $$('[data-home-memory-open]', grid);
  const paint = () => frames.forEach((frame, slot) => {
    const item = memories[(homeMemoryIndex + slot) % memories.length];
    const image = frame.querySelector('img');
    if (!image || !item) return;
    const source = String(item.photoUrl || '');
    if (image.getAttribute('src') === source) return;
    frame.classList.add('is-changing');
    window.setTimeout(() => {
      image.src = source;
      image.alt = item.title ? `Kenangan: ${item.title}` : 'Kenangan bersama';
      frame.classList.remove('is-changing');
    }, 180);
  });
  homeMemoryIndex = 0;
  paint();
  clearInterval(homeMemoryTimer);
  if (memories.length > 1) homeMemoryTimer = window.setInterval(() => { homeMemoryIndex = (homeMemoryIndex + 1) % memories.length; paint(); }, 3600);
}

function updateWelcome() {
  const name = firstName(currentUser.displayName || currentUser.name || 'Kamu');
  const hour = new Date().getHours();
  const greeting = hour < 11 ? 'Selamat pagi' : hour < 15 ? 'Selamat siang' : hour < 19 ? 'Selamat sore' : 'Selamat malam';
  setText('#home-greeting', `${greeting}, ${name}`);
  setText('#home-period-label', new Intl.DateTimeFormat('id-ID', { month: 'long', year: 'numeric' }).format(new Date()));
}

function wireTopbar() {
  const searchButton = $('#topbar-search-btn');
  const notificationButton = $('#topbar-notif-btn');
  const searchPanel = $('#topbar-search-panel');
  const notificationPanel = $('#topbar-notif-panel');
  const input = $('#topbar-search-input');
  if (!searchButton || searchButton.dataset.homeWired) return;
  searchButton.dataset.homeWired = '1';

  const closePanels = () => {
    searchPanel?.classList.add('hidden');
    notificationPanel?.classList.add('hidden');
    searchButton.setAttribute('aria-expanded', 'false');
    notificationButton?.setAttribute('aria-expanded', 'false');
  };

  searchButton.addEventListener('click', (event) => {
    event.stopPropagation();
    const opening = searchPanel.classList.contains('hidden');
    closePanels();
    if (opening) {
      searchPanel.classList.remove('hidden');
      searchButton.setAttribute('aria-expanded', 'true');
      setTimeout(() => input?.focus(), 0);
    }
  });

  notificationButton?.addEventListener('click', (event) => {
    event.stopPropagation();
    const opening = notificationPanel.classList.contains('hidden');
    closePanels();
    if (opening) {
      notificationPanel.classList.remove('hidden');
      notificationButton.setAttribute('aria-expanded', 'true');
    }
  });

  input?.addEventListener('input', () => renderSearch(input.value));
  $('#topbar-search-results')?.addEventListener('click', (event) => {
    const button = event.target.closest('[data-search-item]');
    if (!button) return;
    const item = SEARCH_ITEMS[Number(button.dataset.searchItem)];
    if (item) openDestination(item);
    closePanels();
  });
  $('#topbar-notif-list')?.addEventListener('click',event=>{const button=event.target.closest('[data-notif-delete]');if(!button)return;try{const items=JSON.parse(localStorage.getItem('ac_smart_notifications_v1')||'[]').filter(item=>item.id!==button.dataset.notifDelete);localStorage.setItem('ac_smart_notifications_v1',JSON.stringify(items));renderNotifications()}catch{}});
  $('#topbar-notif-clear')?.addEventListener('click', () => {
    localStorage.setItem('ac_home_notifications_read', '1');
    localStorage.setItem('ac_smart_notifications_v1','[]')
    renderNotifications();
    notify('Semua notifikasi dihapus');
  });

  document.addEventListener('click', (event) => {
    if (!event.target.closest('.top-actions')) closePanels();
  });
  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape') {const wasOpen=!searchPanel.classList.contains('hidden');closePanels();if(wasOpen)searchButton.focus()}
    if ((event.ctrlKey||event.metaKey)&&event.key.toLowerCase()==='k'&&!document.querySelector('dialog[open]')&&!document.documentElement.classList.contains('map-view-open')){event.preventDefault();if(searchPanel.classList.contains('hidden'))searchButton.click();else input?.focus()}
  });
}

function renderSearch(query = '') {
  const box = $('#topbar-search-results');
  if (!box) return;
  const term = String(query).trim().toLowerCase();
  const matches = SEARCH_ITEMS.map((item, index) => ({ item, index })).filter(({ item }) => {
    const haystack = `${item.label} ${item.description}`.toLowerCase();
    return !term || haystack.includes(term);
  }).slice(0, 7);
  box.innerHTML = matches.length
    ? matches.map(({ item, index }) => `<button type="button" data-search-item="${index}"><i data-fa="${item.icon}"></i><span><b>${escapeHtml(item.label)}</b><small>${escapeHtml(item.description)}</small></span></button>`).join('')
    : '<div class="ts-empty">Tidak ada fitur yang cocok.</div>';
  hydrateIcons(box);
}

function renderNotifications() {
  const box=$('#topbar-notif-list'),button=$('#topbar-notif-btn');if(!box||!button)return;
  const allRead=localStorage.getItem('ac_home_notifications_read')==='1';let smart=[];try{smart=JSON.parse(localStorage.getItem('ac_smart_notifications_v1')||'[]')||[]}catch{}
  const icons={chat:'comments',finance:'chart-line',plans:'calendar',savings:'piggy-bank',matus:'sparkles',daily:'bell',income:'money-bill-wave'};
  const dynamic=smart.map(item=>({id:item.id,icon:icons[item.pref]||'bell',title:item.title,body:item.body,unread:!allRead&&!item.read}));
  const items=[...dynamic,...(dynamic.length?[]:DEFAULT_NOTIFICATIONS.map(item=>({...item,unread:allRead?false:item.unread})))];
  box.innerHTML=items.length?items.map(item=>`<article class="${item.unread?'unread':''}"><span><i data-fa="${item.icon}"></i></span><div><b>${escapeHtml(item.title)}</b><small>${escapeHtml(item.body)}</small></div>${item.id?`<button type="button" class="tn-delete" data-notif-delete="${escapeHtml(item.id)}" aria-label="Hapus notifikasi">×</button>`:''}</article>`).join(''):'<div class="ts-empty">Belum ada notifikasi.</div>';
  button.classList.toggle('has-unread',items.some(item=>item.unread));hydrateIcons(box);
}

function openDestination(item = {}) {
  const view = item.view || 'home';
  navigateTo(view);
  if (!item.feature) return;
  window.setTimeout(() => {
    const appTab = $('[data-couple-tab="apps"]');
    appTab?.click();
    $('[data-couple-feature="' + CSS.escape(item.feature) + '"]')?.click();
  }, 140);
}

function refreshHome(button) {
  button.classList.add('is-loading');
  window.setTimeout(() => button.classList.remove('is-loading'), 650);
  updateWelcome();
  renderFinance(window.__appCoupleFinanceSummary || financeState || emptyFinance());
  renderCouple(window.__appCoupleCoupleSummary || coupleState || pendingCouple());
  notify('Ringkasan diperbarui');
}

function renderFinance(summary = emptyFinance()) {
  financeState = summary;
  const income = number(summary.income);
  const expense = number(summary.expense);
  const balance = number(summary.balance);
  const budget = number(summary.budget);
  const budgetPct = Math.max(0, Math.min(100, number(summary.budgetPct)));
  const savingRate = Math.max(0, number(summary.savingRate));

  setText('#home-balance', moneyBalance(balance));
  setText('#home-income', money(income));
  setText('#home-expense', money(expense));
  setText('#home-saving-rate', `${Math.round(savingRate)}%`);
  setText('#home-budget-label', budget ? `${money(expense)} dari ${money(budget)}` : 'Atur anggaran bulanan');
  setText('#home-budget-percent', budget ? `${Math.round(budgetPct)}%` : '—');

  const progress = $('#home-budget-progress');
  if (progress) {
    progress.style.width = `${budgetPct}%`;
    progress.classList.toggle('warning', budgetPct >= 70 && budgetPct < 90);
    progress.classList.toggle('danger', budgetPct >= 90);
  }
  renderHomeCashFlow(summary);
  financeActivity = Array.isArray(summary.recent) ? summary.recent : financeActivity;
  renderActivityFeed();
  renderInsight({ income, expense, balance, budget, budgetPct, savingRate });
  hydrateIcons($('#view-home'));
}


function renderHomeCashFlow(summary = {}) {
  const income = number(summary.income), expense = number(summary.expense), net = income - expense;
  const incomeCount = number(summary.incomeCount), expenseCount = number(summary.expenseCount);
  setText('#home-cf-income', money(income));
  setText('#home-cf-expense', money(expense));
  setText('#home-cf-net', moneyBalance(net));
  setText('#home-cf-income-count', `${incomeCount} transaksi`);
  setText('#home-cf-expense-count', `${expenseCount} transaksi`);
  setText('#home-cf-net-status', net > 0 ? 'Surplus bulan ini' : net < 0 ? 'Defisit bulan ini' : 'Arus kas seimbang');
  const chart = $('#home-cf-chart');
  if (!chart) return;
  const trend = Array.isArray(summary.trend) ? summary.trend.slice(-6) : [];
  const rows = trend.length ? trend : [{ label: '—', income: 0, expense: 0 }];
  const max = Math.max(1, ...rows.flatMap(item => [number(item.income), number(item.expense)]));
  chart.innerHTML = rows.map(item => `<div class="home-cf-month"><div class="home-cf-bars"><i style="height:${Math.max(3, number(item.income) / max * 78)}px" title="Masuk ${money(item.income)}"></i><i style="height:${Math.max(3, number(item.expense) / max * 78)}px" title="Keluar ${money(item.expense)}"></i></div><small>${escapeHtml(item.label || '—')}</small></div>`).join('');
}

function renderCategories(categories) {
  const box = $('#home-category-list');
  if (!box) return;
  const rows = Array.isArray(categories) ? categories.slice(0, 4) : [];
  const max = Math.max(1, ...rows.map((item) => number(item.amount)));
  box.innerHTML = rows.length
    ? rows.map((item, index) => `<div class="home-category-row"><span class="home-category-dot c${index + 1}"></span><div><b>${escapeHtml(item.name || 'Lainnya')}</b><i><span style="width:${Math.max(6, number(item.amount) / max * 100)}%"></span></i></div><strong>${compactMoney(item.amount)}</strong></div>`).join('')
    : '<div class="home-empty"><i data-fa="wallet"></i><span>Belum ada pengeluaran bulan ini.</span></div>';
}

function renderInsight() {
  const connected = Boolean(coupleState?.connected);
  const online = Boolean(coupleState?.online);
  const hour = new Date().getHours();
  let title = connected ? 'Lakukan satu hal kecil untuk kalian.' : 'Mulai ruang bersama kalian.';
  let detail = connected ? 'Kirim kabar, simpan momen, atau susun rencana sederhana bersama Matus.' : 'Hubungkan akun pasangan agar chat, kenangan, rencana, dan aktivitas dapat tersinkron.';
  let status = connected ? 'Ide untuk berdua' : 'Siap membantu';
  if (connected && online) { title = 'Pasangan sedang online.'; detail = 'Ini waktu yang pas untuk bertemu di Our Little World dan mengirim pelukan.'; status = 'Online sekarang'; }
  else if (connected && hour >= 19) { title = 'Tutup hari dengan kabar kecil.'; detail = 'Tanyakan bagaimana harinya atau simpan satu momen yang ingin kalian ingat.'; status = 'Matus menyarankan'; }
  setText('#home-insight-title', title);
  setText('#home-insight-text', detail);
  setText('#home-insight-status', status);
}

function paintHomeAvatar(element, photoUrl, fallback) {
  if (!element) return;
  const reset = () => {
    element.classList.remove('has-google-photo');
    element.style.removeProperty('--google-photo');
    element.textContent = fallback;
  };
  let url = '';
  try {
    const parsed = new URL(String(photoUrl || ''), location.href);
    if (parsed.protocol === 'https:') url = parsed.href;
  } catch {}
  if (!url) return reset();
  const image = new Image();
  image.referrerPolicy = 'no-referrer';
  image.onload = () => {
    element.textContent = fallback;
    element.classList.add('has-google-photo');
    element.style.setProperty('--google-photo', `url("${url.replace(/"/g, '%22')}")`);
  };
  image.onerror = () => { if (!element.classList.contains('has-google-photo')) reset(); };
  image.src = url;
}

function renderCouple(data = pendingCouple()) {
  coupleState = data;
  const connected = Boolean(data.connected);
  const me = firstName(data.me || currentUser.displayName || 'Kamu');
  const partner = firstName(data.partner || 'Pasangan');
  const dateLabel = new Intl.DateTimeFormat('id-ID',{weekday:'long',day:'numeric',month:'long'}).format(new Date());
  setText('#home-today-date', dateLabel);
  setText('#home-couple-name', connected ? `${me} & ${partner}` : 'Hubungkan dengan pasangan');
  setText('#home-couple-status', connected ? data.online ? 'Online sekarang' : 'Terhubung aman' : 'Belum terhubung');
  setText('#home-today-sync', connected ? (data.online ? 'Kalian sedang berada di ruang yang sama' : 'Data terakhir tersinkron aman') : 'Buat Couple Space privat untuk mulai');
  setText('#home-couple-days', connected && number(data.daysTogether) ? new Intl.NumberFormat('id-ID').format(number(data.daysTogether)) : '—');
  setText('#home-couple-caption', connected ? 'hari bertumbuh bersama' : 'buat Couple Space privat');
  setText('#home-couple-cta', connected ? 'Buka Couple Space' : 'Hubungkan sekarang');
  const meAvatar = $('#home-card-user-avatar');
  const partnerAvatar = $('#home-card-partner-avatar');
  paintHomeAvatar(meAvatar, data.mePhoto || currentUser.photoURL, (me[0] || 'K').toUpperCase());
  paintHomeAvatar(partnerAvatar, connected ? data.partnerPhoto : '', connected ? (partner[0] || 'P').toUpperCase() : '+');
  $('#home-couple-live')?.classList.toggle('is-offline', !connected || !data.online);
  setText('#home-couple-live', connected ? (data.online ? 'Online' : 'Terhubung') : 'Privat');
  renderHomeMatus(data);
  renderTodayProgress(data);
  renderTodayNudge(data);
  hydrateIcons($('#view-home'));
  renderInsight();
}

function homeMatusMessages(data={}){
  const me=firstName(data.me||currentUser.displayName||'Kamu'),partner=firstName(data.partner||'pasangan lu'),connected=Boolean(data.connected),hour=new Date().getHours(),finance=financeState||{},income=number(finance.income),expense=number(finance.expense),ratio=income?expense/income:0,wedding=window.__appCoupleWeddingPlan||{},trip=window.__appCoupleTripPlan||{},pendingWedding=(wedding.checklist||[]).filter(item=>!item.done);
  const messages=[
    {kind:'Semangat hari ini',text:`${me}, lu gak harus beresin semuanya sekaligus. Satu langkah kecil yang bener hari ini udah cukup.`},
    {kind:'Jaga diri',text:'Gua ingetin ya: istirahat bukan berarti lu malas. Kepala yang tenang bikin keputusan lu lebih masuk akal.'},
    {kind:'Saran kecil',text:`Kalau pikiran lagi penuh, bilang jujur ke ${partner}. Gak perlu kalimat sempurna, yang penting dia ngerti kondisi lu.`},
    {kind:'Pengingat',text:'Jangan cuma fokus sama yang belum selesai. Cek lagi hal kecil yang udah lu kerjain hari ini.'},
    {kind:'Semangat hubungan',text:'Hubungan yang sehat gak harus selalu romantis. Saling hadir dan dengerin juga bentuk sayang.'},
    {kind:'Saran Matus',text:'Ambil lima menit tanpa layar. Tarik napas, minum, lalu pilih satu urusan yang paling penting dulu.'},
    {kind:'Pengingat berdua',text:`Hari ini coba tanya ${partner}: “Ada yang bisa gua bantu gak?” Pertanyaan kecil, efeknya bisa besar.`},
    {kind:'Jujur aja',text:'Kalau lu lagi capek, bilang capek. Gua lebih suka lu jujur daripada memaksakan diri terus meledak belakangan.'}
  ];
  if(!connected)messages.unshift({kind:'Mulai dari sini',text:`${me}, hubungkan akun pasangan dulu. Setelah itu gua bisa bantu ngingetin hal yang benar-benar relevan buat kalian.`});
  if(connected&&data.online)messages.unshift({kind:'Pasangan online',text:`${partner} lagi online. Kalau ada yang pengin lu omongin, sekarang waktu yang enak buat mulai.`});
  if(ratio>=.8)messages.unshift({kind:'Pengingat keuangan',text:`Pengeluaran lu sudah sekitar ${Math.round(ratio*100)}% dari pemasukan. Tahan belanja yang gak mendesak dulu, ya.`});
  if(pendingWedding.length)messages.unshift({kind:'Pengingat persiapan',text:`Masih ada ${pendingWedding.length} urusan pernikahan. Fokus dulu ke “${pendingWedding[0].title||'tugas terdekat'}”, jangan semuanya sekaligus.`});
  if(trip.destination&&number(trip.total)>number(trip.budget)&&number(trip.budget)>0)messages.unshift({kind:'Pengingat perjalanan',text:`Rencana ke ${trip.destination} masih lewat budget. Coba cek penginapan atau aktivitas sebelum nambah tabungan.`});
  if(hour>=20)messages.unshift({kind:'Tutup hari',text:`Sebelum tidur, kirim satu kabar jujur ke ${partner}. Gak perlu panjang, yang penting hadir.`});
  return messages;
}
function renderHomeMatus(data={},force=false){
  const messages=homeMatusMessages(data);if(!messages.length)return;let next=homeMatusMessageIndex;if(force||next<0||next>=messages.length){next=Math.floor(Math.random()*messages.length);if(messages.length>1&&next===homeMatusMessageIndex)next=(next+1)%messages.length}homeMatusMessageIndex=next;const item=messages[next];setText('#home-matus-daily-kind',item.kind);setText('#home-matus-daily-message',item.text);setText('#home-matus-daily-context',`Dibuat otomatis · ${new Intl.DateTimeFormat('id-ID',{hour:'2-digit',minute:'2-digit'}).format(new Date())}`);clearInterval(homeMatusTimer);homeMatusTimer=window.setInterval(()=>{if(!document.hidden)renderHomeMatus(coupleState||pendingCouple(),true)},45000);
}
function renderTodayProgress(data={}){
  const missions=homeDaily.missions||{},partnerMissions=homeDaily.partnerMissions||{},keys=['online','expense','chat','savings','location'];
  const done=keys.filter(key=>missions[key]).length,partnerDone=keys.filter(key=>partnerMissions[key]).length;
  const connected=Boolean(data.connected),count=connected?done:0;
  setText('#home-today-progress-count',`${count}/5`);setText('#home-today-progress-copy',connected?`${count}/5 selesai · pasangan ${partnerDone}/5`:'Hubungkan pasangan untuk melihat progress bersama');
  const fill=$('#home-today-progress-fill');if(fill)fill.style.width=`${count/5*100}%`;
  $$('[data-today-task]').forEach(item=>{const key=item.dataset.todayTask;item.classList.toggle('done',!!missions[key]);});
}
function renderTodayNudge(data={}){
  const connected=Boolean(data.connected),done=Object.values(homeDaily.missions||{}).filter(Boolean).length,hour=new Date().getHours();
  let copy=connected?'Satu hal kecil hari ini bisa membuat kalian terasa lebih dekat.':'Hubungkan pasangan untuk mulai berbagi kabar, progress, dan rencana hari ini.';
  if(connected&&data.online)copy='Pasangan sedang online. Ini waktu yang pas untuk kirim kabar atau susun rencana kecil.';
  else if(connected&&done<2)copy='Belum banyak yang tercatat hari ini. Kirim satu kabar kecil dulu, jangan menunggu momen besar.';
  else if(connected&&hour>=19)copy='Tutup hari dengan satu pertanyaan sederhana: “Hari ini kamu paling capek di bagian mana?”';
  setText('#home-today-nudge',copy);
}

function renderActivityFeed() {
  const box = $('#home-activity-list');
  if (!box) return;
  const financeRows = financeActivity.map((item) => ({
    title: item.description || 'Transaksi',
    detail: `${item.category || 'Lainnya'} · ${formatDate(item.date)}`,
    amount: `${item.type === 'income' ? '+' : '−'} ${money(item.amount)}`,
    positive: item.type === 'income',
    icon: item.type === 'income' ? 'arrow-trend-up' : 'arrow-trend-down',
    kind: item.type === 'income' ? 'green' : 'pink',
    time: new Date(item.date || Date.now()).getTime(),
  }));
  const coupleRows = coupleActivity.map((item) => ({
    title: item.title || 'Aktivitas bersama',
    detail: item.detail || formatDate(item.createdAt),
    amount: item.amount ? money(item.amount) : '',
    positive: true,
    icon: activityIcon(item.type),
    kind: 'purple',
    time: new Date(item.createdAt || Date.now()).getTime(),
  }));
  const rows = [...coupleRows, ...financeRows].sort((a, b) => b.time - a.time).slice(0, 5);
  box.innerHTML = rows.length
    ? rows.map((item) => `<div class="home-activity-item"><span class="home-activity-icon ${item.kind}"><i data-fa="${item.icon}"></i></span><div><b>${escapeHtml(item.title)}</b><small>${escapeHtml(item.detail)}</small></div>${item.amount ? `<strong class="${item.positive ? 'positive' : ''}">${escapeHtml(item.amount)}</strong>` : ''}</div>`).join('')
    : '<div class="home-empty"><i data-fa="clock"></i><span>Aktivitas terbaru akan muncul di sini.</span></div>';
  hydrateIcons(box);
}

function activityIcon(type) {
  return ({ savings: 'piggy-bank', reward: 'gift', location: 'location-dot', memory: 'image', finance: 'wallet', ai: 'sparkles', anniversary: 'heart-o' })[type] || 'heart-o';
}

function emptyFinance() {
  return { income: 0, expense: 0, balance: 0, budget: 0, budgetPct: 0, savingRate: 0, categories: [], recent: [] };
}
function pendingCouple() {
  return { connected: false, me: firstName(currentUser.displayName || 'Kamu'), partner: 'Pasangan', daysTogether: 0, online: false };
}
function setText(selector, value) {
  const element = $(selector);
  if (element) element.textContent = value;
}
function firstName(value) {
  return String(value || 'Kamu').trim().split(/\s+/)[0] || 'Kamu';
}
function number(value) {
  return Number(value) || 0;
}
function money(value) {
  return `Rp${new Intl.NumberFormat('id-ID').format(Math.round(number(value)))}`;
}
function moneyBalance(value) {
  const v = Math.round(number(value));
  return `${v < 0 ? '-' : ''}Rp${new Intl.NumberFormat('id-ID').format(Math.abs(v))}`;
}
function compactMoney(value) {
  const amount = number(value);
  if (amount >= 1_000_000_000) return `Rp${(amount / 1_000_000_000).toLocaleString('id-ID', { maximumFractionDigits: 1 })} M`;
  if (amount >= 1_000_000) return `Rp${(amount / 1_000_000).toLocaleString('id-ID', { maximumFractionDigits: 1 })} jt`;
  if (amount >= 1_000) return `Rp${(amount / 1_000).toLocaleString('id-ID', { maximumFractionDigits: 0 })} rb`;
  return money(amount);
}
function formatDate(value) {
  const date = new Date(value || Date.now());
  if (Number.isNaN(date.getTime())) return 'Baru saja';
  return new Intl.DateTimeFormat('id-ID', { day: 'numeric', month: 'short' }).format(date);
}
function escapeHtml(value) {
  const element = document.createElement('div');
  element.textContent = String(value ?? '');
  return element.innerHTML;
}
