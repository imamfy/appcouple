import {todayWIB,validateTransaction,readLocal,writeLocal,mergePending,buildReport,validDate} from './finance-core-v20.js';
import {localAiChat,hasLocalAiConfig,getLocalAiProviderInfo} from './local-ai.js';
import {resolveMatusAnswer,researchStatusText} from './matus-research.js';
import {initMatusCore,getMatusHistory,buildMatusSystemPrompt} from './matus-core.js';
import {initializeTheme,toggleAppTheme} from './theme-system.js';
import {initBackupCenter} from './backup-center.js';
import './accessibility-upgrades.js';
import './icons.js';
import './mobile-content-tabs.js';
initializeTheme();
const $ = (s, root = document) => root.querySelector(s);
const $$ = (s, root = document) => [...root.querySelectorAll(s)];
const state = { user: null, demo: false, view: 'home', backendReady: false };
let matusRequestId=0;
let matusSendLocked=false;
let pendingCoupleFeature=null,pendingCoupleTab=null;
const DEFAULT_VIEWPORT='width=device-width, initial-scale=1, viewport-fit=cover';
const LOCKED_MOBILE_VIEWPORT='width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, user-scalable=no, viewport-fit=cover';
function syncMobileZoomLock(view=state.view){
  const locked=matchMedia('(max-width: 800px)').matches&&(view==='couple'||view==='ai');
  const viewport=document.querySelector('meta[name="viewport"]');
  if(viewport)viewport.setAttribute('content',locked?LOCKED_MOBILE_VIEWPORT:DEFAULT_VIEWPORT);
  document.documentElement.classList.toggle('mobile-zoom-locked',locked);
  return locked;
}
['gesturestart','gesturechange','gestureend'].forEach(type=>document.addEventListener(type,event=>{if(document.documentElement.classList.contains('mobile-zoom-locked'))event.preventDefault()},{passive:false}));
document.addEventListener('touchmove',event=>{if(document.documentElement.classList.contains('mobile-zoom-locked')&&event.touches.length>1)event.preventDefault()},{passive:false});
addEventListener('resize',()=>syncMobileZoomLock());
document.addEventListener('click',event=>{const featureButton=event.target.closest?.('[data-couple-feature]'),tabButton=event.target.closest?.('[data-couple-tab]');if(!featureButton&&!tabButton)return;event.preventDefault();event.stopImmediatePropagation();if(tabButton){const tab=tabButton.dataset.coupleTab;if(typeof window.__appCoupleSwitchTab==='function'){window.__appCoupleSwitchTab(tab);pendingCoupleTab=null}else{pendingCoupleTab=tab;toast('Menyiapkan Couple Space…',1000)}return}const feature=featureButton.dataset.coupleFeature;if(typeof window.__appCoupleOpenFeature==='function'){window.__appCoupleOpenFeature(feature);pendingCoupleFeature=null}else{pendingCoupleFeature=feature;toast('Menyiapkan fitur…',1200)}},true);
window.addEventListener('appcouple:feature-router-ready',()=>{if(pendingCoupleTab&&typeof window.__appCoupleSwitchTab==='function'){const tab=pendingCoupleTab;pendingCoupleTab=null;window.__appCoupleSwitchTab(tab)}if(pendingCoupleFeature&&typeof window.__appCoupleOpenFeature==='function'){const feature=pendingCoupleFeature;pendingCoupleFeature=null;window.__appCoupleOpenFeature(feature)}});
const titles = { home:'Beranda', finance:'Keuangan', couple:'Couple Space', memories:'Kenangan Kita', ai:'Matus Assistant' };

function toast(message,duration=2800){ const el=$('#toast'); el.textContent=message; el.classList.add('show'); clearTimeout(toast.t); toast.t=setTimeout(()=>el.classList.remove('show'),duration); }
function supabaseErrorMessage(err){
  const code=err?.code||'';
  if(code==='auth/unauthorized-domain')return 'Domain Netlify belum diizinkan di Supabase Authentication.';
  if(code==='auth/operation-not-allowed')return 'Login Google belum diaktifkan di Supabase Authentication.';
  if(code==='auth/popup-blocked')return 'Popup Google diblokir browser. Izinkan popup lalu coba lagi.';
  if(code==='auth/network-request-failed')return 'Supabase tidak dapat dijangkau. Periksa adblock, Private DNS, VPN, atau jaringan.';
  if(code==='auth/invalid-api-key'||code==='auth/api-key-not-valid')return 'Supabase publishable key tidak valid atau proyek tidak aktif.';
  return `Supabase gagal${code?` (${code})`:''}: ${err?.message||'lihat Console browser'}`;
}
async function showApp(user={displayName:'Imam'}, demo=false){ await window.AppCoupleLoveLoader?.show?.(); state.user=user; state.demo=demo; const auth=$('#auth-screen'),shell=$('#app-shell'); document.body.classList.add('is-authenticated'); auth.classList.add('hidden'); auth.hidden=true; auth.setAttribute('aria-hidden','true'); shell.hidden=false; shell.setAttribute('aria-hidden','false'); shell.classList.add('is-authenticated'); shell.classList.remove('hidden'); const name=(user.displayName||'Imam').split(' ')[0]; $$('.profile-chip b').forEach(el=>el.textContent=name); $$('.avatar').filter(el=>el.textContent==='I').forEach(el=>el.textContent=name[0].toUpperCase()); if(demo)localStorage.removeItem('ac_session');else localStorage.setItem('ac_session','supabase'); try{const [home,couple,finance,memories,privacy,matus,profiles]=await Promise.all([import('./home-ui.js'),import('./couple-ui.js'),import('./finance-ui.js'),import('./memories-ui.js'),import('./privacy-ui.js'),import('./matus-voice.js'),import('./profile-sync.js')]);home.initHome({user,demo,toast,navigate});await Promise.all([couple.initCouple({demo,user,toast,navigate}),finance.initFinance({demo,user,toast,navigate}),memories.initMemories({isDemo:demo,notify:toast,user}),privacy.initPrivacy({isDemo:demo,toast,user}),matus.initMatusVoice({user,demo,toast,navigate}),profiles.initProfileSync({user,demo})]);updateMatusProvider();syncPendingTransactions();window.dispatchEvent(new CustomEvent('appcouple:authenticated',{detail:{user,demo}}));}catch(err){console.error('Feature init:',err);} finally{await window.AppCoupleLoveLoader?.finish?.();} }
function navigate(view){ state.view=view; syncMobileZoomLock(view); window.dispatchEvent(new CustomEvent('appcouple:view-changed',{detail:{view}})); $$('.view').forEach(v=>v.classList.toggle('active',v.id===`view-${view}`)); $$('[data-view]').forEach(b=>{const on=b.dataset.view===view;b.classList.toggle('active',on);if(on)b.setAttribute('aria-current','page');else b.removeAttribute('aria-current')}); $('#view-title').textContent=titles[view]||'AppCouple'; window.scrollTo({top:0,behavior:'smooth'}); }

async function initSupabase(){
  try {
    const service=await import('./supabase-service.js');
    await service.initialize();
    state.backendReady=true;
    const user=await service.currentUser();
    if(user)showApp(user);
    $('#google-login').onclick=async()=>{
      const button=$('#google-login');if(button.disabled)return;const original=button.innerHTML;button.disabled=true;button.setAttribute('aria-busy','true');button.innerHTML='<span class="google-dot">G</span> Menghubungkan…';
      try{const signed=await service.loginGoogle();if(signed){await showApp(signed);toast('Login berhasil. Selamat datang!')}}
      catch(err){console.error('Supabase login:',err);toast(supabaseErrorMessage(err),7000)}
      finally{button.disabled=false;button.removeAttribute('aria-busy');button.innerHTML=original}
    };
  }catch(err){
    console.error('Supabase SDK initialization:',err);
    $('#google-login').onclick=async()=>{toast('Mencoba memuat ulang layanan Google…',4000);await initSupabase();};
  }
}

function openTransaction(type='expense'){if(type==='transfer')return toast('Transfer internal belum tersedia; jangan catat sebagai belanja.');delete $('#transaction-form').dataset.clientId;const modal=$('#transaction-modal'),form=$('#transaction-form');form?.reset();window.dispatchEvent(new CustomEvent('appcouple:transaction-reader-reset'));modal.classList.remove('hidden');const normalized=type==='income'?'income':'expense';$('#transaction-type').value=normalized;$('#transaction-title').textContent=type==='income'?'Tambah pemasukan':type==='transfer'?'Transfer antar dompet':'Tambah pengeluaran';const date=form?.elements?.date;if(date)date.value=todayWIB();}
function closeTransaction(){delete $('#transaction-form').dataset.clientId;$('#transaction-modal').classList.add('hidden');window.dispatchEvent(new CustomEvent('appcouple:transaction-reader-reset'));}
function formatIDR(value){ return new Intl.NumberFormat('id-ID').format(value); }
const financeOwner=()=>state.demo?'demo':state.user?.uid||state.user?.id;
function readPendingTransactions(){return readLocal(financeOwner(),'pending',[])}
function writePendingTransactions(rows){writeLocal(financeOwner(),'pending',rows);window.dispatchEvent(new Event('finance:pending-changed'))}
function queuePendingTransaction(data,error){const item={...data,owner:financeOwner(),pendingAt:new Date().toISOString(),pendingError:error?.code||'network'};writePendingTransactions([...readPendingTransactions().filter(x=>x.clientId!==item.clientId),item]);return item}
let syncLocked=false;
async function syncPendingTransactions(){if(syncLocked||state.demo||!state.backendReady||!navigator.onLine)return;syncLocked=true;const owner=financeOwner();try{const service=await import('./supabase-service.js');let synced=0;for(const item of readPendingTransactions()){if(owner!==financeOwner()||item.owner!==owner)break;try{await service.saveTransaction(item);writePendingTransactions(readPendingTransactions().filter(x=>x.clientId!==item.clientId));synced++}catch(e){console.warn('Transaksi masih tertunda',e)}}if(synced){window.dispatchEvent(new Event('finance:refresh'));toast(`${synced} transaksi tersinkron`)}}finally{syncLocked=false}}
window.addEventListener('finance:retry',syncPendingTransactions);

function updateMatusProvider(){const info=getLocalAiProviderInfo(),badge=$('#matus-provider-badge'),engine=$('#matus-engine-state');if(engine)engine.textContent=info.ready?`${info.label} terverifikasi · AI lokal privat`:'AI lokal privat · uji provider untuk mengaktifkan';if(badge){badge.classList.toggle('ready',info.ready);const text=badge.querySelector('b');if(text)text.textContent=info.ready?info.label:'AI belum aktif'}window.__appCoupleMatusIdleStatus=info.ready?`${info.label} · siap mendengar dan berbicara`:'AI belum aktif · atur provider di Otak AI';const status=$('#matus-status');if(status&&!status.textContent.includes('Mendengarkan')&&!status.textContent.includes('Memproses'))status.textContent=window.__appCoupleMatusIdleStatus}
function openMatusProviderSettings(){navigate('couple');setTimeout(()=>{document.querySelector('[data-couple-tab="apps"]')?.click();setTimeout(()=>{document.querySelector('[data-couple-feature="ai"]:not([hidden])')?.click();setTimeout(()=>document.querySelector('#ai-key-input')?.focus({preventScroll:true}),120)},100)},100)}

function wireUI(){
  $('#today-label').textContent=new Intl.DateTimeFormat('id-ID',{weekday:'long',day:'numeric',month:'long',year:'numeric'}).format(new Date());
  $('[data-view="home"]').classList.add('active');
  $$('[data-view]').forEach(btn=>btn.addEventListener('click',()=>navigate(btn.dataset.view)));
  $$('[data-jump]').forEach(btn=>btn.addEventListener('click',()=>navigate(btn.dataset.jump)));
  document.addEventListener('click',e=>{const g=e.target.closest('[data-couple-goto]');if(!g)return;e.preventDefault();if(typeof window.__appCoupleCloseFeature==='function')window.__appCoupleCloseFeature();else document.querySelector('#fs-overlay')?.classList.add('hidden');navigate(g.dataset.coupleGoto);});
  $$('[data-action]').forEach(btn=>btn.addEventListener('click',()=>openTransaction(btn.dataset.action)));
  $('#demo-login').addEventListener('click',()=>{ showApp({displayName:'Imam'},true); toast('Mode demonstrasi aktif'); });
  ['#theme-toggle','#quick-theme-toggle','#m26-theme-toggle'].forEach(id=>$(id)?.addEventListener('click',()=>toggleAppTheme()));
  $('#open-ai').addEventListener('click',()=>navigate('ai'));
  $('#matus-provider-badge')?.addEventListener('click',openMatusProviderSettings);
  window.addEventListener('appcouple:ai-config-changed',updateMatusProvider);
  updateMatusProvider();
  initMatusCore();
  $('#matus-cancel-ai')?.addEventListener('click',()=>{matusRequestId++;matusSendLocked=false;const form=$('#ai-form');form?.classList.remove('is-busy');delete form?.dataset.sending;const send=$('#matus-send');if(send)send.disabled=false;$('#matus-cancel-ai')?.classList.remove('active');toast('Jawaban Matus dihentikan')});
  $$('#transaction-modal .modal-close, #transaction-modal .modal-cancel').forEach(button=>button.addEventListener('click',closeTransaction));
  $('#transaction-modal').addEventListener('click',e=>{if(e.target.id==='transaction-modal')closeTransaction();});
  document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!$('#transaction-modal').classList.contains('hidden'))closeTransaction();});
  $('#transaction-form').addEventListener('submit',async e=>{e.preventDefault();const form=e.currentTarget,button=form.querySelector('.modal-actions button:last-child');if(button.disabled)return;let x;try{x=validateTransaction({...Object.fromEntries(new FormData(form)),clientId:form.dataset.clientId||crypto.randomUUID()})}catch(error){return toast(error.message)}form.dataset.clientId=x.clientId;button.disabled=true;try{if(state.demo){window.dispatchEvent(new CustomEvent('finance:transaction',{detail:x}));toast('Transaksi demo tersimpan di perangkat')}else{if(!state.backendReady)throw Error('Layanan belum siap');queuePendingTransaction(x,{});const service=await import('./supabase-service.js');await service.saveTransaction(x);writePendingTransactions(readPendingTransactions().filter(r=>r.clientId!==x.clientId));toast('Transaksi tersimpan')}closeTransaction();form.reset()}catch(error){if(error.code&&/^(22|23|42|PGRST)/.test(error.code)){writePendingTransactions(readPendingTransactions().filter(r=>r.clientId!==x.clientId));toast('Tidak tersimpan: '+error.message,6500);return}try{queuePendingTransaction(x,error);toast('Transaksi tertunda disimpan untuk akun ini. Tekan Sinkronkan saat online.',6500);closeTransaction();form.reset()}catch(storageError){toast('Penyimpanan perangkat penuh. Transaksi belum disimpan; jangan tutup formulir.',7000)}}finally{button.disabled=false}});
  $$('.quick-prompts button').forEach(btn=>btn.addEventListener('click',()=>{ $('#ai-input').value=btn.textContent; $('#ai-form').requestSubmit(); }));
  $('#ai-form').addEventListener('submit',async e=>{
    e.preventDefault();
    const form=e.currentTarget,input=$('#ai-input'),text=input.value.trim();if(!text||matusSendLocked||form.dataset.sending==='1')return;
    matusSendLocked=true;form.dataset.sending='1';const send=$('#matus-send');if(send)send.disabled=true;
    const requestId=++matusRequestId,history=getMatusHistory(48),cancel=$('#matus-cancel-ai');form.classList.add('is-busy');cancel?.classList.add('active');
    const clientId=crypto.randomUUID(),messages=$('#ai-messages'),userBubble=document.createElement('div');userBubble.className='message user';userBubble.textContent=text;userBubble.dataset.pending='1';userBubble.dataset.clientPending='1';userBubble.dataset.clientId=clientId;userBubble.dataset.pendingRole='user';userBubble.dataset.pendingText=text;messages.appendChild(userBubble);window.dispatchEvent(new CustomEvent('appcouple:matus-message',{detail:{role:'user',text,clientId}}));input.value='';messages.scrollTop=messages.scrollHeight;
    const loading=document.createElement('div');loading.className='message bot';loading.textContent='Bentar. Gua lagi nyambungin data aplikasi lu…';loading.dataset.pending='1';loading.dataset.clientPending='1';loading.dataset.clientId=clientId;loading.dataset.pendingRole='assistant';loading.dataset.pendingText='';messages.appendChild(loading);
    const publish=reply=>{if(requestId!==matusRequestId)return;loading.textContent=reply;loading.dataset.pendingText=reply;loading.removeAttribute('data-pending');messages.scrollTop=messages.scrollHeight;window.dispatchEvent(new CustomEvent('appcouple:matus-reply',{detail:{text:reply,bubble:loading}}));window.dispatchEvent(new CustomEvent('appcouple:matus-message',{detail:{role:'assistant',text:reply,clientId}}));};
    try{
      if(!hasLocalAiConfig()){await new Promise(resolve=>setTimeout(resolve,360));publish(`Mode lokal · ${window.__appCoupleMatusLocalReply?.(text)||'Kita mulai dari satu langkah kecil yang paling mudah.'}`);return}
      const wantsLocation=/\b(dimana|di mana|alamat|berada|posisi|lokasi sekarang|lagi di)\b/i.test(text);const result=await resolveMatusAnswer({message:text,history,chat:localAiChat,buildPrompt:options=>buildMatusSystemPrompt({...options,includeLocation:wantsLocation}),canSearch:()=>requestId===matusRequestId,onResearch:()=>{loading.textContent=researchStatusText()}});
      publish(String(result.answer||'').trim());
    }catch(error){loading.classList.add('m5-error');publish(`Gua belum bisa menjawab melalui provider AI. ${error.message||'Cek provider dan koneksi internet lu.'}`)}finally{if(requestId===matusRequestId){matusSendLocked=false;delete form.dataset.sending;form.classList.remove('is-busy');cancel?.classList.remove('active');if(send)send.disabled=false}}
  });
}
function escapeHtml(value){ const el=document.createElement('div'); el.textContent=value; return el.innerHTML; }

function initNetworkStatus(){const badge=$('#network-status');const paint=()=>{if(!badge)return;const online=navigator.onLine;badge.textContent=online?'Online':'Offline · perubahan belum tersinkron';badge.classList.toggle('offline',!online)};addEventListener('online',()=>{paint();syncPendingTransactions()});addEventListener('offline',paint);paint()}
syncMobileZoomLock();wireUI();initNetworkStatus();initBackupCenter({notify:toast,user:()=>state.user,demo:()=>state.demo});initSupabase();
if('serviceWorker' in navigator && location.protocol!=='file:') navigator.serviceWorker.register('/service-worker.js').catch(console.warn);
