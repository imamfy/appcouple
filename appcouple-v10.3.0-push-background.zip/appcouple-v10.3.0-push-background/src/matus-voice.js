import {initMatusLocation} from './matus-location.js';
const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
const TASK_KEY = 'ac_matus_tasks_v2';
const VOICE_KEY = 'ac_matus_voice_auto';
const VOICE_PROFILE_KEY = 'ac_matus_voice_profile_v1';
const PERM_KEY = 'ac_matus_permissions_v5';
const DEFAULT_PERMS = { finance: true, activity: true, savings: true, location: true, memories: true, chat: true };
const VOICE_PROFILES = {
  assistant: { label: 'Tegas seperti asisten', rate: 1.04, pitch: 0.90, volume: 1 },
  warm: { label: 'Hangat dan perhatian', rate: 0.98, pitch: 0.98, volume: 1 },
  calm: { label: 'Tenang dan dewasa', rate: 0.92, pitch: 0.94, volume: 0.96 },
};
const SPEECH_WORDS_PER_SECOND = 2.35;

let notify = () => {};
let currentUser = { displayName: 'Imam' };
let demoMode = false;
let tasks = [];
let speakingTimer = null;
let speakingTicker = null;
let reminderTicker = null;
let recognition = null;
let wired = false;
let lastSpokenText = '';
let lastSpokenAt = 0;
let observedReplyTimer = null;
let activeSpeechText = '';
let queuedSpeech = null;
let speechRunId = 0;
let syncApi = null;
let syncChatId = null;
let stopMatusState = null;
let stopMatusMessages = null;
let remoteSaveTimer = null;
let applyingRemoteTasks = false;
let renderedMatusIds = new Set();
let chatterTicker = null;
let chatterCountdown = null;
let nextChatterAt = 0;
let voiceUnlocked = false;
let pendingGreeting = false;
let contextTicker = null;
let lastChatterIndex = -1;
let recentChatter = [];
let pendingChatter = false;
let pendingGlobalAnnouncement = '';
const CHATTER_INTERVAL_MS = 120_000; // 2 menit
const CHATTER_LINES = [
  'Woy, minum dulu. Gua nggak mau lu baru ingat badan setelah kepala mulai pusing.',
  'Lu udah hebat sampai titik ini. Tapi hebat bukan berarti harus kuat sendirian terus.',
  'Coba tarik napas pelan. Yang belum selesai nggak harus beres semuanya hari ini.',
  'Gua cek lu masih di sini. Jangan bilang dari tadi cuma scroll tanpa tujuan, ya.',
  'Kalau hari ini berantakan, kita rapihin satu hal kecil dulu. Satu aja, jangan sok kuat.',
  'Hei, bahu lu rileksin. Duduk tegang begitu nggak bikin masalah kabur.',
  'Udah nyapa pasangan belum? Jangan gengsi. Perhatian kecil sering lebih kepake daripada kata besar.',
  'Cek dompet sebentar. Gua cerewet karena diskon lucu sering berubah jadi penyesalan.',
  'Kalau ada yang bikin sesak, omongin. Gua bisa jutek, tapi gua dengerin beneran.',
  'Istirahat lima menit bukan malas. Itu namanya biar otak lu nggak ngambek.',
  'Satu pengingat dari gua: jangan bandingin proses lu sama potongan terbaik hidup orang lain.',
  'Hari ini ada satu hal yang bikin lu senyum nggak? Simpan di Kenangan sebelum lupa.',
  'Woy, makan yang bener. Kopi doang bukan strategi hidup.',
  'Gua bangga kalau lu konsisten, bukan cuma semangat pas suasana hati bagus.',
  'Kalau rencana gagal, revisi. Jangan malah menghina diri sendiri, itu kerjaan yang nggak berguna.',
  'Coba berdiri dan gerak sebentar. Gua tunggu, nggak usah banyak alasan.',
  'Lu boleh capek. Yang nggak boleh itu pura-pura baik-baik aja terus.',
  'Kasih kabar ke pasangan kalau lagi sibuk. Menghilang bukan bahasa cinta, Bos.',
  'Ada uang keluar hari ini? Catat sekarang sebelum otak lu mendadak amnesia.',
  'Celengan Cinta nggak harus diisi besar. Sedikit tapi rutin masih lebih keren daripada cuma wacana.',
  'Gua pengin lu tidur cukup malam ini. Jangan negosiasi sama jam dua pagi lagi.',
  'Kalau bingung mulai dari mana, pilih tugas paling gampang. Momentum dulu, sempurna belakangan.',
  'Matus hadir. Cerewet sedikit, perhatian banyak. Lu aman buat cerita di sini.',
  'Senyum dikit dong. Bukan karena semua mudah, tapi karena lu masih mau lanjut.'
];

export async function initMatusVoice({ user = { displayName: 'Imam' }, demo = false, toast = () => {} } = {}) {
  currentUser = user;
  demoMode = demo;
  notify = toast;
  initMatusLocation();
  tasks = loadTasks();
  if (demoMode && !localStorage.getItem(TASK_KEY)) seedDemoTasks();
  setGreeting();
  renderVoiceSupport();
  renderVoiceProfile();
  renderTasks();
  updateBriefingStats();
  if (!wired) wireMatus();
  wired = true;
  ensureGlobalVoiceDock();
  clearInterval(reminderTicker);
  reminderTicker = setInterval(checkDueTasks, 10_000);
  checkDueTasks();
  window.__appCoupleMatusLocalReply = localReply;
  window.__appCoupleMatusSpeak = (text,options={}) => requestGlobalSpeech(text,options);
  window.__appCoupleMatusAction = action => {
    if(action==='stop'){stopSpeaking();notify('Matus berhenti berbicara');return}
    unlockVoice();
    if(action==='hello'){const text=buildGreeting();showHeaderAnnouncement(text,'manual');speak(text,{force:true});return}
    if(action==='briefing'){const text=buildBriefing();showHeaderAnnouncement(text,'manual');speak(text,{force:true})}
  };
  if (!demoMode) await initMatusSupabaseSync();
  ['appcouple:finance-update','appcouple:savings-update','appcouple:map-update','appcouple:memories-update','appcouple:couple-update','appcouple:trip-update','appcouple:trip-context-refresh','appcouple:matus-context-refresh'].forEach(type=>window.addEventListener(type,updateAppMemoryDashboard));
  if(navigator.userActivation?.hasBeenActive)unlockVoice();
  clearInterval(contextTicker);contextTicker=setInterval(updateAppMemoryDashboard,15_000);updateAppMemoryDashboard();
  startAutoChatter();
  greetOnOpenOnce();
}

function getMatusPerms() {
  try { return { ...DEFAULT_PERMS, ...JSON.parse(localStorage.getItem(PERM_KEY) || '{}') }; }
  catch { return { ...DEFAULT_PERMS }; }
}

function contextLabel() {
  const p = getMatusPerms();
  const labels = [];
  if (p.finance) labels.push('keuangan');
  if (p.activity) labels.push('Couple Space');
  if (p.savings) labels.push('Celengan Cinta');
  if (p.location) labels.push('Maps');
  if (p.memories) labels.push('kenangan');
  if (p.chat) labels.push('riwayat chat');
  return labels;
}

// Matus otomatis nyeletuk lintas halaman. Browser tetap mewajibkan minimal satu
// interaksi pengguna sebelum text-to-speech boleh dimulai.
function startAutoChatter(){
  stopAutoChatter();
  if(!autoVoiceEnabled())return updateAutoplayState('Nonaktif');
  nextChatterAt=Date.now()+CHATTER_INTERVAL_MS;
  chatterTicker=setTimeout(()=>{speakAutoChatter();startAutoChatter()},CHATTER_INTERVAL_MS);
  chatterCountdown=setInterval(updateChatterCountdown,1000);
  updateChatterCountdown();
}
function stopAutoChatter(){clearTimeout(chatterTicker);clearInterval(chatterCountdown);chatterTicker=null;chatterCountdown=null;nextChatterAt=0}
function updateAutoplayState(text){setText('#matus-autoplay-state',text)}
function updateChatterCountdown(){
  if(!autoVoiceEnabled())return updateAutoplayState('Nonaktif');
  const seconds=Math.max(0,Math.ceil((nextChatterAt-Date.now())/1000));
  updateAutoplayState(voiceUnlocked?`Aktif · suara berikutnya maksimal ${Math.ceil(seconds/60)||1} menit`:'Ketuk halaman sekali untuk mengaktifkan suara otomatis');
}
function unlockVoice(){
  const firstUnlock=!voiceUnlocked;
  voiceUnlocked=true;
  if('speechSynthesis'in window){speechSynthesis.resume();speechSynthesis.getVoices()}
  startAutoChatter();
  updateChatterCountdown();
  if(firstUnlock&&pendingGreeting){pendingGreeting=false;sessionStorage.setItem('ac_matus_greeted','1');setTimeout(()=>speak(buildGreeting(),{once:true}),220)}
  if(pendingGlobalAnnouncement){const text=pendingGlobalAnnouncement;pendingGlobalAnnouncement='';setTimeout(()=>speak(text,{once:true}),firstUnlock&&pendingGreeting?900:260)}
}
function speakAutoChatter() {
  if (!autoVoiceEnabled()||!voiceUnlocked) return;
  if (document.hidden || document.querySelector('#app-shell')?.classList.contains('hidden')) {
    pendingChatter = true;
    return;
  }
  if (typeof speechSynthesis !== 'undefined' && speechSynthesis.speaking) {
    pendingChatter = true;
    return;
  }
  const text=buildProactiveChatter();
  pendingChatter = false;
  showHeaderAnnouncement(text,'auto');
  speak(text,{once:true});
}

function tryPendingChatter() {
  if (!pendingChatter || !autoVoiceEnabled() || !voiceUnlocked) return;
  if (!document.hidden && !document.querySelector('#app-shell')?.classList.contains('hidden') && !(speechSynthesis?.speaking)) speakAutoChatter();
}

function showHeaderAnnouncement(text,source='auto'){
  const clean=String(text||'').trim();if(!clean)return;
  setText('#matus-character-caption',summarize(clean,150));
  setText('#matus-header-mode',source==='auto'?'AUTO · 2 MENIT':'MATUS');
  window.dispatchEvent(new CustomEvent('appcouple:matus-auto-header',{detail:{text:clean,source,at:new Date().toISOString()}}));
}

function ensureGlobalVoiceDock(){
  if($('#matus-global-voice'))return;
  const dock=document.createElement('aside');
  dock.id='matus-global-voice';
  dock.hidden=true;
  dock.setAttribute('aria-live','polite');
  dock.innerHTML='<span class="matus-global-orb" aria-hidden="true">M</span><div><small>MATUS</small><p>Matus siap berbicara</p></div><button type="button" aria-label="Hentikan suara Matus"><i data-fa="stop"></i></button>';
  dock.querySelector('button').addEventListener('click',()=>stopSpeaking());
  document.body.appendChild(dock);
  import('./icons.js').then(module=>module.hydrateIcons?.(dock)).catch(()=>{});
}

function showGlobalVoiceDock(text,state='speaking'){
  ensureGlobalVoiceDock();
  const dock=$('#matus-global-voice');if(!dock)return;
  dock.hidden=false;dock.dataset.state=state;
  const label=dock.querySelector('small');if(label)label.textContent=state==='waiting'?'MATUS · SIAP SETELAH SENTUH':'MATUS · BERBICARA';
  const copy=dock.querySelector('p');if(copy)copy.textContent=summarize(text,150);
}

function hideGlobalVoiceDock(){
  const dock=$('#matus-global-voice');if(!dock)return;
  dock.dataset.state='idle';setTimeout(()=>{if(dock.dataset.state==='idle')dock.hidden=true},700);
}

function requestGlobalSpeech(text,{force=false}={}){
  const clean=String(text||'').trim();if(!clean)return{ok:false,reason:'empty'};if(!autoVoiceEnabled())return{ok:false,reason:'disabled'};
  showHeaderAnnouncement(clean,'global');
  if(!voiceUnlocked){pendingGlobalAnnouncement=clean;showGlobalVoiceDock(clean,'waiting');return{ok:true,queued:true}}
  speak(clean,{force,once:!force});return{ok:true,queued:false};
}

// Sebelum asal pilih baris random, cek dulu ada nggak sesuatu yang benar-benar
// perlu disebut (tugas lewat waktu, tugas yang deket, saldo rendah). Kalau ada,
// itu yang diucapkan — biar Matus kerasa "notice" kondisi user, bukan cuma
// ngoceh generik tiap 2 menit.
function buildProactiveChatter() {
  const perms=getMatusPerms(),name=firstName(),pending=tasks.filter(item=>!item.done).sort(sortTasks),overdue=pending.filter(item=>new Date(item.dueAt).getTime()<=Date.now()),finance=window.__appCoupleFinanceSummary||{},savings=window.__appCoupleSavingsSummary||{},map=window.__appCoupleMapSummary||{};
  const candidates=[...CHATTER_LINES].filter(line =>
    (perms.finance || !/(dompet|uang keluar|belanja)/i.test(line)) &&
    (perms.savings || !/celengan cinta/i.test(line)) &&
    (perms.activity || !/pasangan/i.test(line)) &&
    (perms.memories || !/kenangan/i.test(line))
  );
  if(overdue.length)candidates.push(`${name}, ada ${overdue.length} tugas lewat waktu. Pilih satu dan tuntasin sekarang, jangan kabur lagi.`,`${name}, tugas ${overdue[0].title} udah nunggu. Gua temenin mulai lima menit dulu.`);
  else if(pending.length)candidates.push(`${name}, ${pending[0].title} masih ada di daftar. Sedikit progres juga tetap progres.`,`${name}, sebelum santai total, cek ${pending[0].title} dulu. Gua cuma ngingetin, bukan nyebelin. Ya, mungkin sedikit.`);
  if(perms.finance && Number(finance.balance)<0)candidates.push(`${name}, saldo lagi minus ${rupiah(Math.abs(finance.balance))}. Hari ini tahan dulu belanja yang cuma karena lapar mata.`,`Gua lihat arus kas lu lagi merah. Tenang, buka Keuangan dan kita cari kebocoran paling besar.`);
  if(perms.savings && Number(savings.target)>0)candidates.push(`Celengan Cinta sekarang sekitar ${Math.round(Number(savings.total)/Number(savings.target)*100)||0} persen. Isi kecil hari ini boleh banget.`,`Target berdua nggak bergerak karena niat doang. Sisihkan sedikit buat Celengan Cinta, yuk.`);
  if(perms.location && map.connected)candidates.push(map.meLive&&map.partnerLive?'Lokasi kalian berdua aktif. Tetap kabarin lewat chat, jangan cuma ngandelin titik di peta.':'Kalau lagi perjalanan penting, aktifkan lokasi berdua. Kalau nggak perlu, privasi tetap nomor satu.');
  if(perms.activity && window.__appCoupleCoupleSummary?.connected)candidates.push('Udah kasih kabar ke pasangan? Perhatian kecil lebih berguna daripada nunggu momen besar.');
  if(perms.memories && Number(window.__appCoupleMemoriesSummary?.count)>0)candidates.push('Ada kenangan yang bisa lu buka lagi. Simpan satu momen baik hari ini, biar hari nggak cuma diisi urusan.');
  let pool=candidates.filter(text=>!recentChatter.includes(text));if(!pool.length){recentChatter=[];pool=candidates}
  const text=pool[Math.floor(Math.random()*pool.length)];recentChatter.push(text);recentChatter=recentChatter.slice(-6);lastChatterIndex=candidates.indexOf(text);return text;
}

// Matus otomatis menyapa (dengan suara) begitu app dibuka, bukan cuma saat tab
// Matus dibuka manual. Tetap menghormati toggle "suara otomatis" dan cuma sekali
// per sesi supaya tidak cerewet berlebihan tiap pindah halaman.
function greetOnOpenOnce() {
  if (!autoVoiceEnabled() || sessionStorage.getItem('ac_matus_greeted')) return;
  if(!voiceUnlocked){pendingGreeting=true;updateAutoplayState('Aktif · ketuk aplikasi sekali, habis itu gua mulai ngomel');showGlobalVoiceDock(buildGreeting(),'waiting');return}
  sessionStorage.setItem('ac_matus_greeted', '1');setTimeout(() => speak(buildGreeting(),{once:true}), 500);
}

function wireMatus() {
  ['pointerdown','keydown','touchstart'].forEach(type=>document.addEventListener(type,unlockVoice,{capture:true,once:true,passive:true}));
  $('#matus-briefing-btn')?.addEventListener('click', () => speak(buildBriefing(), { force: true }));
  $('#matus-stop-btn')?.addEventListener('click', stopSpeaking);
  $('#matus-say-hello')?.addEventListener('click', () => speak(buildGreeting(), { force: true }));
  $('#matus-voice-auto')?.addEventListener('change', event => {
    localStorage.setItem(VOICE_KEY, event.currentTarget.checked ? '1' : '0');
    if(event.currentTarget.checked){unlockVoice();notify('Suara otomatis aktif. Matus akan berbicara maksimal setiap 2 menit')}else{stopAutoChatter();stopSpeaking();updateAutoplayState('Nonaktif');notify('Suara otomatis dimatikan')}
  });
  $('#matus-voice-profile')?.addEventListener('change', event => {
    localStorage.setItem(VOICE_PROFILE_KEY, event.currentTarget.value);
    renderVoiceProfile();
    renderVoiceSupport();
    unlockVoice();
    speak(`Siap. Karakter suara ${currentVoiceProfile().label.toLowerCase()} sudah aktif.`, { force: true });
  });
  $('#matus-voice-preview')?.addEventListener('click', () => { unlockVoice(); speak('Matus siap membantu. Sampaikan perintah dengan jelas, lalu kita selesaikan satu per satu.', { force: true }); });
  $('#matus-notify-btn')?.addEventListener('click', enableNotifications);
  $('#matus-mic')?.addEventListener('click', toggleListening);
  $('#matus-task-form')?.addEventListener('submit', addTask);
  $('#matus-task-list')?.addEventListener('click', taskAction);
  $('#matus-task-list')?.addEventListener('change', taskAction);
  $('#matus-copy')?.addEventListener('click', copyLastReply);
  $('#matus-clear')?.addEventListener('click', clearConversation);
  $('#matus-mem-clear')?.addEventListener('click', clearConversation);
  $$('[data-matus-cap]').forEach(button => button.addEventListener('click', () => askCapability(button.dataset.matusCap)));
  $$('[data-view="ai"]').forEach(button => button.addEventListener('click', () => {
    greetOnOpenOnce();
    tryPendingChatter();
  }));
  document.addEventListener('visibilitychange', tryPendingChatter);
  window.addEventListener('appcouple:view-changed', tryPendingChatter);
  window.addEventListener('appcouple:matus-reply', event => {
    const text = String(event.detail?.text || '').trim();
    const live=document.querySelector('#view-ai')?.dataset.m75Tab==='live';
    if ((autoVoiceEnabled()||live) && text) { unlockVoice(); speak(text, { force: live, once: !live }); }
  });
  window.addEventListener('appcouple:matus-announce',event=>requestGlobalSpeech(event.detail?.text,{force:!!event.detail?.force}));
  // Suara Matus tetap aktif lintas halaman sesuai preferensi pengguna.
  window.addEventListener('appcouple:matus-message', event => {
    const role = event.detail?.role === 'assistant' ? 'assistant' : 'user';
    const text = String(event.detail?.text || '').trim();
    if (!demoMode && syncApi && syncChatId && text) syncApi.sendCoupleMatusMessage(syncChatId, role, text).catch(error => console.warn('Pesan Matus belum tersinkron:', error));
  });
  $('#ai-messages')?.addEventListener('click',event=>{const bubble=event.target.closest('.message.bot');if(bubble?.textContent?.trim())speak(bubble.textContent,{force:true})});
  watchChatReplies();
}

function setGreeting() {
  const name = firstName();
  const greeting = dayGreeting();
  const nameNode = $('#matus-user-name');
  if (nameNode) nameNode.textContent = name;
  const greetingNode = $('#matus-greeting');
  if (greetingNode) greetingNode.textContent = `Woy, ${name}.`;
  const auto = $('#matus-voice-auto');
  if (auto) auto.checked = autoVoiceEnabled();
}

function firstName() {
  return String(currentUser?.displayName || currentUser?.name || 'Imam').trim().split(/\s+/)[0] || 'Imam';
}

function dayGreeting() {
  const hour = new Date().getHours();
  if (hour < 11) return 'Selamat pagi';
  if (hour < 15) return 'Selamat siang';
  if (hour < 19) return 'Selamat sore';
  return 'Selamat malam';
}

function buildGreeting() {
  const labels=contextLabel();
  const scope=labels.length?labels.join(', '):'hal yang lu izinkan';
  return `${dayGreeting()}, ${firstName()}. Gua Matus. Gua siap bantu mantau ${scope}. Kalau ada yang berantakan, gua bakal ngomel secukupnya. Sekarang mau cek apa?`;
}

function buildBriefing() {
  const pending = tasks.filter(item => !item.done).sort(sortTasks);
  const perms = getMatusPerms();
  const finance = window.__appCoupleFinanceSummary || {};
  const couple = window.__appCoupleCoupleSummary || {};
  const savings=window.__appCoupleSavingsSummary||{},map=window.__appCoupleMapSummary||{},memories=memorySummary();const parts = [buildGreeting()];
  if (pending.length) {
    const next = pending[0];
    parts.push(`Dengerin. Lu masih punya ${pending.length} tugas. Yang paling dekat: ${next.title}, ${relativeDue(next.dueAt)}. Jangan ditunda lagi.`);
    if (pending.length > 1) parts.push(`Habis itu lanjut ${pending[1].title}. Satu-satu, tapi jangan ngilang.`);
  } else {
    parts.push('Belum ada tugas aktif. Bagus, tapi jangan sok santai. Tambahin pengingat biar gua bisa ngejar lu tepat waktu.');
  }
  if (perms.finance && Number.isFinite(Number(finance.balance))) parts.push(`Keuangan bulan ini: pemasukan ${rupiah(finance.income)}, pengeluaran ${rupiah(finance.expense)}, sisa ${rupiah(finance.balance)}.`);
  if(perms.savings && Number(savings.target)>0)parts.push(`Celengan Cinta ada ${rupiah(savings.total)} dari target ${rupiah(savings.target)}.`);
  if(perms.activity && couple.connected)parts.push(`Couple Space terhubung sama ${couple.partner||'pasangan lu'}.`);
  if(perms.location)parts.push(`Maps: ${map.meLive&&map.partnerLive?'kalian berdua lagi live':map.meLive?'lokasi lu aktif, pasangan belum':'belum aktif lengkap'}.`);
  if(perms.memories)parts.push(`Kenangan tersimpan ${Number(memories.count)||0}.`);
  parts.push('Udah, pilih satu yang paling penting dan kerjain.');
  return parts.join(' ');
}

export function speak(rawText, { force = false, once = false } = {}) {
  const text = cleanSpeech(rawText);
  if (!text) return;
  if (!('speechSynthesis' in window) || !('SpeechSynthesisUtterance' in window)) {
    renderUnsupported('Perangkat ini belum mendukung suara browser');
    if (force) notify('Text-to-speech tidak didukung browser ini');
    return;
  }
  if (once && (text === activeSpeechText || text === queuedSpeech?.text || (text === lastSpokenText && Date.now() - lastSpokenAt < 15_000))) return;
  if (activeSpeechText && !force) {
    queuedSpeech = { text, options: { force: false, once } };
    setText('#matus-voice-state', 'Menyelesaikan jawaban saat ini…');
    return;
  }
  if (force) stopSpeaking(true);
  const runId = ++speechRunId;
  activeSpeechText = text;
  if (once) { lastSpokenText = text; lastSpokenAt = Date.now(); }
  const profile = currentVoiceProfile();
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.lang = 'id-ID';
  utterance.rate = profile.rate;
  utterance.pitch = profile.pitch;
  utterance.volume = profile.volume;
  speechSynthesis.resume();
  const voices = speechSynthesis.getVoices();
  const indonesianVoices = voices.filter(voice => /^id([-_]|$)/i.test(voice.lang) || /Indonesia|Bahasa/i.test(voice.name));
  utterance.voice = indonesianVoices.find(voice => /Google.*Indonesia|Microsoft.*(Gadis|Ardi|Dimas)|Bahasa Indonesia/i.test(voice.name)) || indonesianVoices.find(voice => voice.localService) || indonesianVoices[0] || null;
  const finish = () => {
    if (runId !== speechRunId) return;
    activeSpeechText = '';
    stopSpeaking(false);
    const next = queuedSpeech;
    queuedSpeech = null;
    if (next) setTimeout(() => speak(next.text, next.options), 80);
  };
  utterance.onstart = () => { if (runId === speechRunId) startSpeakingUi(text); };
  utterance.onend = finish;
  utterance.onerror = event => {
    // Autoplay/browser-policy failures are expected on mobile. Only show an
    // error toast after an explicit user request, so it does not cover forms.
    if (event.error !== 'canceled' && event.error !== 'interrupted' && force) notify('Suara Matus tidak dapat diputar');
    finish();
  };
  speechSynthesis.speak(utterance);
  setTimeout(() => {
    if (runId === speechRunId && speechSynthesis.speaking && !$('#matus-character')?.classList.contains('is-speaking')) startSpeakingUi(text);
  }, 160);
}

function startSpeakingUi(text) {
  window.dispatchEvent(new CustomEvent('appcouple:matus-speaking-text',{detail:{text}}));
  clearInterval(speakingTimer);
  if(document.querySelector('#matus-header-mode')?.textContent!=='AUTO · 2 MENIT')setText('#matus-header-mode','BERBICARA');
  clearInterval(speakingTicker);
  $$('.message.bot.is-speaking',$('#ai-messages')).forEach(node=>node.classList.remove('is-speaking'));
  const matching=[...$$('.message.bot',$('#ai-messages'))].reverse().find(node=>node.textContent.trim()===text.trim());
  matching?.classList.add('is-speaking');
  matching?.scrollIntoView({block:'nearest',behavior:'smooth'});
  const character = $('#matus-character');
  character?.classList.add('is-speaking');
  character?.setAttribute('aria-label', 'Matus sedang berbicara');
  setText('#matus-voice-state', 'Sedang berbicara…');
  setText('#matus-character-caption', summarize(text, 72));
  showGlobalVoiceDock(text,'speaking');
  const progress = $('#matus-speech-progress');
  if (progress) progress.style.width = '0%';
  const started = Date.now(), estimatedMs = Math.max(3000, Math.ceil(text.split(/\s+/).length / SPEECH_WORDS_PER_SECOND * 1000));
  speakingTimer=setInterval(()=>{if('speechSynthesis'in window&&speechSynthesis.speaking&&!speechSynthesis.paused){speechSynthesis.pause();speechSynthesis.resume()}},12000);
  speakingTicker = setInterval(() => {
    const elapsed = Date.now() - started, percentage = Math.min(96, (elapsed / estimatedMs) * 100);
    if (progress) progress.style.width = `${percentage}%`;
    setText('#matus-speech-time', `${Math.max(0, Math.ceil((estimatedMs - elapsed) / 1000))} dtk`);
  }, 500);
}

function stopSpeaking(cancel = true) {
  if (cancel) { speechRunId += 1; activeSpeechText = ''; queuedSpeech = null; if ('speechSynthesis' in window) speechSynthesis.cancel(); }
  clearInterval(speakingTimer);
  clearInterval(speakingTicker);
  speakingTimer = null;
  speakingTicker = null;
  $$('.message.bot.is-speaking',$('#ai-messages')).forEach(node=>node.classList.remove('is-speaking'));
  $('#matus-character')?.classList.remove('is-speaking');
  $('#matus-character')?.setAttribute('aria-label', 'Karakter Matus siap berbicara');
  setText('#matus-voice-state', 'Siap mendengarkan kamu');
  setText('#matus-speech-time', 'dibaca sampai selesai');
  const progress = $('#matus-speech-progress');
  if (progress) progress.style.width = '0%';
  hideGlobalVoiceDock();
}

function currentVoiceProfile() {
  const key = localStorage.getItem(VOICE_PROFILE_KEY) || 'assistant';
  return VOICE_PROFILES[key] || VOICE_PROFILES.assistant;
}

function renderVoiceProfile() {
  const key = localStorage.getItem(VOICE_PROFILE_KEY) || 'assistant';
  const select = $('#matus-voice-profile');
  if (select) select.value = VOICE_PROFILES[key] ? key : 'assistant';
  setText('#matus-voice-character-state', currentVoiceProfile().label);
}

function renderVoiceSupport() {
  if (!('speechSynthesis' in window)) renderUnsupported('Suara tidak tersedia');
  else setText('#matus-voice-support', `${currentVoiceProfile().label} · Bahasa Indonesia`);
}

function renderUnsupported(message) {
  setText('#matus-voice-support', message);
  $('#matus-briefing-btn')?.setAttribute('disabled', '');
}

function autoVoiceEnabled() { return localStorage.getItem(VOICE_KEY) !== '0'; }

function watchChatReplies() {
  const messages = $('#ai-messages');
  if (!messages || messages.dataset.voiceObserved) return;
  messages.dataset.voiceObserved = '1';
  const observer = new MutationObserver(() => {
    clearTimeout(observedReplyTimer);
    observedReplyTimer = setTimeout(() => {
      const bots = $$('.message.bot', messages);
      const text = bots.at(-1)?.textContent?.trim() || '';
      if (text && !/sedang (berpikir|memahami)/i.test(text)) setText('#matus-character-caption', summarize(text, 72));
    }, 250);
  });
  observer.observe(messages, { childList: true, subtree: true, characterData: true });
}

async function initMatusSupabaseSync() {
  stopMatusState?.(); stopMatusMessages?.(); syncApi = null; syncChatId = null;
  try {
    syncApi = await import('./supabase-service.js');
    syncChatId = await syncApi.resolveCurrentChatId();
    if (!syncChatId) return;
    let firstState = true;
    stopMatusState = syncApi.watchCoupleMatusState(syncChatId, data => {
      const remote = Array.isArray(data?.tasks) ? data.tasks : [];
      if (remote.length || data?.updatedAt) {
        applyingRemoteTasks = true;
        tasks = remote.map(item => ({ ...item }));
        localStorage.setItem(TASK_KEY, JSON.stringify(tasks));
        renderTasks(); updateBriefingStats();
        applyingRemoteTasks = false;
      } else if (firstState && tasks.length) {
        syncApi.saveCoupleMatusTasks(syncChatId, tasks).catch(console.warn);
      }
      firstState = false;
    }, error => notify(error.message || 'Tugas Matus gagal dibaca'));
    renderedMatusIds = new Set();
    const box = $('#ai-messages'); if (box) delete box.dataset.matusSynced;
    stopMatusMessages = syncApi.watchCoupleMatusMessages(syncChatId, renderSharedMatusMessages, error => console.warn('Percakapan Matus:', error));
  } catch (error) { console.warn('Sinkronisasi Matus belum aktif:', error); }
}

// Menambahkan pesan yang belum pernah dirender, TANPA menghapus seluruh isi kotak
// percakapan. Sebelumnya fungsi ini melakukan box.innerHTML = ... setiap kali data
// Data realtime berubah, sehingga balasan Matus yang sedang "diketik" (belum tersimpan
// ke Supabase) ikut terhapus/tertimpa dan pesan terasa hilang begitu saja.
function renderSharedMatusMessages(rows = []) {
  const box = $('#ai-messages'); if (!box) return;
  if (!Array.isArray(rows) || !rows.length) {
    box.innerHTML = `<div class="message bot">Hai <span id="matus-user-name">${escapeHtml(firstName())}</span>! Riwayat bersama sudah kosong. Aku Matus, siap memulai percakapan baru.</div>`;
    box.dataset.matusSynced = '1';
    renderedMatusIds = new Set();
    return;
  }
  const myUid = currentUser?.uid;
  if (!box.dataset.matusSynced) {
    box.innerHTML = `<div class="message bot">Hai <span id="matus-user-name">${escapeHtml(firstName())}</span>! Aku Matus. Percakapan dan tugas di ruang ini tersinkron untuk kalian berdua.</div>`;
    box.dataset.matusSynced = '1';
    renderedMatusIds = new Set();
  }
  rows.forEach(item => {
    const id = item.id || `${item.actorId || 'x'}-${item.role || 'user'}-${item.text}`;
    if (renderedMatusIds.has(id)) return;
    renderedMatusIds.add(id);
    const mine = item.actorId === myUid;
    const role = item.role === 'assistant' ? 'assistant' : 'user';
    // Hapus bubble sementara (lokal, belum tersinkron) yang cocok agar tidak dobel.
    const pending = $$('.message[data-client-pending="1"]', box).find(node => node.dataset.pendingRole === role && node.dataset.pendingText === item.text);
    pending?.remove();
    let node;
    if (role === 'assistant') { node = document.createElement('div'); node.className = 'message bot'; node.textContent = item.text; }
    else if (mine) { node = document.createElement('div'); node.className = 'message user'; node.textContent = item.text; }
    else { node = document.createElement('div'); node.className = 'message bot matus-partner-message'; node.innerHTML = `<small>${escapeHtml(item.actorName || 'Pasangan')}</small>${escapeHtml(item.text)}`; }
    box.appendChild(node);
  });
  box.scrollTop = box.scrollHeight;
}

function loadTasks() {
  try {
    const data = JSON.parse(localStorage.getItem(TASK_KEY) || '[]');
    return Array.isArray(data) ? data.filter(item => item && item.id && item.title) : [];
  } catch {
    return [];
  }
}

function saveTasks({ remote = true } = {}) {
  localStorage.setItem(TASK_KEY, JSON.stringify(tasks.slice(0, 80)));
  renderTasks();
  updateBriefingStats();
  window.__appCoupleMatusTasks = tasks;
  window.dispatchEvent(new CustomEvent('appcouple:matus-tasks', { detail: { tasks } }));
  if (remote && !demoMode && !applyingRemoteTasks && syncApi && syncChatId) {
    clearTimeout(remoteSaveTimer);
    remoteSaveTimer = setTimeout(() => syncApi.saveCoupleMatusTasks(syncChatId, tasks).catch(error => notify(error.message || 'Tugas Matus gagal disinkronkan')), 180);
  }
}

function seedDemoTasks() {
  const now = new Date();
  const tonight = new Date(now);
  tonight.setHours(Math.max(now.getHours() + 2, 19), 0, 0, 0);
  const tomorrow = new Date(now.getTime() + 86_400_000);
  tomorrow.setHours(9, 0, 0, 0);
  tasks = [
    { id: crypto.randomUUID(), title: 'Cek anggaran harian', dueAt: tonight.toISOString(), done: false, remindedAt: null, createdAt: now.toISOString() },
    { id: crypto.randomUUID(), title: 'Kirim kabar ke pasangan', dueAt: tomorrow.toISOString(), done: false, remindedAt: null, createdAt: now.toISOString() }
  ];
  localStorage.setItem(TASK_KEY, JSON.stringify(tasks));
}

function addTask(event) {
  event.preventDefault();
  const title = $('#matus-task-title')?.value.trim();
  const dueValue = $('#matus-task-due')?.value;
  if (!title) return notify('Tulis nama tugas terlebih dahulu');
  if (!dueValue || Number.isNaN(new Date(dueValue).getTime())) return notify('Pilih waktu pengingat');
  tasks.push({
    id: crypto.randomUUID(),
    title: title.slice(0, 100),
    dueAt: new Date(dueValue).toISOString(),
    done: false,
    remindedAt: null,
    createdAt: new Date().toISOString(),
    createdBy: currentUser?.uid || 'local'
  });
  event.currentTarget.reset();
  setDefaultDue();
  saveTasks();
  notify('Tugas disimpan. Matus akan mengingatkanmu');
  speak(`Siap, ${firstName()}. Aku akan mengingatkan tugas ${title}, ${relativeDue(new Date(dueValue).toISOString())}.`, { force: true });
}

function taskAction(event) {
  const control = event.target.closest('[data-task-action]');
  if (!control) return;
  const task = tasks.find(item => item.id === control.dataset.taskId);
  if (!task) return;
  const action = control.dataset.taskAction;
  if (action === 'toggle') {
    task.done = control.checked;
    task.completedAt = task.done ? new Date().toISOString() : null;
    if (!task.done) task.remindedAt = null;
    saveTasks();
    if (task.done) speak(`Bagus, tugas ${task.title} sudah selesai. Terima kasih sudah menepati rencanamu.`, { force: true });
  }
  if (action === 'delete') {
    tasks = tasks.filter(item => item.id !== task.id);
    saveTasks();
    notify('Tugas dihapus');
  }
  if (action === 'speak') speak(`Pengingat untukmu, ${firstName()}. ${task.title}. ${relativeDue(task.dueAt)}.`, { force: true });
}

function renderTasks() {
  const list = $('#matus-task-list');
  if (!list) return;
  const sorted = [...tasks].sort(sortTasks);
  if (!sorted.length) {
    list.innerHTML = '<div class="mv2-task-empty"><span><i data-fa="check"></i></span><b>Belum ada tugas</b><small>Tambahkan satu pengingat kecil untuk memulai.</small></div>';
  } else {
    list.innerHTML = sorted.map(task => `
      <article class="mv2-task ${task.done ? 'is-done' : ''}">
        <label class="mv2-task-check">
          <input type="checkbox" data-task-action="toggle" data-task-id="${escapeHtml(task.id)}" ${task.done ? 'checked' : ''} />
          <span></span>
        </label>
        <div><b>${escapeHtml(task.title)}</b><small>${formatDue(task.dueAt)} · ${relativeDue(task.dueAt)}</small></div>
        <button type="button" data-task-action="speak" data-task-id="${escapeHtml(task.id)}" aria-label="Bacakan tugas"><i data-fa="volume-high"></i></button>
        <button type="button" data-task-action="delete" data-task-id="${escapeHtml(task.id)}" aria-label="Hapus tugas"><i data-fa="xmark"></i></button>
      </article>`).join('');
  }
  const pending = tasks.filter(item => !item.done).length;
  setText('#matus-task-count', `${pending} aktif`);
  setText('#matus-mem-count', `${tasks.length} tugas ${syncChatId ? 'tersinkron bersama pasangan' : 'tersimpan aman di perangkat ini'}.`);
  setDefaultDue();
}

function updateBriefingStats() {
  const pending = tasks.filter(item => !item.done).sort(sortTasks);
  setText('#matus-briefing-count', String(pending.length));
  setText('#matus-next-task', pending[0] ? pending[0].title : 'Jadwalmu tenang');
  setText('#matus-next-time', pending[0] ? formatDue(pending[0].dueAt) : 'Tambahkan pengingat baru');
}

function setDefaultDue() {
  const input = $('#matus-task-due');
  if (!input || input.value) return;
  const next = new Date(Date.now() + 30 * 60_000);
  next.setSeconds(0, 0);
  input.value = localDateTimeValue(next);
}

function checkDueTasks() {
  const now = Date.now();
  const due = tasks.filter(item => !item.done && !item.remindedAt && new Date(item.dueAt).getTime() <= now);
  if (!due.length) return;
  due.forEach(item => { item.remindedAt = new Date().toISOString(); });
  saveTasks();
  const first = due[0];
  const extra = due.length > 1 ? ` Ada ${due.length - 1} tugas lain yang juga menunggu.` : '';
  const message = `${firstName()}, waktunya ${first.title}.${extra} Ayo gerak. Jangan bikin gua ngingetin berkali-kali.`;
  appendBotMessage(message);
  notify(`Pengingat: ${first.title}`, 7000);
  speak(message, { force: true });
  showTaskNotification(first);
}

async function enableNotifications() {
  if (!('Notification' in window)) return notify('Browser tidak mendukung notifikasi');
  const result = Notification.permission === 'granted' ? 'granted' : await Notification.requestPermission();
  renderNotificationPermission();
  notify(result === 'granted' ? 'Notifikasi pengingat aktif' : 'Izin notifikasi belum diberikan');
}

function renderNotificationPermission() {
  const button = $('#matus-notify-btn');
  if (!button) return;
  const granted = 'Notification' in window && Notification.permission === 'granted';
  const label = button.querySelector('span');
  if (label) label.textContent = granted ? 'Notifikasi aktif' : 'Aktifkan notifikasi';
  else button.insertAdjacentHTML('beforeend', `<span>${granted ? 'Notifikasi aktif' : 'Aktifkan notifikasi'}</span>`);
  button.classList.toggle('is-active', granted);
}

async function showTaskNotification(task) {
  if (!('Notification' in window) || Notification.permission !== 'granted') return;
  const options = { body: `${task.title} · Matus siap menemanimu.`, tag: `matus-task-${task.id}`, icon: '/assets/matus-character.webp', badge: '/icon-192.png' };
  try {
    const registration = await navigator.serviceWorker?.ready;
    if (registration) await registration.showNotification('Pengingat dari Matus', options);
    else new Notification('Pengingat dari Matus', options);
  } catch {
    // In-app reminder and voice remain available.
  }
}

function toggleListening() {
  const Recognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!Recognition) return notify('Pengenalan suara belum didukung browser ini');
  if (recognition) {
    recognition.stop();
    return;
  }
  recognition = new Recognition();
  recognition.lang = 'id-ID';
  recognition.interimResults = true;
  recognition.continuous = false;
  let finalText = '';
  $('#matus-mic')?.classList.add('is-listening');
  setText('#matus-status', 'Mendengarkanmu…');setText('#matus-header-mode','MENDENGAR');setText('#matus-voice-state','Mendengarkan kamu…');
  recognition.onresult = event => {
    let transcript = '';
    for (let index = 0; index < event.results.length; index += 1) transcript += event.results[index][0].transcript;
    $('#ai-input').value = transcript;
    if (event.results[event.results.length - 1].isFinal) finalText = transcript;
  };
  recognition.onerror = () => notify('Suaramu belum terdengar jelas. Coba lagi ya');
  recognition.onend = () => {
    recognition = null;
    $('#matus-mic')?.classList.remove('is-listening');
    setText('#matus-status', window.__appCoupleMatusIdleStatus || 'Online · siap mendengar dan berbicara');
    if (finalText.trim()) $('#ai-form')?.requestSubmit();
  };
  recognition.start();
}

function askCapability(capability) {
  const prompts = {
    finance: 'Cek saldo, pemasukan, pengeluaran, dan transaksi terbaru gua. Omelin kalau ada yang nggak sehat.',
    briefing:'Cek semua kondisi aplikasi gua: keuangan, tugas, Celengan Cinta, Maps, Couple Space, dan kenangan.',
    guide: 'Gua bingung mulai dari mana. Pilihin satu langkah paling penting sekarang.',
    reminder: 'Susun tugas penting gua dan tentukan mana yang harus dikerjain dulu.',
    write: 'Bikinin ucapan buat pasangan gua yang natural dan nggak lebay.'
  };
  const input = $('#ai-input');
  if (!input) return;
  input.value = prompts[capability] || prompts.guide;
  input.focus();
  $('#ai-form')?.requestSubmit();
}

function localReply(message) {
  const value = String(message || '').toLowerCase();
  const name = firstName();
  const pending = tasks.filter(item => !item.done).sort(sortTasks);
  const perms = getMatusPerms();
  const f=window.__appCoupleFinanceSummary||{},s=window.__appCoupleSavingsSummary||{},m=window.__appCoupleMapSummary||{},g=memorySummary(),trip=window.__appCoupleTripContext||null,currentLocation=window.__appCoupleMatusLocation||null;
  const history=perms.chat?[...document.querySelectorAll('#ai-messages .message')].filter(node=>!node.dataset.pending&&node.textContent&&!/Bentar\. Gua sedang/i.test(node.textContent)).slice(-6).map(node=>`${node.classList.contains('user')?'Lu':'Matus'}: ${node.textContent.trim().slice(0,180)}`):[];
  if(/histori|sebelumnya|kemarin|tadi|janji|ingat/.test(value))return history.length?`Frontalnya begini: histori terakhir yang bisa gua baca adalah ${history.slice(-3).join(' | ')}. Kalau ada janji atau keputusan yang belum gua sebut, berarti belum tersimpan atau izin histori belum aktif.`:'Gua belum punya histori yang bisa dibaca. Aktifkan izin Percakapan dengan Matus dulu, jangan minta gua mengingat sesuatu yang memang belum dikasih.';
  if (/semua|kondisi aplikasi|briefing|ringkasan/.test(value)) {
    const parts=[`${name}, nih gua ringkas.`];
    if(perms.finance)parts.push(`Keuangan: masuk ${rupiah(f.income)}, keluar ${rupiah(f.expense)}, sisa ${rupiah(f.balance)}.`);
    if(perms.savings)parts.push(`Celengan Cinta ${rupiah(s.total)} dari ${rupiah(s.target)}.`);
    if(perms.location)parts.push(`Maps ${m.meLive&&m.partnerLive?'kalian berdua aktif':m.meLive?'cuma lokasi lu yang aktif':'belum aktif lengkap'}.`);
    if(perms.memories)parts.push(`Kenangan ada ${Number(g.count)||0}.`);
    if(perms.activity&&trip?.plan?.destination)parts.push(`Jalan Berdua ke ${trip.plan.destination} punya ${trip.itinerary?.length||0} agenda dan ${(trip.routeInsights||[]).reduce((sum,item)=>sum+(item.warnings?.length||0),0)} lokasi yang perlu diperjelas.`);
    parts.push(`Tugas aktif ${pending.length}. Sekarang fokus ke ${pending[0]?.title||'satu hal kecil yang paling penting'}.`);
    return parts.join(' ');
  }
  if (/itinerary|jalan berdua|rencana perjalanan|rencana liburan|agenda perjalanan|jadwal liburan|rute perjalanan/.test(value)){
    if(!perms.activity)return'Gua belum punya izin baca Couple Space dan Jalan Berdua. Aktifkan izin Aktivitas kalau mau gua analisis itinerary lu.';
    if(!trip?.plan?.destination)return'Itinerary Jalan Berdua belum tersedia. Isi tujuan dan agenda dulu, lalu tekan Analisis Matus.';
    const itinerary=Array.isArray(trip.itinerary)?trip.itinerary:[],routes=Array.isArray(trip.routeInsights)?trip.routeInsights:[],warnings=routes.flatMap(item=>item.warnings||[]),conflicts=routes.reduce((sum,item)=>sum+(Number(item.conflicts)||0),0),next=itinerary.slice().sort((a,b)=>Number(a.day)-Number(b.day)||String(a.time||'').localeCompare(String(b.time||'')))[0];
    const status=warnings.length?`${warnings.length} lokasi masih perlu diperjelas, termasuk ${warnings[0].place||warnings[0].title||'satu agenda'}.`:conflicts?`Ada ${conflicts} potensi jadwal bertabrakan.`:'Rute yang sudah dianalisis belum menunjukkan konflik.';
    return `Rencana lu ${trip.plan.origin||'titik awal'} ke ${trip.plan.destination}, ${trip.plan.days||0} hari, dengan ${itinerary.length} agenda. ${next?`Agenda pertama Hari ${next.day} jam ${next.time||'belum diatur'}: ${next.title||'agenda'} di ${next.place||'lokasi belum diisi'}. `:''}${status}`;
  }
  if (/tugas|pengingat|jadwal|prioritas/.test(value)) {
    if (!pending.length) return `${name}, jadwal lu kosong. Bagus, tapi jangan lengah. Tambahin pengingat sekarang biar gua bisa ngejar lu tepat waktu.`;
    return `${name}, kerjain "${pending[0].title}" dulu. Itu paling dekat. Jangan buka sepuluh hal sekaligus, kelarin satu ini lalu centang.`;
  }
  if (/uang|keuangan|saldo|hemat|anggaran|pemasukan|pengeluaran/.test(value)) return perms.finance?`${name}, angka bulan ini: masuk ${rupiah(f.income)}, keluar ${rupiah(f.expense)}, sisa ${rupiah(f.balance)}. ${Number(f.balance)<0?'Lu lagi minus. Stop belanja nonwajib dan buka laporan kategori sekarang.':'Masih aman, tapi jangan ngerasa kebal. Cek kategori terbesar sebelum belanja lagi.'}`:`Gua belum punya izin baca keuangan lu. Aktifkan izin Keuangan di Pengaturan Matus kalau memang mau gua cek.`;
  if (/celengan|tabungan|target/.test(value))return perms.savings?`Celengan Cinta lu sekarang ${rupiah(s.total)} dari ${rupiah(s.target)} atau sekitar ${Number(s.target)?Math.round(Number(s.total)/Number(s.target)*100):0} persen. ${Number(s.target)?'Setor rutin lebih penting daripada nunggu nominal besar.':'Targetnya belum ada. Atur dulu, jangan nabung tanpa arah.'}`:'Gua belum punya izin baca Celengan Cinta. Aktifkan izinnya kalau mau gua bantu pantau.';
  if (/alamat|berada|posisi sekarang|lokasi sekarang|lagi di|di mana|dimana/.test(value))return !perms.location?'Izin lokasi Matus lagi mati. Gua nggak akan menebak atau membaca posisi lu.':currentLocation?.address?`Lu sedang berada di sekitar ${currentLocation.address}. Akurasinya kira-kira ${currentLocation.accuracy||'—'} meter dan data ini aktif sampai 15 menit sejak dibaca.`:'Gua belum membaca lokasi lu. Buka Pengaturan Matus, lalu tekan Gunakan lokasi saya kalau memang mau gua tahu.';
  if (/maps|map|lokasi|jarak/.test(value))return perms.location?`Maps berdua ${m.meLive&&m.partnerLive?'aktif untuk kalian berdua. Jaraknya '+(m.distance||'sedang dihitung'):m.meLive?'lokasi lu aktif, pasangan belum berbagi':'belum aktif lengkap'}. Kalau nggak butuh, biarin privat. Kalau lagi perjalanan, aktifkan durasi secukupnya.`:'Izin Maps lagi mati, jadi gua nggak akan menebak posisi siapa pun.';
  if (/kencan|pasangan|sayang|pesan|ucapan/.test(value)) return `Bilang begini: "Gua mungkin nggak selalu pinter ngomong, tapi gua selalu menghargai hal kecil yang kita jalanin bareng. Makasih udah tetap ada." Simpel, nggak lebay.`;
  if (/bingung|sedih|capek|lelah|mulai|arahkan/.test(value)) return `${name}, gua dengerin. Nggak usah beresin semuanya sekarang. Tarik napas, pilih satu hal yang bisa selesai sepuluh menit, kerjain, lalu balik ke gua.`;
  if (/halo|hai|pagi|siang|sore|malam/.test(value)) return `${dayGreeting()}, ${name}. Gua di sini. Mau curhat, cek duit, cek tugas, atau ngobrol receh juga boleh. Langsung bilang aja.`;
  if (/siapa kamu|tentang kamu|kamu siapa/.test(value)) return `Gua Matus, otak dan pengingat AppCouple lu. Gua cuma baca ${contextLabel().join(', ')||'data yang lu izinkan'}, plus tugas yang lu kasih ke gua.`;
  if (/curhat|cerita|dengerin|temani|ngobrol/.test(value)) return `${name}, cerita aja. Gua nggak bakal motong atau sok paling tahu. Bagian mana yang paling bikin kepala lu penuh?`;
  if (/ide|kreatif|inspirasi|brainstorm/.test(value)) return `Siap, kita brainstorming bareng. Kasih aku topik, tujuan, dan batasannya kalau ada. Nanti aku bantu cari beberapa arah yang beda, bukan jawaban template.`;
  return `${name}, gua nangkep topiknya, tapi datanya kurang. Bilang hasil yang lu mau dalam satu kalimat, jangan muter-muter, nanti gua bantu beresin.`;
}

function memorySummary(){try{return window.__appCoupleDriveGallery?.summary?.()||window.__appCoupleMemoriesSummary||{}}catch{return window.__appCoupleMemoriesSummary||{}}}
function updateAppMemoryDashboard(){const p=getMatusPerms(),f=window.__appCoupleFinanceSummary||{},s=window.__appCoupleSavingsSummary||{},m=window.__appCoupleMapSummary||{},g=memorySummary();setText('#matus-saldo',p.finance?rupiah(f.balance):'Privat');setText('#matus-income',p.finance?rupiah(f.income):'Privat');setText('#matus-expense',p.finance?rupiah(f.expense):'Privat');setText('#matus-savings',p.savings?rupiah(s.total):'Privat');setText('#matus-map-state',p.location?(m.meLive&&m.partnerLive?(m.distance||'Berdua live'):m.meLive?'Lu live':'Privat'):'Privat');setText('#matus-memory-count',p.memories?`${Number(g.count)||0} foto`:'Privat');const mapCard=$('#matus-map-state')?.closest('.m5-context-card');mapCard?.classList.toggle('live',p.location&&!!(m.meLive||m.partnerLive));}

function appendBotMessage(text,kind='reminder') {
  const messages = $('#ai-messages');
  if (!messages) return;
  const node = document.createElement('div');
  node.className = `message bot mv2-${kind}-message`;
  node.title='Ketuk untuk dengarkan ulang';
  node.textContent = text;
  messages.appendChild(node);
  messages.scrollTop = messages.scrollHeight;
}

async function copyLastReply() {
  const bots = $$('.message.bot', $('#ai-messages'));
  const text = bots.at(-1)?.textContent?.trim();
  if (!text) return notify('Belum ada jawaban untuk disalin');
  try {
    await navigator.clipboard.writeText(text);
    notify('Jawaban Matus disalin');
  } catch {
    notify('Jawaban tidak dapat disalin');
  }
}

async function clearConversation() {
  const messages = $('#ai-messages');
  if (!messages) return;
  if(!confirm('Hapus seluruh riwayat Matus bersama? Riwayat akan hilang dari perangkat pasangan juga.'))return;
  const buttons=[$('#matus-clear'),$('#matus-mem-clear')].filter(Boolean);buttons.forEach(button=>{button.disabled=true;button.setAttribute('aria-busy','true')});
  stopSpeaking();
  try{
    if(!demoMode){
      if(!syncApi||!syncChatId)throw new Error('Sinkronisasi Couple Space belum siap. Muat ulang aplikasi lalu coba lagi.');
      await syncApi.clearCoupleMatusMessages(syncChatId);
    }
    messages.innerHTML=`<div class="message bot">Hai ${escapeHtml(firstName())}! Riwayat bersama sudah dihapus. Kita mulai percakapan baru, ya.</div>`;
    messages.dataset.matusSynced='1';renderedMatusIds=new Set();notify('Riwayat Matus bersama berhasil dihapus');
  }catch(error){notify(error.message||'Riwayat belum dapat dihapus')}
  finally{buttons.forEach(button=>{button.disabled=false;button.removeAttribute('aria-busy')})}
}

function sortTasks(a, b) {
  if (a.done !== b.done) return a.done ? 1 : -1;
  return new Date(a.dueAt).getTime() - new Date(b.dueAt).getTime();
}

function formatDue(value) {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return 'Waktu belum ditentukan';
  return new Intl.DateTimeFormat('id-ID', { weekday: 'short', day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }).format(date);
}

function relativeDue(value) {
  const diff = new Date(value).getTime() - Date.now();
  const abs = Math.abs(diff);
  const minutes = Math.max(1, Math.round(abs / 60_000));
  if (diff < 0) return `terlambat ${minutes < 60 ? `${minutes} menit` : `${Math.round(minutes / 60)} jam`}`;
  if (minutes < 60) return `dalam ${minutes} menit`;
  const hours = Math.round(minutes / 60);
  if (hours < 24) return `dalam ${hours} jam`;
  return `dalam ${Math.round(hours / 24)} hari`;
}

function localDateTimeValue(date) {
  const offset = date.getTimezoneOffset() * 60_000;
  return new Date(date.getTime() - offset).toISOString().slice(0, 16);
}

function cleanSpeech(value) {
  return String(value || '')
    .replace(/<[^>]+>/g, ' ')
    .replace(/https?:\/\/\S+/g, '')
    .replace(/[*_#`>|]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function summarize(value, max) {
  const text = String(value || '').trim();
  return text.length > max ? `${text.slice(0, max - 1).trim()}…` : text;
}

function rupiah(value) {
  return new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', maximumFractionDigits: 0 }).format(Number(value) || 0);
}

function setText(selector, value) {
  const node = $(selector);
  if (node) node.textContent = value;
}

function escapeHtml(value) {
  return String(value || '').replace(/[&<>'"]/g, character => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' })[character]);
}

renderNotificationPermission();
