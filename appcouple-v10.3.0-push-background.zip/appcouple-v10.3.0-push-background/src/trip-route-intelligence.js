const cache=new Map();
const wait=ms=>new Promise(resolve=>setTimeout(resolve,ms));
const clean=(value,max=180)=>String(value||'').trim().slice(0,max);
const minutesFromDuration=value=>{
  const text=clean(value,40).toLowerCase().replace(',','.');
  const hours=Number((text.match(/(\d+(?:\.\d+)?)\s*(?:jam|hour|h)/)||[])[1]||0);
  const minutes=Number((text.match(/(\d+(?:\.\d+)?)\s*(?:menit|min|m)\b/)||[])[1]||0);
  return Math.max(0,Math.round(hours*60+minutes));
};
const clockToMinutes=value=>{const [h,m]=String(value||'00:00').split(':').map(Number);return(Number.isFinite(h)?h:0)*60+(Number.isFinite(m)?m:0)};
const clock=value=>{const minutes=((Math.round(value)%1440)+1440)%1440;return`${String(Math.floor(minutes/60)).padStart(2,'0')}.${String(minutes%60).padStart(2,'0')}`};
const modeFrom=value=>{const text=clean(value,60).toLowerCase();if(/jalan|kaki/.test(text))return'WALK';if(/sepeda/.test(text))return'BICYCLE';if(/motor|ojek/.test(text))return'TWO_WHEELER';return'DRIVE'};
const hash=text=>[...String(text)].reduce((sum,char)=>(sum*31+char.charCodeAt(0))>>>0,2166136261);
const demoRoute=(origin,destination,mode)=>{
  const n=hash(`${origin}|${destination}`),km=Math.max(1.2,Math.round((3+(n%270)/10)*10)/10),speed=mode==='WALK'?4.5:mode==='BICYCLE'?14:mode==='TWO_WHEELER'?30:26;
  const normal=Math.max(5,Math.round(km/speed*60)),factor=mode==='WALK'||mode==='BICYCLE'?1:1.08+(n%25)/100;
  return{provider:'Simulasi demo',trafficAware:false,distanceMeters:Math.round(km*1000),durationSeconds:Math.round(normal*factor*60),staticDurationSeconds:normal*60,travelMode:mode};
};
const geocodeKey=value=>clean(value).toLowerCase().replace(/\s+/g,' ');
function geocodeCandidates(address,context=''){
  const input=clean(address),area=clean(context),candidates=[input];
  const routeParts=input.split(/\s+(?:-|–|—|→|ke)\s+/i).map(part=>clean(part)).filter(Boolean);
  if(routeParts.length>1)candidates.push(routeParts.at(-1),routeParts[0]);
  if(area)for(const candidate of [...candidates])if(candidate&&!candidate.toLowerCase().includes(area.toLowerCase()))candidates.push(`${candidate}, ${area}`);
  return[...new Set(candidates.filter(Boolean))];
}
async function geocode(address,context=''){
  const original=clean(address),originalKey=geocodeKey(original);if(cache.has(originalKey))return cache.get(originalKey);
  let stored={};try{stored=JSON.parse(localStorage.getItem('ac_trip_geocode_v1')||'{}')||{}}catch{}if(stored[originalKey]){cache.set(originalKey,stored[originalKey]);return stored[originalKey]}
  for(const query of geocodeCandidates(original,context)){
    const key=geocodeKey(query);if(cache.has(key)){const point=cache.get(key);cache.set(originalKey,point);return point}if(stored[key]){cache.set(key,stored[key]);cache.set(originalKey,stored[key]);return stored[key]}
    try{
      const response=await fetch('https://nominatim.openstreetmap.org/search?format=json&limit=1&countrycodes=id&q='+encodeURIComponent(query),{headers:{'Accept-Language':'id-ID,id;q=0.9'},signal:AbortSignal.timeout(10000)});
      const item=(await response.json().catch(()=>[]))[0];
      if(response.ok&&item){
        const point={lat:Number(item.lat),lng:Number(item.lon),label:clean(item.display_name||query,220),matchedQuery:query};cache.set(key,point);cache.set(originalKey,point);
        try{localStorage.setItem('ac_trip_geocode_v1',JSON.stringify({...stored,[key]:point,[originalKey]:point}))}catch{}
        await wait(1050);return point;
      }
    }catch{}
    await wait(1050);
  }
  throw Error(`Lokasi “${original}” belum ditemukan. Tambahkan nama kota atau alamat yang lebih spesifik.`);
}
function estimatedModeDuration(distanceMeters,mode,osrmSeconds){
  const km=Math.max(0,Number(distanceMeters)||0)/1000;
  if(mode==='WALK')return Math.max(60,Math.round(km/4.5*3600));
  if(mode==='BICYCLE')return Math.max(60,Math.round(km/14*3600));
  return Math.max(60,Math.round(Number(osrmSeconds)||0));
}
async function fallbackRoute(originName,destinationName,mode,context=''){
  const origin=await geocode(originName,context),destination=await geocode(destinationName,context);
  const url=`https://router.project-osrm.org/route/v1/driving/${origin.lng},${origin.lat};${destination.lng},${destination.lat}?overview=false&steps=false`;
  const response=await fetch(url,{signal:AbortSignal.timeout(12000)}),data=await response.json().catch(()=>({})),route=data.routes?.[0];
  if(!response.ok||!route)throw Error('Rute jalan belum dapat dihitung');
  const durationSeconds=estimatedModeDuration(route.distance,mode,route.duration),modeEstimate=mode==='WALK'||mode==='BICYCLE';
  return{provider:modeEstimate?'OpenStreetMap + OSRM · estimasi moda':'OpenStreetMap + OSRM',trafficAware:false,origin,destination,distanceMeters:Math.round(route.distance),durationSeconds,staticDurationSeconds:durationSeconds,travelMode:mode};
}
const trafficLevel=(duration,normal,aware)=>{
  if(!aware)return{key:'unknown',label:'Estimasi rute gratis'};
  const ratio=normal?duration/normal:1;
  if(ratio>=1.45)return{key:'heavy',label:'Padat'};
  if(ratio>=1.18)return{key:'medium',label:'Padat sedang'};
  return{key:'light',label:'Lancar'};
};

export async function analyzeTripDayRoutes({entries=[],origin='',destinationContext='',day=1,demo=false,onProgress=()=>{}}={}){
  const sorted=entries.slice().sort((a,b)=>String(a.time||'').localeCompare(String(b.time||''))),legs=[],warnings=[];let previousPlace=clean(origin)||clean(sorted[0]?.place)||'Titik awal perjalanan',previousEnd=null;
  for(let index=0;index<sorted.length;index++){
    const item=sorted[index],destination=clean(item.place);if(!destination){warnings.push({itemId:item.id,title:clean(item.title)||`Agenda ${index+1}`,place:'',message:'Nama lokasi belum diisi'});continue}
    onProgress({index,total:sorted.length,item});
    const mode=modeFrom(item.transport);
    let route;
    try{route=demo?demoRoute(previousPlace,destination,mode):await fallbackRoute(previousPlace,destination,mode,destinationContext)}catch(error){
      warnings.push({itemId:item.id,title:clean(item.title)||`Agenda ${index+1}`,origin:previousPlace,place:destination,message:clean(error.message,240)||'Rute belum dapat dihitung'});
      previousPlace=destination;const agendaStart=clockToMinutes(item.time||'09:00');previousEnd=agendaStart+minutesFromDuration(item.duration)||agendaStart;continue;
    }
    const duration=Math.max(1,Math.ceil(Number(route.durationSeconds||0)/60)),normal=Math.max(1,Math.ceil(Number(route.staticDurationSeconds||route.durationSeconds||0)/60)),agendaStart=clockToMinutes(item.time||'09:00'),buffer=10,departAt=agendaStart-duration-buffer,arriveAt=departAt+duration,agendaDuration=minutesFromDuration(item.duration),agendaEnd=agendaStart+agendaDuration,traffic=trafficLevel(duration,normal,route.trafficAware),conflict=previousEnd!==null&&previousEnd>departAt;
    legs.push({itemId:item.id,origin:previousPlace,destination,distanceKm:Math.round(Number(route.distanceMeters||0)/100)/10,durationMinutes:duration,normalMinutes:normal,departAt:clock(departAt),arriveAt:clock(arriveAt),agendaStart:clock(agendaStart),agendaEnd:agendaDuration?clock(agendaEnd):'',bufferMinutes:buffer,trafficKey:traffic.key,trafficLabel:traffic.label,trafficAware:!!route.trafficAware,provider:route.provider||'Rute estimasi',travelMode:mode,conflict});
    previousPlace=destination;previousEnd=agendaEnd||agendaStart;
  }
  const totalKm=Math.round(legs.reduce((sum,leg)=>sum+leg.distanceKm,0)*10)/10,totalMinutes=legs.reduce((sum,leg)=>sum+leg.durationMinutes,0),conflicts=legs.filter(leg=>leg.conflict).length,heavy=legs.filter(leg=>leg.trafficKey==='heavy').length,live=legs.some(leg=>leg.trafficAware);
  return{day,analyzedAt:new Date().toISOString(),provider:'OpenStreetMap + OSRM + Matus',trafficLive:false,requestedLegs:sorted.filter(item=>clean(item.place)).length,totalKm,totalMinutes,conflicts,heavy,warnings,legs};
}

export function routeInsightFallback(result){
  const warnings=Array.isArray(result?.warnings)?result.warnings:[];
  if(!result?.legs?.length)return warnings.length?`Belum ada rute yang berhasil dihitung. ${warnings.length} lokasi perlu diperjelas; tambahkan nama kota atau alamat.`:'Belum ada lokasi yang bisa dianalisis pada hari ini.';
  const status=result.conflicts?`${result.conflicts} jadwal berpotensi bertabrakan.`:result.heavy?`${result.heavy} perjalanan diperkirakan padat.`:'Urutan perjalanan masih memiliki jeda yang aman.';
  const warningCopy=warnings.length?` ${warnings.length} rute belum dihitung karena lokasinya perlu diperjelas.`:'';
  return `Matus menghitung ${result.legs.length} perjalanan sejauh sekitar ${result.totalKm} km dengan total waktu di jalan ${result.totalMinutes} menit. ${status}${warningCopy} Durasi dihitung dari rute jalan gratis; klik nama lokasi untuk memeriksa kondisi macet aktual di Google Maps.`;
}