export const supabaseConfig=Object.freeze({
  url:'https://jealpadqntedumedxjsg.supabase.co',
  publishableKey:'sb_publishable_8XtMD9uGM5Dfd4no6HfD7Q_Ki-p4hyq'
});
