/* AppCouple 7.3 — satu sumber kebenaran untuk dark/light mode. */
const STORAGE_KEY='ac_theme';
const VALID=new Set(['light','dark']);
let current='light';

function preferredTheme(){
  const stored=localStorage.getItem(STORAGE_KEY);
  if(VALID.has(stored))return stored;
  return matchMedia?.('(prefers-color-scheme: dark)').matches?'dark':'light';
}

export function syncThemeControls(){
  const dark=current==='dark';
  document.querySelectorAll('[data-settings-theme]').forEach(button=>{
    const active=button.dataset.settingsTheme===current;
    button.classList.toggle('active',active);
    button.setAttribute('aria-pressed',String(active));
  });
  const quick=document.querySelector('#quick-theme-toggle');if(quick){quick.setAttribute('aria-pressed',String(dark));quick.setAttribute('aria-label',dark?'Aktifkan mode terang':'Aktifkan mode gelap');quick.title=dark?'Mode terang':'Mode gelap'}
  const matus=document.querySelector('#m26-theme-toggle');if(matus){matus.setAttribute('aria-pressed',String(dark));matus.setAttribute('aria-label',dark?'Aktifkan mode terang':'Aktifkan mode gelap');matus.title=dark?'Mode terang':'Mode gelap'}
  const toggle=document.querySelector('#theme-toggle');
  if(toggle){
    toggle.setAttribute('aria-pressed',String(dark));
    toggle.setAttribute('aria-label',dark?'Aktifkan mode terang':'Aktifkan mode gelap');
    toggle.title=dark?'Ubah ke mode terang':'Ubah ke mode gelap';
  }
}

export function setAppTheme(mode,{persist=true,announce=true}={}){
  const next=VALID.has(mode)?mode:'light';
  const changed=current!==next;
  current=next;
  const dark=next==='dark';
  document.body.classList.toggle('dark',dark);
  document.documentElement.dataset.theme=next;
  document.documentElement.style.colorScheme=next;
  document.querySelector('meta[name="theme-color"]')?.setAttribute('content',dark?'#141419':'#f5f4f1');
  if(persist)localStorage.setItem(STORAGE_KEY,next);
  syncThemeControls();
  if(changed)window.dispatchEvent(new CustomEvent('appcouple:theme-changed',{detail:{theme:next,dark,announce}}));
  return next;
}

export function toggleAppTheme(){return setAppTheme(current==='dark'?'light':'dark')}
export function getAppTheme(){return current}
export function initializeTheme(){
  current=preferredTheme();
  setAppTheme(current,{persist:false,announce:false});
  try{
    const media=matchMedia('(prefers-color-scheme: dark)');
    media.addEventListener?.('change',event=>{if(!localStorage.getItem(STORAGE_KEY))setAppTheme(event.matches?'dark':'light',{persist:false,announce:false})});
  }catch{}
  return current;
}
