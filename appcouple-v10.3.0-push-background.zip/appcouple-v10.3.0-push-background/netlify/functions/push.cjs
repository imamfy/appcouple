const webpush=require('web-push');
const crypto=require('crypto');
const {authorize,rateLimit}=require('./lib/access.cjs');

const json=(status,body)=>({statusCode:status,headers:{'content-type':'application/json; charset=utf-8','cache-control':'no-store'},body:JSON.stringify(body)});
const env=name=>String(process.env[name]||'').trim();
const fail=(status,message,code='push_error')=>{throw Object.assign(new Error(message),{status,code})};
const clean=(value,max=200)=>String(value??'').trim().slice(0,max);
const allowedIds=()=>env('APPCOUPLE_ALLOWED_USER_IDS').split(',').map(x=>x.trim()).filter(Boolean);

function parseBody(event){
  let raw=event.body||'';
  if(event.isBase64Encoded)raw=Buffer.from(raw,'base64').toString('utf8');
  if(Buffer.byteLength(raw)>16*1024)fail(413,'Payload push terlalu besar.','too_large');
  try{return raw?JSON.parse(raw):{}}catch{fail(400,'Format data push tidak valid.','invalid_json')}
}

function pushConfig(){
  const publicKey=env('VAPID_PUBLIC_KEY'),privateKey=env('VAPID_PRIVATE_KEY');
  if(!publicKey||!privateKey)fail(503,'VAPID belum dikonfigurasi di Netlify.','push_config');
  webpush.setVapidDetails(env('VAPID_SUBJECT')||'mailto:admin@appcouple.local',publicKey,privateKey);
  return{publicKey}
}

function supabaseConfig(){
  const url=env('SUPABASE_URL').replace(/\/$/,''),key=env('SUPABASE_SERVICE_ROLE_KEY');
  if(!/^https:\/\//.test(url)||!key)fail(503,'SUPABASE_URL dan SUPABASE_SERVICE_ROLE_KEY wajib diisi di Netlify.','push_config');
  return{url,key}
}

async function db(path,{method='GET',body,prefer}={}){
  const {url,key}=supabaseConfig(),headers={apikey:key,authorization:'Bearer '+key};
  if(body!==undefined)headers['content-type']='application/json';
  if(prefer)headers.prefer=prefer;
  const response=await fetch(url+'/rest/v1/'+path,{method,headers,body:body===undefined?undefined:JSON.stringify(body),signal:AbortSignal.timeout(8000)});
  if(!response.ok){console.error('push db',response.status,await response.text().catch(()=>''));fail(502,'Penyimpanan push gagal.','push_storage')}
  const text=await response.text();return text?JSON.parse(text):null
}

function validateSubscription(value={}){
  const endpoint=clean(value.endpoint,2048),p256dh=clean(value.keys?.p256dh,256),auth=clean(value.keys?.auth,128);
  let url;try{url=new URL(endpoint)}catch{}
  if(!url||url.protocol!=='https:'||!p256dh||!auth)fail(400,'Subscription push tidak valid.','invalid_subscription');
  return{endpoint,p256dh,auth}
}

async function subscribe(user,body){
  const sub=validateSubscription(body.subscription),endpointHash=crypto.createHash('sha256').update(sub.endpoint).digest('hex');
  await db('push_subscriptions?on_conflict=endpoint_hash',{method:'POST',prefer:'resolution=merge-duplicates,return=minimal',body:{endpoint_hash:endpointHash,user_id:user.id,endpoint:sub.endpoint,p256dh:sub.p256dh,auth:sub.auth,user_agent:clean(body.userAgent,240),updated_at:new Date().toISOString()}});
  return{status:'active'}
}

async function unsubscribe(user,body){
  const endpoint=clean(body.endpoint,2048);
  if(endpoint)await db('push_subscriptions?user_id=eq.'+encodeURIComponent(user.id)+'&endpoint=eq.'+encodeURIComponent(endpoint),{method:'DELETE'});
  return{status:'inactive'}
}

async function removeEndpoint(endpoint){
  const hash=crypto.createHash('sha256').update(endpoint).digest('hex');
  await db('push_subscriptions?endpoint_hash=eq.'+hash,{method:'DELETE'}).catch(()=>{});
}

async function send(user,body){
  const ids=allowedIds(),target=ids.find(id=>id!==user.id);
  if(!target)fail(409,'Akun pasangan belum dikonfigurasi.','partner_missing');
  const messageId=clean(body.messageId,80);
  if(!/^[0-9a-f-]{36}$/i.test(messageId))fail(400,'ID pesan tidak valid.','invalid_message');
  const profiles=await db('profiles?id=in.('+encodeURIComponent(user.id)+','+encodeURIComponent(target)+')&select=id,couple_id,name,notification_prefs');
  const senderProfile=profiles?.find(row=>row.id===user.id),targetProfile=profiles?.find(row=>row.id===target);
  if(!senderProfile?.couple_id||senderProfile.couple_id!==targetProfile?.couple_id)fail(403,'Akun bukan pasangan aktif.','forbidden');
  if(targetProfile.notification_prefs?.chat===false)return{status:'muted',sent:0};
  const messages=await db('messages?id=eq.'+encodeURIComponent(messageId)+'&sender_id=eq.'+encodeURIComponent(user.id)+'&couple_id=eq.'+encodeURIComponent(senderProfile.couple_id)+'&type=eq.text&select=id,text');
  const message=messages?.[0];
  if(!message)fail(404,'Pesan tidak ditemukan.','invalid_message');
  const rows=await db('push_subscriptions?user_id=eq.'+encodeURIComponent(target)+'&select=endpoint,p256dh,auth');
  if(!rows?.length)return{status:'no_subscription',sent:0};
  const sender=clean(senderProfile.name||user.user_metadata?.full_name||user.email?.split('@')[0]||'Pasangan',60);
  const payload=JSON.stringify({notification:{title:'Pesan baru dari '+sender,body:clean(message.text,160)||'Pasangan mengirim pesan'},data:{url:'/#couple',eventType:'chat-'+messageId}});
  let sent=0;
  await Promise.all(rows.map(async row=>{
    try{
      await webpush.sendNotification({endpoint:row.endpoint,keys:{p256dh:row.p256dh,auth:row.auth}},payload,{TTL:86400,urgency:'high',topic:('chat-'+messageId).slice(0,32)});
      sent++;
    }catch(error){
      if(error.statusCode===404||error.statusCode===410)await removeEndpoint(row.endpoint);
      else console.error('web push',error.statusCode||error.message);
    }
  }));
  return{status:sent?'sent':'failed',sent}
}

exports.handler=async event=>{
  try{
    const method=(event.httpMethod||'GET').toUpperCase(),action=clean(event.queryStringParameters?.action,24);
    if(method==='GET'&&action==='config')return json(200,{publicKey:pushConfig().publicKey});
    pushConfig();
    const user=await authorize(event);rateLimit(user.id,'push',90);
    const body=parseBody(event);
    if(method==='POST'&&action==='subscribe')return json(200,await subscribe(user,body));
    if(method==='DELETE'&&action==='unsubscribe')return json(200,await unsubscribe(user,body));
    if(method==='POST'&&action==='send')return json(200,await send(user,body));
    return json(404,{code:'not_found',detail:'Endpoint push tidak ditemukan.'});
  }catch(error){
    console.error('push',error.code||error.statusCode||'server_error');
    const exposed=['push_config','unauthorized','forbidden','rate_limit','too_large','invalid_json','invalid_subscription','invalid_message','partner_missing'];
    return json(error.status||500,{code:error.code||'server_error',detail:exposed.includes(error.code)?error.message:'Layanan push gagal. Coba lagi.'});
  }
};

exports._test={parseBody,validateSubscription};