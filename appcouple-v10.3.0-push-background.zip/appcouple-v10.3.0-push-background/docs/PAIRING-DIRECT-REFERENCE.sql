alter table public.couples add column if not exists invite_expires_at timestamptz;
create policy couples_pair_lookup_direct_v31617 on public.couples for select to authenticated using (invite_code is not null and (invite_expires_at is null or invite_expires_at > now()));
notify pgrst, 'reload schema';
