# AppCouple 13 — penyempurnaan tampilan
- Lingkup: AI OS, brankas, dan Sydas Sector; fungsi dan penyimpanan v12 dipertahankan.
- Empat kategori: Asisten, Keuangan, Memori, Keamanan. Desktop memakai navigasi samping; mobile memakai kategori dan pemilih fungsi, bukan 15 kartu horizontal.
- Header ringkas, aksen rose, ukuran teks lebih terbaca, kontrol sentuh minimal 44px.
- Brankas memiliki kondisi baru/terkunci/terbuka. Backup dan pemulihan berada dalam bagian tambahan yang dapat dibuka.
- Video menampilkan petunjuk sebelum pemutaran, bukan iframe kosong; error embed memiliki pesan dan tautan YouTube.
- Pengujian: navigasi kategori, simpan/buka/kunci brankas, iframe tersembunyi sebelum play, kegagalan katalog, serta overflow 390px dan 1440px berhasil. Screenshot mode terang/gelap diperiksa.
- Tidak mengaktifkan backend atau API secara otomatis. Keterbatasan deployment dan video live pada UPGRADE-12-README.md tetap berlaku.
