# Excel Integrity v31.6.20

Perbaikan berlaku untuk Wedding Command Center dan Jalan Berdua:
- karakter XML ilegal dibuang sebelum data dimasukkan ke workbook;
- ZIP OOXML dibuat sebagai byte array deterministik;
- tanda tangan `PK` diverifikasi sebelum file diunduh;
- seluruh CRC32 isi workbook diverifikasi melalui JSZip;
- object URL dipertahankan 30 detik agar unduhan tidak terpotong;
- cache aplikasi dinaikkan agar exporter lama tidak digunakan.

QA lokal:
- Wedding: 11 sheet, valid di OpenPyXL, JSZip CRC32, unzip, dan LibreOffice Calc;
- Jalan Berdua: 12 sheet, valid di OpenPyXL, JSZip CRC32, unzip, dan LibreOffice Calc.
