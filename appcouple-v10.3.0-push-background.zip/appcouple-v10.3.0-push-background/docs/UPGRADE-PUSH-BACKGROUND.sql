-- AppCouple 10.3.0 — Web Push subscriptions
-- Jalankan sekali di Supabase SQL Editor.

create table if not exists public.push_subscriptions(
  endpoint_hash text primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  endpoint text not null,
  p256dh text not null,
  auth text not null,
  user_agent text default '',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists push_subscriptions_user
  on public.push_subscriptions(user_id);

alter table public.push_subscriptions enable row level security;

-- Browser tidak membaca tabel ini secara langsung.
-- Netlify Function memakai SUPABASE_SERVICE_ROLE_KEY.
revoke all on public.push_subscriptions from anon, authenticated;

notify pgrst, 'reload schema';