# AppCouple v24 — Kenangan kembali ke Google Drive

## Perubahan utama
- File Kenangan (foto dan metadata) disimpan langsung di folder Google Drive lama.
- Daftar, pratinjau, unggah, edit cerita/judul, favorit, unduh, buka di Drive, dan hapus memakai Google Drive API.
- Supabase tetap dipakai untuk login AppCouple, keuangan, chat, dan fitur lain; **Supabase Storage/tabel memories tidak dipakai oleh Kenangan Drive**.
- Backend memvalidasi sesi AppCouple sebelum memberikan akses ke folder Drive.

## Instalasi Netlify
1. Deploy seluruh isi paket ini (jangan hanya `index.html`).
2. Di **Netlify → Site configuration → Environment variables**, hapus atau kosongkan `GOOGLE_DRIVE_FOLDER_ID` agar aplikasi otomatis membuat folder **AppCouple Kenangan**. Isi ID atau URL hanya jika ingin menggunakan folder tertentu.
3. Untuk Google Drive pribadi, pulihkan kredensial OAuth lama:
   - `GOOGLE_DRIVE_CLIENT_ID`
   - `GOOGLE_DRIVE_CLIENT_SECRET`
   - `GOOGLE_DRIVE_REFRESH_TOKEN`
4. Alternatif untuk Google Shared Drive: pasang `GOOGLE_DRIVE_SERVICE_ACCOUNT_JSON`, lalu bagikan folder kepada email service account sebagai Editor. Jangan memakai service account untuk folder My Drive pribadi jika akun tersebut tidak memiliki kuota.
5. Pastikan variabel autentikasi tersedia (biasanya sudah ada):
   - `SUPABASE_URL`
   - `SUPABASE_ANON_KEY` atau `SUPABASE_PUBLISHABLE_KEY`
6. Pastikan akun OAuth/service account dapat membuka folder tersebut. Shortcut folder juga didukung selama targetnya dapat diakses.
7. Trigger **Clear cache and deploy site**.
8. Login ke AppCouple → buka **Kenangan Drive** → tekan **Refresh**. Nama folder lama harus tampil dan tombol **Buka folder** harus aktif.

> Jangan kirim client secret, refresh token, atau JSON service account lewat chat. Masukkan langsung ke Environment variables Netlify.

## Pemeriksaan cepat
- Unggah satu foto uji berukuran di bawah 4 MB.
- Pastikan file muncul di folder Google Drive lama.
- Uji Favorit, Edit cerita, Unduh, Buka di Drive, lalu Hapus.
- Jika muncul pesan konfigurasi server, periksa nama variabel dan izin Editor pada folder.

## Data Kenangan yang telanjur berada di Supabase
Rilis ini tidak memindahkan atau menghapus data Supabase secara otomatis agar tidak terjadi kehilangan atau duplikasi. Jika ada foto yang hanya berada di Supabase, ekspor dahulu lalu unggah ke Kenangan Drive setelah v24 aktif. Jangan menghapus bucket/tabel lama sebelum seluruh file telah dicocokkan.

## Batasan keamanan
- Backend hanya mengizinkan operasi pada file yang merupakan anak langsung dari folder otomatis aplikasi atau folder yang dipilih melalui `GOOGLE_DRIVE_FOLDER_ID`.
- Unggahan dibatasi ke gambar JPEG, PNG, WebP, GIF, HEIC/HEIF maksimum 4 MB.
- Kredensial Google Drive hanya berada di Netlify Functions, tidak dikirim ke browser.
