# AppCouple Personal Security Setup

1. Deploy folder ini ke Netlify agar security headers aktif.
2. Buka Supabase SQL Editor dan jalankan seluruh `SUPABASE-SETUP-CURRENT.sql`.
3. Pastikan Google Auth hanya digunakan oleh akun pribadi Anda dan pasangan, serta aktifkan 2FA pada Google, Netlify, dan GitHub.
4. Setelah SQL dijalankan, bucket `memories` menjadi private. Aplikasi memakai signed URL 10 menit secara otomatis.
5. Jangan pernah memasukkan Service Role Key atau secret OAuth ke source frontend.
6. CSP masih Report-Only agar aplikasi CDN dan provider AI tidak rusak. Periksa laporan browser sebelum mengaktifkan CSP penuh.
