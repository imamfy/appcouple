-- AppCouple 7.9.0 — satu-satunya setup Supabase aktif. Aman dijalankan ulang.

-- AppCouple Next AI 3.8.0 — Supabase schema
-- Run once in Supabase Dashboard > SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.profiles(
 id uuid primary key references auth.users(id) on delete cascade,
 email text, name text not null default 'Pengguna', photo_url text default '',
 couple_id uuid, partner_id uuid, connection_date timestamptz,
 presence text default 'offline', last_active_at timestamptz,
 notification_prefs jsonb not null default '{}'::jsonb,
 created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table if not exists public.couples(
 id uuid primary key default gen_random_uuid(), invite_code text unique, invite_expires_at timestamptz,
 created_by uuid references auth.users(id), created_at timestamptz not null default now()
);
alter table public.couples add column if not exists invite_expires_at timestamptz;
alter table public.profiles drop constraint if exists profiles_couple_id_fkey;
alter table public.profiles add constraint profiles_couple_id_fkey foreign key(couple_id) references public.couples(id) on delete set null;

create or replace function public.is_couple_member(cid uuid) returns boolean language sql stable security definer set search_path=public as $$select exists(select 1 from profiles where id=auth.uid() and couple_id=cid)$$;
create or replace function public.handle_new_user() returns trigger language plpgsql security definer set search_path=public as $$begin insert into profiles(id,email,name,photo_url) values(new.id,new.email,coalesce(new.raw_user_meta_data->>'full_name',new.raw_user_meta_data->>'name',split_part(new.email,'@',1),'Pengguna'),coalesce(new.raw_user_meta_data->>'avatar_url','')) on conflict(id) do update set email=excluded.email,name=excluded.name,photo_url=excluded.photo_url,updated_at=now(); return new; end$$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert or update on auth.users for each row execute function public.handle_new_user();


create table if not exists public.transactions(id uuid primary key default gen_random_uuid(),user_id uuid not null references auth.users on delete cascade,type text not null check(type in('income','expense')),description text not null,amount numeric(16,2) not null check(amount>0),date date not null,category text not null default 'Lainnya',note text default '',client_id text,created_at timestamptz not null default now());
create unique index if not exists transactions_client on transactions(user_id,client_id) where client_id is not null;
create index if not exists transactions_user_date on transactions(user_id,date desc);
create table if not exists public.finance_settings(user_id uuid primary key references auth.users on delete cascade,monthly_budget numeric(16,2) default 0,budget_plan jsonb default '{}'::jsonb,updated_at timestamptz default now());
create table if not exists public.receivables(id uuid primary key default gen_random_uuid(),user_id uuid not null references auth.users on delete cascade,person text not null,amount numeric(16,2) not null,date date,due_date date,note text,status text default 'active',paid_at timestamptz,created_at timestamptz default now());
create table if not exists public.finance_summaries(couple_id uuid not null references couples on delete cascade,user_id uuid not null references auth.users on delete cascade,data jsonb default '{}'::jsonb,updated_at timestamptz default now(),primary key(couple_id,user_id));

create table if not exists public.messages(id uuid primary key default gen_random_uuid(),couple_id uuid not null references couples on delete cascade,sender_id uuid not null references auth.users on delete cascade,text text not null,type text default 'text',reply_to jsonb,reactions jsonb default '{}'::jsonb,pinned boolean default false,read_by uuid[] default '{}',created_at timestamptz default now());
create index if not exists messages_couple_time on messages(couple_id,created_at desc);
create table if not exists public.typing(couple_id uuid references couples on delete cascade,user_id uuid references auth.users on delete cascade,typing boolean default false,updated_at timestamptz default now(),primary key(couple_id,user_id));
create table if not exists public.couple_state(couple_id uuid references couples on delete cascade,key text,data jsonb default '{}'::jsonb,updated_by uuid references auth.users,updated_at timestamptz default now(),primary key(couple_id,key));
create table if not exists public.pulse(couple_id uuid references couples on delete cascade,user_id uuid references auth.users on delete cascade,name text,mood text,note text,updated_at timestamptz default now(),primary key(couple_id,user_id));
create table if not exists public.activities(id uuid primary key default gen_random_uuid(),couple_id uuid references couples on delete cascade,type text,title text,detail text,amount numeric default 0,actor_id uuid references auth.users,actor_name text,actor_photo_url text,created_at timestamptz default now());
create index if not exists activities_couple_time on activities(couple_id,created_at desc);

create table if not exists public.memories(id uuid primary key default gen_random_uuid(),couple_id uuid references couples on delete cascade,title text,place text,story text,memory_date date,lat double precision,lng double precision,photo_url text,added_by uuid references auth.users,added_by_name text,created_at timestamptz default now());
alter table public.memories add column if not exists starred boolean not null default false;
create table if not exists public.live_locations(user_id uuid primary key references auth.users on delete cascade,couple_id uuid references couples on delete cascade,lat double precision,lng double precision,accuracy double precision default 0,sharing boolean default false,expires_at timestamptz,updated_at timestamptz default now());
create table if not exists public.location_history(id uuid primary key default gen_random_uuid(),couple_id uuid references couples on delete cascade,user_id uuid references auth.users on delete cascade,name text,lat double precision,lng double precision,accuracy double precision default 0,shared_minutes integer default 60,created_at timestamptz default now());
create index if not exists location_history_couple_time on location_history(couple_id,created_at desc);
create table if not exists public.matus_messages(id uuid primary key default gen_random_uuid(),couple_id uuid references couples on delete cascade,role text check(role in('user','assistant')),text text,actor_id uuid references auth.users,actor_name text,created_at timestamptz default now());
create table if not exists public.daily_points(id text primary key,couple_id uuid references couples on delete cascade,user_id uuid references auth.users on delete cascade,action text,points integer,day date,created_at timestamptz default now());

alter table profiles enable row level security;alter table couples enable row level security;alter table transactions enable row level security;alter table finance_settings enable row level security;alter table receivables enable row level security;alter table finance_summaries enable row level security;alter table messages enable row level security;alter table typing enable row level security;alter table couple_state enable row level security;alter table pulse enable row level security;alter table activities enable row level security;alter table memories enable row level security;alter table live_locations enable row level security;alter table location_history enable row level security;alter table matus_messages enable row level security;alter table daily_points enable row level security;

do $$declare t text;begin
 foreach t in array array['transactions','finance_settings','receivables'] loop execute format('drop policy if exists own_rows on public.%I',t);execute format('create policy own_rows on public.%I for all using(user_id=auth.uid()) with check(user_id=auth.uid())',t);end loop;
 foreach t in array array['finance_summaries','messages','typing','couple_state','pulse','activities','memories','live_locations','location_history','matus_messages','daily_points'] loop execute format('drop policy if exists couple_rows on public.%I',t);execute format('create policy couple_rows on public.%I for all using(public.is_couple_member(couple_id)) with check(public.is_couple_member(couple_id))',t);end loop;
end$$;
drop policy if exists own_profile on profiles;create policy own_profile on profiles for all using(id=auth.uid() or (couple_id is not null and public.is_couple_member(couple_id))) with check(id=auth.uid());
drop policy if exists couple_access on couples;create policy couple_access on couples for select using(public.is_couple_member(id) or created_by=auth.uid());

insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types) values('avatars','avatars',true,5242880,array['image/jpeg','image/png','image/webp']),('memories','memories',false,10485760,array['image/jpeg','image/png','image/webp']),('receipts','receipts',false,10485760,array['image/jpeg','image/png','image/webp']),('chat-attachments','chat-attachments',false,15728640,null) on conflict(id) do update set public=excluded.public,file_size_limit=excluded.file_size_limit,allowed_mime_types=excluded.allowed_mime_types;
drop policy if exists avatar_upload on storage.objects;create policy avatar_upload on storage.objects for all using(bucket_id='avatars' and (storage.foldername(name))[1]=auth.uid()::text) with check(bucket_id='avatars' and (storage.foldername(name))[1]=auth.uid()::text);
drop policy if exists memory_upload on storage.objects;create policy memory_upload on storage.objects for all using(bucket_id='memories' and public.is_couple_member(((storage.foldername(name))[1])::uuid)) with check(bucket_id='memories' and public.is_couple_member(((storage.foldername(name))[1])::uuid));

do $$begin alter publication supabase_realtime add table messages,typing,couple_state,pulse,activities,memories,live_locations,location_history,matus_messages,transactions,finance_settings,finance_summaries,profiles;exception when duplicate_object then null;end$$;
do $$begin if not exists(select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='finance_summaries') then alter publication supabase_realtime add table public.finance_summaries;end if;end$$;

-- Optional retention: run daily with pg_cron if enabled.
-- select cron.schedule('location-retention','0 3 * * *',$$delete from public.location_history where created_at < now()-interval '90 days'$$);

-- AppCouple 3.8.3 — pairing langsung, kode 6 karakter
-- Jalankan sekali di Supabase SQL Editor. Aman dijalankan ulang.

drop policy if exists couple_access on public.couples;
drop policy if exists couples_read_direct on public.couples;
drop policy if exists couples_insert_direct on public.couples;
drop policy if exists couples_update_direct on public.couples;

create policy couples_read_direct on public.couples
for select to authenticated
using (created_by = auth.uid() or public.is_couple_member(id));

create policy couples_insert_direct on public.couples
for insert to authenticated
with check (created_by = auth.uid());

create policy couples_update_direct on public.couples
for update to authenticated
using (created_by = auth.uid() or public.is_couple_member(id))
with check (created_by = auth.uid() or public.is_couple_member(id));

notify pgrst, 'reload schema';


-- AppCouple 3.8.5 — pemulihan akun yang hanya memiliki kode pending
-- Jalankan setelah policy pairing v3.8.3. Aman dijalankan ulang.

drop policy if exists couples_delete_direct on public.couples;
create policy couples_delete_direct on public.couples
for delete to authenticated
using (created_by = auth.uid() and not exists (
  select 1 from public.profiles p
  where p.couple_id = couples.id and p.id <> auth.uid()
));

notify pgrst, 'reload schema';


-- AppCouple 4.1.1 — aktivasi realtime Ringkasan Bulan Ini / Keuangan Berdua
-- Aman dijalankan berulang kali di Supabase SQL Editor.

create table if not exists public.finance_summaries(
  couple_id uuid not null references public.couples on delete cascade,
  user_id uuid not null references auth.users on delete cascade,
  data jsonb default '{}'::jsonb,
  updated_at timestamptz default now(),
  primary key(couple_id,user_id)
);

alter table public.finance_summaries enable row level security;
drop policy if exists couple_rows on public.finance_summaries;
create policy couple_rows on public.finance_summaries for all
using(public.is_couple_member(couple_id))
with check(public.is_couple_member(couple_id));

do $$begin
  if not exists(
    select 1 from pg_publication_tables
    where pubname='supabase_realtime' and schemaname='public' and tablename='finance_summaries'
  ) then
    alter publication supabase_realtime add table public.finance_summaries;
  end if;
end$$;

-- Isi ringkasan bulan berjalan dari transaksi yang sudah ada.
insert into public.finance_summaries(couple_id,user_id,data,updated_at)
select p.couple_id,t.user_id,
  jsonb_build_object(
    'income',coalesce(sum(t.amount) filter(where t.type='income'),0),
    'expense',coalesce(sum(t.amount) filter(where t.type='expense'),0),
    'balance',coalesce(sum(t.amount) filter(where t.type='income'),0)-coalesce(sum(t.amount) filter(where t.type='expense'),0),
    'incomeCount',count(*) filter(where t.type='income'),
    'expenseCount',count(*) filter(where t.type='expense'),
    'period',to_char(current_date,'YYYY-MM'),
    'updatedAt',now()
  ),now()
from public.transactions t
join public.profiles p on p.id=t.user_id and p.couple_id is not null
where date_trunc('month',t.date)=date_trunc('month',current_date)
group by p.couple_id,t.user_id
on conflict(couple_id,user_id) do update set data=excluded.data,updated_at=excluded.updated_at;


-- AppCouple 7.3.0 — audit sinkronisasi pasangan dan realtime
-- Jalankan satu kali di Supabase SQL Editor. Aman dijalankan ulang.

create extension if not exists pgcrypto;

-- Kode tepat 6 karakter, bebas karakter ambigu, dan atomik.
create or replace function public.create_pair_code()
returns text
language plpgsql
security definer
set search_path=public
as $$
declare
  alphabet constant text := 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  code text;
  cid uuid;
  me public.profiles%rowtype;
  members integer;
begin
  if auth.uid() is null then raise exception 'Sesi login tidak valid'; end if;
  select * into me from public.profiles where id=auth.uid() for update;
  if me.couple_id is not null then
    select count(*) into members from public.profiles where couple_id=me.couple_id and id<>auth.uid();
    if members>0 then raise exception 'Akun sudah terhubung dengan pasangan'; end if;
    cid:=me.couple_id;
  else
    insert into public.couples(created_by) values(auth.uid()) returning id into cid;
    update public.profiles set couple_id=cid,partner_id=null,connection_date=now(),updated_at=now() where id=auth.uid();
  end if;
  loop
    code:='';
    for i in 1..6 loop
      code:=code||substr(alphabet,1+(get_byte(gen_random_bytes(1),0)%length(alphabet)),1);
    end loop;
    exit when not exists(select 1 from public.couples where invite_code=code and id<>cid);
  end loop;
  update public.couples set invite_code=code,invite_expires_at=now()+interval '24 hours' where id=cid and created_by=auth.uid();
  if not found then raise exception 'Ruang pasangan tidak dapat diperbarui'; end if;
  return code;
end;
$$;

-- Menghubungkan kedua profil dalam satu transaksi.
create or replace function public.connect_with_pair_code(pair_code text)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  cid uuid;
  owner_id uuid;
  old_cid uuid;
  members integer;
begin
  if auth.uid() is null then raise exception 'Sesi login tidak valid'; end if;
  if length(upper(trim(pair_code)))<>6 then raise exception 'Kode pasangan harus terdiri dari 6 karakter'; end if;
  select id,created_by into cid,owner_id from public.couples where invite_code=upper(trim(pair_code)) and invite_expires_at>now() for update;
  if cid is null then raise exception 'Kode pasangan tidak valid atau sudah digunakan'; end if;
  if owner_id=auth.uid() then raise exception 'Masukkan kode dari akun pasangan'; end if;
  select couple_id into old_cid from public.profiles where id=auth.uid() for update;
  if old_cid is not null and old_cid<>cid then
    select count(*) into members from public.profiles where couple_id=old_cid and id<>auth.uid();
    if members>0 then raise exception 'Akun sudah terhubung dengan pasangan'; end if;
    delete from public.couples where id=old_cid and created_by=auth.uid();
  end if;
  update public.profiles set couple_id=cid,partner_id=owner_id,connection_date=coalesce(connection_date,now()),updated_at=now() where id=auth.uid();
  update public.profiles set couple_id=cid,partner_id=auth.uid(),connection_date=coalesce(connection_date,now()),updated_at=now() where id=owner_id;
  update public.couples set invite_code=null,invite_expires_at=null where id=cid;
  return cid;
end;
$$;

-- Memutuskan kedua profil, bukan hanya akun yang menekan tombol.
create or replace function public.disconnect_couple()
returns boolean
language plpgsql
security definer
set search_path=public
as $$
declare cid uuid;
begin
  if auth.uid() is null then raise exception 'Sesi login tidak valid'; end if;
  select couple_id into cid from public.profiles where id=auth.uid() for update;
  if cid is null then return true; end if;
  update public.profiles set couple_id=null,partner_id=null,connection_date=null,updated_at=now() where couple_id=cid;
  delete from public.couples where id=cid;
  return true;
end;
$$;

revoke all on function public.create_pair_code() from public;
revoke all on function public.create_pair_code() from anon;
revoke all on function public.connect_with_pair_code(text) from public;
revoke all on function public.connect_with_pair_code(text) from anon;
revoke all on function public.disconnect_couple() from public;
revoke all on function public.disconnect_couple() from anon;
grant execute on function public.create_pair_code() to authenticated;
grant execute on function public.connect_with_pair_code(text) to authenticated;
grant execute on function public.disconnect_couple() to authenticated;

-- Indeks untuk query realtime dan ringkasan agar tidak boros kuota.
create index if not exists idx_profiles_couple_id on public.profiles(couple_id);
create index if not exists idx_messages_couple_created on public.messages(couple_id,created_at);
create index if not exists idx_activities_couple_created on public.activities(couple_id,created_at desc);
create index if not exists idx_memories_couple_created on public.memories(couple_id,created_at desc);
create index if not exists idx_locations_couple_updated on public.live_locations(couple_id,updated_at desc);
create index if not exists idx_location_history_couple_created on public.location_history(couple_id,created_at desc);
create index if not exists idx_matus_messages_couple_created on public.matus_messages(couple_id,created_at);
create index if not exists idx_finance_summaries_couple on public.finance_summaries(couple_id,user_id);

-- Pastikan tabel yang dipantau tersedia untuk postgres_changes.
do $$
declare t text;
begin
  foreach t in array array['profiles','messages','activities','memories','live_locations','location_history','couple_state','pulse','matus_messages','finance_summaries'] loop
    if not exists(select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename=t) then
      execute format('alter publication supabase_realtime add table public.%I',t);
    end if;
  end loop;
end $$;
