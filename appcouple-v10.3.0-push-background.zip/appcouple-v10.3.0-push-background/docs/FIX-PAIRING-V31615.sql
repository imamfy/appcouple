-- AppCouple v31.6.15 — perbaikan koneksi pasangan atomik
-- Jalankan sekali di Supabase Dashboard > SQL Editor.
-- Aman dijalankan ulang. Kode undangan berlaku 24 jam.

create extension if not exists pgcrypto;
alter table public.couples add column if not exists invite_expires_at timestamptz;
create unique index if not exists couples_invite_code_unique on public.couples(invite_code) where invite_code is not null;
create index if not exists profiles_couple_id_idx on public.profiles(couple_id);

create or replace function public.create_pair_code()
returns text
language plpgsql
security definer
set search_path=public
as $$
declare
  alphabet constant text := 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  code text;
  cid uuid;
  me public.profiles%rowtype;
  members integer;
begin
  if auth.uid() is null then raise exception 'Sesi login tidak valid'; end if;

  insert into public.profiles(id,email,name,photo_url)
  select u.id,u.email,
    coalesce(u.raw_user_meta_data->>'full_name',u.raw_user_meta_data->>'name',split_part(u.email,'@',1),'Pengguna'),
    coalesce(u.raw_user_meta_data->>'avatar_url',u.raw_user_meta_data->>'picture','')
  from auth.users u where u.id=auth.uid()
  on conflict(id) do nothing;

  select * into me from public.profiles where id=auth.uid() for update;
  if not found then raise exception 'Profil pengguna belum tersedia'; end if;

  if me.couple_id is not null then
    select count(*) into members from public.profiles where couple_id=me.couple_id and id<>auth.uid();
    if members>0 then raise exception 'Akun sudah terhubung dengan pasangan'; end if;
    select id into cid from public.couples where id=me.couple_id and created_by=auth.uid() for update;
  end if;

  if cid is null then
    update public.profiles set couple_id=null,partner_id=null,connection_date=null,updated_at=now() where id=auth.uid();
    insert into public.couples(created_by) values(auth.uid()) returning id into cid;
    update public.profiles set couple_id=cid,partner_id=null,connection_date=now(),updated_at=now() where id=auth.uid();
  end if;

  loop
    code:='';
    for i in 1..6 loop
      code:=code||substr(alphabet,1+(get_byte(gen_random_bytes(1),0)%length(alphabet)),1);
    end loop;
    exit when not exists(select 1 from public.couples where invite_code=code and id<>cid);
  end loop;

  update public.couples
  set invite_code=code,invite_expires_at=now()+interval '24 hours'
  where id=cid and created_by=auth.uid();
  if not found then raise exception 'Ruang pasangan tidak dapat diperbarui'; end if;
  return code;
end;
$$;

create or replace function public.connect_with_pair_code(pair_code text)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  normalized text := upper(trim(pair_code));
  cid uuid;
  owner_id uuid;
  old_cid uuid;
  members integer;
begin
  if auth.uid() is null then raise exception 'Sesi login tidak valid'; end if;
  if length(normalized)<>6 then raise exception 'Kode pasangan harus terdiri dari 6 karakter'; end if;

  insert into public.profiles(id,email,name,photo_url)
  select u.id,u.email,
    coalesce(u.raw_user_meta_data->>'full_name',u.raw_user_meta_data->>'name',split_part(u.email,'@',1),'Pengguna'),
    coalesce(u.raw_user_meta_data->>'avatar_url',u.raw_user_meta_data->>'picture','')
  from auth.users u where u.id=auth.uid()
  on conflict(id) do nothing;

  select id,created_by into cid,owner_id
  from public.couples
  where invite_code=normalized and invite_expires_at>now()
  for update;

  if cid is null then raise exception 'Kode pasangan tidak valid, kedaluwarsa, atau sudah digunakan'; end if;
  if owner_id=auth.uid() then raise exception 'Masukkan kode dari akun pasangan, bukan kode akun sendiri'; end if;

  insert into public.profiles(id,email,name,photo_url)
  select u.id,u.email,
    coalesce(u.raw_user_meta_data->>'full_name',u.raw_user_meta_data->>'name',split_part(u.email,'@',1),'Pengguna'),
    coalesce(u.raw_user_meta_data->>'avatar_url',u.raw_user_meta_data->>'picture','')
  from auth.users u where u.id=owner_id
  on conflict(id) do nothing;

  if not exists(select 1 from public.profiles where id=owner_id) then
    raise exception 'Profil pembuat kode tidak ditemukan';
  end if;

  select count(*) into members from public.profiles where couple_id=cid and id<>owner_id;
  if members>0 then raise exception 'Kode pasangan sudah digunakan'; end if;

  select couple_id into old_cid from public.profiles where id=auth.uid() for update;
  if old_cid is not null and old_cid<>cid then
    if exists(select 1 from public.profiles where couple_id=old_cid and id<>auth.uid()) then
      raise exception 'Akun sudah terhubung dengan pasangan lain';
    end if;
    delete from public.couples where id=old_cid and created_by=auth.uid();
  end if;

  update public.profiles
  set couple_id=cid,partner_id=owner_id,connection_date=now(),updated_at=now()
  where id=auth.uid();
  if not found then raise exception 'Profil pengguna tidak dapat diperbarui'; end if;

  update public.profiles
  set couple_id=cid,partner_id=auth.uid(),connection_date=now(),updated_at=now()
  where id=owner_id;
  if not found then raise exception 'Profil pasangan tidak dapat diperbarui'; end if;

  update public.couples set invite_code=null,invite_expires_at=null where id=cid;
  return cid;
end;
$$;

create or replace function public.disconnect_couple()
returns boolean
language plpgsql
security definer
set search_path=public
as $$
declare cid uuid;
begin
  if auth.uid() is null then raise exception 'Sesi login tidak valid'; end if;
  select couple_id into cid from public.profiles where id=auth.uid() for update;
  if cid is null then return true; end if;
  update public.profiles set couple_id=null,partner_id=null,connection_date=null,updated_at=now() where couple_id=cid;
  delete from public.couples where id=cid;
  return true;
end;
$$;

revoke all on function public.create_pair_code() from public,anon;
revoke all on function public.connect_with_pair_code(text) from public,anon;
revoke all on function public.disconnect_couple() from public,anon;
grant execute on function public.create_pair_code() to authenticated;
grant execute on function public.connect_with_pair_code(text) to authenticated;
grant execute on function public.disconnect_couple() to authenticated;

notify pgrst, 'reload schema';
