# AppCouple v25 — Kenangan Kita

## Tampilan baru
- Halaman Kenangan lama diganti dengan struktur baru yang lebih tenang dan rapi.
- Hero romantis dengan satu foto sorotan, dua aksi utama, dan animasi lembut.
- Ringkasan hanya menampilkan tiga informasi penting: Kenangan, Tempat, dan Favorit.
- Cerita terbaru disajikan sebagai strip foto sederhana.
- Peta Cinta dan momen terbaru dibuat sebagai dua kartu ringkas.
- Galeri desktop menggunakan tiga kolom seragam; mobile menggunakan satu kolom lega.
- Filter utama diprioritaskan dan kontrol lanjutan tidak mendominasi layar.
- Mendukung mode terang, gelap, dan prefers-reduced-motion.

## Fungsi yang dipertahankan
- Google Drive tetap menjadi penyimpanan utama Kenangan.
- Unggah, pratinjau, edit cerita, favorit, unduh, buka sumber Drive, peta, pemilihan massal, dan hapus tetap tersedia.
- Tidak ada operasi Kenangan yang dialihkan kembali ke Supabase Storage.

## Deploy
Deploy seluruh folder aplikasi ke Netlify dan pertahankan Environment variables Google Drive dari v24. Setelah deploy, gunakan **Clear cache and deploy site** agar cache `appcouple-next-v2500` aktif.

## Hasil validasi
- Desktop 1440 px: hero 2 kolom, galeri 3 kolom, tanpa overflow.
- Mobile 390 px: hero vertikal, galeri 1 kolom, tanpa overflow horizontal.
- Seluruh rute Google Drive lulus pengujian mock.
