# AppCouple v28 — Peta Full Screen

## Perubahan
- Tampilan peta dikembalikan menjadi layar penuh seperti versi sebelumnya.
- Peta tidak lagi dibagi permanen dengan panel album.
- Album Jejak dibuka sebagai panel overlay dari tombol Album dan dapat ditutup kembali.
- Header, pencarian, pilihan layer, lokasi pasangan, rute, dan tombol foto mengambang di atas peta.
- Mobile memakai kontrol ringkas dan album dua kolom.

## Fitur yang tetap dipertahankan
- Foto Kenangan tetap berasal dari Google Drive.
- Pin foto dapat diklik untuk membuka pratinjau.
- Lokasi terakhir pengguna dan pasangan tetap tersimpan.
- Berbagi lokasi sementara dan rute pasangan tetap tersedia.
- Unggah Kenangan tetap mewajibkan alamat dan koordinat valid.
- Mode terang, gelap, dan reduced motion tetap didukung.

## Versi
- Build: `28.0.0`
- Service worker cache: `appcouple-next-v2800`
