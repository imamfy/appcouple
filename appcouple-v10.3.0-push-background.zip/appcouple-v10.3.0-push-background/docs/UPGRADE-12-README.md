# AppCouple 12.0 — corrective implementation for seven areas

## What changed, and what is NOT completed
1. AI: authenticated Netlify endpoint reads the caller's own transactions under Supabase RLS, checks persisted AND requested permissions, limits usage to 20 requests/hour, and returns advice. UI can save an answer as a local note after confirmation. This is NOT an autonomous agent; it never writes financial transactions.
2. Vault: AES-256-GCM ciphertext, random IV and salt stored locally; key derived by PBKDF2-SHA256 (600,000 iterations) from a >=12-character passphrase. Supports decrypt, encrypted backup download, verified restore, manual lock, 2-minute auto-lock, tab hidden and feature-exit lock. Passphrase is not saved. No password reset. This is NOT cross-account E2EE and has not had an independent security audit. Other scripts on the same origin can access plaintext while unlocked; protect the origin against XSS.
3. Permissions: default off for finance, selected memories, images. Backend checks DB consent on each request and independently queries current caller data. Permissions are intersected with current client choices. If syncing consent fails, UI says so. New local requests honor local revocation; server revocation across devices only occurs after successful sync. Matus legacy finance context is locally gated; other legacy Matus permissions remain separate. No claim of app-wide backend privacy enforcement.
4. Memory: local CRUD, keyword-ranked search, expiration, and optional selection of <=5 matching notes for an AI request. Plaintext browser-local notes are explicitly labeled: NOT encrypted, NOT isolated by account, NOT vector RAG, NOT synced. Use vault for secrets. Old v11 notes are not silently transferred to a provider. The old v11 vault persisted only metadata: those old ciphertexts were not saved and cannot be recovered.
5. Finance: dated current-month transactions, signed balance, daily projection, explicit extra bills/income scenario, variation estimate (NOT confidence interval), sparse-data warning, category totals and duplicate candidates without automatic deletion. No automatic bill inference, multi-month forecast model or validated prediction accuracy claimed.
6. Multimodal/voice/world: opt-in server image analysis for PNG/JPEG/WebP <=2MB; transcript review before sending; optional spoken response and stop; browser capability checks explicitly labeled for passkeys/AR; real category relationships; gallery counts; acknowledged cross-tab ping; opens existing Game world; local reminders while app open. PDF OCR, new AR content, generative 3D, passkey enrollment, server push are NOT implemented. Microphone/camera headers now allow same-origin use, still subject to browser consent. Opening world does not generate a new environment.
7. Sydas: fixed-channel public YouTube Data API endpoint with page tokens (50/page), duration metadata, embeddable flag, cache, bounded fetches, RSS fallback, cache on failure, exponential retry backoff and visibility-aware polling. Sync never reloads a playing video. Client supports selected-video iframe, pause on leaving, error messages from validated YouTube events and external fallback. RSS is incomplete and cannot classify Shorts. Duration <=180s is explicitly a SHORT CANDIDATE, not confirmed Shorts; confirmed IDs may be configured server-side. YouTube embedding restrictions remain in effect.

## Deploy (required for AI and reliable full video catalog)
1. Back up the existing site and database. Apply `UPGRADE-12.sql` after the current base schema in Supabase. Test RLS with two separate accounts: no cross-user reads/writes.
2. Deploy the entire project to Netlify with Functions enabled. Functions live in `netlify/functions/` and are called directly via `/.netlify/functions/intelligence` and `/.netlify/functions/sydas`. Static-only hosting will NOT run these endpoints.
3. Set server environment variables in hosting settings, NOT in frontend JS and NOT in chat:
   - SUPABASE_URL
   - SUPABASE_ANON_KEY (public key, used with caller JWT; never a service-role key)
   - OPENAI_API_KEY
   - OPENAI_MODEL (choose a supported model with chat-completions/image support)
   - YOUTUBE_API_KEY (enable YouTube Data API v3, restrict to that API; add quota alerts)
   - Optional SYDAS_CONFIRMED_SHORT_IDS (comma-separated verified Shorts IDs)
4. Redeploy. Sign in with a real account, open AI OS > Izin data AI, save consent and check server status. Demo cannot authenticate to production endpoints.
5. Verify one actual YouTube long video and one actual Short, including playback on mobile, embedding denied, wrong/missing key, quota exhausted, offline, and reopening. Use official channel IDs only.
6. Exercise AI with permission off/on and then revoked; verify the provider receives only permitted data. Configure provider spending limits. Quota table maintenance should delete old windows periodically with an admin-scheduled job.
7. Test encrypted backup restoration in another browser using a known test phrase BEFORE storing important notes. Keep two encrypted backups. Never reuse account passwords.

## Tests and limitations
`qa/v12-test-results.json` records tests performed on this revision. Browser tests used mocked public video metadata, not real playback. DNS to www.youtube.com was unavailable in the sandbox. Live YouTube playback, real provider responses, live RLS, SQL migration and cloud deployment were NOT executed or certified.
- Local encryption round-trip/wrong password: passed.
- UI store/decrypt/manual lock: passed.
- CRUD/search/delete, expiry, signed projections, permission gates: passed.
- Fixture filtering, player URL selection, refresh continuity and failure fallback: passed.
- Mobile/desktop overflow: passed; screenshots reviewed.
- Keep existing unrelated AI OS/finance/world behaviors under regression testing; no claim all 15 original technologies are production complete.
