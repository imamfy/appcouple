# AppCouple 30.7.0 — Perbaikan halaman Laporan Keuangan

Dua perbaikan, murni logika tampilan/kalkulasi — tidak ada perubahan skema database.

## 1. Ekspor Excel: Saldo Bersih sekarang menyertakan saldo bawaan sebelum periode ekspor

**Sebelum:** kolom "Saldo Berjalan" di sheet Transaksi dan "Saldo Bersih" di Dashboard Excel
selalu mulai dari Rp0 di transaksi pertama pada rentang yang diekspor — tidak peduli berapa
saldo yang sebenarnya terbawa dari sebelum periode itu. Ini beda dari grafik "Saldo
kumulatif" di halaman Laporan (dalam app), yang sudah benar menyertakan saldo bawaan sejak
awal. Akibatnya, ekspor scope "Bulan ini"/"Tahun ini" bisa menampilkan "Saldo Bersih" yang
sama sekali berbeda dari "Saldo" yang dilihat user di app.

**Sekarang:**
- `exportFinancialReport()` di `finance-ui.js` mengambil `opening` dari periode laporan yang
  sedang aktif (`reportBuckets().opening`) dan mengirimkannya ke `downloadFinanceWorkbook()`.
  Untuk scope "Semua transaksi", opening tetap 0 (memang tidak ada periode sebelumnya).
- `buildFinanceWorkbook()`, `dashboardRows()`, dan `detailRows()` di
  `excel-finance-export.js` menerima parameter `opening` ini dan menambahkannya ke "Saldo
  Bersih" serta ke setiap baris "Saldo Berjalan" — termasuk ke formula Excel-nya sendiri
  (bukan cuma nilai yang di-cache), supaya kalau user re-kalkulasi manual di Excel, hasilnya
  tetap konsisten.
- Catatan di baris ke-2 file Excel sekarang dinamis: menyebutkan angka saldo awal yang
  dipakai, bukan cuma teks generik.

## 2. Skor kesehatan arus kas tidak lagi kontradiktif untuk periode kosong

**Sebelum:** memilih periode yang sama sekali belum ada transaksinya menghasilkan skor
**0/100** dengan judul **"Arus kas membutuhkan perhatian"** (alarm merah), tapi deskripsi di
bawahnya malah bilang **"Surplus Rp0 memberi ruang untuk tabungan..."** (nada positif) — dua
pesan yang saling bertentangan.

**Sekarang:** kondisi "belum ada transaksi sama sekali pada periode ini" (income=0 DAN
expense=0) dideteksi terpisah dan menampilkan pesan netral: skor `—` (bukan 0), judul
"Belum ada transaksi pada periode ini", copy "Catat transaksi pada periode ini untuk melihat
analisis arus kas otomatis." Kasus lain yang sebelumnya sudah benar (misalnya periode dengan
pengeluaran tapi tanpa pemasukan tercatat — tetap dianggap perlu perhatian, bukan netral)
tidak berubah sama sekali.

## Berkas yang diubah
- `src/finance-ui.js` — `exportFinancialReport()` mengirim opening balance; logika skor
  kesehatan arus kas di `renderFinancialReport()` menambah kondisi "belum ada transaksi".
- `src/excel-finance-export.js` — `buildFinanceWorkbook`, `downloadFinanceWorkbook`,
  `dashboardRows`, `detailRows` menerima dan memakai parameter `opening`.

## Pengujian yang disarankan
1. Buka Laporan → catat transaksi di bulan-bulan sebelumnya sampai Saldo di halaman Finance
   menunjukkan angka tertentu (misalnya Rp7.000.000). Ekspor scope "Sesuai tampilan saat
   ini" → cek "Saldo Bersih" di Excel = angka yang sama.
2. Ekspor scope "Semua transaksi" → cek saldo awal = Rp0 (karena memang tidak ada periode
   sebelumnya untuk cakupan ini).
3. Pilih rentang custom yang belum ada transaksinya sama sekali → cek kartu kesehatan arus
   kas menampilkan "Belum ada transaksi", bukan skor 0 dengan teks surplus.
