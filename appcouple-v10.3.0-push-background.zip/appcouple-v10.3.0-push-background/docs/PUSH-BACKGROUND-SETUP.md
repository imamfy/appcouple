# AppCouple 10.3.0 — Push saat aplikasi ditutup

## 1. Supabase

Jalankan `docs/UPGRADE-PUSH-BACKGROUND.sql` di Supabase SQL Editor.

## 2. Buat VAPID key

Di folder proyek:

```bash
npm install
npx web-push generate-vapid-keys
```

Jangan memasukkan private key ke source code.

## 3. Environment variables Netlify

Tambahkan melalui **Site configuration → Environment variables**:

- `VAPID_PUBLIC_KEY`
- `VAPID_PRIVATE_KEY`
- `VAPID_SUBJECT` — contoh `mailto:email-anda@example.com`
- `SUPABASE_URL`
- `SUPABASE_ANON_KEY` atau `SUPABASE_PUBLISHABLE_KEY`
- `SUPABASE_SERVICE_ROLE_KEY`
- `APPCOUPLE_ALLOWED_USER_IDS` — UUID akun kamu dan pasangan, dipisahkan koma

Lakukan deploy ulang setelah variabel disimpan.

## 4. Aktifkan di kedua perangkat

1. Buka aplikasi melalui HTTPS.
2. Login.
3. Buka **Profil & Privasi → Notifikasi perangkat**.
4. Tekan **Aktifkan notifikasi**.
5. Izinkan notifikasi browser.

Langkah ini harus dilakukan sekali pada setiap browser/perangkat. Di iPhone/iPad,
pasang aplikasi ke Home Screen terlebih dahulu lalu aktifkan notifikasi dari PWA.

## Perilaku

- Pesan chat disimpan ke Supabase terlebih dahulu.
- Netlify Function mengirim Web Push ke seluruh subscription aktif milik pasangan.
- Service worker menampilkan notifikasi ketika aplikasi tertutup atau berada di background.
- Subscription kedaluwarsa (HTTP 404/410) dibersihkan otomatis.
- Jika aplikasi sedang terlihat, push perangkat tidak ditampilkan agar tidak menduplikasi notifikasi realtime.