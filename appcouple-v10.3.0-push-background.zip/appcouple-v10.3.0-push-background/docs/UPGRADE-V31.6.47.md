# AppCouple v31.6.47 — Suara Matus Global

Matus kini dapat berbicara ketika pengguna sedang berada di Beranda, Keuangan,
Couple Space, Jalan Berdua, atau Kenangan. Halaman Assistant Matus tidak perlu
dibuka.

## Perilaku

- Setelah login melalui interaksi pengguna, Matus langsung menyapa jika
  **Suara otomatis** aktif.
- Hasil Analisis Matus pada itinerary langsung dibacakan setelah selesai.
- Auto chatter dua menit berjalan lintas halaman selama aplikasi terlihat.
- Dock suara global menampilkan kalimat yang sedang dibacakan dan tombol stop.
- Toggle **Suara otomatis** tetap menjadi kontrol utama untuk mematikan seluruh
  suara proaktif.

## Batasan browser

Browser dapat melarang audio otomatis sebelum pengguna menyentuh halaman.
Dalam kondisi tersebut, dock menampilkan status menunggu dan Matus mulai
berbicara setelah sentuhan atau tombol pertama. Pembatasan ini tidak dapat
dilewati oleh aplikasi.