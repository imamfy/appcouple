-- Run AFTER UPGRADE-FINANCE-V20.sql, first on staging.
-- Adds planning data only; no existing transactions are changed.
begin;
alter table public.finance_settings add column if not exists planner jsonb not null default '{"budgets":[],"bills":[],"paid":[]}'::jsonb;
alter table public.finance_settings add column if not exists planner_revision integer not null default 0;
do $$ begin
 if not exists(select 1 from pg_constraint where conname='finance_planner_object_v21' and conrelid='public.finance_settings'::regclass) then
 alter table public.finance_settings add constraint finance_planner_object_v21 check(jsonb_typeof(planner)='object' and jsonb_typeof(planner->'budgets')='array' and jsonb_typeof(planner->'bills')='array' and jsonb_typeof(planner->'paid')='array' and planner_revision>=0) not valid;
 end if;
end $$;
commit;
