# AppCouple 23.0.0 — Mobile Calm UI

Paket lengkap lanjutan v22. Perubahan v23 hanya berfokus pada Kenangan Kita dan Sydas Sector di layar mobile; fitur keuangan serta migrasi v20–v22 tetap disertakan.

## Kenangan Kita pada mobile
- Jarak antarpanel diperbesar dan sudut/tampilan kartu diseragamkan.
- Teks pengantar hero dan deskripsi bagian disembunyikan pada mobile; judul serta aksi utama tetap terlihat.
- Navigasi bagian menjadi lima tombol rapi dengan target sentuh minimal sekitar 44–52 px.
- Statistik diringkas menjadi Kenangan, Tempat, dan Favorit. Jumlah Foto/Video tetap tersedia di data aplikasi tetapi tidak ditampilkan pada ringkasan mobile.
- Album menjadi grid 2×2 dengan label singkat; keterangan panjang disembunyikan.
- Kontrol galeri disederhanakan menjadi pencarian, pilihan tampilan, dan empat filter utama. Filter lokasi/tahun tetap dapat diakses melalui bagian navigasi/album, tetapi tidak memenuhi toolbar mobile.
- Galeri mobile menjadi satu kartu besar per baris dengan jarak 14 px, bukan grid kecil yang rapat.
- Tombol tambah, favorit, hapus, dan lightbox diperbesar serta ditata ulang. Lightbox menampilkan deskripsi maksimum tiga baris dan menyembunyikan panel terkait pada layar kecil.
- Desktop tidak diubah oleh aturan v23.

## Sydas Sector pada mobile
- Tetap memakai dua kolom video seperti permintaan sebelumnya.
- Judul diletakkan di tengah kartu, maksimal dua baris, dan teks panjang dipotong dengan ellipsis.
- Ikon profil kecil dan tombol panah di baris judul disembunyikan pada mobile agar judul tidak terdorong ke kanan.
- Tanggal dipusatkan di bawah judul dan tinggi area judul diseragamkan.
- Desktop dan pemutar video tidak diubah.

## Pengujian
- Mobile 390×844: galeri Kenangan satu kolom, jarak 14 px, toolbar tidak sticky, dua statistik redundan tersembunyi, tombol utama/nav memenuhi ukuran sentuh, tanpa overflow horizontal.
- Sydas 390×844: dua kartu per baris, pusat judul sama dengan pusat kartu, text-align center, maksimal dua baris, tanpa overflow horizontal.
- Tidak ditemukan pageerror JavaScript pada alur Kenangan demo.
- Pratinjau Sydas memakai kartu sampel lokal karena feed eksternal tidak selalu tersedia pada sandbox; struktur markup sama dengan renderer aplikasi.

## Instalasi
Deploy isi folder finance-app seperti versi sebelumnya. Badge harus menunjukkan Build 23.0.0. Cache service worker berubah menjadi appcouple-next-v2300. Jika tampilan lama masih tersimpan, tutup tab lama lalu muat ulang satu kali.
