# AppCouple v31.6.45 — Resilient Matus Itinerary

## Perubahan

- **Susun itinerary** sekarang membuat kerangka bila diperlukan, membuka tab
  Itinerary, lalu langsung menjalankan Analisis Matus untuk hari aktif.
- Lokasi berbentuk rute seperti `Jombor - Kaliurang` dicoba sebagai alamat
  lengkap, kemudian sebagai titik tujuan `Kaliurang`.
- Kegagalan satu lokasi tidak lagi membatalkan analisis satu hari. Hasil rute
  yang berhasil tetap tampil, disertai daftar agenda yang perlu diperjelas.
- Durasi jalan kaki dan sepeda dihitung dari jarak OSRM dengan kecepatan moda
  yang realistis, bukan menggunakan durasi mobil.
- Backup menolak nama penyimpanan yang menyerupai API key, AI key, token,
  credential, session, client secret, private key, dan rahasia Supabase.

## Pesan untuk pengguna

Jika sebuah lokasi belum ditemukan, tulis nama tempat beserta kota, misalnya:

- `Kaliurang, Sleman, Yogyakarta`
- `Terminal Jombor, Sleman`
- `Malioboro, Yogyakarta`

Jangan menuliskan dua titik perjalanan dalam satu kolom lokasi. Matus tetap
mendukung data lama seperti `Jombor - Kaliurang` melalui fallback otomatis.

## QA

- `tests/trip-route-resilience-v31645.cjs`
- `tests/trip-matus-analysis-ui-v31645.cjs`
- `tests/backup-security-v31645.cjs`
- `tests/trip-itinerary-ui-v31625.cjs`