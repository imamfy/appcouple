# AppCouple 10.2.0 — Deploy Aktif

1. Jalankan `SUPABASE-SETUP-CURRENT.sql` di Supabase SQL Editor.
2. Jalankan `UPGRADE-PUSH-BACKGROUND.sql` agar subscription Web Push dapat disimpan.
3. Ikuti `PUSH-BACKGROUND-SETUP.md` untuk VAPID key dan environment variables Netlify.
4. Unggah seluruh isi folder ini ke Netlify.
5. Pastikan `_redirects`, `_headers`, `netlify.toml`, dan `service-worker.js` berada di root.
6. Tutup-buka PWA setelah deploy untuk mengambil cache terbaru.

Jangan masukkan Service Role Key, VAPID Private Key, atau OAuth Client Secret ke source frontend.


## v8.7.1
- Tombol hapus langsung pada setiap foto Kenangan dan tombol hapus aktif di lightbox mobile.
- Tanya Matus desktop memakai workspace full screen.
- Pemasukan/pengeluaran menerima gambar dari Galeri atau Kamera dan membaca bukti transfer/struk dengan Gemini Vision atau OCR lokal.


## v8.7.2
- Payload location_history disesuaikan dengan skema Supabase sehingga berbagi lokasi tidak lagi menghasilkan HTTP 400.
- Service worker melewati Range request/HTTP 206 dan hanya menyimpan respons HTTP 200.
- SmartScan menemukan model Gemini aktif langsung dari API, bukan memakai model lama yang 404.
- OCR memakai build browser Tesseract yang menyediakan createWorker dengan benar.


## v8.7.3
- Halaman Kenangan mobile dipadatkan agar galeri tampil jauh lebih cepat.
- Showcase, hero, dan status sinkron yang berulang disembunyikan pada layar ponsel.
- Popup Tambah Kenangan memakai area isi yang dapat digulir terpisah.
- Tombol Batal dan Simpan momen selalu menetap di bagian bawah, termasuk di iPhone dengan home indicator.
- Tata letak diuji pada 390x844 dan iPhone 375x667.


## v8.7.4
- Header Peta iPhone dipadatkan menjadi 44px dengan tombol kembali 36px yang mudah dijangkau.
- Jarak pasangan tampil pada baris kontrol atas, termasuk status kosong saat lokasi belum aktif.
- MiniMap mendukung pinch dua jari untuk memperbesar dan memperkecil dengan titik tengah gesture sebagai jangkar.
- Tombol Rute kembali tersedia di dock mobile dan memakai OSRM untuk jalur berkendara, jarak, serta estimasi waktu.
- Ringkasan rute tampil sebagai kartu ringkas di atas dock.
- Album Jejak, lokasi real-time, dan preview kenangan menjadi bottom sheet yang dapat digulir dan ditutup dengan swipe ke bawah.
- Diuji pada viewport 390x844 dan 360x780; uji pinch berhasil menaikkan zoom dari 10 menjadi 11.08.



## v8.9.1 — Online-only call invitation
- Menghapus undangan link, WhatsApp, QR, dan Web Share.
- Undangan masuk tampil langsung di aplikasi dengan tombol Terima atau Tolak.
- Presence pasangan diperbarui setiap 60 detik selama aplikasi aktif.




## v8.9.4 — Static mobile tabs
- Tab Beranda, Keuangan, dan Couple tidak lagi sticky saat halaman digulir.
- Tab tetap berada pada posisi awal konten di mobile dan iPhone.
- Navigasi utama bawah tetap tersedia.


## v9.0.0 — Our Couple Journey
- Beranda didesain ulang sebagai pengantar tujuan dan ringkasan AppCouple.
- Menghapus dashboard serta laporan arus kas dari Beranda.
- Menambahkan hero hubungan, manfaat aplikasi, Couple Today, akses cepat, Matus, dan perjalanan terbaru.
- Laporan arus kas tersedia melalui tab Laporan di halaman Keuangan.
- Layout dirapikan untuk desktop, mobile, dan iPhone.



## v9.1.0 — Our Little World 3D
- Couple Call, WebRTC, izin kamera/mikrofon, signaling, TURN, undangan panggilan, dan seluruh UI panggilan telah dihapus.
- Menggantinya dengan dunia pasangan 3D sinematik berbasis Three.js/WebGL.
- Rumah, taman, portal kenangan, kristal masa depan, dua karakter, dan Matus 3D dibuat secara prosedural.
- Mendukung bayangan Ultra, PBR, ACES tone mapping, air dinamis, hujan 1.800 partikel, atmosfer, siang/malam, orbit kamera, zoom, fullscreen, dan Photo Mode.
- Pelukan serta presence pasangan tersinkron melalui Supabase Broadcast tanpa kamera, mikrofon, TURN, atau server media.


## v9.2.0 — Automated Living World
- Dunia bereaksi otomatis terhadap tugas Matus, mood, kenangan, anniversary, misi harian, tabungan, hadiah, chat, dan presence pasangan.
- Menambahkan pembuka kamera sinematik, awan 3D, kunang-kunang, daun, bangku, jembatan, interior rumah, pulau kenangan, kembang api anniversary, musik ambient, dan suara sambutan Matus.
- Tugas Matus tampil sebagai misi dunia; Matus berpindah ke area yang relevan secara otomatis.
- Menambahkan kamera halus, pinch-to-zoom iPhone, Photo Mode tanpa UI, dan fullscreen fallback Safari.


## v9.4.0 — Automatic World & Floating Missions
- Menambahkan tab Tugas Dunia mengambang dengan daftar tindakan dan status selesai.
- Siang, malam, cerah, berawan, dan hujan berjalan otomatis berdasarkan waktu perangkat serta Open-Meteo; kontrol manual dihapus.
- Skala karakter diperkecil agar proporsional terhadap rumah dan lingkungan.
- Musik Our World diganti dengan couple-song.mp3 dari pengguna, diputar otomatis saat fitur dibuka, loop, dan berhenti saat keluar.
- Jika autoplay dibatasi iPhone, sentuhan pertama pada dunia melanjutkan musik otomatis.


## v9.5.0 — Living Sync Characters
- Memperbaiki karakter pasangan yang sebelumnya disembunyikan saat pasangan offline; karakter kini selalu tampil dan status online hanya mengubah aura.
- Menambahkan animasi kedipan, napas, berjalan, gerak lengan dan kaki, pelukan lebih panjang, serta partikel hati.
- Tujuan berjalan dan pelukan disiarkan realtime ke pasangan melalui Couple World.
- Karakter lokal berjalan otomatis ke beberapa lokasi agar dunia tidak terasa diam.
- UI mobile/iPhone disederhanakan menjadi identitas kecil, tombol tugas, tombol pelukan, dan dock lokasi.
- Story, kartu misi besar, roster, kartu musik, presence, fullscreen, dan Photo Mode disembunyikan pada layar kecil.


## v9.6.0 — Immersive Love World
- Menghapus objek tangan dan kaki tambahan yang tampak terpisah dari gambar karakter.
- Gerak karakter kini memakai animasi 2.5D bersih pada gambar asli: kedipan, napas, body lean, walking bob, dan pelukan tersinkron.
- Our World otomatis masuk fullscreen saat tab dibuka di mobile; iPhone memakai fixed 100dvh fallback jika fullscreen native dibatasi.
- Menambahkan tombol Kembali dengan dukungan safe area.
- Mengganti bola ungu Matus dan orbit ring menjadi Love Heart 3D dengan detak ganda, garis ECG, halo, dan cahaya pink.
- Musik di-unlock pada pointer-down tab Our World, diputar otomatis, loop, dan tetap memakai fallback sentuhan jika kebijakan browser menahan audio.


## v9.6.1 — Guaranteed Mobile Fullscreen
- Memperbaiki deteksi yang sebelumnya hanya bekerja pada lebar maksimal 760px.
- Fullscreen immersive kini mendeteksi perangkat sentuh, coarse pointer, user-agent mobile, serta viewport hingga 900px.
- Kontainer Matus, workspace, panel, dan panggung dipromosikan langsung ke 100vw × 100dvh.
- Tab Matus dan input di luar Our World disembunyikan selama immersive mode.
- Mendukung iPhone portrait dan landscape, dengan tombol Kembali serta safe area.


## v9.7.0 — Lifetime Love Journey
- Musik tidak lagi mati saat menekan tombol, membuka misi, berpindah lokasi dunia, memeluk, atau membuka panel perjalanan.
- Watchdog audio melanjutkan musik selama Our World aktif; musik hanya berhenti saat Kembali atau benar-benar meninggalkan Our World.
- Menambahkan 7 bab: Awal Cerita, Jadian, Komitmen, Menikah, Membangun Rumah, Menua Bersama, dan Selamanya hingga Akhir Hayat.
- Setiap bab mengubah rumah, pohon, kristal, gerbang, cincin, lentera, perayaan, dan konstelasi dunia.
- Tahap otomatis mengikuti usia hubungan dan dapat dipilih manual bila status pasangan lebih maju.


## v9.7.1 — Manual Mobile Fullscreen
- Fullscreen otomatis saat membuka Our World dinonaktifkan.
- Menambahkan tombol Layar Penuh khusus mobile.
- Tombol Kembali hanya keluar dari fullscreen dan tetap berada di Our World.
- Safari/iPhone tetap memakai immersive 100dvh apabila fullscreen native tidak tersedia.


## v9.8.0 — Our World in Couple Games
- Memindahkan Our Little World dari tab Matus Assistant ke Couple Space > Game.
- Menambahkan kartu game ketiga “Our Little World” di Couple Playground.
- Tombol Semua Game mengembalikan pengguna ke lobby dan menghentikan musik dunia.
- Fullscreen manual, perjalanan cinta tujuh bab, cuaca otomatis, karakter, musik, dan sinkronisasi pasangan tetap dipertahankan.
- Tab Matus kini hanya berisi Matus Live dan Tanya Matus.


## v9.8.1 — Single Fullscreen Control
- Menghapus tombol fullscreen mobile tambahan.
- Mempertahankan tombol fullscreen lama dari HUD Our World.
- Tombol lama sekarang memakai fullscreen native jika tersedia dan immersive fallback pada iPhone.


## v9.8.2 — Our World Performance & Accessibility
- Render loop, timer cuaca, dan gerak karakter dijeda saat Our World ditutup atau tab disembunyikan.
- Menambahkan kualitas LOW/MEDIUM/HIGH berdasarkan perangkat, dengan pixel ratio, shadow, dan jumlah partikel adaptif.
- Memperbaiki disposal material, texture, geometry hujan, dan pulau kenangan.
- Menambahkan kontrol jeda/putar musik yang tersimpan, reduced motion, status live untuk pembaca layar, dan fokus keyboard yang terlihat.
- Cuaca tidak lagi memakai Jakarta sebagai lokasi tersembunyi; tanpa izin lokasi dunia memakai waktu perangkat.


## v9.9.0 — Playable Our Little World
- Menambahkan interaksi objek, tap-to-walk, kontrol keyboard, serta aktivitas menanam, berdansa, memasak, melihat bintang, dan memberi hadiah.
- Misi dunia kini membuka aksi atau data sebenarnya, termasuk Portal Kenangan dan Kristal Masa Depan.
- Menambahkan XP, koin, level, Love Energy dinamis, dekorasi yang dapat dibuka, progres tersimpan, dan event berkala.
- Rumah memiliki interaksi sofa, tempat tidur, dapur, dan pintu masa depan.
- Aktivitas dunia disiarkan realtime kepada pasangan.
- Tahap hubungan yang belum tercapai hanya dapat dipratinjau dan tidak menggantikan progres asli.
- Menambahkan mode dunia ringan agar gameplay dasar tetap dapat digunakan ketika mesin 3D gagal dimuat.


## v10.2.0 — Personal Security Hardened
- Menambahkan HSTS, anti-clickjacking, nosniff, Referrer Policy, Permissions Policy, dan CSP Report-Only.
- Menutup akses langsung pengguna lain terhadap kode pairing.
- Kode pairing kini kedaluwarsa setelah 15 menit dan RPC sensitif ditutup untuk anon.
- Bucket Kenangan menjadi private; foto memakai signed URL 10 menit.
- Penghapusan kenangan turut menghapus objek penyimpanan.
- HTML ikon hadiah divalidasi untuk mencegah stored XSS.
