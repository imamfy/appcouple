# Jalan Berdua — Rute Gratis v31.6.44

Fitur ini tidak membutuhkan Routes API, Geocoding API, API key Google, atau akun berbayar.

## Layanan yang digunakan

- **Nominatim/OpenStreetMap** untuk mencari koordinat dari Nama lokasi.
- **OSRM** untuk menghitung rute jalan, jarak, dan estimasi durasi.
- **Google Maps Directions URL** untuk membuka rute ketika nama lokasi diklik. Tautan biasa ini tidak memerlukan API key dari aplikasi.
- **Matus** untuk merangkum jadwal dari data rute yang sudah dihitung. Matus tidak mengarang kondisi macet.

## Tentang kemacetan

Penyedia gratis di atas tidak memberikan traffic live yang dapat diandalkan. Karena itu AppCouple menampilkan label **Estimasi rute gratis**, bukan klaim macet/lancar. Untuk melihat kemacetan aktual, pengguna menekan nama lokasi; Google Maps akan terbuka dengan asal, tujuan, dan moda yang sudah terisi.

## Alur lokasi

1. Agenda pertama: asal dari kolom **Dari mana**.
2. Agenda berikutnya: asal dari lokasi agenda sebelumnya.
3. Tujuan: dari **Nama lokasi**.
4. Moda: Mobil/Motor → driving, Jalan kaki → walking, Sepeda → bicycling, Bus/Kereta/Angkot → transit.

Hasil geocoding disimpan sementara di perangkat untuk mengurangi permintaan ke layanan publik. Permintaan alamat dijalankan berurutan agar menghormati batas pemakaian Nominatim.
