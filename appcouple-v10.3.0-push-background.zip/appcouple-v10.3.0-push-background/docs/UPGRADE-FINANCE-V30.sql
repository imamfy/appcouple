-- Finance v30 migration: receivable (piutang) payment ledger.
-- Run AFTER v20, v21, v22, v29 on staging first. No historical receivable row is rewritten.
-- Nothing here touches transactions/receivables rows that already exist except adding a
-- nullable column; old data keeps working through the app's own fallback logic.
begin;

-- Preserve the original loan amount. Until now `receivables.amount` was mutated in place on
-- every partial payment, so the original principal was permanently lost after the first
-- partial payment. New rows get this set by the app; existing rows are backfilled with their
-- CURRENT amount as a best-effort default since the true original value is not recoverable
-- from data alone. This is a display convenience only, it does not change any balance.
alter table public.receivables add column if not exists original_amount numeric(16,2);
update public.receivables set original_amount=amount where original_amount is null;

-- Ledger of every partial payment against a receivable. Immutable rows, never rewritten in
-- place, so payment history can never be silently truncated the way the old note-concatenation
-- approach was (it stored history as text and cut it to the last 200 characters).
create table if not exists public.receivable_payments(
 id uuid primary key default gen_random_uuid(),
 receivable_id uuid not null references public.receivables(id) on delete cascade,
 user_id uuid not null references auth.users on delete cascade,
 amount numeric(16,2) not null,
 payment_date date not null,
 note text,
 client_id text not null,
 transaction_id uuid references public.transactions(id) on delete set null,
 created_at timestamptz not null default now(),
 constraint receivable_payments_valid_v30 check(amount>0 and amount=trunc(amount))
);
create unique index if not exists receivable_payments_client on public.receivable_payments(user_id,client_id);
create index if not exists receivable_payments_receivable on public.receivable_payments(receivable_id,created_at);
alter table public.receivable_payments enable row level security;
drop policy if exists own_rows on public.receivable_payments;
create policy own_rows on public.receivable_payments for all using(user_id=auth.uid()) with check(user_id=auth.uid());

drop trigger if exists finance_audit_receivable_payments_v30 on public.receivable_payments;
create trigger finance_audit_receivable_payments_v30 after insert or update or delete on public.receivable_payments for each row execute function public.capture_finance_audit_v20();

do $$ begin
 if not exists(select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='receivable_payments') then
 alter publication supabase_realtime add table public.receivable_payments;
 end if;
end $$;

-- Row lock + idempotency key, same pattern as pay_finance_bill_v29. A partial payment now
-- ALWAYS books a matching income transaction; before v30 the money coming back was invisible
-- to every report and to "Sisa bulan ini" / "Saldo total".
create or replace function public.pay_receivable_partial_v30(p_receivable_id uuid,p_amount numeric,p_date date,p_note text,p_client_id text)
returns jsonb language plpgsql security invoker set search_path=public,pg_temp as $$
declare
 uid uuid:=auth.uid(); rec public.receivables%rowtype; existing public.receivable_payments%rowtype;
 tx public.transactions%rowtype; remaining numeric; cid text; payment_id uuid;
begin
 if uid is null then raise exception 'Login diperlukan'; end if;
 if p_receivable_id is null then raise exception 'Piutang tidak ditemukan'; end if;
 if p_amount is null or p_amount<1 or p_amount>1000000000 or p_amount<>trunc(p_amount) then raise exception 'Nominal pembayaran harus Rupiah bulat, Rp1-Rp1 miliar'; end if;
 if p_date is null or p_date>(now() at time zone 'Asia/Jakarta')::date then raise exception 'Tanggal pembayaran harus valid dan tidak di masa depan'; end if;
 if p_client_id is null or length(trim(p_client_id))=0 then raise exception 'ID pembayaran tidak valid'; end if;
 -- Retry after a lost response returns the same result instead of paying twice.
 select * into existing from public.receivable_payments where user_id=uid and client_id=p_client_id;
 if found then
  select * into rec from public.receivables where id=existing.receivable_id and user_id=uid;
  if not found then raise exception 'Piutang tidak ditemukan'; end if;
  return jsonb_build_object('receivable',to_jsonb(rec),'paymentId',existing.id,'transactionId',existing.transaction_id,'replayed',true);
 end if;
 select * into rec from public.receivables where id=p_receivable_id and user_id=uid for update;
 if not found then raise exception 'Piutang tidak ditemukan'; end if;
 if rec.status<>'active' then raise exception 'Piutang sudah lunas atau tidak aktif'; end if;
 if p_amount>=rec.amount then raise exception 'Pembayaran sebagian harus lebih kecil dari sisa piutang. Gunakan Tandai lunas untuk pelunasan penuh.'; end if;
 remaining:=rec.amount-p_amount;
 cid:='receivable-payment:'||p_client_id;
 insert into public.transactions(user_id,type,description,amount,date,category,note,client_id)
 values(uid,'income','Pembayaran piutang: '||rec.person,p_amount,p_date,'Piutang',coalesce(nullif(trim(p_note),''),'Pembayaran sebagian piutang'),cid)
 returning * into tx;
 insert into public.receivable_payments(receivable_id,user_id,amount,payment_date,note,client_id,transaction_id)
 values(p_receivable_id,uid,p_amount,p_date,nullif(trim(p_note),''),p_client_id,tx.id)
 returning id into payment_id;
 update public.receivables set amount=remaining where id=p_receivable_id and user_id=uid returning * into rec;
 return jsonb_build_object('receivable',to_jsonb(rec),'paymentId',payment_id,'transactionId',tx.id,'replayed',false);
end $$;
revoke all on function public.pay_receivable_partial_v30(uuid,numeric,date,text,text) from public,anon;
grant execute on function public.pay_receivable_partial_v30(uuid,numeric,date,text,text) to authenticated;

-- Full settlement ("Tandai lunas") used to only flip a status flag; the money received was
-- never booked anywhere. Now it books the remaining balance as income, same idempotency
-- pattern as the partial-payment function above.
create or replace function public.settle_receivable_v30(p_receivable_id uuid,p_date date,p_client_id text)
returns jsonb language plpgsql security invoker set search_path=public,pg_temp as $$
declare
 uid uuid:=auth.uid(); rec public.receivables%rowtype; existing public.receivable_payments%rowtype;
 tx public.transactions%rowtype; cid text; payment_id uuid;
begin
 if uid is null then raise exception 'Login diperlukan'; end if;
 if p_receivable_id is null then raise exception 'Piutang tidak ditemukan'; end if;
 if p_date is null or p_date>(now() at time zone 'Asia/Jakarta')::date then raise exception 'Tanggal pelunasan harus valid dan tidak di masa depan'; end if;
 if p_client_id is null or length(trim(p_client_id))=0 then raise exception 'ID pembayaran tidak valid'; end if;
 select * into existing from public.receivable_payments where user_id=uid and client_id=p_client_id;
 if found then
  select * into rec from public.receivables where id=existing.receivable_id and user_id=uid;
  if not found then raise exception 'Piutang tidak ditemukan'; end if;
  return jsonb_build_object('receivable',to_jsonb(rec),'paymentId',existing.id,'transactionId',existing.transaction_id,'replayed',true);
 end if;
 select * into rec from public.receivables where id=p_receivable_id and user_id=uid for update;
 if not found then raise exception 'Piutang tidak ditemukan'; end if;
 if rec.status<>'active' then raise exception 'Piutang sudah lunas atau tidak aktif'; end if;
 cid:='receivable-payment:'||p_client_id;
 insert into public.transactions(user_id,type,description,amount,date,category,note,client_id)
 values(uid,'income','Pelunasan piutang: '||rec.person,rec.amount,p_date,'Piutang','Piutang dilunasi penuh',cid)
 returning * into tx;
 insert into public.receivable_payments(receivable_id,user_id,amount,payment_date,note,client_id,transaction_id)
 values(p_receivable_id,uid,rec.amount,p_date,'Pelunasan penuh',p_client_id,tx.id)
 returning id into payment_id;
 update public.receivables set status='paid',paid_at=now() where id=p_receivable_id and user_id=uid returning * into rec;
 return jsonb_build_object('receivable',to_jsonb(rec),'paymentId',payment_id,'transactionId',tx.id,'replayed',false);
end $$;
revoke all on function public.settle_receivable_v30(uuid,date,text) from public,anon;
grant execute on function public.settle_receivable_v30(uuid,date,text) to authenticated;

commit;
