# AppCouple v27 — Matus Research Brain

## Yang berubah

- Matus kini boleh membahas topik di luar AppCouple: pengetahuan umum, teknologi, pekerjaan, hobi, obrolan santai, dan curhat.
- Karakter LU–GUA tetap dipertahankan, tetapi tidak lagi memaksa semua percakapan kembali ke keuangan, tugas, atau pasangan.
- Matus wajib mengakui ketidakpastian dan dilarang menebak, mengarang fakta, atau membuat sumber palsu.
- Pertanyaan yang jelas membutuhkan data terbaru langsung memicu pencarian.
- Untuk topik yang tidak dikenali model, model dapat meminta satu pencarian melalui protokol internal, kemudian menyusun jawaban kedua.
- Jawaban riset menampilkan penanda sumber `[1]`, `[2]` dan daftar tautan sumber yang benar-benar diperiksa.
- Hasil web diperlakukan sebagai data tidak tepercaya, bukan instruksi.

## Alur jawaban

1. Pertanyaan stabil dijawab langsung.
2. Pertanyaan terkini dicari lebih dulu.
3. Jika model menyatakan perlu riset, server menjalankan satu pencarian lalu model menjawab ulang dengan konteks sumber.
4. Pencarian dibatasi satu putaran per pesan agar tidak membuat loop.
5. Jika pencarian gagal atau sumber kurang, Matus harus mengatakan informasi tersebut belum dapat diverifikasi.

## Deploy Netlify

Endpoint baru:

- `POST /api/matus/search`
- Function: `netlify/functions/matus-search.cjs`

Pencarian hanya tersedia untuk sesi AppCouple yang valid. Browser mengirim token Supabase pengguna; kredensial provider pencarian tetap berada di server.

### Environment variables wajib

- `SUPABASE_URL`
- `SUPABASE_ANON_KEY` atau `SUPABASE_PUBLISHABLE_KEY`

### Provider pencarian opsional

Untuk hasil web yang lebih luas, isi salah satu:

- `TAVILY_API_KEY` — prioritas pertama
- `BRAVE_SEARCH_API_KEY` — prioritas kedua

Tanpa keduanya, server memakai sumber publik Wikipedia, DuckDuckGo Instant Answer, dan Google News RSS untuk pertanyaan terkini. Fallback publik tidak selengkap mesin pencarian berbayar.

## Privasi dan keamanan

- API key pencarian tidak pernah dikirim ke browser.
- Endpoint memvalidasi bearer session Supabase.
- Ada batas panjang kueri, timeout, cache singkat, pembatasan permintaan, sanitasi judul/cuplikan, dan maksimal enam hasil.
- Isi halaman/sumber tidak dieksekusi dan tidak boleh mengubah instruksi Matus.
- Mode demo tanpa sesi Supabase akan gagal dengan aman; Matus diminta jujur bahwa sumber belum dapat diverifikasi.

## Versi

- Build: `27.0.0`
- Cache service worker: `appcouple-next-v2700`
