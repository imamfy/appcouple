# AppCouple 30.3.0 — Perbaikan ringkasan pemasukan, pengeluaran, sisa, dan saldo

Paket ini adalah perbaikan bug, bukan migrasi database baru. Tidak ada perubahan skema SQL.

## Bug utama yang diperbaiki

**Kartu "Keuangan berdua" (Ringkasan bulan ini) di halaman pasangan SELALU menampilkan
"Belum tersedia" untuk saldo, walaupun data keuangan sudah lengkap.**

Akar masalah: `saveCoupleFinanceSummary()` di `supabase-service.js` membangun ulang objek
`safe` sebelum disimpan ke tabel `finance_summaries`, dan field `availableBalance` (saldo
total/berjalan) tidak pernah ikut disalin — hanya `income`, `expense`, dan `balance` bulanan
yang tersimpan. Sementara itu, kode tampilan di `couple-ui.js` (`renderFinanceSummaries`)
justru membaca `raw.availableBalance`, yang akibatnya selalu `undefined`. Efeknya, widget
gagal menampilkan angka apa pun — baik untuk akun sendiri maupun pasangan, di mode demo
maupun data asli.

### Perbaikan
- `saveCoupleFinanceSummary()` sekarang ikut menyimpan `availableBalance` (saldo total
  semua waktu) dan `monthNet` (pemasukan − pengeluaran bulan berjalan) secara eksplisit.
- `renderFinanceSummaries()` membaca `availableBalance` dengan fallback ke `balance` lama,
  supaya baris data yang sudah tersimpan sebelum pembaruan ini tetap tampil (tidak perlu
  migrasi data).
- `demoFinance()` diperbarui agar mode demo memakai jalur data yang sama dengan mode nyata.

## Saldo minus tidak lagi disembunyikan jadi Rp0

Sebelumnya kode client memakai `Math.max(0, saldo)` sebelum ditampilkan — kalau saldo
sebenarnya minus (misalnya salah satu pasangan sedang defisit bulan ini), tampilan tetap
menunjukkan **Rp0**, seolah keuangan aman. Sekarang:
- Nilai asli ditampilkan apa adanya, termasuk minus (format `-Rp...`).
- Kartu diberi kelas peringatan (warna merah) saat saldo minus, dan tooltip berubah jadi
  "Saldo total sedang minus. Periksa pengeluaran bulan ini."
- Saat data pasangan basi (belum dibuka bulan ini), pengeluaran ditampilkan `—` alih-alih
  `Rp0`, supaya tidak disalahartikan sebagai "belum ada pengeluaran".

## Konsep baru: 4 angka yang jelas dibedakan, bukan 3 yang membingungkan

Kartu ringkasan di halaman Keuangan pribadi sebelumnya menampilkan **Pemasukan bulan ini**,
**Pengeluaran bulan ini**, dan **Saldo pembukuan** berdampingan — padahal dua angka pertama
bersifat bulanan sedangkan angka ketiga adalah akumulasi *sepanjang waktu*. Ini mudah
disalahartikan seolah saldo = pemasukan bulan ini dikurangi pengeluaran bulan ini.

Sekarang kartu tersebut menampilkan empat konsep secara eksplisit:
1. **Pemasukan bulan ini**
2. **Pengeluaran bulan ini**
3. **Sisa bulan ini** — `pemasukan bulan ini − pengeluaran bulan ini`, boleh minus, dan
   berubah warna merah saat minus (bukan disembunyikan).
4. **Saldo total (semua waktu)** — akumulasi seluruh transaksi sampai hari ini, label diubah
   dari "Saldo pembukuan" agar tidak tertukar dengan angka bulanan.

## Berkas yang diubah
- `src/supabase-service.js` — perbaikan penyimpanan ringkasan (akar masalah).
- `src/couple-ui.js` — perbaikan tampilan, fallback data lama, indikator saldo minus.
- `src/finance-ui.js` — tambahan angka "Sisa bulan ini" dan penjelasan `monthNet` pada
  event `appcouple:finance-update`.
- `index.html` — label kartu ringkasan keuangan diperjelas, badge versi ke 30.3.0.

## Yang belum disentuh (di luar cakupan perbaikan ini)
- Ledger cicilan piutang (pembayaran sebagian masih menimpa satu field `amount` + catatan
  teks, belum atomic dan belum tercatat sebagai transaksi kas). Ini ditemukan saat audit
  tapi sengaja tidak diubah karena fokus permintaan kali ini adalah pemasukan/pengeluaran/
  sisa/saldo. Beri tahu saya kalau mau lanjut ke sana berikutnya.
- Skema database, RLS, dan fungsi atomic tagihan (bills) tidak diubah.

## Pengujian yang disarankan sebelum deploy
1. Dua akun tersambung sebagai pasangan: masing-masing catat transaksi, buka halaman
   Keuangan, lalu buka halaman Ruang Kita → pastikan saldo masing-masing muncul (bukan
   "Belum tersedia").
2. Buat salah satu akun defisit (pengeluaran > pemasukan sepanjang waktu) → pastikan saldo
   tampil minus berwarna merah, bukan Rp0.
3. Refresh browser, cek localStorage lama tidak menyebabkan crash pada baris `finance_summaries`
   yang belum punya `availableBalance` (baris lama harus tetap tampil via fallback `balance`).
4. Cek kartu Keuangan pribadi menampilkan 4 angka dan "Sisa bulan ini" berubah merah saat
   pengeluaran bulan ini melebihi pemasukan bulan ini.
