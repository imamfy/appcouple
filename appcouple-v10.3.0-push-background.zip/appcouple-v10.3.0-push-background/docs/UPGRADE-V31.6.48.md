# Upgrade v31.6.48 — Wedding Command Center

## Aplikasi
- Pusat Tindakan otomatis untuk risiko budget, tugas terlambat, pembayaran vendor, RSVP, dan target tabungan.
- Budget item menyimpan rencana, realisasi, selisih, dan tenggat.
- Progress budget memakai tingkat alokasi, bukan semakin banyak uang dibelanjakan.
- Tamu menyimpan WhatsApp dan batas RSVP.
- Vendor menyimpan status kontrak dan jatuh tempo pembayaran.
- Tabungan menampilkan kebutuhan setoran per bulan.
- Seluruh field baru masuk ke konteks Matus.

## Excel
- Sheet Anggaran: Rencana, Realisasi, Selisih, Tenggat.
- Sheet Tamu: WhatsApp dan Batas RSVP.
- Sheet Vendor: Status kontrak dan Jatuh tempo.
- Dashboard dan Ringkasan memakai metrik budget teralokasi yang sama dengan aplikasi.
- Struktur lama tetap terbaca; field baru memiliki fallback kosong/0.
