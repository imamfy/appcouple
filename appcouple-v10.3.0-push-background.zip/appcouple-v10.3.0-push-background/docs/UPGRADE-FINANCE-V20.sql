-- Finance v20 migration. Review and back up first. Run in Supabase SQL Editor.
-- No transaction / receivable rows are deleted. Legacy invalid rows are not rewritten.
begin;
create unique index if not exists transactions_client on public.transactions(user_id,client_id) where client_id is not null;

create table if not exists public.finance_audit(
 id bigint generated always as identity primary key,
 user_id uuid not null,
 actor_id uuid,
 entity text not null,
 entity_id uuid not null,
 operation text not null,
 old_data jsonb,
 new_data jsonb,
 occurred_at timestamptz not null default now()
);
alter table public.finance_audit enable row level security;
drop policy if exists finance_audit_owner_read on public.finance_audit;
create policy finance_audit_owner_read on public.finance_audit for select to authenticated using(user_id=auth.uid());
revoke all on public.finance_audit from anon,authenticated;
grant select on public.finance_audit to authenticated;
create or replace function public.capture_finance_audit_v20() returns trigger
language plpgsql security definer set search_path=public,pg_temp as $$
begin
 insert into public.finance_audit(user_id,actor_id,entity,entity_id,operation,old_data,new_data)
 values(case when TG_OP='DELETE' then OLD.user_id else NEW.user_id end,auth.uid(),TG_TABLE_NAME,
 case when TG_OP='DELETE' then OLD.id else NEW.id end,TG_OP,
 case when TG_OP in ('UPDATE','DELETE') then to_jsonb(OLD) else null end,
 case when TG_OP in ('INSERT','UPDATE') then to_jsonb(NEW) else null end);
 if TG_OP='DELETE' then return OLD; end if;return NEW;
end $$;
revoke all on function public.capture_finance_audit_v20() from public;
drop trigger if exists finance_audit_transactions_v20 on public.transactions;
create trigger finance_audit_transactions_v20 after insert or update or delete on public.transactions for each row execute function public.capture_finance_audit_v20();
drop trigger if exists finance_audit_receivables_v20 on public.receivables;
create trigger finance_audit_receivables_v20 after insert or update or delete on public.receivables for each row execute function public.capture_finance_audit_v20();

-- Members read each other's summaries; only the owner writes their own summary.
drop policy if exists couple_rows on public.finance_summaries;
drop policy if exists finance_summary_read_v20 on public.finance_summaries;
drop policy if exists finance_summary_insert_v20 on public.finance_summaries;
drop policy if exists finance_summary_update_v20 on public.finance_summaries;
drop policy if exists finance_summary_delete_v20 on public.finance_summaries;
create policy finance_summary_read_v20 on public.finance_summaries for select to authenticated using(public.is_couple_member(couple_id));
create policy finance_summary_insert_v20 on public.finance_summaries for insert to authenticated with check(user_id=auth.uid() and public.is_couple_member(couple_id));
create policy finance_summary_update_v20 on public.finance_summaries for update to authenticated using(user_id=auth.uid() and public.is_couple_member(couple_id)) with check(user_id=auth.uid() and public.is_couple_member(couple_id));
create policy finance_summary_delete_v20 on public.finance_summaries for delete to authenticated using(user_id=auth.uid() and public.is_couple_member(couple_id));

do $$ begin
 if not exists(select 1 from pg_constraint where conname='receivables_valid_v20' and conrelid='public.receivables'::regclass) then
 alter table public.receivables add constraint receivables_valid_v20 check(amount>0 and amount=trunc(amount) and status in ('active','paid') and date is not null and due_date is not null and due_date>=date) not valid;
 end if;
 if not exists(select 1 from pg_constraint where conname='transactions_rupiah_v20' and conrelid='public.transactions'::regclass) then
 alter table public.transactions add constraint transactions_rupiah_v20 check(amount=trunc(amount) and amount<=1000000000 and length(trim(description))>0) not valid;
 end if;
end $$;

do $$ begin
 if not exists(select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='receivables') then
 alter publication supabase_realtime add table public.receivables;
 end if;
end $$;

-- Row lock prevents concurrent deposits from overwriting one another.
create or replace function public.finance_shared_deposit_v20(p_couple uuid,p_amount numeric,p_note text default '') returns jsonb
language plpgsql security invoker set search_path=public,pg_temp as $$
declare current_data jsonb; entry jsonb; result jsonb;
begin
 if auth.uid() is null or not public.is_couple_member(p_couple) then raise exception 'Not authorized';end if;
 if p_amount is null or p_amount<=0 or p_amount>1000000000 or p_amount<>trunc(p_amount) then raise exception 'Invalid deposit';end if;
 insert into public.couple_state(couple_id,key,data,updated_by,updated_at) values(p_couple,'shared','{}',auth.uid(),now()) on conflict(couple_id,key) do nothing;
 select data into current_data from public.couple_state where couple_id=p_couple and key='shared' for update;
 entry=jsonb_build_object('id',gen_random_uuid(),'amount',p_amount,'note',left(coalesce(p_note,''),100),'by',auth.uid(),'byName',coalesce((select name from public.profiles where id=auth.uid()),'Pengguna'),'createdAt',now());
 result=coalesce(current_data,'{}')||jsonb_build_object('savingTotal',coalesce((current_data->>'savingTotal')::numeric,0)+p_amount,'deposits',jsonb_build_array(entry)||coalesce(current_data->'deposits','[]'::jsonb));
 update public.couple_state set data=result,updated_by=auth.uid(),updated_at=now() where couple_id=p_couple and key='shared';
 return jsonb_build_object('id',entry->>'id','total',result->'savingTotal');
end $$;
revoke all on function public.finance_shared_deposit_v20(uuid,numeric,text) from public,anon;
grant execute on function public.finance_shared_deposit_v20(uuid,numeric,text) to authenticated;
commit;
