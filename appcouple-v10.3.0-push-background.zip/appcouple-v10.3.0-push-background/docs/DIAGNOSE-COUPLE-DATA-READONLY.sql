select id,email,name,couple_id,partner_id,connection_date from public.profiles order by updated_at desc;

select source,couple_id,row_count from (
  select 'profiles'::text source,couple_id,count(*)::bigint row_count from public.profiles where couple_id is not null group by couple_id
  union all select 'finance_summaries',couple_id,count(*) from public.finance_summaries group by couple_id
  union all select 'messages',couple_id,count(*) from public.messages group by couple_id
  union all select 'typing',couple_id,count(*) from public.typing group by couple_id
  union all select 'couple_state',couple_id,count(*) from public.couple_state group by couple_id
  union all select 'pulse',couple_id,count(*) from public.pulse group by couple_id
  union all select 'activities',couple_id,count(*) from public.activities group by couple_id
  union all select 'memories',couple_id,count(*) from public.memories group by couple_id
  union all select 'live_locations',couple_id,count(*) from public.live_locations group by couple_id
  union all select 'location_history',couple_id,count(*) from public.location_history group by couple_id
  union all select 'matus_messages',couple_id,count(*) from public.matus_messages group by couple_id
  union all select 'daily_points',couple_id,count(*) from public.daily_points group by couple_id
) x
order by couple_id,source;
