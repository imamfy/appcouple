# AppCouple v29 — Perbaikan keamanan dan kestabilan

Paket ini menggantikan v28; peta tetap full-screen. Tidak mengubah layanan produksi secara otomatis.

## WAJIB sebelum deploy

1. Cadangkan database dan folder Drive. Uji di staging dulu.
2. Di Supabase → Authentication → Users, salin UUID akun kamu dan pasangan. Bukan email atau couple_id.
3. Di Netlify Environment variables, isi:
   - `APPCOUPLE_ALLOWED_USER_IDS`: dua UUID dipisahkan koma, tanpa tanda kutip. Satu UUID juga dapat dipakai saat setup.
   - `SUPABASE_URL`
   - `SUPABASE_ANON_KEY` atau `SUPABASE_PUBLISHABLE_KEY`
   - `GOOGLE_DRIVE_FOLDER_ID` — opsional. Hapus/kosongkan agar aplikasi membuat folder **AppCouple Kenangan** otomatis; isi ID/URL hanya bila ingin memakai folder tertentu.
   - `GOOGLE_DRIVE_CLIENT_ID`
   - `GOOGLE_DRIVE_CLIENT_SECRET`
   - `GOOGLE_DRIVE_REFRESH_TOKEN`
4. Alternatif OAuth: `GOOGLE_DRIVE_SERVICE_ACCOUNT_JSON` untuk akun yang benar-benar memiliki kemampuan menulis di Shared Drive. Jika variabel ini diisi, ia diprioritaskan; hapus konfigurasi lama yang sudah tidak dipakai.
5. Pastikan Google Drive API aktif dan akun OAuth berhak mengedit folder. Tidak perlu membuat folder publik.
6. Jalankan `UPGRADE-FINANCE-V29.sql` setelah migrasi v20, v21, v22. Baca batas pengujian di bawah.
7. Deploy seluruh isi folder `finance-v29` melalui Git/Netlify CLI yang membangun Netlify Functions. Jangan hanya mengunggah HTML ke hosting statis. Publish directory: `.` pada root project ini. Functions directory: `netlify/functions`.
8. Redeploy setelah mengubah environment variables. Login ulang dan tekan Refresh di Kenangan.

Backend Drive, pencarian, dan AI server sekarang MENOLAK akses jika daftar akun kosong. Ini pengamanan sengaja, bukan error yang boleh dilewati. Hapus UUID pasangan dari daftar dan redeploy jika akses pasangan dicabut. Desain ini untuk SATU pasangan per deployment, bukan aplikasi multi-tenant.

## Pembayaran tagihan

- Transaksi dan pembaruan planner kini menggunakan satu fungsi database atomik dengan row lock.
- Satu pembayaran menyelesaikan satu periode. Tunggakan lain tidak otomatis dilunasi.
- Nominal aktual boleh berbeda karena diskon/denda, tetapi pembayaran ini berarti periode tersebut selesai. Cicilan parsial belum didukung.
- Lewati juga hanya melewati satu periode tanpa transaksi.
- Retry dengan periode, nominal, dan tanggal sama mengembalikan hasil sebelumnya.
- Revisi lama ditolak. Pengguna harus muat ulang jika perangkat lain mengubah planner.
- Jika migrasi v29 belum dipasang, pembayaran ditolak; tidak ada fallback ke alur lama dua tahap.
- Riwayat lama yang keliru tidak dikoreksi otomatis. Rekonsiliasi sebelum mengedit, jangan membayar ulang tanpa memeriksa transaksi lama.
- Transaksi lama untuk periode yang sama dapat direkonsiliasi jika nominal/tanggal cocok; perbedaan ditolak agar tidak dobel.

## Matus dan key AI

- Default baru: provider Server privat. Pilih provider ini di pengaturan AI; key tidak diisi di browser.
- Environment variables server:
  - `MATUS_AI_API_KEY`
  - `MATUS_AI_MODEL`: nama model yang didukung akun provider
  - `MATUS_AI_BASE_URL`: opsional, default `https://api.openai.com/v1`; gunakan endpoint OpenAI-compatible tanpa `/chat/completions` di belakangnya.
- Server AI tidak otomatis mendukung protokol native semua provider; Gemini/Anthropic native tetap melalui pilihan provider pribadi yang sudah ada.
- Key pribadi lama di localStorage DIHAPUS pada pembaruan. Masukkan kembali bila memilih mode pribadi; hanya bertahan dalam sesi tab. Sesi browser tetap bukan penyimpanan rahasia yang kebal XSS. Logout menghapusnya.
- Pencarian opsional: `TAVILY_API_KEY` atau `BRAVE_SEARCH_API_KEY`.
- Maksimal satu pencarian per pesan; tag internal dibuang; semua enam sumber dapat ditampilkan.
- Hasil kosong/gagal memberikan jawaban ketidakpastian yang ditentukan aplikasi, tidak meminta model menebak.
- Filter privasi memblokir pola data sensitif yang dikenali. Ini perlindungan heuristik, bukan jaminan mendeteksi seluruh informasi pribadi. Kueri pencarian tetap dikirim ke provider eksternal.
- Data konteks aplikasi yang izin aksesnya diaktifkan masih dikirim ke provider AI untuk menyusun jawaban, termasuk pada mode server. Jangan mengaktifkan izin konteks yang tidak diperlukan.
- Sumber berupa cuplikan pencarian, bukan pembacaan penuh halaman. Sitasi valid tidak menjamin semua klaim model benar.
- Rate limit masih per instance serverless; bukan kuota global terdistribusi.

## Kenangan dan peta

- Alamat yang diedit dicari ulang koordinatnya; tanggal/koordinat divalidasi juga di backend.
- Foto tanpa koordinat tidak dianggap berada di (0,0).
- Hapus memindahkan ke Sampah Drive. Pemulihan melalui Google Drive → Trash/Sampah → Restore, lalu Refresh di aplikasi. Kebijakan retensi Google tetap berlaku.
- Daftar menggunakan halaman 60 file; UI menampilkan bertahap 24 foto. Tombol Muat lebih banyak mengambil halaman berikutnya.
- Filter, statistik, dan pin peta hanya mencakup file yang SUDAH dimuat, bukan keseluruhan folder. Muat halaman berikutnya untuk melihat data lain.
- Galeri memakai thumbnail Drive; jika Google belum menyediakan thumbnail, kartu sementara menampilkan placeholder. Klik foto mengambil file asli.
- Foto asli berukuran besar yang sudah ada di Drive dapat melampaui batas respons hosting; unduh/buka langsung di Google Drive jika gagal. Unggah aplikasi tetap maksimum 4 MB.
- Pencarian peta tetap tersedia pada layar 390 px ke bawah. Panel lokasi memakai selector yang benar.

## Pengujian dan batas yang belum selesai

- Pengujian otomatis backend menggunakan MOCK, tidak mengakses foto, akun, atau key produksi.
- Pengujian browser menggunakan mode demo/mocks; koneksi Google, AI live, dan Netlify produksi harus diperiksa setelah deploy.
- Mesin PostgreSQL lokal tidak tersedia dan unduhan dependensi pengujian gagal karena jaringan sandbox. SQL v29 sudah ditinjau tetapi BELUM dieksekusi terhadap PostgreSQL dalam sesi ini. Wajib uji staging sebelum produksi: pembayaran normal, retry, stale revision, rollback, dua perangkat, akhir bulan, dan RLS beda akun.
- CSS utama lama belum dirombak menyeluruh. Perbaikan selector dilakukan terarah untuk menjaga tampilan. Refactor total stylesheet masih pekerjaan berikutnya.
- CSP dasar sekarang diterapkan (object/base/frame), tetapi pembatasan script/connect lengkap masih report-only agar integrasi lama tidak rusak. Bukan klaim perlindungan XSS menyeluruh.

## Uji penerimaan staging

1. Akun di luar daftar: endpoint Drive/AI ditolak 403. Daftar kosong: gagal tertutup 503.
2. Akun terdaftar: daftar folder, upload foto dengan alamat, buka foto, edit alamat, favorit, pindah Trash, restore melalui Google.
3. Tagihan bulanan tertunggak tiga periode: bayar sekali, hanya satu periode maju. Muat ulang, saldo harus sama.
4. Kirim ulang pembayaran yang sama: jumlah transaksi tetap satu. Nominal retry berbeda harus ditolak.
5. Ubah planner dari perangkat B lalu bayar dari snapshot A: ditolak tanpa transaksi baru.
6. Sengaja gagalkan constraint pembaruan planner di staging: transaksi pembayaran harus rollback bersama planner.
7. Login akun lain: tidak dapat membaca/menulis keuangan akun sebelumnya.
8. Matus: pertanyaan umum, pertanyaan terkini, sumber kosong, kueri sensitif, server belum dikonfigurasi, provider timeout.
9. Peta: mobile 360/390 px, desktop, buka/tutup Album dan lokasi, kembali ke aplikasi.

Tidak ada migrasi, pemindahan foto, deployment, atau perubahan kredensial produksi yang dilakukan saat membuat paket ini.

## Folder Google Drive otomatis 29.6

- `GOOGLE_DRIVE_FOLDER_ID` sekarang **opsional**.
- Jika variabel tersebut dikosongkan atau dihapus, backend mencari folder aplikasi yang pernah dibuat sebelumnya.
- Jika belum ada, backend otomatis membuat folder **AppCouple Kenangan** di akun Google Drive yang terhubung.
- ID folder hasil pembuatan dipakai otomatis untuk daftar foto, upload, edit, favorit, unduh, dan pindah ke Sampah.
- Kredensial OAuth atau service account tetap diperlukan karena pembuatan folder dilakukan melalui Google Drive API.

## Koreksi Ringkasan Keuangan 29.5

- **Sisa bulan ini** pada **Ringkasan bulan ini → Keuangan berdua** sekarang mengambil **Saldo pembukuan** saja.
- Nilainya tidak lagi dihitung dari pemasukan dikurangi pengeluaran bulan berjalan.
- Saldo pembukuan negatif ditampilkan sebagai **Rp0**, bukan angka minus.

## Ringkasan keuangan dan Drive 29.4

- Catatan versi 29.4: rumus gabungan bulanan telah digantikan pada versi 29.5 oleh Saldo pembukuan saja.
- Folder Kenangan bawaan diarahkan ke `https://drive.google.com/drive/folders/1WcQPFYB826nlhINaYtMiDXxxufhGO1C_`.
- Foto yang sudah berada langsung di folder tersebut dimuat otomatis saat pengguna masuk dan halaman Kenangan diinisialisasi.
- Jika `GOOGLE_DRIVE_FOLDER_ID` dipasang di Netlify, nilainya tetap menjadi konfigurasi utama. Isi dengan URL di atas agar deployment memakai folder yang sama.

## Perbaikan tata letak peta 29.3

- Menghapus transform overscan yang membuat kanvas melewati viewport.
- Mengisolasi HUD GPS lama yang berubah menjadi bidang putih di sisi kiri.
- Merapikan header, pemilih layer, kartu jarak, kontrol bawah, zoom, dan kompas pada desktop serta mobile.
- Panel Album dan Lokasi menjadi bottom sheet yang tidak bertabrakan dengan dock pada mobile.
- Grid foto Album memakai rasio konsisten dan tidak menimbulkan overflow horizontal.

## Hotfix galeri 29.2

- `GOOGLE_DRIVE_FOLDER_ID` sekarang menerima ID maupun URL folder lengkap.
- Shortcut folder Drive didukung jika target dapat diakses akun backend.
- Pesan error membedakan ID salah, folder di Sampah, target shortcut hilang, dan izin akun backend.

## Hotfix peta 29.1

Hotfix ini memperbaiki peta yang terjepit menjadi strip sempit seperti Screenshot_111. Akar masalahnya adalah konflik beberapa generasi CSS peta pada viewport/embedded view sangat sempit. Layer terakhir kini mengisolasi ukuran peta memakai visual viewport, mereset scroll horizontal, menjepit label marker, dan mengganti kontrol dengan mode ultra-ringkas di bawah 240 px. Diuji pada lebar 120, 240, 320, 360, 390, dan 412 px tanpa overflow.


## Build 29.7.0 — Responsive UI Polish

- Pencarian peta dipusatkan di desktop dan dibuat selebar viewport aman di mobile.
- Tombol cari dan tutup selalu terlihat; kontrol jarak/lapisan yang bertabrakan disembunyikan saat pencarian terbuka.
- Kenangan Kita dirapikan menyeluruh: hero, ringkasan, status Drive, cerita terbaru, toolbar, dan kartu galeri.
- Galeri memakai 3 kolom desktop, 2 kolom mobile, dan 1 kolom untuk layar sangat sempit.
- Tidak menambah stylesheet override baru: otoritas akhir tetap di `map-layout-v293.css` dan `memory-love-v25.css`.
- QA: `QA-UI-LAYOUT-V297.json`.


## Build 29.8.0 — Memory Map Sync

- Foto Kenangan dari Google Drive kini digabungkan ke sumber data Peta Cinta.
- Unggahan baru langsung membuat pin dan item Album Jejak tanpa menunggu reload.
- Thumbnail foto ikut digunakan pada marker peta setelah selesai dimuat.
- Data kenangan Supabase tetap dipertahankan dan digabung tanpa duplikasi ID.
- QA: `QA-MEMORY-MAP-SYNC-V298.json`.
