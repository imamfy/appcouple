# AppCouple v31.6.46 — Jalan Berdua terhubung ke Matus

Hasil Jalan Berdua sekarang dipublikasikan sebagai konteks Matus yang terstruktur:

- asal, tujuan, tanggal, durasi, jumlah orang, dan budget;
- seluruh agenda itinerary per hari;
- hasil analisis rute, jarak, waktu, konflik, dan warning lokasi;
- ringkasan pengeluaran dan pembagian pembayaran;
- progres checklist perjalanan;
- insight Matus terakhir.

Konteks mengikuti izin **Aktivitas / Couple Space**. Jika izin dimatikan,
Matus tidak menerima data Jalan Berdua.

Mode AI dan mode lokal sama-sama dapat menjawab pertanyaan seperti:

- “Bagaimana itinerary perjalanan saya?”
- “Agenda hari kedua apa saja?”
- “Ada jadwal yang bertabrakan?”
- “Lokasi mana yang belum bisa dianalisis?”
- “Budget dan pengeluaran perjalanan masih aman?”

Matus dilarang mengarang traffic, jarak, waktu, harga, atau lokasi yang tidak
tersedia dalam konteks.