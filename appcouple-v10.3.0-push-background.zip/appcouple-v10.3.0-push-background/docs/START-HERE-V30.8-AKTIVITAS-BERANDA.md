# AppCouple 30.8.0 — Transaksi keuangan hilang dari "Aktivitas Terbaru" di Beranda

Ditemukan saat mengaudit kartu "Couple Today" dan bagian sekitarnya di halaman Beranda.

## Bug 1: `financeRows` dibangun tapi tidak pernah dipakai

Di `renderActivityFeed()` (`src/home-ui.js`), transaksi keuangan (`financeActivity`, diisi
dari `summary.recent` yang dikirim `finance-ui.js`) sudah dipetakan dengan benar jadi
`financeRows` — judul, ikon, nominal, semua lengkap. Tapi baris terakhir fungsi ini cuma
memakai `coupleRows`:
```js
const rows = coupleRows.sort((a, b) => b.time - a.time).slice(0, 5);
```
`financeRows` jadi dead code. Efeknya: kartu "Aktivitas Terbaru" di Beranda **tidak pernah**
menampilkan transaksi pemasukan/pengeluaran — hanya aktivitas non-keuangan (tabungan, hadiah,
lokasi, kenangan, dll) yang muncul, walau data transaksinya sudah tersedia dan siap pakai.

**Perbaikan:** gabungkan kedua sumber sebelum diurutkan:
```js
const rows = [...coupleRows, ...financeRows].sort((a, b) => b.time - a.time).slice(0, 5);
```

## Bug 2: Ikon panah pemasukan/pengeluaran terbalik

Pada `financeRows` yang sama, ikon trennya kebalik:
```js
icon: item.type === 'income' ? 'arrow-trend-down' : 'arrow-trend-up'
```
Pemasukan mendapat ikon panah turun, pengeluaran mendapat panah naik — kebalik dari konvensi
yang sudah benar di halaman Laporan Keuangan (pemasukan = panah naik, pengeluaran = panah
turun). Diperbaiki jadi:
```js
icon: item.type === 'income' ? 'arrow-trend-up' : 'arrow-trend-down'
```

## Berkas yang diubah
- `src/home-ui.js` — `renderActivityFeed()`.

## Pengujian yang disarankan
1. Catat satu transaksi pemasukan dan satu pengeluaran, lalu buka Beranda → keduanya harus
   muncul di "Aktivitas Terbaru", berselang dengan aktivitas non-keuangan sesuai urutan waktu.
2. Cek ikon: pemasukan panah naik (hijau), pengeluaran panah turun (pink/merah).
