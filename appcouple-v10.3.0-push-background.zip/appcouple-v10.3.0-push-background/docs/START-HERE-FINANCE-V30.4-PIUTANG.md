# AppCouple 30.4.0 — Ledger pembayaran piutang

Paket ini menutup kekurangan yang ditemukan saat audit fitur "Bayar sebagian" piutang.
Menambah tabel dan dua fungsi database baru (`UPGRADE-FINANCE-V30.sql`). Jalankan setelah
v20, v21, v22, v29 di staging dulu — belum dieksekusi terhadap PostgreSQL sungguhan dalam
sesi ini.

## Masalah sebelumnya

1. **Uang yang kembali tidak pernah tercatat sebagai transaksi.** Pembayaran sebagian
   maupun pelunasan penuh hanya mengubah field `amount`/`status` pada baris piutang. Tidak
   ada transaksi pemasukan yang dibuat, jadi cicilan yang diterima tidak pernah muncul di
   "Pemasukan bulan ini", laporan, atau saldo.
2. **Riwayat pembayaran berupa teks yang bisa hilang.** Setiap cicilan ditempel sebagai satu
   baris ke field `note`, lalu dipotong ke 200 karakter terakhir (`slice(-200)`) — riwayat
   lama otomatis terhapus begitu string terlalu panjang.
3. **Tidak atomic.** `saveReceivable()` melakukan select→update tanpa row lock atau
   pengecekan revisi. Dua perangkat yang membayar piutang yang sama hampir bersamaan bisa
   saling menimpa.
4. **Validasi hanya di client.** Server tidak memeriksa bahwa nominal cicilan harus lebih
   kecil dari sisa piutang.

## Perbaikan (konsep baru)

- Tabel baru `receivable_payments`: satu baris permanen per cicilan (`amount`, `payment_date`,
  `note`, `transaction_id`). Baris ini tidak pernah ditimpa, jadi riwayat lengkap selalu ada,
  seberapa pun banyak cicilan yang tercatat.
- Fungsi database atomic `pay_receivable_partial_v30`: mengunci baris piutang (`for update`),
  memvalidasi nominal dan tanggal di server, membuat transaksi pemasukan, mencatat baris
  ledger, lalu mengurangi sisa piutang — semua dalam satu transaksi database. Idempotent:
  retry dengan client ID yang sama mengembalikan hasil yang sama, tidak membayar dua kali.
- Fungsi database atomic `settle_receivable_v30`: dipakai saat "Tandai lunas". Sebelumnya
  aksi ini tidak membuat transaksi apa pun; sekarang sisa piutang dibukukan sebagai
  pemasukan sebelum status diubah menjadi lunas.
- Kolom baru `receivables.original_amount` menyimpan nominal pinjaman awal. Baris lama
  di-backfill dengan nilai `amount` saat ini sebagai perkiraan terbaik — nominal asli yang
  sudah tertimpa cicilan sebelum pembaruan ini tidak bisa dipulihkan dari data yang ada.
- UI "Bayar sebagian" sekarang menampilkan **riwayat cicilan** (dari `receivable_payments`),
  bukan lagi teks yang berpotensi terpotong.

## Yang sengaja tidak diubah

- Piutang yang sudah dilunasi lewat cara lama (sebelum v30.4) tidak dikoreksi otomatis;
  transaksi pemasukan untuk pelunasan itu tidak dibuat retroaktif.
- "Aktifkan lagi" (dari lunas kembali ke aktif) tetap aksi sederhana ubah status, tidak
  membalik transaksi yang sudah dibukukan — konsisten dengan cara tagihan (bills) menangani
  koreksi manual.
- Mode offline untuk pembayaran piutang tidak didukung (sama seperti pembayaran tagihan
  sejak v29): jika koneksi terputus saat menyimpan, pengguna diminta mencoba lagi saat
  online, bukan diam-diam disimpan lokal lalu disinkronkan nanti — supaya tidak ada nominal
  yang tercatat dua kali atau berbeda dari server.

## Pengujian yang disarankan sebelum deploy

1. Bayar sebagian sebuah piutang → cek transaksi pemasukan baru muncul di Riwayat Transaksi
   dan di "Pemasukan bulan ini".
2. Ulangi submit dengan koneksi terputus di tengah jalan, lalu retry → pastikan hanya satu
   transaksi dan satu baris ledger yang tercatat (tidak dobel).
3. Tandai piutang lunas → cek transaksi pemasukan sebesar sisa piutang muncul.
4. Coba bayar sebagian dua kali dari dua tab/perangkat untuk piutang yang sama → satu
   berhasil, satu lagi mendapat error yang jelas (bukan data yang salah senyap).
5. Buka modal "Bayar sebagian" pada piutang yang sudah punya beberapa cicilan → riwayat
   tampil lengkap, terbaru di atas.
