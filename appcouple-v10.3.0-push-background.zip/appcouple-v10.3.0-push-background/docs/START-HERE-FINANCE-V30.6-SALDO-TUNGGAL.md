# AppCouple 30.6.0 — Saldo sebagai satu angka utama

Menggantikan pendekatan v30.5 (yang menambah baris "Saldo awal bulan" terpisah) dengan
sesuatu yang lebih sederhana, atas permintaan langsung: jadikan satu angka saja sebagai
fokus, mirip tampilan saldo di aplikasi m-banking.

## Perubahan

Kartu ringkasan kini:
- **Saldo** — satu-satunya angka besar (hero number). Ini saldo total, akumulasi sepanjang
  waktu, jadi defisit bulan lalu otomatis sudah "terpotong" oleh pemasukan berikutnya —
  tidak perlu dihitung manual atau dilihat sebagai baris terpisah.
- **Bulan ini** — subjudul kecil di bawahnya (bekas "Sisa bulan ini"), tetap ada tapi bukan
  kartu sendiri. Fungsinya jadi peringatan dini: kalau bulan ini boros parah, tetap kelihatan
  merah meskipun Saldo besar masih terlihat aman karena menumpang tabungan lama.
- Baris "Saldo awal bulan" (v30.5) dihapus — begitu Saldo total jadi fokus utama, baris
  penjelas itu jadi berlebihan.

## Kenapa "Bulan ini" tidak ikut dihapus total

Kalau cuma satu angka Saldo yang tampil tanpa info bulan berjalan sama sekali, masalah bulan
ini yang sedang terjadi bisa tersembunyi di balik tabungan lama — persis pola yang
menyebabkan bug `Math.max(0,n)` di v30.3 dulu (defisit nyata tidak kelihatan). "Bulan ini"
tetap dipertahankan dalam ukuran kecil supaya sinyal itu tidak hilang, tapi tidak lagi
bersaing perhatian dengan angka Saldo utama.

## Berkas yang diubah
- `index.html` — kartu ringkasan disederhanakan ke 1 angka utama + 1 subjudul.
- `src/finance-ui.js` — hapus perhitungan `monthOpening` yang tidak lagi ditampilkan.
