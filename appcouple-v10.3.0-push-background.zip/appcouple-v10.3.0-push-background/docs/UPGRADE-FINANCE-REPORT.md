# Upgrade Laporan Keuangan v4.0

## Peningkatan tampilan
- Dashboard monitoring yang lebih bersih, responsif, dan konsisten untuk desktop/mobile.
- Skor kesehatan keuangan dengan indikator progres dan rekomendasi otomatis.
- Kartu metrik utama dengan perbandingan terhadap periode sebelumnya.
- Ringkasan cepat: rata-rata pengeluaran harian, kategori terbesar, rasio pengeluaran, dan rata-rata transaksi.
- Grafik arus kas dan grafik saldo kumulatif yang lebih mudah dibaca.
- Komposisi pemasukan/pengeluaran lengkap dengan persentase.

## Peningkatan fungsi
- Pilihan periode 14 hari, 12 bulan, dan tahunan.
- Perbandingan otomatis dengan periode sebelumnya.
- Pencarian transaksi berdasarkan deskripsi, kategori, dan catatan.
- Filter jenis transaksi serta pengurutan tanggal/nominal.
- Ekspor laporan terfilter ke CSV.
- Dukungan cetak laporan.
- Tampilan gelap, responsive mobile, safe-area, dan reduced motion.

## Validasi
- JavaScript lolos pemeriksaan sintaks.
- Diuji pada 1440×900 dan 390×844.
- Tidak ada horizontal overflow pada dashboard utama.
