select
  c.id as couple_id,
  c.created_by,
  c.created_at,
  count(distinct p.id) as linked_profiles,
  string_agg(distinct coalesce(p.email,p.name), ', ') as linked_accounts,
  cs.updated_at as shared_updated_at,
  coalesce((cs.data->>'points')::numeric,0) as love_points,
  jsonb_array_length(coalesce(cs.data->'rewards','[]'::jsonb)) as reward_count,
  jsonb_array_length(coalesce(cs.data->'claims','[]'::jsonb)) as claim_count,
  case when cs.data ? 'weddingPlan' then 'ADA' else 'KOSONG' end as wedding_plan,
  case when cs.data ? 'tripPlan' then 'ADA' else 'KOSONG' end as trip_plan,
  jsonb_array_length(coalesce(cs.data->'tripExpenses','[]'::jsonb)) as trip_expenses,
  jsonb_array_length(coalesce(cs.data->'tripItinerary','[]'::jsonb)) as trip_itinerary,
  jsonb_array_length(coalesce(cs.data->'tripChecklist','[]'::jsonb)) as trip_checklist
from public.couples c
left join public.profiles p on p.couple_id=c.id
left join public.couple_state cs on cs.couple_id=c.id and cs.key='shared'
group by c.id,c.created_by,c.created_at,cs.updated_at,cs.data
order by cs.updated_at desc nulls last,c.created_at desc;
