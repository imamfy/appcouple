# Excel Office Base v31.6.21

Generator manual murni dihentikan sebagai fondasi paket. Exporter Wedding dan Jalan Berdua sekarang:
1. memuat workbook dasar OOXML lengkap yang dibuat dan dinormalisasi OpenPyXL;
2. menyuntikkan seluruh sheet dinamis tanpa batas baris aplikasi;
3. mempertahankan theme, workbook properties, relationships, styles, dan content types standar Office;
4. menghapus relasi sheet lama sebelum menulis hyperlink baru;
5. memvalidasi CRC32 sebelum mengunduh.

Workbook uji berhasil dibaca OpenPyXL, di-unzip tanpa error, dan dibuka/disimpan ulang LibreOffice Calc.
