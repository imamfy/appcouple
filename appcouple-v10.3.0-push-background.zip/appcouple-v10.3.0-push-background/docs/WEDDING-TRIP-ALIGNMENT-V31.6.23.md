# Wedding & Jalan Berdua Alignment — v31.6.23

## Wedding Command Center
Core app fields now map directly to 12 workbook sheets:
- Dashboard and Ringkasan use the same progress weights as the app.
- Anggaran: category, item/service, status, realization.
- Seserahan: category, item, brand/description, realization.
- Guests: name, side, relationship, invitation type, seats, status; dynamic row count.
- Checklist Wedding: task, owner, due date, status.
- Vendor: category, vendor, contact, budget, paid, remaining, WhatsApp link.
- Savings: target, deadline, date, depositor, amount, note; saved-value fallback.
- Activity and reconciliation are complete.
- Administration KUA remains a separate reference sheet and never overwrites Wedding Checklist.

## Jalan Berdua
Core app fields map to the workbook:
- plan identity, dates, duration, travelers and style;
- budget assumptions, inflation, estimates, actuals, variances and status;
- actual expense ledger, payer and payment method;
- editable itinerary, Maps links and estimated costs;
- readiness checklist with owner, deadline and notes;
- travel savings, cost split, map/memories, activity and reconciliation;
- Reservations and Contact & Health sheets are added only when those shared datasets exist.

## Visual upgrade
- Professional navy/rose/violet visual hierarchy.
- Contextual local Font Awesome-style icons for tabs, metrics and actions.
- New metric icon tiles, refined shadows, glass accents, hover states and dark-mode support.
- Responsive two-column metric cards on mobile.

## QA
- Wedding: 12 sheets, 75 guests exported, no truncation.
- Jalan Berdua: 14 sheets with optional data.
- Both passed ZIP CRC, OpenPyXL load, and strict worksheet child-order checks.
