-- Run AFTER v20, v21, v22 on staging first. No historical payment is rewritten.
begin;
create or replace function public.pay_finance_bill_v29(p_bill_id text,p_due date,p_amount numeric,p_date date,p_revision integer)
returns jsonb language plpgsql security invoker set search_path=public,pg_temp as $$
declare
 uid uuid:=auth.uid(); settings public.finance_settings%rowtype; tx public.transactions%rowtype;
 bill jsonb; paid jsonb; updated_bill jsonb; next_date date; period_start date; anchor integer;
 cid text; matches integer; out_planner jsonb;
begin
 if uid is null then raise exception 'Login diperlukan'; end if;
 if p_bill_id is null or p_due is null or p_date is null or p_revision is null or p_amount is null or p_amount<1 or p_amount>1000000000 or p_amount<>trunc(p_amount) or p_date>(now() at time zone 'Asia/Jakarta')::date then raise exception 'Pembayaran tidak valid'; end if;
 select * into settings from public.finance_settings where user_id=uid for update;
 if not found then raise exception 'Planner belum tersedia. Simpan tagihan terlebih dahulu.'; end if;
 cid:='bill:'||p_bill_id||':'||p_due::text;
 -- Retry after a lost response: return the current authoritative state, not another payment.
 select item into paid from jsonb_array_elements(settings.planner->'paid') item where item->>'clientId'=cid limit 1;
 if found then
  if coalesce((paid->>'skipped')::boolean,false) then raise exception 'Periode sudah dilewati, bukan dibayar.'; end if;
  if (paid->>'amount')::numeric<>p_amount or (paid->>'date')::date<>p_date then raise exception 'Periode sudah dibayar dengan nominal/tanggal berbeda. Muat ulang.'; end if;
  return jsonb_build_object('planner',settings.planner,'revision',settings.planner_revision,'replayed',true);
 end if;
 if settings.planner_revision<>p_revision then raise exception 'Planner berubah di perangkat lain. Muat ulang sebelum membayar.'; end if;
 select count(*) into matches from jsonb_array_elements(settings.planner->'bills') x where x->>'id'=p_bill_id;
 if matches<>1 then raise exception 'Tagihan tidak ditemukan atau ID tidak unik'; end if;
 select x into bill from jsonb_array_elements(settings.planner->'bills') x where x->>'id'=p_bill_id;
 if not coalesce((bill->>'active')::boolean,false) or (bill->>'due')::date<>p_due then raise exception 'Jadwal tagihan berubah. Muat ulang.'; end if;
 select * into tx from public.transactions where user_id=uid and client_id=cid;
 if found then
  if tx.type<>'expense' or tx.amount<>p_amount or tx.date<>p_date then raise exception 'Ada transaksi lama untuk periode ini. Gunakan nominal/tanggal yang sama untuk rekonsiliasi.'; end if;
 else
  insert into public.transactions(user_id,type,description,amount,date,category,note,client_id)
  values(uid,'expense',bill->>'title',p_amount,p_date,bill->>'category','Pembayaran satu periode: '||p_due::text,cid) returning * into tx;
 end if;
 anchor:=least(31,greatest(1,coalesce((bill->>'anchorDay')::integer,extract(day from p_due)::integer)));
 case bill->>'repeat'
 when 'once' then next_date:=null;
 when 'weekly' then next_date:=p_due+7;
 when 'monthly' then
  period_start:=(date_trunc('month',p_due)+interval '1 month')::date;
  next_date:=period_start+least(anchor,extract(day from (period_start+interval '1 month - 1 day'))::integer)-1;
 when 'yearly' then
  period_start:=(date_trunc('month',p_due)+interval '1 year')::date;
  next_date:=period_start+least(anchor,extract(day from (period_start+interval '1 month - 1 day'))::integer)-1;
 else raise exception 'Frekuensi tagihan tidak valid'; end case;
 updated_bill:=case when next_date is null then bill||jsonb_build_object('active',false) else bill||jsonb_build_object('due',next_date::text) end;
 out_planner:=jsonb_set(settings.planner,'{bills}',(select jsonb_agg(case when x->>'id'=p_bill_id then updated_bill else x end order by n) from jsonb_array_elements(settings.planner->'bills') with ordinality as t(x,n)));
 out_planner:=jsonb_set(out_planner,'{paid}',coalesce(out_planner->'paid','[]'::jsonb)||jsonb_build_array(jsonb_build_object('clientId',cid,'transactionId',tx.id,'title',bill->>'title','amount',tx.amount,'date',tx.date::text,'due',p_due::text,'cycles',1)));
 update public.finance_settings set planner=out_planner,planner_revision=planner_revision+1,updated_at=now() where user_id=uid;
 return jsonb_build_object('planner',out_planner,'revision',settings.planner_revision+1,'replayed',false);
end $$;
revoke all on function public.pay_finance_bill_v29(text,date,numeric,date,integer) from public,anon;
grant execute on function public.pay_finance_bill_v29(text,date,numeric,date,integer) to authenticated;
commit;
