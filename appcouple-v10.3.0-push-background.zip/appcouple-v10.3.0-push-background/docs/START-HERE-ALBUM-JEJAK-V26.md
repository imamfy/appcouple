# AppCouple v26 — Album Jejak Cinta

## Dibangun ulang
- Tampilan peta lama diganti dengan Album Jejak Cinta yang lebih tenang dan rapi.
- Desktop memakai dua panel: peta besar dan album foto.
- Mobile memakai susunan vertikal yang dapat digulir tanpa overflow horizontal.
- Kontrol peta dipadatkan, animasi dibuat lembut, dan mode gelap tetap didukung.

## Lokasi user dan partner
- Lokasi live tetap memiliki durasi privasi.
- Saat berbagi live berhenti atau kedaluwarsa, lokasi terakhir mengambil data terbaru dari `location_history`.
- Lokasi terakhir user dan partner tetap ditampilkan sebagai kartu dan pin peta.
- Pengguna hanya dapat menghapus riwayat lokasinya sendiri.

## Kenangan terhubung ke peta
- Google Drive tetap menjadi sumber file Kenangan.
- Album peta menerima data Kenangan dari galeri Drive, bukan tabel memories Supabase.
- Menekan foto album atau pin akan membuka foto, judul, alamat, tanggal, dan cerita.
- Tombol Abadikan Jejak diarahkan ke formulir unggah Kenangan Drive agar tidak membuat penyimpanan foto kedua.

## Alamat wajib saat unggah
1. Pilih foto maksimal 4 MB.
2. Isi alamat lengkap minimal lima karakter.
3. Tekan **Temukan alamat**, atau gunakan GPS lalu lengkapi alamat.
4. Tombol simpan hanya aktif setelah alamat berhasil memiliki koordinat.
5. Setelah tersimpan, foto otomatis memiliki pin yang dapat diklik di Album Jejak Cinta.

Pencarian alamat menggunakan Nominatim/OpenStreetMap dan memerlukan koneksi internet. Kredensial Google Drive v24 tetap diperlukan di Netlify.

## Hasil QA
- Desktop 1440 px: dua panel, tanpa overflow.
- Mobile 390 px: tata letak vertikal, tanpa overflow horizontal.
- Foto album dan pin dapat membuka pratinjau.
- Lokasi user tetap tampil dari riwayat setelah live dihentikan.
- Validasi alamat wajib dan geocoding lulus.
- Seluruh operasi Google Drive tetap lulus; Supabase Storage tidak digunakan untuk Kenangan.
