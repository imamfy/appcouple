# AppCouple 22.0.0 — Budget Control

Paket lengkap lanjutan v21. Fokusnya menutup kekurangan anggaran dan tagihan; bukan deployment produksi atau seluruh roadmap keuangan.

## Urutan pemasangan
1. Backup database, aplikasi lama, dan backup JSON dari aplikasi.
2. Di staging, jalankan UPGRADE-FINANCE-V20.sql (bila belum), lalu v21, kemudian UPGRADE-FINANCE-V22.sql.
3. Uji dengan dua akun dan dua perangkat. Migrasi SQL belum dijalankan pada database produksi oleh asisten.
4. Setelah staging lolos, terapkan migrasi yang sama ke produksi dan deploy isi folder finance-app. Pastikan badge Build 22.0.0.

## Perbaikan anggaran
- Total belanja bulanan kini mencakup semua kategori, bukan hanya kategori yang memiliki batas.
- Menampilkan belanja belum dianggarkan, persentase cakupan, dan kategori tanpa anggaran. Kategori tersebut tetap mengurangi sisa keseluruhan.
- Tombol cepat menambahkan batas untuk kategori yang belum dianggarkan.
- Batas dapat diubah/dihapus; transaksi tidak ikut berubah.
- Salin bulan sebelumnya menyalin batas dan memperbarui kategori yang sama pada bulan target setelah konfirmasi.
- Peringatan 80% dan 100% tetap tersedia. Sisa negatif tampil sebagai kelebihan belanja.
- Pencocokan kategori mengabaikan kapitalisasi, tetapi belum memakai ID kategori permanen; mengganti nama kategori transaksi dapat memisahkan riwayat.
- Anggaran adalah alat perencanaan, bukan dana yang dikunci di rekening.

## Perbaikan tagihan
- Tagihan dapat diubah, dinonaktifkan, dan diaktifkan kembali.
- Pembayaran memakai dialog nominal aktual serta tanggal aktual; tanggal masa depan ditolak.
- Tagihan terlambat menghitung jumlah periode. Setelah pembayaran, jadwal dimajukan ke periode berikutnya setelah hari ini. Satu pembayaran dianggap menyelesaikan semua periode tertinggal yang ditampilkan.
- Tombol Lewati memajukan jadwal tanpa membuat transaksi dan mencatatnya sebagai periode dilewati.
- Nominal pembayaran boleh berbeda dari nominal rencana tanpa mengubah nominal rencana.
- Akhir bulan mempertahankan tanggal jangkar: 31 Januari → 28/29 Februari → 31 Maret. Leap-day tahunan disesuaikan.
- Riwayat menandai apakah transaksi pembayaran masih tersedia, belum dimuat, atau sudah dihapus.
- Retry menggunakan ID pembayaran yang sama. Jika respons transaksi hilang, server v20 mencegah duplikasi; nominal/tanggal riwayat mengambil nilai transaksi yang benar-benar tersimpan.
- Pencatatan transaksi dan pembaruan jadwal masih dua operasi, bukan transaksi database atomik. Jika terjadi kegagalan parsial, muat ulang dan ulangi untuk jatuh tempo yang sama—jangan membuat tagihan baru.
- Tidak ada pembayaran bank otomatis atau pengingat push ketika aplikasi tertutup.

## Database dan audit
- v22 menambah validasi server untuk struktur/nilai planner serta batas jumlah elemen.
- Perubahan planner di finance_settings dicatat ke finance_audit milik pengguna.
- Constraint dibuat NOT VALID agar data lama tidak langsung menghambat migrasi, tetapi write baru diperiksa.
- Tetap tinjau kebijakan RLS tambahan di proyek; policy permisif lain dapat memperluas akses.

## Pengujian lokal
- Belanja Rp1,67 juta dengan anggaran Kebutuhan Rp2 juta menunjukkan Rp420 ribu belum dianggarkan, sisa keseluruhan Rp330 ribu, cakupan 75%.
- Setelah batas Transportasi Rp500 ribu, belanja tanpa anggaran menjadi nol dan sisa Rp830 ribu.
- Tagihan terlambat empat periode dapat diedit, dibayar dengan nominal aktual, dimajukan sampai periode berikutnya, dilewati, dinonaktifkan, dan dipulihkan.
- Reload mempertahankan planner; kalender, tanggal bayar masa depan, mobile 390px tanpa overflow, dan pageerror diuji.
- Pengujian SQL/RLS produksi belum dilakukan. Staging tetap wajib.

## Masih belum tersedia
Multi-dompet, saldo awal/transfer internal, cicilan piutang yang masuk jurnal, rekonsiliasi bank, impor mutasi dengan deduplikasi, pembayaran bank otomatis, push reminder background, restore JSON otomatis, dan kategori berbasis ID. Planner masih satu dokumen JSON per akun; batas server mencegah pertumbuhan tak terbatas, tetapi arsitektur tabel terpisah lebih baik untuk skala sangat besar.
