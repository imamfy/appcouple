# AppCouple 20.0.0 — Finance Integrity

Paket berbasis v19.1, mempertahankan Kenangan, Sydas adaptive theme/grid mobile, login fix, dan fitur lainnya. Rilis ini memperbaiki fondasi keuangan, BUKAN menyelesaikan seluruh roadmap fitur keuangan.

## Sebelum digunakan pada akun asli
1. Backup database Supabase dan simpan paket aplikasi v19.1 untuk rollback frontend.
2. Di proyek uji/staging yang memakai skema yang sama, jalankan **UPGRADE-FINANCE-V20.sql**. Jangan menjalankan ulang SUPABASE-SETUP-CURRENT.sql sesudah migrasi ini: kebijakan lamanya dapat mengembalikan izin ringkasan yang lebih luas.
3. Tinjau kebijakan RLS lain yang sudah ada. Kebijakan permisif tambahan dapat mengalahkan pembatasan kebijakan baru. Uji sebagai dua akun berbeda, bukan hanya sebagai administrator.
4. Uji tambah/edit/hapus transaksi, retry offline, perubahan akun, piutang, dan dua setoran bersama bersamaan. Pastikan audit tercatat.
5. Setelah staging lolos, terapkan migrasi yang sama ke produksi lalu deploy isi folder finance-app ke hosting. Migrasi belum dijalankan oleh asisten pada database produksi.
6. Buka aplikasi dan pastikan badge 20.0.0. Tutup tab lama, muat ulang. Jangan menghapus seluruh penyimpanan situs bila ada antrean offline yang belum dicadangkan.

## Fitur yang diterapkan
- Pemisahan cache/antrean per akun; demo terpisah.
- Antrean transaksi ditulis sebelum upaya simpan; retry memakai identitas yang sama. Indeks unik SQL mencegah duplikasi. Tombol Sinkronkan dan status tertunda.
- Data lama tanpa pemilik tidak dimigrasikan otomatis. Tombol **Ekspor data lokal lama** mengunduh salinan untuk diperiksa pemiliknya. Jangan memasukkan ulang sebelum mengecek apakah transaksi sudah ada di server.
- Riwayat server dimuat bertahap 500 per permintaan sampai habis, bukan dibatasi 500 total. Piutang tidak dibatasi 200 total. Untuk jutaan baris, agregasi server/ledger masih disarankan.
- Pencarian transaksi, muat berikutnya, edit/hapus dengan konfirmasi, pembaruan saldo/laporan.
- File migrasi menambahkan audit insert/update/delete transaksi dan piutang. Audit baru dimulai setelah migrasi; belum ada panel penampil audit di aplikasi.
- Periode laporan 14 hari, minggu berjalan, 12 bulan bergulir sampai hari ini, tahun berjalan, dan rentang khusus. Grafik/kartu/daftar memakai cakupan sama. Pembanding adalah rentang sebelumnya dengan jumlah hari sama.
- Grafik saldo memasukkan saldo awal dari transaksi sebelum periode. Saldo tetap saldo pembukuan, bukan saldo rekening bank terverifikasi.
- Rasio negatif tidak ditutupi dengan nol. Rasio tanpa pemasukan ditandai tidak tersedia pada laporan.
- Validasi Rupiah bulat Rp1–Rp1 miliar dan tanggal nyata, tanpa tanggal transaksi masa depan. Jadwal transaksi belum tersedia.
- Tanggal default transaksi/baca struk memakai WIB; minggu Excel Senin–Minggu tidak bergeser ke UTC.
- Cakupan Excel mengikuti periode/filter atau seluruh data yang dimuat. Formula total per periode terhubung ke sheet Transaksi untuk periode yang sudah terbentuk.
- Backup JSON berisi transaksi, piutang, rencana, antrean, waktu ekspor dan pemilik. Simpan privat: berisi informasi finansial. Restore otomatis belum tersedia.
- Smart Payday membatasi sisa rencana dengan saldo aktual dikurangi cadangan, membedakan rencana belum mulai, dan mengecualikan ID transaksi lama untuk rencana baru. Buat ulang rencana lama untuk memakai model baseline baru.
- Retry piutang mempertahankan ID; cache piutang terpisah akun. Tombol Sinkronkan mencoba ulang catatan tertunda.
- Setoran bersama memakai fungsi database dengan row lock agar dua pembaruan bersamaan tidak saling menimpa. Riwayat setoran baru tidak dipotong 100 item. Fungsi ini memerlukan migrasi; tidak ada fallback ke cara lama yang tidak atomik. Bonus poin setoran belum diberikan oleh fungsi baru.
- Ringkasan pasangan dapat dibaca anggota, tetapi penulisan dibatasi pemilik dalam migrasi.
- Persetujuan sebelum mengirim gambar ke Gemini; batal memakai OCR perangkat. OCR tidak lagi mengambil nominal terbesar dari seluruh teks tanpa baris total yang cocok.

## Belum tersedia / batasan yang perlu diketahui
- Multi-dompet, saldo awal khusus, transfer internal dan rekonsiliasi bank. Jalur transfer lama diblokir agar tidak diam-diam tercatat sebagai belanja.
- Piutang masih catatan terpisah: belum ada pembayaran parsial, cicilan, atau jurnal pencairan/pelunasan otomatis.
- Tabungan bersama belum terhubung ke jurnal transaksi pribadi, belum ada penarikan atau rekonsiliasi, dan idempotensi retry setoran bersama belum diterapkan. Jika respons setoran terputus, periksa riwayat terlebih dahulu sebelum mencoba lagi.
- Anggaran per kategori, transaksi/tagihan berulang, pengingat terjadwal, impor bank dengan deduplikasi, dan restore JSON otomatis.
- Tidak ada migrasi saldo awal otomatis atau koreksi data historis. Data lama invalid tidak ditulis ulang; constraint baru NOT VALID memeriksa write baru.
- Snapshot Excel: kategori/jumlah transaksi/label tidak semuanya dinamis; menambah periode/kategori baru di workbook tidak otomatis membentuk baris ringkasan baru. Ekspor ulang setelah perubahan. Saldo berjalan Excel dimulai nol untuk cakupan ekspor.
- LocalStorage terpisah secara logis per akun, bukan penyimpanan terenkripsi. Jangan berbagi profil browser untuk data sensitif.
- Snapshot pagination bukan transaksi database tunggal; saat volume sangat besar dan banyak update bersamaan, gunakan agregasi/snapshot server sebagai tahap selanjutnya.

## Pengujian
- Uji fungsi: kalender WIB, Senin/Minggu, tanggal invalid, periode konsisten, isolasi key akun, deduplikasi, nominal nol.
- Backend mock: 1.201 baris terbaca; respons hilang setelah commit lalu retry hanya menghasilkan satu transaksi; retry piutang satu baris.
- Browser demo: halaman keuangan, edit, saldo negatif, laporan minggu/rentang khusus, mobile 390x844 dan desktop 1440x900.
- XLSX: file dibuka dengan openpyxl, enam sheet, label minggu 07–13 Sep 2026, formula SUMIFS.
- Bukan uji Supabase produksi. SQL belum dieksekusi pada PostgreSQL di lingkungan ini. Login, RLS aktual, realtime produksi, bank, dan provider AI eksternal perlu uji staging.
