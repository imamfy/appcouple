-- AppCouple Maps 2026 · location history retention
-- Apply once in Supabase SQL Editor.
-- Keeps at most one rolling 24-hour location-history row per user.

begin;

delete from public.location_history
where created_at < now() - interval '24 hours';

with ranked as (
  select id,
         row_number() over (
           partition by couple_id, user_id
           order by created_at desc, id desc
         ) as row_rank
  from public.location_history
)
delete from public.location_history h
using ranked r
where h.id = r.id and r.row_rank > 1;

create or replace function public.appcouple_location_history_24h_guard()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  delete from public.location_history
  where created_at < now() - interval '24 hours';

  if tg_op = 'INSERT' then
    delete from public.location_history
    where couple_id = new.couple_id
      and user_id = new.user_id
      and created_at >= now() - interval '24 hours';
  end if;

  return new;
end;
$$;

drop trigger if exists location_history_24h_guard on public.location_history;
create trigger location_history_24h_guard
before insert on public.location_history
for each row execute function public.appcouple_location_history_24h_guard();

commit;

-- Optional when pg_cron is enabled. The app and trigger already clean up on use.
-- select cron.schedule(
--   'appcouple-location-history-24h',
--   '15 * * * *',
--   $$delete from public.location_history where created_at < now() - interval '24 hours'$$
-- );
