-- Run AFTER v20 and v21 migrations. Test on staging first.
-- Adds planner auditing and stricter server-side planner validation.
begin;
create or replace function public.finance_planner_valid_v22(value jsonb) returns boolean
language sql immutable set search_path=public,pg_temp as $$
 select jsonb_typeof(value)='object'
 and jsonb_typeof(value->'budgets')='array'
 and jsonb_typeof(value->'bills')='array'
 and jsonb_typeof(value->'paid')='array'
 and jsonb_array_length(value->'budgets')<=2400
 and jsonb_array_length(value->'bills')<=1000
 and jsonb_array_length(value->'paid')<=10000
 and not exists(select 1 from jsonb_array_elements(value->'budgets') x where
   jsonb_typeof(x)<>'object' or coalesce(x->>'id','')='' or coalesce(x->>'category','')='' or
   coalesce(x->>'month','')!~'^\d{4}-(0[1-9]|1[0-2])$' or
   coalesce((x->>'limit')::numeric,0)<=0 or coalesce((x->>'limit')::numeric,0)>1000000000)
 and not exists(select 1 from jsonb_array_elements(value->'bills') x where
   jsonb_typeof(x)<>'object' or coalesce(x->>'id','')='' or coalesce(x->>'title','')='' or
   coalesce(x->>'category','')='' or coalesce(x->>'due','')!~'^\d{4}-(0[1-9]|1[0-2])-([0-2][0-9]|3[01])$' or
   coalesce(x->>'repeat','') not in ('once','weekly','monthly','yearly') or
   coalesce((x->>'amount')::numeric,0)<=0 or coalesce((x->>'amount')::numeric,0)>1000000000)
$$;
revoke all on function public.finance_planner_valid_v22(jsonb) from public;
grant execute on function public.finance_planner_valid_v22(jsonb) to authenticated;

do $$ begin
 if not exists(select 1 from pg_constraint where conname='finance_planner_values_v22' and conrelid='public.finance_settings'::regclass) then
  alter table public.finance_settings add constraint finance_planner_values_v22 check(public.finance_planner_valid_v22(planner)) not valid;
 end if;
end $$;

create or replace function public.capture_finance_planner_audit_v22() returns trigger
language plpgsql security definer set search_path=public,pg_temp as $$
begin
 if TG_OP='INSERT' or OLD.planner is distinct from NEW.planner then
  insert into public.finance_audit(user_id,actor_id,entity,entity_id,operation,old_data,new_data)
  values(NEW.user_id,auth.uid(),'finance_planner',NEW.user_id,TG_OP,
   case when TG_OP='UPDATE' then jsonb_build_object('planner',OLD.planner,'revision',OLD.planner_revision) else null end,
   jsonb_build_object('planner',NEW.planner,'revision',NEW.planner_revision));
 end if;
 return NEW;
end $$;
revoke all on function public.capture_finance_planner_audit_v22() from public;
drop trigger if exists finance_planner_audit_v22 on public.finance_settings;
create trigger finance_planner_audit_v22 after insert or update on public.finance_settings
for each row execute function public.capture_finance_planner_audit_v22();
commit;
