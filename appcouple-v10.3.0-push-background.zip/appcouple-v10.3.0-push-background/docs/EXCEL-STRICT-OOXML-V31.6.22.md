# Excel strict OOXML fix v31.6.22

Penyebab file ditolak Microsoft Excel ditemukan pada urutan elemen worksheet. Exporter lama menulis `mergeCells` sebelum `autoFilter`, sedangkan skema OOXML Microsoft mengharuskan `autoFilter` lebih dahulu.

Urutan telah diperbaiki pada exporter Wedding dan Jalan Berdua:
`sheetData → autoFilter → mergeCells → dataValidations → hyperlinks → pageMargins`.

QA tambahan memeriksa urutan seluruh child worksheet terhadap urutan skema, selain OpenPyXL, CRC32, dan unzip.
