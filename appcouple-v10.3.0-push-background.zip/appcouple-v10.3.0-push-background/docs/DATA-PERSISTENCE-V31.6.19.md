# AppCouple v31.6.19 — Shared Data Persistence

## Yang diperbaiki
- Baris `couple_state/shared` dibuat otomatis segera setelah pasangan berhasil terhubung.
- Koneksi pasangan tidak lagi menghapus ruang lama; data lama tidak terkena cascade delete.
- Poin Hadiah, Wedding Command Center, Celengan, dan Jalan Berdua dicadangkan ke `localStorage` berdasarkan dua UID pasangan (bukan hanya `couple_id`).
- Jika pasangan yang sama terhubung kembali dan baris server kosong, snapshot pasangan dipulihkan tanpa menimpa data server yang sudah berisi.
- Wedding Planner selalu menyimpan salinan lokal sebelum sinkron ke Supabase.
- Jalan Berdua dapat menemukan bundle lokal dari `couple_id` lama dan meminta pengguna menyinkronkannya.
- Cache rilis dinaikkan supaya browser mengambil JavaScript terbaru.

## Cara memastikan data tersimpan
1. Deploy seluruh isi paket, bukan hanya satu file.
2. Buka aplikasi dan login ulang pada kedua akun.
3. Pastikan status pasangan sudah terhubung.
4. Ubah satu data lalu tunggu status `Tersinkron ke partner` / `Tersimpan bersama`.
5. Reload kedua perangkat dan periksa data yang sama.

## Catatan pemulihan
Perbaikan ini mencegah kehilangan berikutnya dan memulihkan cadangan yang masih ada di browser untuk pasangan yang sama. Data historis yang sudah terhapus dari Supabase dan tidak memiliki cadangan lokal hanya dapat dikembalikan melalui Supabase Database Backup/PITR.
