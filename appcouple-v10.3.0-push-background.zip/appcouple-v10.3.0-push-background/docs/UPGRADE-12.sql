-- Apply after SUPABASE-SETUP-CURRENT.sql. No service-role key in frontend.
create table if not exists public.ai_permissions (
 user_id uuid primary key references auth.users(id) on delete cascade,
 finance boolean not null default false, memory boolean not null default false,
 media boolean not null default false, updated_at timestamptz not null default now()
);
alter table public.ai_permissions enable row level security;
drop policy if exists ai_permissions_owner on public.ai_permissions;
create policy ai_permissions_owner on public.ai_permissions for all to authenticated using (user_id=auth.uid()) with check (user_id=auth.uid());
grant select,insert,update,delete on public.ai_permissions to authenticated;
revoke all on public.ai_permissions from anon;
create table if not exists public.ai_request_quota (user_id uuid references auth.users(id) on delete cascade, window_start timestamptz, used integer not null, primary key(user_id,window_start));
alter table public.ai_request_quota enable row level security;
revoke all on public.ai_request_quota from anon, authenticated;
create or replace function public.consume_ai_request() returns boolean language plpgsql security definer set search_path=public as $$
declare n integer; u uuid:=auth.uid(); w timestamptz:=date_trunc('hour',now());
begin
 if u is null then return false; end if;
 insert into public.ai_request_quota values(u,w,1) on conflict(user_id,window_start) do update set used=ai_request_quota.used+1 where ai_request_quota.used<20 returning used into n;
 return n is not null;
end $$;
revoke all on function public.consume_ai_request() from public,anon;
grant execute on function public.consume_ai_request() to authenticated;
